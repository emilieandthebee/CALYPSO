using System;
using System.Collections;
using Server;
using Server.Items;
using Server.ContextMenus;

namespace Server.Mobiles
{
	public class PostalWorker : BaseVendor
	{
		private ArrayList m_SBInfos = new ArrayList();
		protected override ArrayList SBInfos{ get { return m_SBInfos; } }

		public override NpcGuild NpcGuild{ get{ return NpcGuild.MerchantsGuild; } }

		[Constructable]
		public PostalWorker() : base( "the Postal Worker" )
		{
		}

		public override void InitSBInfo()
		{
			m_SBInfos.Add( new SBPostalWorker() );
		}

		public override VendorShoeType ShoeType
		{
			get{ return Utility.RandomBool() ? VendorShoeType.Shoes : VendorShoeType.Boots; }
		}

		public override void InitOutfit()
		{
			base.InitOutfit();
			
			AddItem( new  Robe( Utility.RandomBlueHue() ) );
		}

		public PostalWorker( Serial serial ) : base( serial )
		{
		}
		
		public override void AddCustomContextEntries( Mobile from, ArrayList list )
		{
			if ( from.Alive )
				list.Add( new OpenMailEntry( from, this ) );

			base.AddCustomContextEntries( from, list );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
