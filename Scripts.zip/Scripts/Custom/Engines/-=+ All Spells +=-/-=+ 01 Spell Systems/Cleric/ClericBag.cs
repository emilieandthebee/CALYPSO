using System;
using Server;

namespace Server.Items
{
	public class ClericBag : Bag
	{
		[Constructable]
		public ClericBag()
		{
			PlaceItemIn( 30, 35, new AngelicFaithScroll() );
			PlaceItemIn( 50, 35, new BanishEvilScroll() );
			PlaceItemIn( 70, 35, new DampenSpiritScroll() );
			PlaceItemIn( 90, 35, new DivineFocusScroll() );
			PlaceItemIn( 30, 55, new HammerOfFaithScroll() );
			PlaceItemIn( 50, 55, new PurgeScroll() );
			PlaceItemIn( 70, 55, new RestorationScroll() );
			PlaceItemIn( 90, 55, new SacredBoonScroll() );
			PlaceItemIn( 30, 75, new SacrificeScroll() );
			PlaceItemIn( 50, 75, new SmiteScroll() );
			PlaceItemIn( 70, 75, new TouchOfLifeScroll() );
			PlaceItemIn( 90, 75, new TrialByFireScroll() );
		}

		private void PlaceItemIn( int x, int y, Item item )
		{
			AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public ClericBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}