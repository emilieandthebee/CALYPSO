using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class Anim
	{
		public static void Initialize()
		{
			Server.Commands.Register( "Anim", AccessLevel.Player, new CommandEventHandler( Anim_OnCommand ) );
		}

		[Usage( "Anim <numero de l'animation>" )]
		[Description( "Anime votre personnage (ceci est une commande roleplay)." )]
		private static void Anim_OnCommand( CommandEventArgs e )
		{
			string toSay = e.ArgString.Trim();			
			if( toSay.Length > 0 )
			{
				int action=(int)e.GetInt32( 0 );;
				e.Mobile.Animate( action, 5, 1, true, false, 0 );
			}
		}
	}
}