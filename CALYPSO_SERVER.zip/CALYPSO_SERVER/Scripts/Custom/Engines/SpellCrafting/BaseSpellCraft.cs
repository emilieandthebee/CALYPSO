using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.SpellCrafting.Items
{
	public class BaseSpellCraft : Item
	{
		private int m_CraftID;

		[CommandProperty( AccessLevel.GameMaster )]
		public int CraftID
		{
			get { return m_CraftID; } 
			set { m_CraftID = value; InvalidateProperties(); }
		}

		public BaseSpellCraft( int amount, int craft ) : base( 0xF26 )
		{
			Name = "Spellcraft Jewel";
			Stackable = false;
			Weight = 0.1;
			Amount = amount;
			CraftID = craft;
		}

		public BaseSpellCraft( Serial serial ) : base( serial )
		{
		}

		public override void GetProperties( ObjectPropertyList list )
		{
			base.GetProperties(list);

			if ( m_CraftID > 46 )
				list.Add( 1050045," \tNon Aos Only Craft\t " );

			if ( m_CraftID == 0 )
				list.Add( 1050045," \tStrength Bonus\t " );

			if ( m_CraftID == 1 )
				list.Add( 1050045," \tDexterity Bonus\t " );

			if ( m_CraftID == 2 )
				list.Add( 1050045," \tIntelligence Bonus\t " );

			if ( m_CraftID == 3 )
				list.Add( 1050045," \tHit Point Bonus\t " );

			if ( m_CraftID == 4 )
				list.Add( 1050045," \tStamina Bonus\t " );

			if ( m_CraftID == 5 )
				list.Add( 1050045," \tMana Bonus\t " );

			if ( m_CraftID == 6 )
				list.Add( 1050045," \tPhysical Resist Bonus\t " );

			if ( m_CraftID == 7 )
				list.Add( 1050045," \tFire Resist Bonus\t " );

			if ( m_CraftID == 8 )
				list.Add( 1050045," \tCold Resist Bonus\t " );

			if ( m_CraftID == 9 )
				list.Add( 1050045," \tPoison Resist Bonus\t " );

			if ( m_CraftID == 10 )
				list.Add( 1050045," \tEnergy Resist Bonus\t " );

			if ( m_CraftID == 11 )
				list.Add( 1050045," \tHit Point Rengeration\t " );

			if ( m_CraftID == 12 )
				list.Add( 1050045," \tMana Regeneration\t " );

			if ( m_CraftID == 13 )
				list.Add( 1050045," \tStamina Regeneration\t " );

			if ( m_CraftID == 14 )
				list.Add( 1050045," \tFaster Cast Recovery\t " );

			if ( m_CraftID == 15 )
				list.Add( 1050045," \tFaster Cast Speed\t " );

			if ( m_CraftID == 16 )
				list.Add( 1050045," \tLower Mana Cost\t " );

			if ( m_CraftID == 17 )
				list.Add( 1050045," \tLower Reagent Cost\t " );

			if ( m_CraftID == 18 )
				list.Add( 1050045," \tMage Armor\t " );

			if ( m_CraftID == 19 )
				list.Add( 1050045," \tMage Weapon\t " );

			if ( m_CraftID == 20 )
				list.Add( 1050045," \tSpell Channeling\t " );

			if ( m_CraftID == 21 )
				list.Add( 1050045," \tSpell Damage Increase\t " );

			if ( m_CraftID == 22 )
				list.Add( 1050045," \tHit Cold Area\t " );

			if ( m_CraftID == 23 )
				list.Add( 1050045," \tHit Energy Area\t " );

			if ( m_CraftID == 24 )
				list.Add( 1050045," \tHit Fire Area\t " );

			if ( m_CraftID == 25 )
				list.Add( 1050045," \tHit Physical Area\t " );

			if ( m_CraftID == 26 )
				list.Add( 1050045," \tHit Poison Area\t " );

			if ( m_CraftID == 27 )
				list.Add( 1050045," \tHit Dispel\t " );

			if ( m_CraftID == 28 )
				list.Add( 1050045," \tHit Fireball\t " );

			if ( m_CraftID == 29 )
				list.Add( 1050045," \tHit Harm\t " );

			if ( m_CraftID == 30 )
				list.Add( 1050045," \tHit Lightning\t " );

			if ( m_CraftID == 31 )
				list.Add( 1050045," \tHit Magic Arrow\t " );

			if ( m_CraftID == 32 )
				list.Add( 1050045," \tHit Lower Attack\t " );

			if ( m_CraftID == 33 )
				list.Add( 1050045," \tHit Lower Defense\t " );

			if ( m_CraftID == 34 )
				list.Add( 1050045," \tHit Leech Hits\t " );

			if ( m_CraftID == 35 )
				list.Add( 1050045," \tHit Leech Mana\t " );

			if ( m_CraftID == 36 )
				list.Add( 1050045," \tHit Leech Stamina\t " );

			if ( m_CraftID == 37 )
				list.Add( 1050045," \tUse Best Weapon Skill\t " );

			if ( m_CraftID == 38 )
				list.Add( 1050045," \tWeapon Damage Increase\t " );

			if ( m_CraftID == 39 )
				list.Add( 1050045," \tSwing Speed Increase\t " );

			if ( m_CraftID == 40 )
				list.Add( 1050045," \tHit Chance Increase\t " );

			if ( m_CraftID == 41 )
				list.Add( 1050045," \tDefense Chance Increase\t " );

			if ( m_CraftID == 42 )
				list.Add( 1050045," \tEnhance Potions\t " );

			if ( m_CraftID == 43 )
				list.Add( 1050045," \tLower Stat Requirements\t " );

			if ( m_CraftID == 44 )
				list.Add( 1050045," \tLuck\t " );

			if ( m_CraftID == 45 )
				list.Add( 1050045," \tReflect Physical\t " );

			if ( m_CraftID == 46 )
				list.Add( 1050045," \tSelf Repair\t " );
		}

		public override void OnSingleClick( Mobile from )
		{
			string prop = "";

			if ( m_CraftID < 47 )
				prop = "Aos Only Craft";

			if ( m_CraftID == 47 )
				prop = "Durable";

			if ( m_CraftID == 48 )
				prop = "Substantial";

			if ( m_CraftID == 49 )
				prop = "Massive";

			if ( m_CraftID == 50 )
				prop = "Fortified";

			if ( m_CraftID == 51 )
				prop = "Indestructible";

			if ( m_CraftID == 52 )
				prop = "Ruin";

			if ( m_CraftID == 53 )
				prop = "Might";

			if ( m_CraftID == 54 )
				prop = "Force";

			if ( m_CraftID == 55 )
				prop = "Power";

			if ( m_CraftID == 56 )
				prop = "Vanquishing";

			if ( m_CraftID == 57 )
				prop = "Accurate";

			if ( m_CraftID == 58 )
				prop = "Surpassingly Accurate";

			if ( m_CraftID == 59 )
				prop = "Eminently Accurate";

			if ( m_CraftID == 60 )
				prop = "Exceedingly Accurate";

			if ( m_CraftID == 61 )
				prop = "Supremely Accurate";

			if ( m_CraftID == 62 )
				prop = "Defense";

			if ( m_CraftID == 63 )
				prop = "Guarding";

			if ( m_CraftID == 64 )
				prop = "Hardening";

			if ( m_CraftID == 65 )
				prop = "Fortification";

			if ( m_CraftID == 66 )
				prop = "Invulnerability";

			this.LabelTo( from, "Spellcraft Jewel : {0}", prop );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
			writer.Write( m_CraftID );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			m_CraftID = reader.ReadInt();
		}
	}
}