using System;
using Server;
using Server.Gumps;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Targeting;
using System.Collections;
using Server.Scripts.Commands;
using Server.Prompts;
using Server.Guilds;

namespace Server.Gumps
{
    public class VoteMiniGM : Gump
    {
		Accounting.Account acct=null;
		
        public VoteMiniGM(Mobile Requester) : base( 50, 200 )
        {
            this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			
			string text="QUELQU'UN";
			if (Requester is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)Requester;
				acct = pm.Account as Accounting.Account;
				text = acct.Username;
			}
		
			AddPage(0);
			AddBackground(5, 4, 148, 91, 9200);
			AddPage(1);
			AddLabel(9, 10, 2057, text);
			AddButton(14, 64, 9904, 9903, (int)Buttons.YES, GumpButtonType.Reply, 0);
			AddLabel(37, 66, 1271, @"OUI?");
			AddLabel(8, 26, 2057, @"se propose en tant que");
			AddLabel(7, 42, 2057, @"mini Maitre de Jeu");
			AddButton(84, 65, 9904, 9903, (int)Buttons.NO, GumpButtonType.Reply, 0);
			AddLabel(107, 67, 1259, @"NON?");
        }

        public enum Buttons
		{
			YES,
			NO
		}

        public override void OnResponse(NetState sender, RelayInfo info)
        {
            Mobile from = sender.Mobile;
            switch(info.ButtonID)
            {
                case (int)Buttons.YES:
				{
					if (ShardControler.TheShardControlerStone != null)
						ShardControler.TheShardControlerStone.GMPollYes++;
					break;
				}
                case (int)Buttons.NO:
				{
					if (ShardControler.TheShardControlerStone != null)
						ShardControler.TheShardControlerStone.GMPollNo++;
					break;
				}
				default:
					break;
			}
        }
    }
}