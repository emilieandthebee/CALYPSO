using System;
using System.Collections;
/*2.0*
using System.Collections.Generic;
******/
using Server.Items;

namespace Server.Mobiles
{
	public class APS_SBAlchemist : SBInfo
	{
/*2.0*
		private List<GenericBuyInfo> m_BuyInfo = new InternalBuyInfo();
*1.0*/
		private ArrayList m_BuyInfo = new InternalBuyInfo(); 
/****/
		private IShopSellInfo m_SellInfo = new InternalSellInfo();

		public APS_SBAlchemist()
		{
		}

		public override IShopSellInfo SellInfo { get { return m_SellInfo; } }
/*2.0*
		public override List<GenericBuyInfo> BuyInfo { get { return m_BuyInfo; } }
*1.0*/
		public override ArrayList BuyInfo { get { return m_BuyInfo; } }
/****/
		public class InternalBuyInfo : ArrayList
		{
			public InternalBuyInfo()
			{
				
				// Add( new GenericBuyInfo( <name>, typeof( <class> ), <price>, <quantity>, <ItemID>, <Hue> ) );
				
				Add( new GenericBuyInfo( "mortier",typeof( APS_Mortier ), 33, 3, 0xE9B, 0 ) );
				Add( new GenericBuyInfo( "erlenmeyer",typeof( APS_Erlenmeyer ), 20, 4, 6189, 0 ) );
				Add( new GenericBuyInfo( "fiole a vide",typeof( APS_FioleAVide ), 20, 4, 6194, 0 ) );
				Add( new GenericBuyInfo( "melangeur",typeof( APS_Melangeur ), 20, 4, 6205, 0 ) );
				Add( new GenericBuyInfo( "longue vue",typeof( APS_LongueVue ), 24, 3, 0x14F5, 0 ) );
				Add( new GenericBuyInfo( "bruleur",typeof( APS_Bruleur ), 16, 3, 6217, 0 ) );
			
				int PotionSellingPrice  = 15;
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Potion ),    PotionSellingPrice, 10, 3854, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3835 ), PotionSellingPrice, 2, 3835, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3836 ), PotionSellingPrice, 2, 3836, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3837 ), PotionSellingPrice, 2, 3837, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3838 ), PotionSellingPrice, 2, 3838, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3839 ), PotionSellingPrice, 2, 3839, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3840 ), PotionSellingPrice, 2, 3840, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3841 ), PotionSellingPrice, 2, 3841, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3842 ), PotionSellingPrice, 2, 3842, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3843 ), PotionSellingPrice, 2, 3843, 0 ) );
				Add( new GenericBuyInfo( "fiole vide",typeof( APS_Fiole3844 ), PotionSellingPrice, 2, 3844, 0 ) );
				
				Add( new GenericBuyInfo( "tonnelet",typeof( APS_Tonnelet ), 45, 1, 0x1940, 0 ) );
				Add( new GenericBuyInfo( "tonnelet",typeof( APS_Chaudron ), 45, 1, 2541, 0 ) );
				
			}
		}

		public class InternalSellInfo : GenericSellInfo
		{
			public InternalSellInfo()
			{
			}
		}
	}
}
