using System;
using Server;
using Server.Spells;

namespace Server.Spells.Undead
{
	public class UndeadInitializer
	{
		public static void Initialize()
		{
			if( Core.AOS )
			{
				Register( 116, typeof( PoisonMarkSpell ) );
				Register( 117, typeof( TravelByPoisonSpell ) );
				Register( 118, typeof( CurePoisonSpell ) );
				Register( 119, typeof( NecroPoisonFieldSpell ) );
				Register( 120, typeof( GraveyardGatewaySpell ) );
				Register( 121, typeof( RevivalBySeanceSpell ) );
				Register( 122, typeof( HordeMinionsEyesSpell ) );
				Register( 123, typeof( WallOfSpikesSpell ) );
				Register( 124, typeof( PoisonIvyPatchSpell ) );
				Register( 125, typeof( BloodPactSpell ) );
				Register( 126, typeof( NecroPoisonSpell ) );
				Register( 127, typeof( NecroMassCurseSpell ) );
				Register( 128, typeof( MisfitsOfMondainSpell ) );

				//RegDef( spellID, "Name", "Description", "Reagent1; Reagent2; Reagentn", "Skill; Mana; Tithe; Etc" );
				RegDef( 116, "Poison Mark",         "The Necromancer uses this spell to mark runes for travel.", "Daemon Blood; Pig Iron", "Skill: 60; Mana: 30" );
				RegDef( 117, "Travel By Poison",    "The Necromancer uses this spell to travel with the use of a marked rune.", "Bat Wing; Nox Crystal", "Skill: 40; Mana: 11" );
				RegDef( 118, "Cure Poison",         "Cures most poisons on anyone targeted by this spell.", "Nox Crystal; Pig Iron", "Skill: 15; Mana: 20" );
				RegDef( 119, "Poison Field",        "Produces a wall of poison that will poison just about anything that walks through it.", "Bat Wing; Nox Crystal; Pig Iron", "Skill: 45; Mana: 20" );
				RegDef( 120, "Graveyard Gateway",   "Produces a moongate from the use of a marked rune used for travel.", "Daemon Blood; Bat Wing; Grave Dust", "Skill: 70; Mana: 45" );
				RegDef( 121, "Revival By Seance",   "Resurrects person of choice by the use of a Ouija board.", "Nox Crystal; Daemon Blood; Grave Dust", "Skill: 90; Mana: 55" );
				RegDef( 122, "Horde Minion's Eyes", "Grants the target the eyes of a horde minion for superior vision to see at night.", "Bat Wing; Nox Crystal", "Skill: 15; Mana: 5" );
				RegDef( 123, "Wall Of Spikes",      "Summons a wall of stone spikes as a shield.", "Daemon Blood; Pig Iron", "Skill: 24; Mana: 10" );
				RegDef( 124, "Poison Ivy Patch",    "Forms a circle of poison ivy that causes damage & the ability to poison when walked on.", "Grave Dust; Nox Crystal; Pig Iron", "Skill: 68; Mana: 28" );
				RegDef( 125, "Blood Pact",          "Heals a person of choice draining health & blood from the Necromancer.", "Bat Wing; Pig Iron", "Skill: 33; Mana: 15" );
				RegDef( 126, "Poison",              "Poison's the slected target.", "Nox Crystal; Daemon Blood", "Skill: 30; Mana: 20" );
				RegDef( 127, "Mass Curse",          "Lowers the nearby enemeies abilities in combat.", "Bat Wing; Grave Dust; Daemon Blood; Nox Crystal", "Skill: 65; Mana: 25" );
				RegDef( 128, "Misfits Of Mondain",  "Summons creatures of the undead to aid in battle.", "Bat Wing; Grave Dust; Nox Crystal", "Skill: 37; Mana: 30" );
			}
		}
		public static void Register( int spellID, Type type )
		{
			SpellRegistry.Register( spellID, type );
		}
		public static void RegDef( int spellID, string name, string des, string regs, string inf )
		{
			SpellDefRegistry.Register( spellID, name, des, regs, inf );
		}
	}
}