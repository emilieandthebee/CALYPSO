/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items
{
	[Flipable( 6194 , 6197 )]
	public class APS_FioleAVide : Item
	{
		
/********************
Fiole à vide
6194 Gauche VIDE
6195 Gauche Rouge
6196 Gauche Turquoise
6197 Droite VIDE
6198 Droite Bleu
6199 Droite Vert
*********************/
	
		[CommandProperty( AccessLevel.GameMaster )]
		public virtual string CurrentFormula
		{
			get { return Formula; }
			set { Formula = value; }
		}
		public string Formula;
		public int ReagentsCount;

		public override void OnDoubleClick( Mobile from )
		{ if ( Utility.RandomDouble() < APS_Mortier.APS_ChanceToBreak )
			{
				from.SendMessage("Oups... ça s'est cassé...");
				Delete();
				return;
			}
		  from.SendMessage("Selectionnez quelquechose que vous voulez mettre dedans.");
		  from.Target = new InternalTarget( this ); }
		private class InternalTarget : Target
		{
			private APS_FioleAVide m_thing;
			public InternalTarget( APS_FioleAVide thing ) : base( -1, false, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( !( targeted is Item ) ) {
					from.SendMessage( "Il faut que ce soit un objet..." );
					return;					
				}
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else {
					m_thing.LikeDragDrop( from, (Item)targeted );
				}
			}
		}

		public void SelfClick( Mobile from )
		{
			if ((ItemID == 6194) || (ItemID == 6197)) /*Empty*/
			{
				from.SendMessage("Elle est déjà vide...");
			} else {
				from.SendMessage("Vous videz la fiole a vide...");
				if (ItemID > 6197)
					ItemID = 6197;
				else
					ItemID = 6194;						
				ReagentsCount=0;
				Formula = APS_Mortier.APS_EmptyFormula;
				Effects.PlaySound(from.Location, from.Map, 0x240);
			}
		}

		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}
		
		public bool LikeDragDrop( Mobile from, Item dropped )
		{
				if (dropped is APS_Erlenmeyer)
				{
					if ((ItemID != 6194) && (ItemID != 6197)) /*Not Empty*/
					{
						from.SendMessage("Il y a déjà quelquechose dans cette fiole a vide...");	
						from.SendMessage( "Si vous désirez la vider, utilisez la fiole sur elle-meme." );						
					} else if (((APS_Erlenmeyer)dropped).ReagentsCount == 0) {
						from.SendMessage("Vous devriez mettre quelquechose dans l'erlenmeyer avant...");							
					} else {
						from.SendMessage("Vous pratiquez une savante transformation thermo-régulée sur la solution...");	
						Formula = APS_Mortier.Transform(((APS_Erlenmeyer)dropped).Formula);
						ReagentsCount = ((APS_Erlenmeyer)dropped).ReagentsCount;
						((APS_Erlenmeyer)dropped).ReagentsCount = 0;
						((APS_Erlenmeyer)dropped).ItemID=6189;
						((APS_Erlenmeyer)dropped).Formula = APS_Mortier.APS_EmptyFormula;
						Effects.PlaySound(from.Location, from.Map, 36); 
						ItemID=ItemID+1+ReagentsCount % 2; // Pseudo-random color, uniq per formula
					}
				} else {
						from.SendMessage("Non, ca ne marchera pas... Essayez plutôt de mettre le contenu d'un Erlenmeyer..");
				}
			return true;
		}

		[Constructable]
		public APS_FioleAVide() : base( 6194 )
		{
			InitializeItemVaraiables();
		}

		public void InitializeItemVaraiables()
		{
			Name = "Une fiole a vide";
			ReagentsCount = 0;
			Formula = APS_Mortier.APS_EmptyFormula;
			Weight = 1.0;
		}
		
		public APS_FioleAVide( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (string) Formula );
			writer.Write( (int) ReagentsCount );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			Formula = reader.ReadString();
			ReagentsCount = reader.ReadInt();
			int version = reader.ReadInt();
		}
	}
}