using System;
using Server;
using Server.Mobiles;

/*
** report command
** version 1.0
** updated 26Apr05
** Roadkill aka EUORoadkill
** This will add a command, [report  that players can use to open their browser to a set url
** on a forum for your server, should be a "posting reply" url on a thread you make for spawn reports
** with their xyz coordinates, map, and region pre-loaded in the 
** subject line for them, and a blurb pre-written in the message body saying "spawn report".
*/

namespace Server.Scripts.Commands
{
	public class Report
	{
		public static void Initialize()
		{
			Server.Commands.Register( "report", AccessLevel.Administrator, new CommandEventHandler( report_OnCommand ) );			
		}

		[Usage( "bug" )]
		[Description( "Ouvre un navigateur internet afin de publier un probleme technique lie a la decoration, etc..." )]
		public static void report_OnCommand( CommandEventArgs e )
		{
			//this string thread below is what you change to the thread in your forums you want
			//the posts to go to.  Try posting a new reply in that thread and get the url from there
			//for pHp form should be "http://www.shardname.com/forum/posting.php?mode=reply&t=1"
			string thread = "http://technophobia.goo-done.com/post.forum?mode=reply&t=355";
			Mobile from = e.Mobile;
			Map map = from.Map;
			string location = from.X.ToString() + '_' + from.Y.ToString() + '_' + from.Z.ToString() + '_' + from.Map.ToString() + '_' + from.Region;
			location = location.Replace(' ', '_');
			string message = "Rapport_de_probleme_local";
			string url = thread + "&subject=AutoReport-" + location + "&message=" + message;

			from.LaunchBrowser( url );
		}
	}
}
