using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;

namespace Server.Gumps
{	
	public class LetterWriteGump : Gump
	{
		public LetterWriteGump( Mobile m ) : base( 25, 25)
		{
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;
			AddPage(0);
			AddBackground(29, 49, 384, 350, 3000);
			AddImage(40, 64, 95);
			AddImage(47, 73, 96);
			AddImage(214, 73, 96);
			AddImage(392, 64, 97);
			AddLabel(84, 110, 0, "To ");
			AddImage(340, 111, 1261);
			AddLabel(281, 138, 0, "Raisor's");
			AddImage(32, 101, 52);
			AddImage(40, 364, 95);
			AddImage(47, 373, 96);
			AddImage(214, 373, 96);
			AddImage(392, 364, 97);
			AddLabel(90, 300, 0, "Done");
			AddImage(269, 163, 9000);
			AddButton(70, 302, 5601, 5605, 1, GumpButtonType.Reply, 0);
			AddLabel(264, 266, 0, @"Post System");
			AddTextEntry(103, 110, 99, 20, 0, 0, "");
			AddTextEntry(63, 143, 190, 137, 0, 1, "");
			AddLabel(93, 200, 0, "<-Message Here->");
			AddButton(70, 322, 5601, 5605, 0, GumpButtonType.Reply, 0);
			AddLabel(90, 320, 0, "Close");
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			Mobile m_from = state.Mobile;
			
			if ( info.ButtonID == 1 )
			{
				TextRelay relayTo = info.GetTextEntry( 0 );
				string to = ( relayTo == null ? null : relayTo.Text.Trim() );
				
				TextRelay relayMessage = info.GetTextEntry( 1 );
				string message = ( relayMessage == null ? null : relayMessage.Text.Trim() );
				
				if ( to == "" )
				{
					m_from.SendMessage("You did not specify a recipient.");
				}
				
				if ( message == "" )
				{
					m_from.SendMessage("You did not write a message.");
				}
				
				Letter newLetter = new Letter();
				newLetter.i_to = to;
				newLetter.i_from = m_from.Name;
				newLetter.i_message = message;
				newLetter.Name = "a letter from " + m_from.Name;
				m_from.AddToBackpack( newLetter);
			}
			else
				m_from.AddToBackpack( new Letter() );
		}
	}
}
