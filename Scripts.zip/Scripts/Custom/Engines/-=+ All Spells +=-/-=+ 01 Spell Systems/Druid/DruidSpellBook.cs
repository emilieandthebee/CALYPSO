using System;
using Server.Spells;
using Server.Spells.Druid;

namespace Server.Items
{
	public class DruidSpellbook : Spellbook
	{
		public override SpellbookType SpellbookType{ get{ return SpellbookType.Druid; } }
		public override int BookOffset{ get{ return 551; } }
		public override int BookCount{ get{ return 16; } }

		public override Item Dupe( int amount )
		{
			Spellbook book = new DruidSpellbook();
			book.Content = this.Content;
			return base.Dupe( book, amount );
		}

		[Constructable]
		public DruidSpellbook() : this( (ulong)0 )
		{
		}

		[Constructable]
		public DruidSpellbook( ulong content ) : base( content, 0xEFA )
		{
			Hue = 0x48C;
			Name = "Tome of Nature";
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel == AccessLevel.Player )
			{
				Container pack = from.Backpack;
				if( !(Parent == from || (pack != null && Parent == pack)) )
				{
					from.SendMessage( "The spellbook must be in your backpack [and not in a container within] to open." );
					return;
				}
				else if( UseRestrictions && !SpellRestrictions.CheckRestrictions( from, this ) )
				{
					return;
				}
			}

			from.CloseGump( typeof( DruidSpellbookGump ) );
			from.SendGump( new DruidSpellbookGump( from, this ) );
		}

		public DruidSpellbook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
