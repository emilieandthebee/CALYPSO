using System;
using Server.Mobiles;
using Server.Items;
using Server.Network;

namespace Server.Spells
{
	public class SpellRestrictions
	{
		//Set Restricted to true if you want new spellbooks to be created with restrictions.
		public static bool Restricted = true;

		public static bool CheckRestrictions( Mobile caster, Spellbook book )
		{
			if( book == null )
				return false;

			if( caster == null )
				return false;

			if( book.SpellbookType == SpellbookType.Invalid )
				return false;

			if( caster.AccessLevel > AccessLevel.Player )
				return true;

/*** DELETED ***
			switch( (int)book.SpellbookType )
			{
				case (int)SpellbookType.Regular:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Magery].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Magery to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Necromancer:
				{
					if( caster.Skills[SkillName.Magery].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Necromancy].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Necromancy to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Paladin:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Chivalry].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Chivalry to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Ninja:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Ninjitsu].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Ninjitsu to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Samurai:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Bushido].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Bushido to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Druid:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.AnimalTaming].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Animal Taming to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Ancient:
				{
					if( caster.AccessLevel < AccessLevel.GameMaster )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are allowed to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Cleric:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Healing].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Healing to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Song:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Musicianship].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Musicianship to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Undead:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Necromancy].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Necromancy to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Rogue:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Stealing].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Stealing to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Avatar:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Chivalry].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Chivalry to use this.", caster.NetState );
						return false;
					}
					break;
				}
				case (int)SpellbookType.Ranger:
				{
					if( caster.Skills[SkillName.Necromancy].Value > 29.0 ||
						caster.Skills[SkillName.Chivalry].Value > 29.0 ||
						caster.Skills[SkillName.Ninjitsu].Value > 29.0 ||
						caster.Skills[SkillName.Bushido].Value > 29.0 ||
						caster.Skills[SkillName.Magery].Value > 29.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are too proficient in other magics to use this.", caster.NetState );
						return false;
					}
					else if( caster.Skills[SkillName.Archery].Value < 19.0 )
					{
						caster.PrivateOverheadMessage( MessageType.Regular, 0x22, false, "You are not proficient enough in Stealing to use this.", caster.NetState );
						return false;
					}
					break;
				}
				default: return true;
			}
*** DELETED ***/
			return true;
		}
	}
}