using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Spells;
using Server.Spells.Seventh;
using Server.Gumps;

namespace Server.Spells.Rogue
{
	public class ShadowSpell : Spell
	{
		private static SpellInfo m_Info = new SpellInfo(
		                                                "Shadow", " ",
		                                                SpellCircle.Fourth,
		                                                212,
		                                                9041,
		                                                Reagent.SpidersSilk,
		                                                Reagent.DaemonBlood,
		                                                Reagent.BlackPearl
		                                               );

		private static Hashtable m_Table = new Hashtable();

		public ShadowSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public static bool HasEffect( Mobile m )
		{
			return ( m_Table[m] != null );
		}

		public static void RemoveEffect( Mobile m )
		{
			object[] mods = (object[])m_Table[m];

			if ( mods != null )
			{
			}

			m_Table.Remove( m );

			m.EndAction( typeof( ShadowSpell ) );
			m.Hidden = false ;
			m.BodyMod = 0;
		}

		public override bool CheckCast()
		{
			if ( !base.CheckCast() )
			{
				return false;
			}
			else if ( !Caster.CanBeginAction( typeof( ShadowSpell ) ) )
			{
				Caster.SendLocalizedMessage( 1005559 );
				return false;
			}
			else if ( Necromancy.TransformationSpell.UnderTransformation( Caster ) )
			{
				Caster.SendMessage( "You cannot transform while in that form." );
				return false;
			}
			else if ( DisguiseGump.IsDisguised( Caster ) )
			{
				Caster.SendMessage( "You cannot transform while disguised." );
				return false;
			}
			else if ( Caster.BodyMod == 183 || Caster.BodyMod == 184 )
			{
				Caster.SendMessage( "You cannot transform while wearing body paint." );
				return false;
			}
			else if ( !Caster.CanBeginAction( typeof( PolymorphSpell ) ) )
			{
				Caster.SendMessage( "You cannot transform while polymorphed." );
				return false;
			}

			return true;
		}

		public override void OnCast()
		{
			if ( !Caster.CanBeginAction( typeof( ShadowSpell ) ) )
			{
				ShadowSpell.RemoveEffect( Caster );
			}
			else if ( Necromancy.TransformationSpell.UnderTransformation( Caster ) )
			{
				Caster.SendMessage( "You cannot transform while in that form." );
			}
			else if ( DisguiseGump.IsDisguised( Caster ) )
			{
				Caster.SendMessage( "You cannot transform while disguised." );
			}
			else if ( Caster.BodyMod == 183 || Caster.BodyMod == 184 )
			{
				Caster.SendMessage( "You cannot transform while wearing body paint." );
			}
			else if ( !Caster.CanBeginAction( typeof( PolymorphSpell ) ) )
			{
				Caster.SendMessage( "You cannot transform while polymorphed." );
			}
			else if ( CheckSequence() )
			{
				object[] mods = new object[]
				{
				};

				m_Table[Caster] = mods;

				new InternalTimer( Caster, TimeSpan.FromMinutes(1) ).Start();

				IMount mount = Caster.Mount;

				if ( mount != null )
					mount.Rider = null;

				Caster.Hidden = true ;
				Caster.BeginAction( typeof( ShadowSpell ) );
			}
		}


		private class InternalTimer : Timer
		{
			private Mobile m_Owner;
			private DateTime m_Expire;

			public InternalTimer( Mobile owner, TimeSpan duration ) : base( TimeSpan.Zero, TimeSpan.FromSeconds( 0.1 ) )
			{
				m_Owner = owner;
				m_Expire = DateTime.Now + duration;

			}

			protected override void OnTick()
			{
				if ( DateTime.Now >= m_Expire )
				{
					ShadowSpell.RemoveEffect( m_Owner );
					Stop();
				}
			}
		}
	}
}
