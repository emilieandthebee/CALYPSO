using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class SinewyEtudeScroll : SpellScroll
	{
		[Constructable]
		public SinewyEtudeScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public SinewyEtudeScroll( int amount ) : base( 666, 0x14ED, amount )
		{
			Name = "Sinewy Etude sheet music";
			Hue = 0x96;
		}
		
		public SinewyEtudeScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			from.SendMessage( "The sheet music must be in your music book." );
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new SinewyEtudeScroll( amount ), amount );
		}
	}
}
