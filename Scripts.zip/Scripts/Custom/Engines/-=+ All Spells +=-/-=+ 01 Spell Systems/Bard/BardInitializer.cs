using System;
using Server;
using Server.Spells;

namespace Server.Spells.Song
{
	public class BardInitializer
	{
		public static void Initialize()
		{
			if( Core.AOS )
			{
				Register( 651, typeof( ArmysPaeonSongSpell ) );
				Register( 652, typeof( EnchantingEtudeSongSpell ) );
				Register( 653, typeof( EnergyCarolSongSpell ) );
				Register( 654, typeof( EnergyThrenodySongSpell ) );
				Register( 655, typeof( FireCarolSongSpell ) );
				Register( 656, typeof( FireThrenodySongSpell ) );
				Register( 657, typeof( FoeRequiemSongSpell ) );
				Register( 658, typeof( IceCarolSongSpell ) );
				Register( 659, typeof( IceThrenodySongSpell ) );
				Register( 660, typeof( KnightsMinneSongSpell ) );
				Register( 661, typeof( MagesBalladSongSpell ) );
				Register( 662, typeof( MagicFinaleSongSpell ) );
				Register( 663, typeof( PoisonCarolSongSpell ) );
				Register( 664, typeof( PoisonThrenodySongSpell ) );
				Register( 665, typeof( SheepfoeMamboSongSpell ) );
				Register( 666, typeof( SinewyEtudeSongSpell ) );

				//RegDef( spellID, "Name", "Description", "Reagent1; Reagent2; Reagentn", "Skill; Mana; Tithe; Etc" );
				RegDef( 651, "Army's Paeon",     "Regenerates your partys health slowly. [Area Effect]",       null, "Skill: 70; Mana: 12" );
				RegDef( 652, "Enchanting Etude", "Raises the intelligence of your party.  [Area Effect]",      null, "Skill: 60; Mana: 15" );
				RegDef( 653, "Energy Carol",     "Raises the energy resistance of your party. [Area Effect]",  null, "Skill: 35; Mana:  7" );
				RegDef( 654, "Energy Threnody",  "Lowers the energy resistance of your target.",               null, "Skill: 30; Mana: 12" );
				RegDef( 655, "Fire Carol",       "Lowers the energy resistance of your target.",               null, "Skill: 70; Mana: 12" );
				RegDef( 656, "Fire Threnody",    "Raises the fire resistance of your party. [Area Effect]",    null, "Skill: 70; Mana: 12" );
				RegDef( 657, "Foe Requiem",      "Damages your target with a burst of sonic energy.",          null, "Skill: 30; Mana: 12" );
				RegDef( 658, "Ice Carol",        "Raises the cold resistance of your party. [Area Effect]",    null, "Skill: 55; Mana: 18" );
				RegDef( 659, "Ice Threnody",     "Lowers the ice resistance of your target.",                  null, "Skill: 45; Mana: 12" );
				RegDef( 660, "Knight's Minne",   "Raises the physical resist of your party. [Area Effect]",    null, "Skill: 35; Mana:  7" );
				RegDef( 661, "Mage's Ballad",    "Regenerates your party's mana slowly. [Area Effect]",        null, "Skill: 80; Mana: 15" );
				RegDef( 662, "Magic Finale",     "Dispels all summoned creatures around you. [Area Effect]",   null, "Skill: 65; Mana: 15" );
				RegDef( 663, "Poison Carol",     "Raises the poison resistance of your party.  [Area Effect]", null, "Skill: 35; Mana:  7" );
				RegDef( 664, "Poison Threnody",  "Lowers the poison resistance of your target.",               null, "Skill: 30; Mana: 12" );
				RegDef( 665, "Sheepfoe Mambo",   "Raises the dexterity of your party. [Area Effect]",          null, "Skill: 70; Mana: 12" );
				RegDef( 666, "Sinewy Etude",     "Raises the strength of your party. [Area Effect]",           null, "Skill: 70; Mana: 12" );
			}
		}
		public static void Register( int spellID, Type type )
		{
			SpellRegistry.Register( spellID, type );
		}
		public static void RegDef( int spellID, string name, string des, string regs, string inf )
		{
			SpellDefRegistry.Register( spellID, name, des, regs, inf );
		}
	}
}