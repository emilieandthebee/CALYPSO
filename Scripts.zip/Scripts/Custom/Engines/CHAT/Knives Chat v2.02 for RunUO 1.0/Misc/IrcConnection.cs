using System;
using System.Reflection;
using System.Collections;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;

using Server;
using Server.Mobiles;
using Server.Items;
using Server.Network;
using Server.Prompts;
using Server.Misc;
using Server.Accounting;
using Server.Scripts.Commands;
using Server.Gumps;
using CPA = Server.CommandPropertyAttribute;
using Knives.Utils;
using BotPlatformConsoleServer;

namespace Knives.Chat
{
	public enum IrcColor
	{
		White = 0,
		Black = 1,
		Blue = 2,
		Green = 3,
		LightRed = 4,
		Brown = 5,
		Purple = 6,
		Orange = 7,
		Yellow = 8,
		LightGreen = 9,
		Cyan = 10,
		LightCyan = 11,
		LightBlue = 12,
		Pink = 13,
		Grey = 14,
		LightGrey = 15,
	};

	public class IrcConnection
	{

		private static Point3D IRCBox=new Point3D(5555,1700,0);
	
		private void TreatCommand(string cmd)
		{
			string[] e=Server.Commands.Split(cmd);
			int nbArgs=e.Length;
			if (nbArgs < 2)
			{
				SendSuperUserMessage("Maitre ?");
				return;
			}
			if (e[0] != ",")
			{
				SendSuperUserMessage("Maitre ?");
				return;
			}
			string command=e[1].ToLower();
			string msg;
			////////////////////////////// 	WHO
			if (command == "who") {
				SendSuperUserMessage("LISTE DES JOUEURS EN LIGNE:");
				foreach ( NetState state in NetState.Instances )
				{
					Mobile m = state.Mobile;
					msg=String.Format("({0}) \"{1}\" ({2},{3},{4}) on {5}",m.Serial,m.Name,m.X,m.Y,m.Z,m.Map);
					SendSuperUserMessage(msg);
				}
				SendSuperUserMessage("FIN DE LISTE");
			////////////////////////////// 	EMOTE
			} else if (command == "emote") {
				if (nbArgs != 4)
				{
					SendSuperUserMessage("emote <Serial>  <blablabla>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				if (ent is Mobile)
				{
					Mobile m=(Mobile)ent;
					m.Emote(e[3]);
					SendSuperUserMessage("Le personnage a dit le texte...");
				} else if (ent is Item) {
					Item item=(Item)ent;
					msg=String.Format("*{0}*",e[3]);
					item.PublicOverheadMessage( MessageType.Regular, Utility.RandomDyedHue(), false, msg);
					SendSuperUserMessage("L'objet a dit le texte...");
				} else {
					SendSuperUserMessage("Ce n'est ni un Mobile ni un Item...");
				}
			////////////////////////////// 	SAY
			} else if (command == "say") {
				if (nbArgs != 4)
				{
					SendSuperUserMessage("say <Serial>  <blablabla>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				if (ent is Mobile)
				{
					Mobile m=(Mobile)ent;
					m.Say(e[3]);
					SendSuperUserMessage("Le personnage a dit le texte...");
				} else if (ent is Item) {
					Item item=(Item)ent;
					item.PublicOverheadMessage( MessageType.Regular, Utility.RandomDyedHue(), false, e[3]);
					SendSuperUserMessage("L'objet a dit le texte...");
				} else {
					SendSuperUserMessage("Ce n'est ni un Mobile ni un Item...");
				}
			////////////////////////////// 	TIP
			} else if (command == "tip") {
				if (nbArgs != 4)
				{
					SendSuperUserMessage("props <Serial> <blablabla>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				if (ent is Mobile)
				{
					Mobile m=(Mobile)ent;
					m.SendMessage(e[3]);
					SendSuperUserMessage("Message envoye...");
				} else {
					SendSuperUserMessage("Ce n'est pas un Mobile...");
				}
			////////////////////////////// 	HEARALL
			} else if (command == "hearall") {
				ChatInfo.IrcBackShard=!ChatInfo.IrcBackShard;
				if (ChatInfo.IrcBackShard)
					SendSuperUserMessage("Systeme espion actif.");
				else
					SendSuperUserMessage("Systeme espion inactif.");
			////////////////////////////// 	PLAYERSONLY
			} else if (command == "playersonly") {
				AccountHandler.PlayersOnly=!AccountHandler.PlayersOnly;
				if (AccountHandler.PlayersOnly)
					SendSuperUserMessage("Seul les joueurs et administrateurs peuvent se connecter.");
				else
					SendSuperUserMessage("Tout le monde peut se connecter.");
			////////////////////////////// 	BROADCAST
			} else if (command == "broadcast") {
				if (nbArgs != 3)
				{
					SendSuperUserMessage("broadcast \"Message a afficher\"");
					return;
				}
				foreach ( NetState state in NetState.Instances )
				{
					Mobile m = state.Mobile;
					m.SendMessage(e[2]);
				}
				SendSuperUserMessage("Message transmis a tout les joueurs en ligne.");
			////////////////////////////// 	SAVE
			} else if (command == "save") {
				SendSuperUserMessage("Sauvegarde du monde...");
				Server.Misc.AutoSave.Save();
				SendSuperUserMessage("...et voila.");
			////////////////////////////// 	RESTART
			} else if (command == "restart") {
				SendSuperUserMessage("Redemarrage!!!");
				Process.Start( Core.ExePath );
				Core.Process.Kill();
			////////////////////////////// 	BAZARRE
			} else if (command == "bazarre") {
				SendSuperUserMessage("LISTE DES OBJESTS DU BAZARRE:");
				IPooledEnumerable eable = Map.Trammel.GetObjectsInBounds(new Rectangle2D(IRCBox.X,IRCBox.Y,1,1));
				foreach ( object o in eable )
				{
					Type type=o.GetType();
					if (o is IEntity)
					{
						if (o is Mobile)
							msg=String.Format("Type {0}: {1} {2}",type.Name,((IEntity)o).Serial,((Mobile)o).Name);
						else if (o is Item)
							msg=String.Format("Type {0}: {1} {2}",type.Name,((IEntity)o).Serial,((Item)o).Name);
						else
							msg=String.Format("Type {0}: {1}",type.Name,((IEntity)o).Serial);
						SendSuperUserMessage(msg);
					}
				}
				eable.Free();
				SendSuperUserMessage("FIN DE LISTE");
			////////////////////////////// 	FREEZE
			} else if (command == "freeze") {
				SendSuperUserMessage("Gele de tout les PJ et PNJ");
				foreach ( Mobile mob in World.Mobiles.Values )
				{
					if ( !mob.Deleted )
					if ( mob.Alive )
						mob.Frozen=true;
				}
				SendSuperUserMessage("PJ et PNJ geles.");
			////////////////////////////// 	UNFREEZE
			} else if (command == "unfreeze") {
				SendSuperUserMessage("Degele de tout les PJ et PNJ");
				foreach ( Mobile mob in World.Mobiles.Values )
				{
					if ( !mob.Deleted )
					if (mob.Alive)
						mob.Frozen=false;
				}
				SendSuperUserMessage("PJ et PNJ degeles.");
			////////////////////////////// 	PROPS
			} else if (command == "props") {
				if (nbArgs != 3)
				{
					SendSuperUserMessage("props <Serial>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				ArrayList m_List=new ArrayList();;
				Type type = ent.GetType();
				PropertyInfo[] props = type.GetProperties( BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public );
				ArrayList groups = GetGroups( type, props );
				groups.Sort( new GroupComparer( type ) );
				for ( int i = 0; i < groups.Count; ++i )
				{
					DictionaryEntry de = (DictionaryEntry)groups[i];
					ArrayList groupList = (ArrayList)de.Value;
					if ( !HasAttribute( (Type)de.Key, typeofNoSort, false ) )
						groupList.Sort( PropertySorter.Instance );
					if ( i != 0 )
						m_List.Add( null );
					m_List.Add( de.Key );
					m_List.AddRange( groupList );
				}
				for ( int index = 0; index<m_List.Count; index++ )
				{
					object o = m_List[index];
					if ( o == null )
					{
						SendSuperUserMessage("================");
					}
					else if ( o is Type )
					{
						Type type2 = (Type)o;
						msg=String.Format("TYPE: {0}",type2.Name);
						SendSuperUserMessage(msg);
					}
					else if ( o is PropertyInfo )
					{
						PropertyInfo prop = (PropertyInfo)o;
						msg=String.Format("{0} = {1}",prop.Name,ValueToString( ent,prop ));
						SendSuperUserMessage(msg);
					}
				}
			////////////////////////////// 	GET
			} else if (command == "get") {
				if (nbArgs != 4)
				{
					SendSuperUserMessage("get <Serial> <propriete>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				string propriete = e[3];
				ArrayList m_List=new ArrayList();;
				Type type = ent.GetType();
				PropertyInfo[] props = type.GetProperties( BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public );
				ArrayList groups = GetGroups( type, props );
				groups.Sort( new GroupComparer( type ) );
				for ( int i = 0; i < groups.Count; ++i )
				{
					DictionaryEntry de = (DictionaryEntry)groups[i];
					ArrayList groupList = (ArrayList)de.Value;
					if ( !HasAttribute( (Type)de.Key, typeofNoSort, false ) )
						groupList.Sort( PropertySorter.Instance );
					if ( i != 0 )
						m_List.Add( null );
					m_List.Add( de.Key );
					m_List.AddRange( groupList );
				}
				for ( int index = 0; index<m_List.Count; index++ )
				{
					object o = m_List[index];
					if ( o == null )
					{}
					else if ( o is Type )
					{}
					else if ( o is PropertyInfo )
					{
						PropertyInfo prop = (PropertyInfo)o;
						if (propriete.ToLower() == prop.Name.ToLower())
						{
							msg=String.Format("{0} = {1}",prop.Name,ValueToString( ent,prop ));
							SendSuperUserMessage(msg);
						}
					}
				}
			////////////////////////////// 	LOOKMOBILES
			} else if (command == "lookmobiles") {
				if (nbArgs != 4)
				{
					SendSuperUserMessage("lookmobiles <Serial> <range>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				IPooledEnumerable eable = ent.Map.GetMobilesInRange( ent.Location, Utility.ToInt32(e[3]) );
				ArrayList list = new ArrayList();
				foreach( Mobile mob in eable )
				{
					list.Add( mob );
				}
				eable.Free();
				for ( int i = 0; i < list.Count; ++i )
				{
					Mobile mobile = (Mobile)list[i];
					msg=String.Format("{0} ({1},{2},{3}) {4} \"{5}\"",mobile.Serial,mobile.X,mobile.Y,mobile.Z,mobile.GetType().Name,mobile.Name);
					SendSuperUserMessage(msg);
				}
			////////////////////////////// 	LOOKITEMS
			} else if (command == "lookitems") {
				if (nbArgs != 4)
				{
					SendSuperUserMessage("lookitems <Serial> <range>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				IPooledEnumerable eable = ent.Map.GetItemsInRange( ent.Location, Utility.ToInt32(e[3]) );
				ArrayList list = new ArrayList();
				foreach( Item ite in eable )
				{
					list.Add( ite );
				}
				eable.Free();
				for ( int i = 0; i < list.Count; ++i )
				{
					Item item = (Item)list[i];
					msg=String.Format("{0} ({1},{2},{3}) {4} \"{5}\"",item.Serial,item.X,item.Y,item.Z,item.GetType().Name,item.Name);
					SendSuperUserMessage(msg);
				}
			////////////////////////////// 	MOVE
			} else if (command == "move") {
				if (nbArgs != 6)
				{
					SendSuperUserMessage("move <Serial> <x> <y> <z>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				if (ent is Mobile)
					((Mobile)ent).MoveToWorld(new Point3D(Utility.ToInt32(e[3]),Utility.ToInt32(e[4]),Utility.ToInt32(e[5])),ent.Map);
				if (ent is Item)
					((Item)ent).MoveToWorld(new Point3D(Utility.ToInt32(e[3]),Utility.ToInt32(e[4]),Utility.ToInt32(e[5])),ent.Map);
			////////////////////////////// 	SET
			} else if (command == "set") {
				if (nbArgs != 5)
				{
					SendSuperUserMessage("set <Serial> <propriete> <value>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				}
				string propriete = e[3];
				string property_value = e[4];
				ArrayList m_List=new ArrayList();;
				Type type = ent.GetType();
				PropertyInfo[] props = type.GetProperties( BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public );
				ArrayList groups = GetGroups( type, props );
				groups.Sort( new GroupComparer( type ) );
				for ( int i = 0; i < groups.Count; ++i )
				{
					DictionaryEntry de = (DictionaryEntry)groups[i];
					ArrayList groupList = (ArrayList)de.Value;
					if ( !HasAttribute( (Type)de.Key, typeofNoSort, false ) )
						groupList.Sort( PropertySorter.Instance );
					if ( i != 0 )
						m_List.Add( null );
					m_List.Add( de.Key );
					m_List.AddRange( groupList );
				}
				for ( int index = 0; index<m_List.Count; index++ )
				{
					object o = m_List[index];
					if ( o == null )
					{}
					else if ( o is Type )
					{}
					else if ( o is PropertyInfo )
					{
						PropertyInfo prop = (PropertyInfo)o;
						if (propriete.ToLower() == prop.Name.ToLower())
						{
							bool shouldSet=false;
							object toSet;
							try
							{
								toSet = PropertiesGump.GetObjectFromString( prop.PropertyType, property_value );
								shouldSet = true;
							}
							catch
							{
								toSet = null;
								shouldSet = false;
								SendSuperUserMessage( "Bad format" );
							}
							if (shouldSet)
							{
								prop.SetValue( ent, toSet, null );
								msg=String.Format("{0} = {1}",prop.Name,ValueToString( ent,prop ));
								SendSuperUserMessage(msg);
							}
						}
					}
				}
			////////////////////////////// 	DELETE
			} else if (command == "delete") {
				if (nbArgs != 3)
				{
					SendSuperUserMessage("delete <Serial>");
					return;
				}
				IEntity ent = World.FindEntity( Utility.ToInt32(e[2]));
				if (ent == null)
				{
					SendSuperUserMessage("Cette entite m'est inconnue.");
					return;
				} else {
					if (ent is Item)
					{
						((Item)ent).Delete();
						SendSuperUserMessage("Objet supprim�.");
					}
					else if (ent is Mobile)
					{
						((Mobile)ent).Delete();
						SendSuperUserMessage("Mobile supprim�.");
					}
					else
						SendSuperUserMessage("Je ne connais pas ce type d'entit�.");
				}				
			////////////////////////////// 	ADD
			} else if (command == "add") {
				if (nbArgs != 3)
				{
					SendSuperUserMessage("add <object>");
					return;
				}
				Type t = ScriptCompiler.FindTypeByName( e[2] );
				if ( t == null )
				{
					SendSuperUserMessage("Je ne connais pas ce type d'objet");
					return;
				}
				try
				{
					object o = Activator.CreateInstance( t );
					if ( o is Mobile )
					{
						Mobile m = (Mobile)o;
						m.MoveToWorld( IRCBox, Map.Trammel );
						if ( m is BaseCreature )
						{
							BaseCreature c = (BaseCreature)m;
							c.RangeHome = 0;
							c.Home = IRCBox;
						}
					}
					else if ( o is Item )
					{
						Item item = (Item)o;
						item.MoveToWorld( IRCBox, Map.Trammel );
					}
					if (o is IEntity)
					{
						msg=String.Format("SERIAL de l'objet: {0}",((IEntity)o).Serial);
						SendSuperUserMessage(msg);
					}
					SendSuperUserMessage("Element cree dans la boite a bazarre.");
				}
				catch {}
			} else {
				SendSuperUserMessage("Maitre ?");
				return;
			}
		}
		
		public Mobile findHim(string name)
		{
				foreach ( NetState state in NetState.Instances )
				{
					Mobile m = state.Mobile;
					if (m.Name == name)
						return m;
				}
				return null;
		}
	
		public static bool debug=false;
		private static IrcConnection s_Connection = new IrcConnection();

		public static IrcConnection Connection{ get{ return s_Connection; } }

		private TcpClient c_Tcp;
		private Thread c_Thread;
		private StreamReader c_Reader;
		private StreamWriter c_Writer;
		private bool c_Connecting, c_Connected;
		private int c_Attempts;
		private DateTime c_LastPong;

		public bool Connecting{ get{ return c_Connecting; } }
		public bool Connected{ get{ return c_Connected; } }
		public bool HasMoreAttempts{ get{ return c_Attempts <= ChatInfo.IrcMaxAttempts; } }

		public IrcConnection()
		{
		}

		public void Connect( Mobile m )
		{
			ChatInfo info = ChatInfo.GetInfo( m );

			if ( c_Connecting )
			{
				m.SendMessage( info.SystemColor, "The server is already attempting to connect." );
				return;
			}

			if ( c_Connected )
			{
				m.SendMessage( info.SystemColor, "The server is already connected." );
				return;
			}

			Connect();
		}

		public void Connect()
		{
			if (debug) System.Console.WriteLine("CHAT: Connect thread starting up");
			new Thread( new ThreadStart( ConnectTcp ) ).Start();
			if (debug) System.Console.WriteLine("CHAT: Connect thread started. up");
		}

		public void CancelConnect()
		{
			c_Attempts = ChatInfo.IrcMaxAttempts;
		}

		private void Reconnect()
		{
			c_Attempts++;

			if ( !HasMoreAttempts )
			{
				c_Attempts = 1;
				BroadcastSystem( "Irc Connection failed." );
				return;
			}

			BroadcastSystem( String.Format( "Attempting to connect to IRC... {0}", c_Attempts ) );

			Connect();
		}

		private void ConnectTcp()
		{
			try{ c_Tcp = new TcpClient( ChatInfo.IrcServer, ChatInfo.IrcPort ); }
			catch
			{
				BroadcastSystem( "Connection could not be established." );
				if (debug) System.Console.WriteLine("CHAT: Connection could not be established.");

				Reconnect();

				return;
			}

			ConnectStream();
		}

		private void ConnectStream()
		{try{

			if (debug) System.Console.WriteLine("CHAT: Connecting stream...");
			c_Connecting = true;
			c_LastPong = DateTime.Now;

			c_Reader = new StreamReader( c_Tcp.GetStream() );
			c_Writer = new StreamWriter( c_Tcp.GetStream() );

			BroadcastSystem( "Connecting to IRC Server..." );

			SendMessage( String.Format( "NICK {0}", ChatInfo.IrcNick ) );
			SendMessage( String.Format( "USER {0} \"technophobia.free.fr\" \"web2.epiknet.org\" :Technophobia", ChatInfo.IrcNick ) );
			SendMessage( String.Format( "JOIN {0}", ChatInfo.IrcRoom ) );

			c_Thread = new Thread( new ThreadStart( ReadStream ) );
			c_Thread.Start();

			Server.Timer.DelayCall( TimeSpan.FromSeconds( 15.0 ), new Server.TimerCallback( Ping ) );
			if (debug) System.Console.WriteLine("CHAT: Connected stream.");

		}catch{ Errors.Report( String.Format( "IrcConnection-> ConnectStream" ) ); } }

		private void Ping()
		{
			if (debug) System.Console.WriteLine("CHAT: Pinging...");
			if ( c_LastPong < DateTime.Now-TimeSpan.FromMinutes( 1 ) )
				Disconnect();

			if ( !c_Connecting && !c_Connected )
			{
				if (debug) System.Console.WriteLine("CHAT: Pinged.");
				return;
			}
			
			SendMessage( "PING " + ChatInfo.IrcServer );

			if ( c_Connected )
				SendMessage( "NAMES " + ChatInfo.IrcRoom );

			Server.Timer.DelayCall( TimeSpan.FromSeconds( 15.0 ), new Server.TimerCallback( Ping ) );
			if (debug) System.Console.WriteLine("CHAT: Pinged.");
		}

		public void SendMessage( string msg )
		{
			try{

			BroadcastRaw( msg );

			c_Writer.WriteLine( msg );
			c_Writer.Flush();

			}catch{ Disconnect(); }
		}

		public void SendUserMessage( Mobile m, string msg )
		{
			if ( !Connected )
				return;

			if ( !ChatInfo.PublicPlusIRC )
				s_Connection.Broadcast( m, String.Format( "<{0}> {1}: {2}", ChatInfo.IrcRoom, m.Name, msg ) );

			msg = OutParse( m, m.Name + ": " + msg );
			s_Connection.SendMessage( String.Format( "PRIVMSG {0} : {1}", ChatInfo.IrcRoom, msg  ));
			MyRobot.MSNBroadcast(msg);
			
			BroadcastRaw( String.Format( "PRIVMSG {0} : {1}", ChatInfo.IrcRoom, msg ) );
		}

		public void SendSuperUserMessage( Mobile m, string msg )
		{
			if ( !Connected )
				return;
			s_Connection.SendMessage( String.Format( "PRIVMSG alchemy,#backshard : {0} ({1},{2},{3}) > {4}", m.Name, m.X,m.Y,m.Z, msg  ));
		}

		public void SendSuperUserMessage( string msg )
		{
			if ( !Connected )
				return;
			s_Connection.SendMessage( String.Format( "PRIVMSG alchemy,#backshard : {0}",msg  ));
		}

		private string OutParse( Mobile m, string str )
		{
			if ( m.AccessLevel != AccessLevel.Player )
				return str = '\x0003' + ((int)ChatInfo.IrcStaffColor).ToString() + str;

			return str;
		}

		private void BroadcastSystem( string msg )
		{
			foreach( ChatInfo info in ChatInfo.ChatInfos.Values )
				if ( info.IrcOn && !info.Banned )
					info.Mobile.SendMessage( info.SystemColor, msg );
		}

		public void Broadcast( string msg )
		{
			foreach( ChatInfo info in ChatInfo.ChatInfos.Values )
				if ( info.IrcOn && !info.Banned )
					info.Mobile.SendMessage( info.IrcColor, msg );
		}

		public void Broadcast( Mobile m, string msg )
		{
			ChatInfo info = ChatInfo.GetInfo( m );

			foreach( ChatInfo otherInfo in ChatInfo.ChatInfos.Values )
				if ( otherInfo.IrcOn && !otherInfo.Banned )
					otherInfo.Mobile.SendMessage( m.AccessLevel == AccessLevel.Player ? otherInfo.IrcColor : info.StaffColor, msg );
		}

		private void BroadcastRaw( string msg )
		{
			foreach( ChatInfo info in ChatInfo.ChatInfos.Values )
				if ( info.IrcRaw )
				{
					info.Mobile.SendMessage( info.SystemColor, "RAW: " + msg );
					System.Console.WriteLine(msg);
				}
		}

		private void ReadStream()
		{try{

			string input = "";

			while( c_Thread.IsAlive )
			{
				input = c_Reader.ReadLine();

				if ( input == null )
					break;

				HandleInput( input );
			}

			Disconnect();

		}catch{ Disconnect(); } }

		private void HandleInput( string str )
		{try{

			if (debug) System.Console.WriteLine("CHAT: Handling Input...");
			BroadcastRaw( str );
			
			if ( str.IndexOf( "PING" ) != -1 )
			{
				SendMessage( String.Format( "PONG {0}", 
							str.Substring( 6, str.Length-6 ) ) );
			}
			
			if ( str.IndexOf( "PONG" ) != -1 )
			{
				if ( !c_Connected )
				{
					c_Connected = true;
					c_Connecting = false;
					BroadcastSystem( String.Format( "Server is now connected to IRC channel." ) );
					c_Attempts = 1;
				}

				c_LastPong = DateTime.Now;
				if (debug) System.Console.WriteLine("CHAT: Handled Input.");
				return;
			}
			
			if ( str.Length > 300 )
			{
				if (debug) System.Console.WriteLine("CHAT: Handled Input.");
				return;
			}
			
			if ( str.IndexOf( "353" ) != -1 )
			{
				BroadcastRaw( "IRC names list updating." );

				int index = str.ToLower().IndexOf( ChatInfo.IrcRoom.ToLower() ) + ChatInfo.IrcRoom.Length + 2;

				if ( index == 1 )
				{
					if (debug) System.Console.WriteLine("CHAT: Handled Input.");
					return;
				}
				
				string strList = str.Substring( index, str.Length-index );

				string[] strs = strList.Trim().Split( ' ' );

				ChatInfo.IrcList.Clear();
				ChatInfo.IrcList.AddRange( strs );
				ChatInfo.IrcList.Remove( ChatInfo.IrcNick );
			}

			if ( str.IndexOf( "NOTICE" ) != -1 )
			{

				if ( str.IndexOf( ":Themis!" ) != -1 )
				if ( str.IndexOf( "/msg Themis IDENTIFY" ) != -1 )
				{
					SendMessage( String.Format( "JOIN {0}", ChatInfo.IrcRoom ) );
					SendMessage( String.Format( "MODE {0}", ChatInfo.IrcRoom ) );
					s_Connection.SendMessage( String.Format( "PRIVMSG Themis : IDENTIFY alleluia"  ));
					if (debug) System.Console.WriteLine("CHAT: Handled Input.");
					return;
				}
			}

			if ( str.IndexOf( "PRIVMSG" ) != -1 )
			{
				string parOne = str.Substring( 1, str.IndexOf( "!" )-1 );

				if ( parOne == "Defender")
				if ( str.IndexOf( "VERSION" ) != -1 )
				{
					SendMessage( "NOTICE Defender :VERSION mIRC v6.17 Khaled Mardam-Bey" );
					SendMessage( String.Format( "JOIN {0}", ChatInfo.IrcRoom ) );
					SendMessage( String.Format( "MODE {0}", ChatInfo.IrcRoom ) );
					//SendMessage( String.Format( "Themis IDENTIFY alleluia" ) );
					if (debug) System.Console.WriteLine("CHAT: Handled Input.");
					return;
				}

				int index = 0;

				index = str.ToLower().IndexOf( ChatInfo.IrcRoom.ToLower() );
				if ( index == -1 )
				{
					index = str.ToLower().IndexOf( ChatInfo.IrcNick.ToLower() );
					if (index == -1)
					{
						if (debug) System.Console.WriteLine("CHAT: Handled Input.");
						return;
					}
					index=index+ChatInfo.IrcNick.Length + 2;
					string myCommand = str.Substring( index, str.Length-index );
					if (parOne == "alchemy")
					{
						TreatCommand(myCommand);
					}
					return;
				}
				index=index+ChatInfo.IrcRoom.Length + 2;
				
				string parTwo = str.Substring( index, str.Length-index );

				if ( parTwo.IndexOf( "ACTION" ) != -1 )
				{
					index = parTwo.IndexOf( "ACTION" ) + 7;
					parTwo = parTwo.Substring( index, parTwo.Length-index );
					str = String.Format( "<{0}> {1} {2}", ChatInfo.IrcRoom, parOne, parTwo );
				}
				else
					str = String.Format( "{0}: {1}", parOne, parTwo );
					//str = String.Format( "<{0}> {1}: {2}", ChatInfo.IrcRoom, parOne, parTwo );

				Broadcast( str );
			}
			if (debug) System.Console.WriteLine("CHAT: Handled Input.");

		}catch{ Errors.Report( String.Format( "IrcConnection-> HandleInput" ) ); } }

		public void Disconnect()
		{
			Disconnect( true );
		}

		public void Disconnect( bool reconn )
		{try{
			if (debug) System.Console.WriteLine("CHAT: Disconnecting...");

			if ( c_Connected )
				BroadcastSystem( "IRC connection down." );

			c_Connected = false;
			c_Connecting = false;

			if ( c_Thread != null )
				c_Thread.Suspend();
			if ( c_Reader != null )
				c_Reader.Close();
			if ( c_Writer != null )
				c_Writer.Close();
			if ( c_Tcp != null )
				c_Tcp.Close();

			if ( reconn )
				Reconnect();
			if (debug) System.Console.WriteLine("CHAT: Disconnected...");

		}catch{ Errors.Report( String.Format( "IrcConnection-> Disconnect" ) ); } }

		public static string[] m_BoolNames = new string[]{ "True", "False" };
		public static object[] m_BoolValues = new object[]{ true, false };

		public static string[] m_PoisonNames = new string[]{ "None", "Lesser", "Regular", "Greater", "Deadly", "Lethal" };
		public static object[] m_PoisonValues = new object[]{ null, Poison.Lesser, Poison.Regular, Poison.Greater, Poison.Deadly, Poison.Lethal };

		public class StackEntry
		{
			public object m_Object;
			public PropertyInfo m_Property;

			public StackEntry( object obj, PropertyInfo prop )
			{
				m_Object = obj;
				m_Property = prop;
			}
		}

		private static object[] GetObjects( Array a )
		{
			object[] list = new object[a.Length];

			for ( int i = 0; i < list.Length; ++i )
				list[i] = a.GetValue( i );

			return list;
		}

		private static bool IsCustomEnum( Type type )
		{
			return type.IsDefined( typeofCustomEnum, false );
		}

		public static void OnValueChanged( object obj, PropertyInfo prop, Stack stack )
		{
			if ( stack == null || stack.Count == 0 )
				return;

			if ( !prop.PropertyType.IsValueType )
				return;

			StackEntry peek = (StackEntry)stack.Peek();

			if ( peek.m_Property.CanWrite )
				peek.m_Property.SetValue( peek.m_Object, obj, null );
		}

		private static string[] GetCustomEnumNames( Type type )
		{
			object[] attrs = type.GetCustomAttributes( typeofCustomEnum, false );

			if ( attrs.Length == 0 )
				return new string[0];

			CustomEnumAttribute ce = attrs[0] as CustomEnumAttribute;

			if ( ce == null )
				return new string[0];

			return ce.Names;
		}

		private static bool HasAttribute( Type type, Type check, bool inherit )
		{
			object[] objs = type.GetCustomAttributes( check, inherit );

			return ( objs != null && objs.Length > 0 );
		}

		private static bool IsType( Type type, Type check )
		{
			return type == check || type.IsSubclassOf( check );
		}

		private static bool IsType( Type type, Type[] check )
		{
			for ( int i = 0; i < check.Length; ++i )
				if ( IsType( type, check[i] ) )
					return true;

			return false;
		}

		private static Type typeofMobile = typeof( Mobile );
		private static Type typeofItem = typeof( Item );
		private static Type typeofType = typeof( Type );
		private static Type typeofPoint3D = typeof( Point3D );
		private static Type typeofPoint2D = typeof( Point2D );
		private static Type typeofTimeSpan = typeof( TimeSpan );
		private static Type typeofCustomEnum = typeof( CustomEnumAttribute );
		private static Type typeofEnum = typeof( Enum );
		private static Type typeofBool = typeof( Boolean );
		private static Type typeofString = typeof( String );
		private static Type typeofPoison = typeof( Poison );
		private static Type typeofMap = typeof( Map );
		private static Type typeofSkills = typeof( Server.Skills );
		private static Type typeofPropertyObject = typeof( PropertyObjectAttribute );
		private static Type typeofNoSort = typeof( NoSortAttribute );

		private static Type[] typeofReal = new Type[]
			{
				typeof( Single ),
				typeof( Double )
			};

		private static Type[] typeofNumeric = new Type[]
			{
				typeof( Byte ),
				typeof( Int16 ),
				typeof( Int32 ),
				typeof( Int64 ),
				typeof( SByte ),
				typeof( UInt16 ),
				typeof( UInt32 ),
				typeof( UInt64 )
			};

//		private string ValueToString( PropertyInfo prop )
//		{
//			return ValueToString( m_Object, prop );
//		}

		public static string ValueToString( object obj, PropertyInfo prop )
		{
			try
			{
				return ValueToString( prop.GetValue( obj, null ) );
			}
			catch ( Exception e )
			{
				return String.Format( "!{0}!", e.GetType() );
			}
		}

		public static string ValueToString( object o )
		{
			if ( o == null )
			{
				return "-null-";
			}
			else if ( o is string )
			{
				return String.Format( "\"{0}\"", (string)o );
			}
			else if ( o is bool )
			{
				return o.ToString();
			}
			else if ( o is char )
			{
				return String.Format( "0x{0:X} '{1}'", (int)(char)o, (char)o );
			}
			else if ( o is Serial )
			{
				Serial s = (Serial)o;

				if ( s.IsValid )
				{
					if ( s.IsItem )
					{
						return String.Format( "(I) 0x{0:X}", s.Value );
					}
					else if ( s.IsMobile )
					{
						return String.Format( "(M) 0x{0:X}", s.Value );
					}
				}

				return String.Format( "(?) 0x{0:X}", s.Value );
			}
			else if ( o is byte || o is sbyte || o is short || o is ushort || o is int || o is uint || o is long || o is ulong )
			{
				return String.Format( "{0} (0x{0:X})", o );
			}
			else if ( o is Mobile )
			{
				return String.Format( "(M) 0x{0:X} \"{1}\"", ((Mobile)o).Serial.Value, ((Mobile)o).Name );
			}
			else if ( o is Item )
			{
				return String.Format( "(I) 0x{0:X}", ((Item)o).Serial );
			}
			else if ( o is Type )
			{
				return ((Type)o).Name;
			}
			else
			{
				return o.ToString();
			}
		}
		private static Type typeofCPA = typeof( CPA );
		private static Type typeofObject = typeof( object );
		private static CPA GetCPA( PropertyInfo prop )
		{
			object[] attrs = prop.GetCustomAttributes( typeofCPA, false );
			if ( attrs.Length > 0 )
				return attrs[0] as CPA;
			else
				return null;
		}
		private ArrayList GetGroups( Type objectType, PropertyInfo[] props )
		{
			Hashtable groups = new Hashtable();
			for ( int i = 0; i < props.Length; ++i )
			{
				PropertyInfo prop = props[i];

				if ( prop.CanRead )
				{
						Type type = prop.DeclaringType;

						while ( true )
						{
							Type baseType = type.BaseType;

							if ( baseType == null || baseType == typeofObject )
								break;

							if ( baseType.GetProperty( prop.Name, prop.PropertyType ) != null )
								type = baseType;
							else
								break;
						}

						ArrayList list = (ArrayList)groups[type];

						if ( list == null )
							groups[type] = list = new ArrayList();

						list.Add( prop );
				}
			}

			ArrayList sorted = new ArrayList( groups );
			sorted.Sort( new GroupComparer( objectType ) );
			return sorted;
		}

		public static object GetObjectFromString( Type t, string s )
		{
			if ( t == typeof( string ) )
			{
				return s;
			}
			else if ( t == typeof( byte ) || t == typeof( sbyte ) || t == typeof( short ) || t == typeof( ushort ) || t == typeof( int ) || t == typeof( uint ) || t == typeof( long ) || t == typeof( ulong ) )
			{
				if ( s.StartsWith( "0x" ) )
				{
					if ( t == typeof( ulong ) || t == typeof( uint ) || t == typeof( ushort ) || t == typeof( byte ) )
					{
						return Convert.ChangeType( Convert.ToUInt64( s.Substring( 2 ), 16 ), t );
					}
					else
					{
						return Convert.ChangeType( Convert.ToInt64( s.Substring( 2 ), 16 ), t );
					}
				}
				else
				{
					return Convert.ChangeType( s, t );
				}
			}
			else if ( t == typeof( double ) || t == typeof( float ) )
			{
				return Convert.ChangeType( s, t );
			}
			else if ( t.IsDefined( typeof( ParsableAttribute ), false ) )
			{
				MethodInfo parseMethod = t.GetMethod( "Parse", new Type[]{ typeof( string ) } );

				return parseMethod.Invoke( null, new object[]{ s } );
			}

			throw new Exception( "bad" );
		}

		private static string GetStringFromObject( object o )
		{
			if ( o == null )
			{
				return "-null-";
			}
			else if ( o is string )
			{
				return String.Format( "\"{0}\"", (string)o );
			}
			else if ( o is bool )
			{
				return o.ToString();
			}
			else if ( o is char )
			{
				return String.Format( "0x{0:X} '{1}'", (int)(char)o, (char)o );
			}
			else if ( o is Serial )
			{
				Serial s = (Serial)o;

				if ( s.IsValid )
				{
					if ( s.IsItem )
					{
						return String.Format( "(I) 0x{0:X}", s.Value );
					}
					else if ( s.IsMobile )
					{
						return String.Format( "(M) 0x{0:X}", s.Value );
					}
				}
				return String.Format( "(?) 0x{0:X}", s.Value );
			}
			else if ( o is byte || o is sbyte || o is short || o is ushort || o is int || o is uint || o is long || o is ulong )
			{
				return String.Format( "{0} (0x{0:X})", o );
			}
			else if ( o is Mobile )
			{
				return String.Format( "(M) 0x{0:X} \"{1}\"", ((Mobile)o).Serial.Value, ((Mobile)o).Name );
			}
			else if ( o is Item )
			{
				return String.Format( "(I) 0x{0:X}", ((Item)o).Serial );
			}
			else if ( o is Type )
			{
				return ((Type)o).Name;
			}
			else
			{
				return o.ToString();
			}
		}

		private class PropertySorter : IComparer
		{
			public static readonly PropertySorter Instance = new PropertySorter();
			private PropertySorter()
			{
			}
			public int Compare( object x, object y )
			{
				if ( x == null && y == null )
					return 0;
				else if ( x == null )
					return -1;
				else if ( y == null )
					return 1;
				PropertyInfo a = x as PropertyInfo;
				PropertyInfo b = y as PropertyInfo;
				if ( a == null || b == null )
					throw new ArgumentException();
				return a.Name.CompareTo( b.Name );
			}
		}
		
		private class GroupComparer : IComparer
		{
			private Type m_Start;

			public GroupComparer( Type start )
			{
				m_Start = start;
			}

			private static Type typeofObject = typeof( Object );

			private int GetDistance( Type type )
			{
				Type current = m_Start;
				int dist;
				for ( dist = 0; current != null && current != typeofObject && current != type; ++dist )
					current = current.BaseType;
				return dist;
			}

			public int Compare( object x, object y )
			{
				if ( x == null && y == null )
					return 0;
				else if ( x == null )
					return -1;
				else if ( y == null )
					return 1;
				if ( !(x is DictionaryEntry) || !(y is DictionaryEntry) )
					throw new ArgumentException();
				DictionaryEntry de1 = (DictionaryEntry)x;
				DictionaryEntry de2 = (DictionaryEntry)y;
				Type a = (Type)de1.Key;
				Type b = (Type)de2.Key;
				return GetDistance( a ).CompareTo( GetDistance( b ) );
			}
		}
		
	}
}