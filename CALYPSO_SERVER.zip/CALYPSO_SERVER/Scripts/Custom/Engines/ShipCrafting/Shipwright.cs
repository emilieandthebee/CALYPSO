//
// Shipwright.cs
//
// Released:	March 17 2004
//
// Version:	1.0
//
// Author:	awdball
//
// Implements DefShipwright, ShipwrightTools and several component parts for the
// crafting of ships. This version was designed to not require any files except
// this script file. No mul changes no graphics changes, simply re-use any existing
// graphics already in the base distribution.
//
// NOTE 1:
// 	Specifically ignores the key, hold, tillerman and a few other items.
// 	I considered using a key or a pair of keys, a crate for the hold, and
// 	a service contract to bind a tillerman. I even remotely considered
// 	needing an unmarked rune to justify being able to recall to your key
// 	to get back to your boat. But dismissed it just so that I could limit 
// 	the crafting gump to one menu page in each category.
//
// NOTE 2:
// 	There is a bug in RUNUO Beta 36 CraftItem.cs see:
// 		http://www.runuo.com/forum/showthread.php?t=32078
// 	This only affects new craft menus like my DefShipwright, that use the
// 	final parameter for a string message when you do not have enough resources.
// 	Instead of displaying the string for the message it displays the string
// 	for the object name. The following fix applied to CraftItem.cs at
// 	approximately line 523 and line 648 ( of a clean Beta 36 build) :
//
// 	Change
//		message = res.NameString;
// 	to
//		message = res.MessageString;
// 	
// Future Version plans:
// 	A) Implement replacement boat classes that allow makers mark, and perhaps
// 	   variable hold sizes.
// 	B) Use a multi for the mast and assembled fixtures, or simply change
// 	   them to deeds. Please send me any comments on whether you like the
// 	   large mast, want a full multi version, or the simpler deed.
//
// To add the tools to the tinkers craft menu, add the following to
// Scripts/Engines/Craft/DefTinkering.cs:
//
//	AddCraft( typeof( ShipwrightTools ), 1044046, "shipwright tools",
//			20.0, 70.0, typeof( IronIngot ), "iron ingots", 3, 1044037 );
//
// To add some of these components to the Shipwright Vendor you would edit
// Scripts/Mobiles/Vendors/SBInfo/SBShipwright.cs
//
// To add the tools to the Tinker Vendor you would add the following to 
// Scripts/Mobiles/Vendors/SBInfo/SBTinker.cs:
//
//	Add( new GenericBuyInfo( "shipwright tools", typeof( ShipwrightTools ), 30, 20, 0x1EBA, 0 ) );
// 


using System;
using Server;
using Server.Items;
using Server.Engines.Craft;

namespace Server.Engines.Craft
{
	public class DefShipwright : CraftSystem
	{
		private const int c_var_scale = 40; // sets scale on variable quantity items based upon ship size: deck sections and hull sections
		private const int c_fix_scale = 50; // sets scale on fixed quantity assemblies: keel, rudder and mast
		// Size Factor ( small == 4, medium == 5, large == 6 )
		// boards used in total == c_var_scale * 7 * <size factor> + c_fix_scale * 12 + 20
		// cost of materials == boards used * <cost_per_board> + approx 1600 for other components

		public override SkillName MainSkill
		{
			get	{ return SkillName.Carpentry;	}
		}

		public override int GumpTitleNumber
		{
			get { return 0; } // Use String
		}

		public override string GumpTitleString
		{
			get { return "<basefont color=#FFFFFF><CENTER>Shipwright Menu</CENTER></basefont>"; } 
		}

		private static CraftSystem m_CraftSystem;

		public static CraftSystem CraftSystem
		{
			get
			{
				if ( m_CraftSystem == null )
					m_CraftSystem = new DefShipwright();

				return m_CraftSystem;
			}
		}

		public override double GetChanceAtMin( CraftItem item )
		{
			return 0.5; // 50%
		}

		private DefShipwright() : base( 1, 1, 1.25 ) // MinCraftEffect, MaxCraftEffect, Delay
		{
		}

		public override int CanCraft( Mobile from, BaseTool tool, Type itemType )
		{
			if ( tool.Deleted || tool.UsesRemaining < 0 )
				return 1044038; // You have worn out your tool!

			return 0;
		}

		public override void PlayCraftEffect( Mobile from )
		{
			// Copied from DefCarpentry.cs
			from.PlaySound( 0x23D );
		}

		public override int PlayEndingEffect( Mobile from, bool failed, bool lostMaterial, bool toolBroken, int quality, bool makersMark, CraftItem item )
		{
			if ( toolBroken )
				from.SendLocalizedMessage( 1044038 ); // You have worn out your tool

			if ( failed )
			{
				if ( lostMaterial )
					return 1044043; // You failed to create the item, and some of your materials are lost.
				else
					return 1044157; // You failed to create the item, but no materials were lost.
			}
			else
			{
				if ( quality == 0 )
					return 502785; // You were barely able to make this item.  It's quality is below average.
				else if ( makersMark && quality == 2 )
					return 1044156; // You create an exceptional quality item and affix your maker's mark.
				else if ( quality == 2 )
					return 1044155; // You create an exceptional quality item.
				else				
					return 1044154; // You create the item.
			}
		}

		public override void InitCraftList()
		{
			int index = -1;

			// Components
			AddCraft( typeof( Rope ), 1011155, 1020934, SkillName.Tailoring, 20.0, 45.0, typeof( SpoolOfThread ), 1024000, 5, "You do not have sufficient thread to make that." );

			AddCraft( typeof( HullPlankSet ), 1011155, "hull plank set", 60.0, 85.0, typeof( Log ), "Boards or Logs", c_var_scale, 1044351 );

			index = AddCraft( typeof( Keel ), 1011155, "keel deed", 60.0,  85.0, typeof( Log ), "Boards or Logs", c_fix_scale*6, 1044351 );
			AddRes( index, typeof( IronIngot ), 1044036, 50, "You do not have enough iron for the ballast." );

			index = AddCraft( typeof( DeckSection ),   1011155, "deck section", 40.0, 65.0, typeof( Log ), "Boards or Logs",  c_var_scale*2, 1044351 );
			AddRes( index, typeof( Nails ), "nails", 3, "You do not have sufficient nails to assemble that." );

			AddCraft( typeof( Mast ), 1011155, "mast", 60.0,  85.0, typeof( Log ), "Boards or Logs", c_fix_scale*2, 1044351 );
			
			AddCraft( typeof( SailBundle ), 1011155, 1035961, SkillName.Tailoring, 40.0, 65.0, typeof( Cloth ), 1044286, 100, 1044287 );

			index = AddCraft( typeof( GangPlank ), 1011155, "gangplank", 40.0,  65.0, typeof( Log ), "Boards or Logs", 10, 1044351 );
			AddSkill( index, SkillName.Tinkering, 40.0, 65.0 );
			AddRes( index, typeof( IronIngot ), 1044036, 5, 1044037 );

			index = AddCraft( typeof( ShipsDragonHead ), 1011155, "ships dragon head", 100.0,  120.0, typeof( Log ), "Boards or Logs", c_fix_scale*2, 1044351 );
			AddRes( index, typeof( BaseScales ), 1060883, 8, 1060884 );
			

			// Subassemblies
			index = AddCraft( typeof( HullSection ), 1044051, "hull section", 80.0, 105.0, typeof( HullPlankSet ), "hull plank sets", 4, "You do not have sufficient hull planks to make that." );
			AddRes( index, typeof( Log ), "Boards or Logs", c_var_scale, 1044351 );
			AddRes( index, typeof( Nails ), "nails", 4, "You do not have sufficient nails to assemble that." );

			index = AddCraft( typeof( Rigging ), 1044051, "rigging", 40.0, 65.0, typeof( Rope ), "Rope", 8, "You need more rope to assemble your rigging." );
			AddSkill( index, SkillName.Tinkering, 80.0, 105.0 );
			AddRes( index, typeof( Axle ), "axle", 10, "You need more axles to assemble your rigging." );
			AddRes( index, typeof( Log ), "Boards or Logs", 10, 1044351 );

			index = AddCraft( typeof( Anchor ), 1044051, 1025367, SkillName.Blacksmith, 60.0, 85.0, typeof( IronIngot ), 1044036, 50, 1044037 );
			AddRes( index, typeof( Rope ), "Rope", 2, "You need more rope to make a usable Anchor." );

			index = AddCraft( typeof( Rudder ), 1044051, 1035983, 80.0, 105.0, typeof( Log ), "Boards or Logs", c_fix_scale*4, 1044351 );
			AddSkill( index, SkillName.Tinkering, 50.0, 55.0 );
			AddRes( index, typeof( Hinge ), 1044172, 4, "You do not have enough hinges to make that." );

			index = AddCraft( typeof( SmallShipPhase1 ), 1044051, "small ship phase 1 deed", 90.0, 115.0, typeof( DeckSection ), "deck sections", 4, "You need more deck sections for that boat." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( HullSection ), "hull section", 4, "You need more hull sections for that boat." );
			AddRes( index, typeof( Keel ), "keel", 1, "You need a keel for that boat." );
			AddRes( index, typeof( Rudder ), "rudder", 1, "You need a rudder for that boat." );

			index = AddCraft( typeof( MediumShipPhase1 ), 1044051, "medium ship phase 1 deed", 95.0, 115.0, typeof( DeckSection ), "deck sections", 5, "You need more deck sections for that boat." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( HullSection ), "hull section", 5, "You need more hull sections for that boat." );
			AddRes( index, typeof( Keel ), "keel", 1, "You need a keel for that boat." );
			AddRes( index, typeof( Rudder ), "rudder", 1, "You need a rudder for that boat." );

			index = AddCraft( typeof( LargeShipPhase1 ), 1044051, "large ship phase 1 deed", 100.0, 115.0, typeof( DeckSection ), "deck sections", 6, "You need more deck sections for that boat." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( HullSection ), "hull section", 6, "You need more hull sections for that boat." );
			AddRes( index, typeof( Keel ), "keel", 1, "You need a keel for that boat." );
			AddRes( index, typeof( Rudder ), "rudder", 1, "You need a rudder for that boat." );

			index = AddCraft( typeof( ShipFixtures ), 1044051, "ship fixtures", 80.0, 105.0, typeof( Mast ), "mast", 1, "You need a mast to assemble that." );
			AddSkill( index, SkillName.Tinkering, 80.0, 85.0 );
			AddRes( index, typeof( SailBundle ), "sail bundle", 1, "You need a set of sails to assemble that." );
			AddRes( index, typeof( Rigging ), "rigging", 1, "You need a set of rigging to assemble that." );
			AddRes( index, typeof( Anchor ), "anchor", 1, "You need a anchor to assemble that." );
			

			// Boats
			index = AddCraft( typeof( Multis.SmallBoatDeed ), 1022997, 1041205, 80.0, 90.0, typeof( SmallShipPhase1 ), "small ship phase 1 deed", 1, "You need the shell of a small ship to assemble that ship." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( ShipFixtures ), "ship fixtures", 1, "You need a set of ship fixtures to assemble that." );
			AddRes( index, typeof( GangPlank ), "gangplank", 1, "You need a gangplank to assemble that." );

			index = AddCraft( typeof( Multis.SmallDragonBoatDeed ), 1022997, 1041206, 80.0, 90.0, typeof( SmallShipPhase1 ), "small ship phase 1 deed", 1, "You need the shell of a small ship to assemble that ship." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( ShipFixtures ), "ship fixtures", 1, "You need a set of ship fixtures to assemble that." );
			AddRes( index, typeof( GangPlank ), "gangplank", 1, "You need a gangplank to assemble that." );
			AddRes( index, typeof( ShipsDragonHead ), "ships dragon head", 1, "You need a ships dragon head to assemble that." );

			index = AddCraft( typeof( Multis.MediumBoatDeed ), 1022997, 1041207, 80.0, 90.0, typeof( MediumShipPhase1 ), "medium ship phase 1 deed", 1, "You need the shell of a medium ship to assemble that ship." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( ShipFixtures ), "ship fixtures", 1, "You need a set of ship fixtures to assemble that." );
			AddRes( index, typeof( GangPlank ), "gangplank", 1, "You need a gangplank to assemble that." );

			index = AddCraft( typeof( Multis.MediumDragonBoatDeed ), 1022997, 1041208, 80.0, 90.0, typeof( MediumShipPhase1 ), "medium ship phase 1 deed", 1, "You need the shell of a medium ship to assemble that ship." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( ShipFixtures ), "ship fixtures", 1, "You need a set of ship fixtures to assemble that." );
			AddRes( index, typeof( GangPlank ), "gangplank", 1, "You need a gangplank to assemble that." );
			AddRes( index, typeof( ShipsDragonHead ), "ships dragon head", 1, "You need a ships dragon head to assemble that." );

			index = AddCraft( typeof( Multis.LargeBoatDeed ), 1022997, 1041209, 80.0, 90.0, typeof( LargeShipPhase1 ), "large ship phase 1 deed", 1, "You need the shell of a large ship to assemble that ship." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( ShipFixtures ), "ship fixtures", 1, "You need a set of ship fixtures to assemble that." );
			AddRes( index, typeof( GangPlank ), "gangplank", 1, "You need a gangplank to assemble that." );

			index = AddCraft( typeof( Multis.LargeDragonBoatDeed ), 1022997, 1041210, 80.0, 90.0, typeof( LargeShipPhase1 ), "large ship phase 1 deed", 1, "You need the shell of a large ship to assemble that ship." );
			AddSkill( index, SkillName.Tinkering, 60.0, 65.0 );
			AddRes( index, typeof( ShipFixtures ), "ship fixtures", 1, "You need a set of ship fixtures to assemble that." );
			AddRes( index, typeof( GangPlank ), "gangplank", 1, "You need a gangplank to assemble that." );
			AddRes( index, typeof( ShipsDragonHead ), "ships dragon head", 1, "You need a ships dragon head to assemble that." );

			MarkOption = true;
			Repair = Core.AOS;
		}
	}
}

namespace Server.Items
{
	[Flipable(0x3E89, 0x3E86)]
	public class GangPlank : Item
	{

		[Constructable]
		public GangPlank() : base(0x3E89)
		{
			Weight = 1;
			Name = "gangplank";
		}

		public GangPlank(Serial serial) : base(serial) { } 
		public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int) 0); } 
		public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); }
	}

	public class Mast : Item
	{
		[Constructable]
		public Mast() : base(0x3ED0)
		{
			Weight = 10;
			Name = "mast";
		}

		public Mast(Serial serial) : base(serial) { } 
		public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int) 0); } 
		public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); } 
	}

	[Flipable(0x1EB1, 0x1EB2)]
	public class HullPlankSet : Item
	{
		[Constructable]
		public HullPlankSet() : base(0x1EB1)
		{
			Weight = 1;
			Name = "hull plank set";
			Hue = 51;
		}

		public HullPlankSet(Serial serial) : base(serial) { } 
		public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int) 0); } 
		public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); }
	}
		
	public class Rudder : Item
	{
		[Constructable]
		public Rudder() : base( 0x3E6F )
		{
			Weight = 5.0;
			Name = "rudder";
		}

		public Rudder( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x3E8B, 0x3EAC )]
	public class DeckSection : Item
	{

		[Constructable]
		public DeckSection() : base( 0x3E8B )
		{
			Weight = 10.0;
			Name = "deck section";
		}

		public DeckSection( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0xA58, 0xA59 )]
	public class SailBundle : Item
	{
		[Constructable]
		public SailBundle() : base( 0xA58 )
		{
			Weight = 5.0;
			Name = "sail bundle";
		}

		public SailBundle( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x14F7, 0x14F9 )]
	public class Anchor : Item
	{
		[Constructable]
		public Anchor() : base( 0x14F7 )
		{
			Weight = 10.0;
			Name = "anchor";
		}

		public Anchor( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}
	
	[Flipable( 0x1E9E, 0x1E9F )]
	public class Rigging : Item
	{
		[Constructable]
		public Rigging() : base( 0x1E9E )
		{
			Weight = 10.0;
			Name = "rigging";
		}

		public Rigging( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x14ED, 0x14EE )]
	public class HullSection : Item
	{
		[Constructable]
		public HullSection() : base( 0x14ED )
		{
			Weight = 0.1;
			Name = "hull section deed";
		}

		public HullSection( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x14ED, 0x14EE )]
	public class Keel : Item
	{
		[Constructable]
		public Keel() : base( 0x14ED )
		{
			Weight = 0.1;
			Name = "keel deed";
		}

		public Keel( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x3E48, 0x3E56, 0x3E45, 0x3E44 )]
	public class ShipsDragonHead : Item
	{
		[Constructable]
		public ShipsDragonHead() : base( 0x3E48 )
		{
			Weight = 5.0;
			Name = "ships dragon head";
		}

		public ShipsDragonHead( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x14ED, 0x14EE )]
	public class SmallShipPhase1 : Item
	{
		[Constructable]
		public SmallShipPhase1() : base( 0x14ED )
		{
			Weight = 0.1;
			Name = "small ship phase 1 deed";
		}

		public SmallShipPhase1( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x14ED, 0x14EE )]
	public class MediumShipPhase1 : Item
	{
		[Constructable]
		public MediumShipPhase1() : base( 0x14ED )
		{
			Weight = 0.1;
			Name = "medium ship phase 1 deed";
		}

		public MediumShipPhase1( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x14ED, 0x14EE )]
	public class LargeShipPhase1 : Item
	{
		[Constructable]
		public LargeShipPhase1() : base( 0x14ED )
		{
			Weight = 0.1;
			Name = "large ship phase 1 deed";
		}

		public LargeShipPhase1( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable(0x3EDD, 0x3E5A, 0x3E6C, 0x3EE2)]
	public class ShipFixtures : Item
	{
		[Constructable]
		public ShipFixtures() : base( 0x3EDD )
		{
			Weight = 25.0;
			Name = "ship fixtures";
		}

		public ShipFixtures( Serial serial ) : base( serial ) { } 
		public override void Serialize( GenericWriter writer ) { base.Serialize( writer ); writer.Write( (int) 0 ); } 
		public override void Deserialize( GenericReader reader ) { base.Deserialize( reader ); int version = reader.ReadInt(); }
	}

	[Flipable( 0x1EBA, 0x1EBB )]
	public class ShipwrightTools : BaseTool
	{
		public override CraftSystem CraftSystem{ get{ return DefShipwright.CraftSystem; } }

		[Constructable]
		public ShipwrightTools() : base( 0x1EBA )
		{
			Weight = 2.0;
			Name = "Shipwright Tools";
		}

		[Constructable]
		public ShipwrightTools( int uses ) : base( uses, 0x1EBA )
		{
			Weight = 2.0;
			Name = "Shipwright Tools";
		}

		public ShipwrightTools( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
