using System; 
using Server; 

namespace Server.Items 
{ 
	public class CluePipe : Item
	{ 
		[Constructable]
		public CluePipe() : base( 0x1BDD ) 
		{
			Hue = 1175;
			Weight = 1.0; 
			Name = "un Matrakoton de Kloedu"; 
		} 

		public CluePipe( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 0 ); 
		} 
       
		public override void Deserialize(GenericReader reader) 
		{ 
			base.Deserialize( reader ); 
			int version = reader.ReadInt(); 
		}
	} 
}