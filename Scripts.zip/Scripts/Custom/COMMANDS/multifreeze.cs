// ================================================================================================
// Multi freeze script for RunUO
// By Mr. Fixit (Daniel Storjordet)
// Tested on RunUO beta 33r2
// ================================================================================================
// 	Version		Date		Notes
// ================================================================================================
//	0.9		2003-07-26	Buggy first attempt. (Mr. Fixit)
//	1.0		2003-07-27	Bugs worked out, thanks to Krrios. (Mr. Fixit)
//	1.1		2003-07-27	Some cleanups, thanks to Krrios. (Mr. Fixit)
//	1.2		2003-07-28	Added support for center item. (Mr. Fixit)
//	1.3		2003-08-04	Some cleanups and a debug constant. (Mr. Fixit)
//	1.4		2003-08-11	Now flags doors and signs correctly. (Mr. Fixit)
// ================================================================================================

using System;
using System.IO;
using System.Collections;
using Server;
using Server.Gumps;
using Server.Items;
using Server.Scripts.Commands;
using Server.Targeting;

namespace Server
{
	public class MultiFreeze
	{


		// --------------------------------------------------------------------------------
		// Should we show debug information?
		// --------------------------------------------------------------------------------
		private static bool Debug = false;


		// --------------------------------------------------------------------------------
		// The location of the multi files goes here. Change this to your settings!
		// --------------------------------------------------------------------------------
		private static string MultiMUL = @"c:\multi.mul";
		private static string MultiIDX = @"c:\multi.idx";


		// --------------------------------------------------------------------------------
		// The commands is registered here
		// --------------------------------------------------------------------------------
		public static void Initialize()
		{
			Commands.Register( "FreezeMulti", AccessLevel.Administrator, new CommandEventHandler( FreezeMulti_OnCommand ) );
		}


		// --------------------------------------------------------------------------------
		// The FreezeMulti command
		// --------------------------------------------------------------------------------
		[Usage( "FreezeMulti <multiindex>" )]
		[Description( "Makes a targeted area of dynamic items into a multi." )]
		public static void FreezeMulti_OnCommand( CommandEventArgs e )
		{
			
			// Did they include a parameter?
			if ( e.Length == 0 ) {
			   e.Mobile.SendMessage( "Format: FreezeMulti <multiindex>" );
			   return;
			}
			
			// Check the value
			int multiindex = e.GetInt32( 0 );
			if (multiindex > 8181) { e.Mobile.SendMessage( "A MultiIndex goes from 0 to 8181!" ); return; }
			if (multiindex < 0) { e.Mobile.SendMessage( "A MultiIndex goes from 0 to 8181!" ); return; }
			
			// Create the state object
			Point3D start = new Point3D( int.MinValue, int.MinValue, int.MinValue );
			Point3D end = new Point3D( int.MinValue, int.MinValue, int.MinValue );
			StateInfo state = new StateInfo( null, start, end, multiindex );
			
			// Select the range in the map
			BoundingBoxPicker.Begin( e.Mobile, new BoundingBoxCallback( FreezeMultiBox_Callback ), state );
		}


		// --------------------------------------------------------------------------------
		// After the user selects a box where the dynamic items are, we come here
		// --------------------------------------------------------------------------------
		private static void FreezeMultiBox_Callback( Mobile from, Map map, Point3D start, Point3D end, object state )
		{
			
			// Calculate the sizes
			int TotalX = end.X - start.X+1;
			int TotalY = end.Y - start.Y+1;
		        
			// Are the values in legal ranges?
			if (TotalX < 1) { from.SendMessage( "Illegal value!" ); return; }
			if (TotalY < 1) { from.SendMessage( "Illegal value!" ); return; }
			if (TotalX > 64) { from.SendMessage( "Selection too big!" ); return; }
			if (TotalY > 64) { from.SendMessage( "Selection too big!" ); return; }
		        
			// Store values
			StateInfo multifreezeparams = (StateInfo)state;
			multifreezeparams.map = map;
			multifreezeparams.start = start;
			multifreezeparams.end = end;

			// Warning dialog box		        
			SendWarning( from, "Creating Multi", "Multi index:" + multifreezeparams.multiindex.ToString() + "<br>Multi size:" + TotalX.ToString() + "x" + TotalY.ToString() + "<br><br>Are you sure you want to create this multi?", multifreezeparams, new WarningGumpCallback( FreezeMultiWarning_Callback ) );
			
		}


		// --------------------------------------------------------------------------------
		// Shows a warning window
		// --------------------------------------------------------------------------------
		private static void SendWarning( Mobile m, string header, string baseWarning, object state, WarningGumpCallback callback )
		{
			m.SendGump( new WarningGump( 1060635, 30720, String.Format( baseWarning ), 0xFFC000, 420, 400, callback, state ) );
		}


                // --------------------------------------------------------------------------------
		// Comes here after the warning window
		// --------------------------------------------------------------------------------
		private static void FreezeMultiWarning_Callback( Mobile from, bool okay, object state )
		{
			
			// Did the user agree?
			if ( !okay ) return;

			// Get the state object			
			StateInfo multifreezeparams = (StateInfo)state;
			
			// Start freezing
			from.SendMessage( "Freezing! Please wait!" );
			Freeze( from, multifreezeparams.map, multifreezeparams.start, multifreezeparams.end, multifreezeparams.multiindex );

		}


		// --------------------------------------------------------------------------------
		// This function will do the actual Multifreezing
		// --------------------------------------------------------------------------------
		private static void Freeze( Mobile from, Map map, Point3D start, Point3D end, int multiindex )
		{
		
			// Check if there are any items at that location		
			int ItemCount = 0;
			foreach ( Item item in World.Items.Values )
			{			
				// Skip if its the wrong map
				if ( item.Map != map ) continue;				

				// Skip if the item are in a container
				if ( item.Parent != null ) continue;
				
				// Skip if its out of the target box
				if ((item.X<start.X) || (item.X>end.X)) continue;
				if ((item.Y<start.Y) || (item.Y>end.Y)) continue;

				// Increase counter
				ItemCount = ItemCount + 1;
			}
		
			// Did we find anything?
			if (ItemCount < 1) {
				from.SendMessage( "There was not enough items at the target location to freeze into multi.");
				return;
			}

			// Does the files exist?
			if (!File.Exists(MultiMUL) || !File.Exists(MultiIDX)) {
				from.SendMessage( "Cannot find the multifiles in the specified path.");
				return;
			}

                        // Opening files
                        FileStream multimulfs;
                        BinaryWriter multimul;
                        FileStream multiidxfs;
                        BinaryWriter multiidx;
                        try 
                        {
                        	multimulfs = new FileStream(MultiMUL, FileMode.Open);
				multimul = new BinaryWriter(multimulfs);
                        	multiidxfs = new FileStream(MultiIDX, FileMode.Open);
				multiidx = new BinaryWriter(multiidxfs);
			}
			catch
			{
				from.SendMessage( "Unable to open the multi files for writing!" );
				return;
			}			
			
			// Move to the end of the mul file
			multimul.BaseStream.Seek(0, SeekOrigin.End);

			// The location, size and flags of the new multi			
			int multilocation = (int)multimulfs.Length;
			int multisize = 0;
			int multiflags = 0;
			
			// Finding the center offset
			int CenterX = (int)(((end.X - start.X) / 2) + start.X);
			int CenterY = (int)(((end.Y - start.Y) / 2) + start.Y);
			
			// Add a invisible item
			short ArtID = 1;
			short X = 0;
			short Y = 0;
			short Z = 0;
			int Flags = 0;	
			ItemCount = 1;		
			multimul.Write( (short) ArtID);	
			multimul.Write( (short) X);
			multimul.Write( (short) Y);
			multimul.Write( (short) Z);
			multimul.Write( (int) Flags);
			multisize = 12;	

			// Create object container for any possible center objects
			Item CenterItem = null;
			int ReplaceCenter = 0;

			// Here we go again
			foreach ( Item item in World.Items.Values )
			{

				// Skip if its the wrong map
				if ( item.Map != map ) continue;				

				// Skip if the item are in a container
				if ( item.Parent != null ) continue;
				
				// Skip if its out of the target box
				if ((item.X<start.X) || (item.X>end.X)) continue;
				if ((item.Y<start.Y) || (item.Y>end.Y)) continue;
				
				// Set data
				ArtID = (short)(item.ItemID & 0x3FFF);
				X = (short)(item.X - CenterX);
				Y = (short)(item.Y - CenterY);
				Z = (short)(item.Z);
				if ( item is BaseDoor || item is BaseSign ) {
				   Flags = 0;
				} else {
				   Flags = 1;
				}
				
				// If this item are in the center, use it instead of the no draw tile
				if ( (X == 0) && (Y == 0) && (Z == 0) && (ReplaceCenter == 0) ) {
					   CenterItem = item;
					   ReplaceCenter = 1;
					   //ItemCount = ItemCount + 1;
					   continue;
				}

				// Write data to file
				multimul.Write( (short) ArtID);	
				multimul.Write( (short) X);
				multimul.Write( (short) Y);
				multimul.Write( (short) Z);
				multimul.Write( (int) Flags);
				
				// List the items being added
				if (Debug) from.SendMessage( "ArtID: " + ArtID.ToString() + "  Y: " + Y.ToString() + "  X: " + Z.ToString() );
				
				// Increase the size counter
				multisize = multisize + 12;
				
				// Increase counter
				ItemCount = ItemCount + 1;				
				
			}	

			// Update any possible center item
			if (ReplaceCenter != 0) {
				multimul.BaseStream.Seek(multilocation, SeekOrigin.Begin);
				ArtID = (short)(CenterItem.ItemID & 0x3FFF);
				X = (short)(CenterItem.X - CenterX);
				Y = (short)(CenterItem.Y - CenterY);
				Z = (short)(CenterItem.Z);
				Flags = 0;
				
				// List the center item being added
				if (Debug) from.SendMessage( "ArtID: " + ArtID.ToString() + "  Y: " + Y.ToString() + "  X: " + Z.ToString() );
				
				multimul.Write( (short) ArtID);	
				multimul.Write( (short) X);
				multimul.Write( (short) Y);
				multimul.Write( (short) Z);
				multimul.Write( (int) Flags);				
			}

			// Update the index
			multiidx.BaseStream.Seek(multiindex*12, SeekOrigin.Begin);
			multiidx.Write( (int) multilocation);
			multiidx.Write( (int) multisize);
			multiidx.Write( (int) multiflags);

			// Close files			
			multiidx.Close();
			multiidxfs.Close();
			multimul.Close();
			multimulfs.Close();
			
			// Success
			from.SendMessage( ItemCount.ToString() + " items was freezed into multi " + multiindex.ToString() + "." );

		}


		// --------------------------------------------------------------------------------
		// Will take care of the data inbeween calls
		// --------------------------------------------------------------------------------
		private class StateInfo
		{
			public Map map;
			public Point3D start, end;
			public int multiindex;

			public StateInfo( Map m_Map, Point3D m_Start, Point3D m_End, int m_MultiIndex)
			{
				map = m_Map;
				start = m_Start;
				end = m_End;
				multiindex = m_MultiIndex;
			}
		}
		
	
	}
}		