using System; 
using Server.Items; 

namespace Server.Items 
{ 
   	public class GoldenDNA: Item 
   	{ 
		[Constructable]
		public GoldenDNA() : this( 1 )
		{
		}

		[Constructable]
		public GoldenDNA( int amount ) : base( 0x0F91 )
		{
			Stackable = true;
			Weight = 0.0;
			Amount = amount;
			Name = "Golden DNA";
			Hue = 0x499;
		}

            	public GoldenDNA( Serial serial ) : base ( serial ) 
            	{             
           	} 

		public override Item Dupe( int amount )
		{
			return base.Dupe( new GoldenDNA( amount ), amount );
		}

           	public override void Serialize( GenericWriter writer ) 
           	{ 
              		base.Serialize( writer ); 
              		writer.Write( (int) 0 ); 
           	} 
            
           	public override void Deserialize( GenericReader reader ) 
           	{ 
              		base.Deserialize( reader ); 
              		int version = reader.ReadInt(); 
           	} 
        } 
} 