using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Gumps;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class RoundTripCheck
	{
		public static void Initialize()
		{
			Server.Commands.Register( "RoundTripCheck", AccessLevel.GameMaster, new CommandEventHandler( RoundTripCheck_OnCommand ) );
		}

		[Usage( "RoundTripCheck" )]
		[Description( "Verifie l'integrite de WayPoints lies en boucles" )]
		private static void RoundTripCheck_OnCommand( CommandEventArgs e )
		{
			e.Mobile.SendMessage("S�lectionnez un WayPoint.");
			e.Mobile.Target = new myTarget();
		}
		
		///// //// /// // / BEGIN TARGET / // /// //// /////
		private class myTarget : Target
		{
			private WayPoint m_WayPoint;

			public myTarget () : base( -1, false, TargetFlags.None)
			{
			}

			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( targeted is WayPoint )
				{
					m_WayPoint=(WayPoint)targeted;
					WayPoint current=m_WayPoint;
					bool loop=true;
					while (loop)
					{
						if (current == null) {
							from.SendMessage("Le prochain WayPoint n'existe pas.");
							loop=false;
						} else if ( current.Deleted ) {
							from.SendMessage("Le prochain WayPoint a ete supprime.");
							loop=false;
						} else {
							from.MoveToWorld(current.Location,current.Map);
							if (current == m_WayPoint) {
								from.SendMessage("La boucle est ok.");
								loop=false;
							} else {
								current=current.NextPoint;
							}
						}
					}
				} else {
					from.SendMessage("Ce n'est pas un WayPoint.");
				}
			}
		}
		///// //// /// // / END TARGET / // /// //// /////

	}
}