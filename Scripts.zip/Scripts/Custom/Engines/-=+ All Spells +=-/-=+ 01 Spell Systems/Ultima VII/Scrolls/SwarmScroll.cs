using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class SwarmScroll : SpellScroll
	{
		[Constructable]
		public SwarmScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public SwarmScroll( int amount ) : base( 358, 0x1F43, amount )
		{
			Name = "Swarm";
		}
		
		public SwarmScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel <= AccessLevel.Counselor )
			{
				//--<Optional Restrictions>----------<Start>
				from.SendMessage( "Low level staff and players are not allowed to have this scroll." );
				Delete();
			}
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new SwarmScroll( amount ), amount );
		}
	}
}
