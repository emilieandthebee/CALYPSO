using System;
using Server;
using Server.Items;

namespace Server.Items
{
   public class LeafWhirlwindScroll : SpellScroll
   {
      [Constructable]
      public LeafWhirlwindScroll() : this( 1 )
      {
      }

      [Constructable]
      public LeafWhirlwindScroll( int amount ) : base( 551, 0xE39 )
      {
         Name = "leaf whirlwind";
         Hue = 0x58B;
      }

      public LeafWhirlwindScroll( Serial serial ) : base( serial )
      {
      		ItemID=0xE39;
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );

         writer.Write( (int) 0 ); // version
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );

         int version = reader.ReadInt();
      }

      public override Item Dupe( int amount )
      {
         return base.Dupe( new LeafWhirlwindScroll( amount ), amount );
      }
   }
}

