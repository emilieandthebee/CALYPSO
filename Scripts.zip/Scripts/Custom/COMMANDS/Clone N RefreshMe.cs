using System;
using System.Collections;
using System.Reflection;
using Server;
using Server.Items;
using Server.Mobiles;
using Server.Network;
using Server.Targeting;
using Server.Regions;

namespace Server.Scripts.Commands
{
	public class CloneMe
	{
		private class InternalSelector : Target
		{
			public InternalSelector () : base( -1, false, TargetFlags.None )
			{
			}

			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( targeted is Mobile)
				{
					Mobile m=(Mobile)targeted;
					CloneMe.Copy(from,m);
					m.Hidden=true;
					m.Frozen=true;
				}
				else
					from.SendMessage("Ce n'est pas un �tre vivant.");
			}
		}

		public static void Initialize()
		{
			/*
			Server.Commands.Register( "Clone", AccessLevel.GameMaster,
						new CommandEventHandler( CloneMe_OnCommand ) );
			*/
                }
		
		[Usage( "Clone" )]
		[Description( "Copy un Mobile" )]
                 public static void CloneMe_OnCommand( CommandEventArgs e )
		{
			e.Mobile.SendMessage("Qui voulez-vous controler ?");
			e.Mobile.Target = new InternalSelector();
		}

		public static void Copy(Mobile to, Mobile from)
		{
                    to.NameHue = from.NameHue;
                    to.SpeechHue = from.SpeechHue;
                    to.Criminal = from.Criminal;
                    to.Name = from.Name;
                    to.Title = from.Title;
                    to.Female = from.Female;
                    to.Body = from.Body;
                    to.Hue = from.Hue;
                    to.BodyMod = from.Body;
		    to.Hits = from.HitsMax;
		    to.Mana = from.ManaMax;
		    to.Stam = from.StamMax;
                    to.Dex = from.Dex;
       	            to.Int = from.Int;
               	    to.Str = from.Str;
                    to.Fame = from.Fame;
       	            to.Karma = from.Karma;
               	    to.Map = from.Map;
                    to.Location = from.Location;
       	            to.Direction = from.Direction;
                    for (int i=0; i<from.Skills.Length; i++)
       	              to.Skills[i].Base = from.Skills[i].Base;

                  // This code block duplicates all equiped items
                  ArrayList items = new ArrayList( from.Items );
                  for (int i=0; i<items.Count; i++)
                  {
                     Item item = (Item)items[i]; 
                     if((( item != null ) && ( item.Parent == from ) && ( item != from.Backpack )))
                     {
                        Type type = item.GetType();
                        Item newitem = Loot.Construct( type );
                        CopyProperties( newitem, item );
                        to.AddItem( newitem );
                     }
                  }
		}

		private static void CopyProperties ( Item dest, Item src )
		{
			PropertyInfo[] props = src.GetType().GetProperties();
			for ( int i = 0; i < props.Length; i++ )
     			{
				try
			        {
            				if ( props[i].CanRead && props[i].CanWrite )
				               props[i].SetValue( dest, props[i].GetValue( src, null ), null );
			        }
			        catch
			        {
			        }
			}
		}
	}
}


