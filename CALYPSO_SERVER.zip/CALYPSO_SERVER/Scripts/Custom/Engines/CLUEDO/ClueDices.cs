using System;
using Server;
using Server.Network;

namespace Server.Items
{
	public class ClueDices : Item
	{
		[Constructable]
		public ClueDices() : base( 0xFA7 )
		{
			Name="D�s de Kloedu";
			Weight = 1.0;
		}

		public ClueDices( Serial serial ) : base( serial )
		{
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( !from.InRange( this.GetWorldLocation(), 1 ) )
				return;

			this.PublicOverheadMessage( MessageType.Regular, 0, false, string.Format( "*{0} rolls {1}*", from.Name, Utility.Random( 1, 6 ) ) );
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}