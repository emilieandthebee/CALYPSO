using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class AntiHulk
	{
		public static void Initialize()
		{
			Server.Commands.Register( "AntiHulk", AccessLevel.GameMaster, new CommandEventHandler( AntiHulk_OnCommand ) );
		}

		[Usage( "AntiHulk" )]
		[Description( "Permet de sortir de l'infranevralgie proprement" )]
		private static void AntiHulk_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				TechnoIomode.deactivate((PlayerMobile)(e.Mobile));
			}
		}
	}
}