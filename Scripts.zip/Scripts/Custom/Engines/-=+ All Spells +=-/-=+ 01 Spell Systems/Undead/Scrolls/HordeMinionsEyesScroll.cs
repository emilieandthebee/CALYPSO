using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class HordeMinionsEyesScroll : SpellScroll
	{
		[Constructable]
		public HordeMinionsEyesScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public HordeMinionsEyesScroll( int amount ) : base( 122, 0x226F, amount )
		{
			Name = "Horde Minions Eyes";
			Hue = 0x44;
		}
		
		public HordeMinionsEyesScroll( Serial ser ) : base(ser)
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new HordeMinionsEyesScroll( amount ), amount );
		}
	}
}
