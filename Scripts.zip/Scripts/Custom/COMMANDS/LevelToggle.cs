using System;
using Server;
using Server.Accounting;
using Server.Items;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class LevelToggle
	{
		public static void Initialize()
		{
			Server.Commands.Register(
				"LevelToggle",
				AccessLevel.Player,
				new CommandEventHandler( LevelToggle_OnCommand ) );
		}

		[Usage( "LevelToggle" )]
		[Description( "Toggle your access level with player" )]
		private static void LevelToggle_OnCommand( CommandEventArgs e )
		{
			if (((Account)(e.Mobile.Account)).AccessLevel==AccessLevel.Player)
			{
				e.Mobile.SendMessage("Cette commande est d�sactiv�e.");
				return;
			}
		  	if ( e.Mobile.AccessLevel== AccessLevel.Player )
				e.Mobile.AccessLevel=((Account)(e.Mobile.Account)).AccessLevel;
			else
				e.Mobile.AccessLevel=AccessLevel.Player;
			e.Mobile.SendMessage("Votre level est maintenant {0}.",e.Mobile.AccessLevel);
			if ( e.Mobile.AccessLevel == AccessLevel.Player )
				e.Mobile.Blessed=false;
		}
	}
}

namespace Server.Misc
{
	public class LevelToggle : Item
	{
		[Constructable]
		public LevelToggle() : base( 574 )
		{
			Visible = true;
			Weight = 0;
			Name = "une pierre de changement de level";
		        LootType=LootType.Blessed;
		}

		public override bool HandlesOnSpeech{ get{ return true; } }

		public override void OnSpeech( SpeechEventArgs e )
		{
			if ( !e.Handled )
			{
				Mobile m = e.Mobile;
				if ( !m.Player )
					return;
				if (((Account)(e.Mobile.Account)).AccessLevel==AccessLevel.Player)
					return;
				string cmd = e.Speech;
				if (cmd.Length > 0)
				if ( cmd[0] == '.' )
				{
					cmd	= '[' + cmd.Remove(0,1);
					Commands.Handle( m, cmd );
				}
			}
		}
		
		public LevelToggle( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}

		public override void OnDoubleClick(Mobile from)
		{
		  	if ( from.AccessLevel== AccessLevel.Player )
				from.AccessLevel=((Account)(from.Account)).AccessLevel;
			else
				from.AccessLevel=AccessLevel.Player;
			from.SendMessage("Votre level est maintenant {0}.",from.AccessLevel);
			if ( from.AccessLevel == AccessLevel.Player )
				from.Blessed=false;

		}
	}
}
