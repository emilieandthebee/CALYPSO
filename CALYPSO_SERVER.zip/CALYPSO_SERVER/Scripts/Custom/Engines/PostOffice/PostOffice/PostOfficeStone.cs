using System; 
using Server;
using Server.Gumps;
using Server.Mobiles;

namespace Server.Items
{
	public class PostOfficeStone : Item
	{
		[Constructable]
		public PostOfficeStone() : base( 0xED4 )
		{
			Movable = false;
			Name = "Post Office";
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if( from.InRange( this.GetWorldLocation(), 3 ) ) 
			{
				if ( from.Backpack.FindItemByType( typeof( AddressBook ) ) != null )
				{
					from.SendGump( new PostOfficeGump( from, "", "" ) );
				}
				else
					from.SendMessage("You need an address book to use this");
			} 
			else 
			{
		    		from.SendLocalizedMessage( 500446 ); // That is too far away.
			}
		}
		
		public PostOfficeStone( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 

			writer.Write( (int) 0 ); // version 
		}

		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 

			int version = reader.ReadInt(); 
		} 
	}
}
