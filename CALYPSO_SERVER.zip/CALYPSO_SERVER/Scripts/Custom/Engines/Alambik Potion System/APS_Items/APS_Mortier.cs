/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;
using System.IO;
using System.Collections;
/*2.0*
using System.Collections.Generic;
using Server.Commands;
*****/

namespace Server.Items
{
	public class APS_Mortier : Item
	{
		////////////////////////
		// GENERAL PARAMETERS
		// The unique key defines a unique combination of formula. Change it for your own server;
		public static ulong		APS_UniqueKey = 3452874;				// Better use the 7 decimal number for the aleas
		// If you want to change the chance to find a potion, change this:
		public static double  	APS_ChanceToHaveEffect=0.005; 				// (ex: 0.01 is 1 percent chance)
		// If you want to modify how many of 1 given reagent can be used, modify the following:
		// Note that the number shall be a set of 2^n.
		// Examples: 1 bits: 1 reagents max
		//           2 bits: 3 reagents max
		//           3 bits: 7 reagents max
		//           etc...
		public static int  		APS_MaxNumberForOneReagent=3; 				// (ex: 7, is a 8 bit encoding value (0 to 7))
		public static int  		APS_OneReagentEncodingBits=2; 				// (ex: 0 to 7 > 8 bits > mask 111 > 3 bits encoded)
		// The chance the tools of alchemy does break during an operation is defined here:
		public static double  	APS_ChanceToBreak=0.01; 					//(ex: 0.01 is 1 percent chance)
		// Constraint N°1 for making a potion: have a minimum of reagents (whatever types)
		public static int 		APS_MinNumberOfTotalReagants = 2;
		// Constraint N°2 for making a potion: use at least a minimum of different types of reagents (whatever the total is)
		public static int 		APS_MinNumberOfDifferentReagentsTypes = 2;
		// When having the chance to get a double power potion, the secondary power increases the main power.
		public static double 	APS_SecondPowerImpactOnMainPower = 0.25;	//(ex: 0.2 increases the main power with 20% of second power)
		// Moon impacts can be changed here:
		public static double 	APS_NewMoonEffectIncrease  = 0.3;			//(ex:  0.3 is 30% power increase)
		public static double 	APS_FullMoonEffectIncrease = 0.15;			//(ex: -0.3 is 30% power decrease)
		public static ulong		APS_AddedKeyGrowingMoon = 54321;			//(this change potions formula on growing moon (set zero for none))
		// The followinf flag is used to reserve the first declared for special formula
		public static bool 		APS_UseDecicatedFormulaReagent = true;
		////////////////////////
		
		public static bool 		APS_debug=false;					// Dev purpose
		public static string  	APS_EmptyFormula="";				// will be computed	
		public static int  		APS_NumberOfReagents=0;				// will be computed	
		public static ulong 	APS_HighestNumber=0;				// will be computed
/*** .Net 2.0+ ***
		public static Dictionary<Type, int> 	APS_PossibleReagents;		// Reagent type against position in string formula
		public static Dictionary<int, Type> 	APS_InvPossibleReagents;	// Position in string formula against reagent type
		public static Dictionary<int, string> 	APS_PlayerLastFormula;		// Last formula done by a player, if any (for redo in a keg)
****  .Net 1.1-***/
		public static Dictionary_Type_int 		APS_PossibleReagents;		// Reagent type against position in string formula
		public static Dictionary_int_Type 		APS_InvPossibleReagents;	// Position in string formula against reagent type
		public static Dictionary_int_string 	APS_PlayerLastFormula;		// Last formula done by a player, if any (for redo in a keg)
/****/
		public static string	APS_ReagentsNamesList="";			// Used for report generation
		public static void Initialize()
		{
/*** .Net 2.0+ ***
			APS_PossibleReagents 	= new Dictionary<Type, int>();
			APS_InvPossibleReagents	= new Dictionary<int, Type>();
			APS_PlayerLastFormula 	= new Dictionary<int, string>();
****  .Net 1.1-***/
			APS_PossibleReagents 	= new Dictionary_Type_int();
			APS_InvPossibleReagents	= new Dictionary_int_Type();
			APS_PlayerLastFormula 	= new Dictionary_int_string();
/****/
			APS_NumberOfReagents 	= 0;
			/////////////////////////////////////////////////////////
			// Here you add the reagents you want to be able to use
			/////////////////////////////////////////////////////////
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(GraveDust));APS_ReagentsNamesList+="GraveDust|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(BlackPearl));APS_ReagentsNamesList+="BlackPearl|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(Bloodmoss));APS_ReagentsNamesList+="Bloodmoss|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(Garlic));APS_ReagentsNamesList+="Garlic|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(Ginseng));APS_ReagentsNamesList+="Ginseng|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(MandrakeRoot));APS_ReagentsNamesList+="MandrakeRoot|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(Nightshade));APS_ReagentsNamesList+="Nightshade|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(SpidersSilk));APS_ReagentsNamesList+="SpidersSilk|";
			APS_NumberOfReagents++; APS_InvPossibleReagents.Add(APS_NumberOfReagents,typeof(SulfurousAsh));APS_ReagentsNamesList+="SulfurousAsh|";
			for (int k=1;k<=APS_NumberOfReagents;k++)
				APS_PossibleReagents.Add(InvLookup(k), k);
			/////////////////////////////////////////////////////////
			int i=0;
			string str="0";
			str=str.PadLeft(APS_OneReagentEncodingBits+1,'0');
			for (i=0;i<APS_NumberOfReagents;i++)
			{
				if ( i > 0 )
					APS_EmptyFormula =  APS_EmptyFormula + "|";
				APS_EmptyFormula = APS_EmptyFormula + str;
			}
		}

		public static int MaxReagents=APS_MaxNumberForOneReagent; // This set how many of a reagent type can be used in a Mortar

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual string CurrentFormula
		{
			get { return Formula; }
			set { Formula = value; }
		}
		public string Formula;
		public int ReagentsCount;

		public static int Lookup( Type key )
		{
			int e = -1;
/*2.0*
			APS_PossibleReagents.TryGetValue( key, out e );
*1.0*/
			if (APS_PossibleReagents.Contains(key)) e=APS_PossibleReagents[key];
/****/
			return e;
		}

		public static Type InvLookup( int key )
		{
			Type e = null;
/*2.0*
			APS_InvPossibleReagents.TryGetValue( key, out e );
*1.0*/
			if (APS_InvPossibleReagents.Contains(key)) e=APS_InvPossibleReagents[key];
/****/
			return e;
		}

		public static string LookupPlayerLastFormula( int key )
		{
			string e = APS_EmptyFormula;
/*2.0*
			APS_PlayerLastFormula.TryGetValue( key, out e );
*1.0*/
			if (APS_PlayerLastFormula.Contains(key)) e=APS_PlayerLastFormula[key];
/****/
			return e;
		}

		public static void GenerateList()
		{
			System.Console.WriteLine("APS Generation started...");
			MoonPhase phase;
			ulong jj;
			string str="";
			str=str.PadLeft((APS_NumberOfReagents+(APS_UseDecicatedFormulaReagent?-1:0))*(APS_OneReagentEncodingBits+1),'1');
			ulong value0=0;
			ulong value1=Convert.ToUInt64(str,2);
			int mpswitch = 2;
			if (APS_AddedKeyGrowingMoon == 0) 
				mpswitch=1;
			string filename;
			for (int mp=0;mp<mpswitch;mp++)
			{
				if (mp == 0)
				{
					phase = MoonPhase.FirstQuarter;
					filename = "APS_ToFullMoon.csv";
					System.Console.WriteLine("To Full Moon generation...");
				} else {
					phase = MoonPhase.LastQuarter;
					filename = "APS_ToNewMoon.csv";
					System.Console.WriteLine("To New Moon generation...");
				}
				jj=0;
				filename = Path.Combine( Core.BaseDirectory , filename);
				using ( StreamWriter op = new StreamWriter( filename ) )
				{
					op.WriteLine("REAGENTS:");
					op.WriteLine("1 bit for transformation and {0} bits for number of reagents.",APS_OneReagentEncodingBits);
					op.WriteLine("FORMULAS:");
					op.WriteLine("{0}Effect|Power|Second Effect|Second Power",APS_ReagentsNamesList);
					for (ulong ii=value0;ii<=value1;ii++)
					{
						bool result;
						str=BackToFormula(ii);
						result = PreCheckFormula(str);
						if (result) 
							result = CheckFormula(ii,phase);
						if (result)
						{
							jj++;
							APS_Potion.APS_PotionEffect m_PotionEffect=APS_Potion.APS_PotionEffect.NoEffect;
							APS_Potion.APS_PotionEffect m_SecondPotionEffect=APS_Potion.APS_PotionEffect.NoEffect;
							double m_Power=0.0;
							double m_SecondPower=0.0;
							int PotionItemID;
							ulong val0 = APS_Mortier.FirstPseudoAlea(ii,phase);						
		/*************************************************************************************************************/
		/* SEE APS_Potion */
		/*************************************************************************************************************/
				ulong val1 = APS_Mortier.NextPseudoAlea (val0); 		// Effect category (+/-/Neutral), Double effect check
				ulong val2 = APS_Mortier.NextPseudoAlea (val1); 		// Effect
				ulong val3 = APS_Mortier.NextPseudoAlea (val2);			// Power
				ulong val4 = APS_Mortier.NextPseudoAlea (val3); 		// Second Effect
				ulong val5 = APS_Mortier.NextPseudoAlea (val4);			// Second Power
				/******** COLOR ********/			
				PotionItemID = 3847 + (int)(val0 % 7); // Pseudo-random color, uniq per formula
				/******** EFFECT CATEGORY ********/			
				int EffectCategory = ((int)(val1/10) % 3)-1; // -1 = negative , 0 = Neutral , +1 = Positive
				/******** DOUBLE EFFECT CHECK ********/
				bool IsDoubleEffect = ((int)((val1/100) % 3) == 0); // The "Modulo 3 = zero" equivalent to 25% chance 
				/******** EFFECT ********/
				switch (EffectCategory)
				{
					case 1: 
						m_PotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.PositiveEffect[(int)(val2 % (ulong)APS_Potion.PositiveEffect.Count)]); break;
					case 0: 
						m_PotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.NeutralEffect[(int)(val2 % (ulong)APS_Potion.NeutralEffect.Count)]); break;
					case -1: 
						m_PotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.NegativeEffect[(int)(val2 % (ulong)APS_Potion.NegativeEffect.Count)]); break;
					default: 
						break;
				}
				/******** POWER ********/
				m_Power=((double)(val2%1000))/1000.0;
				/******** Second EFFECT ********/
				if (IsDoubleEffect)
				{
					// We must find an effect that is DIFFERENT from the primary effect.
					// Moreover, if it is a positive effect, it should be a negative one (and inverse)
					bool otherEffectFound = false;
					switch (EffectCategory)
					{
						case 1: 
							for (int i=0;(!otherEffectFound && ( i < APS_Potion.NegativeEffect.Count ));i++)
							{
								m_SecondPotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.NegativeEffect[(int)(val4+(ulong)i) % APS_Potion.NegativeEffect.Count]);
								if ( m_SecondPotionEffect != m_PotionEffect)
									otherEffectFound = true;
							}
							break;
						case 0:
							otherEffectFound = false;
							break;
						case -1: 
							for (int i=0;(!otherEffectFound && ( i < APS_Potion.PositiveEffect.Count ));i++)
							{
								m_SecondPotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.PositiveEffect[(int)(val4+(ulong)i) % APS_Potion.PositiveEffect.Count]);
								if ( m_SecondPotionEffect != m_PotionEffect)
									otherEffectFound = true;
							}
							break;
						default: 
							break;
					}
					if (!otherEffectFound)
						m_SecondPotionEffect = APS_Potion.APS_PotionEffect.NoEffect; // May occur, so let's deal with it.					
				} else {
					m_SecondPotionEffect = APS_Potion.APS_PotionEffect.NoEffect;
				}
				/******** Second POWER ********/
				if (IsDoubleEffect)
				{
					if (m_SecondPotionEffect != APS_Potion.APS_PotionEffect.NoEffect)
					{
						m_SecondPower=((double)(val5%1000))/1000.0;
						// A double effect has a drawback effect but it increases the main power 
						m_Power=m_Power*(1.0+m_SecondPower*APS_Mortier.APS_SecondPowerImpactOnMainPower);
					}
				}
				if ( phase == MoonPhase.FullMoon)
				{
					m_Power=m_Power*(1.0+APS_Mortier.APS_FullMoonEffectIncrease);
					m_SecondPower=m_SecondPower*(1.0+APS_Mortier.APS_FullMoonEffectIncrease);
				} else if ( phase == MoonPhase.NewMoon)
				{
					m_Power=m_Power*(1.0+APS_Mortier.APS_NewMoonEffectIncrease);
					m_SecondPower=m_SecondPower*(1.0+APS_Mortier.APS_NewMoonEffectIncrease);
				}
	/*************************************************************************************************************/
							op.WriteLine("{0}|{1}|{2}|{3}|{4}",
								str,m_PotionEffect,m_Power,m_SecondPotionEffect,m_SecondPower);
							if ((ii % (value1/(ulong)100000)) == 0)
							System.Console.WriteLine("{0}%",(double)((int)((1000*ii)/value1)/10));
						}
					}
				}
			}
			System.Console.WriteLine("APS Generation finished.");
		}
		
		public static int GetReageantsNumberFromFormula(string theformula, int reagenttype )
		{
			if (APS_debug) System.Console.WriteLine("GetReageantsNumberFromFormula theformula={0} reagenttype={1}",theformula,reagenttype);
			string[] reagents = theformula.Split('|');
			if (reagents.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return 0;
			}
			string str=reagents[reagenttype-1]; 
			// The first bit is the transformation flag
			int val = Convert.ToInt32( str.Substring(1,str.Length-1), 2 );
			if (str[0] == '1')
				val = -val;
			if (APS_debug) System.Console.WriteLine("GetReageantsNumberFromFormula returns {0}",val);
			return val;
		}

		public static string SetReageantsNumberToFormula(string theformula, int reagenttype, int value )
		{
			if (APS_debug) System.Console.WriteLine("SetReageantsNumberToFormula theformula={0} reagenttype={1} value={2}",theformula,reagenttype,value);
			string newformula="";
			string[] reagents = theformula.Split('|');
			if (reagents.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return APS_EmptyFormula;
			}
			int i;
			for (i=0;i<reagents.Length;i++)
			{
				if (i>0)
					newformula=newformula+"|";
				if (reagenttype == i+1)
				{
					if (value >= 0)
						newformula = newformula + "0";
					else
						newformula = newformula + "1";
					newformula=newformula+Convert.ToString(value,2).PadLeft(APS_OneReagentEncodingBits,'0');
			} else {
					newformula=newformula+reagents[i];
				}
			}
			if (APS_debug) System.Console.WriteLine("SetReageantsNumberToFormula returns {0}",newformula);
			return newformula;
		}

		public static string AddToFormula( string theformula1, string theformula2 )
		{
			if (APS_debug) System.Console.WriteLine("AddToFormula theformula1={0} theformula2={1}",theformula1,theformula2);
			string newformula="";
			string[] reagents1 = theformula1.Split('|');
			if (reagents1.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return APS_EmptyFormula;
			}
			string[] reagents2 = theformula2.Split('|');
			if (reagents2.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return APS_EmptyFormula;
			}
			int i;
			int value;
			int value1;
			int value2;
			for (i=0;i<reagents1.Length;i++)
			{
				if (i>0)
					newformula=newformula+"|";
				value1=Convert.ToInt32((reagents1[i]).Substring(1,(reagents1[i]).Length-1),2);
				value2=Convert.ToInt32((reagents2[i]).Substring(1,(reagents2[i]).Length-1),2);
				value=value1+value2;
				if (value > APS_MaxNumberForOneReagent)
					value = APS_MaxNumberForOneReagent;
				if ( ((reagents1[i])[0] == '1') || ((reagents2[i])[0] == '1'))
					newformula=newformula+'1';
				else
					newformula=newformula+'0';
				newformula=newformula+(Convert.ToString(value,2)).PadLeft(APS_OneReagentEncodingBits,'0');
			}
			if (APS_debug) System.Console.WriteLine("AddToFormula returns {0}",newformula);
			return newformula;
		}
		
		public static string AddToFormula( string theformula, int quantity, int reagenttype )
		{
			if (APS_debug) System.Console.WriteLine("AddToFormula theformula={0} quantity={1} reagenttype={2}",theformula,quantity,reagenttype);
			string newformula;
			bool transformed;
			int value = GetReageantsNumberFromFormula (theformula,reagenttype);
			transformed = (value < 0) || (quantity < 0);
			if (value < 0)
				value = -value;
			if (quantity < 0)
				quantity = -quantity;
			value = value + quantity;			
			if (value > APS_MaxNumberForOneReagent)
				value = APS_MaxNumberForOneReagent;
			if (transformed)
				value = -value;
			newformula=SetReageantsNumberToFormula(theformula,reagenttype,value);
			if (APS_debug) System.Console.WriteLine("SetReageantsNumberToFormula returns {0}",newformula);
			return newformula;
		}
		
		public static string Transform( string theformula )
		{
			string newformula="";
			string[] reagents = theformula.Split('|');
			if (reagents.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return APS_EmptyFormula;
			}
			int i;
			for (i=0;i<reagents.Length;i++)
			{
				string str=(reagents[i]).Substring(1,(reagents[i]).Length-1);
				int val=Convert.ToInt32(str,2);
				if (i > 0)
					newformula=newformula+"|";	
				if (val==0)					
					newformula=newformula+"0";	
				else
					newformula=newformula+"1";
				newformula=newformula+str;
			}
			return newformula;
		}

		public static string BackToFormula( ulong theformulavalue )
		{
			string result="";
			string str=(Convert.ToString((Int64)theformulavalue,2)).PadLeft(APS_NumberOfReagents*(APS_OneReagentEncodingBits+1),'0');
			for (int i=0;i<APS_NumberOfReagents;i++)
			{	
				if (i > 0) 
					result = result + "|";
				for(int j=0;j<(APS_OneReagentEncodingBits+1);j++)
				{
					result=result+str[i*(APS_OneReagentEncodingBits+1)+j];
				}
			}
			return result;
		}
		
		public static ulong ComputeFormula( string theformula )
		{
			ulong  longvalue;
			string binvalue;
			string[] reagents = theformula.Split('|');
			if (reagents.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return 0;
			}
			int i;
			binvalue="";
			for (i=0;i<reagents.Length;i++)
			{
				binvalue = binvalue+reagents[i];
			}
			longvalue=Convert.ToUInt64(binvalue,2);
			return longvalue;
		}

		public static bool PreCheckFormula( string theformula )
		{
			// Check if there are enough reagents
			// Of different kinds and totaly
			string[] reagents = theformula.Split('|');
			if (reagents.Length != APS_NumberOfReagents)
			{
				System.Console.WriteLine("Error in APS system while reading a wrong formula.");
				return false;
			}
			int totalregcount=0;
			int differentregtypecount=0;
			int i;
			bool Enough=false;
			for (i=0;i<reagents.Length;i++)
			{
				string str=reagents[i]; 
				// The first bit is the transformation flag
				int val = Convert.ToInt32( str.Substring(1,str.Length-1), 2 );
				if ( val > 0 )
				{
					if (APS_UseDecicatedFormulaReagent && (i == 0))
						return false; // Avoid bad reporting with custom formula's
					totalregcount = totalregcount + val;
					differentregtypecount++;
					// Already achieved the constraints?
					if ((totalregcount >= APS_MinNumberOfTotalReagants) && (differentregtypecount >= APS_MinNumberOfDifferentReagentsTypes))
						Enough = true;
				} else {
					if (str[0] == '1')
						return false; // No reagents (zero) but with a transformation = Not Allowed 
				}
			}
			return Enough;			
		}
		
		public static bool CheckFormula( ulong theformulavalue, MoonPhase phase)
		{
			// Check the pseudo probability
			double result=((double)(FirstPseudoAlea(theformulavalue, phase) % 1000))/1000;
			return (result <= APS_ChanceToHaveEffect);
		}

		public static ulong FirstPseudoAlea(ulong value, MoonPhase phase)
		{
			ulong offset=0;
			switch (phase)
			{
				case MoonPhase.WaxingCrescentMoon:
				case MoonPhase.FirstQuarter:
				case MoonPhase.WaxingGibbous:
				case MoonPhase.FullMoon:
					offset = APS_AddedKeyGrowingMoon;
					break;
				default:
					break;
			}
			const ulong a=16807, m=2147483647UL;
			ulong ret;
			ret=value+APS_UniqueKey+offset; //add a uniq key
			for (ulong i=1;i<1+value%10;i++)
				ret = a*ret % m; // alea passes
			return ret;
		}

		public static ulong NextPseudoAlea(ulong value)
		{
			const ulong a=16807, m=2147483647UL;
			return a*value % m;
		}

		public override void OnDoubleClick( Mobile from )
		{ if ( Utility.RandomDouble() < APS_ChanceToBreak/5.0 )
			{
				from.SendMessage("Oups... ça s'est cassé...");
				Delete();
				return;
			}
		  from.SendMessage("Selectionnez quelquechose que vous voulez mettre dedans.");
		  from.Target = new InternalTarget( this ); }
		private class InternalTarget : Target
		{
			private APS_Mortier m_thing;
			public InternalTarget( APS_Mortier thing ) : base( -1, false, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( !( targeted is Item ) ) {
					from.SendMessage( "Il faut que ce soit un objet..." );
					return;					
				}
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else {
					m_thing.LikeDragDrop( from, (Item)targeted );
				}
			}
		}
		
		public void SelfClick( Mobile from )
		{
				ReagentsCount = 0;
				Formula = APS_EmptyFormula;
				from.SendMessage( "Vous videz le mortier." );				
		}

		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}
		
		public bool LikeDragDrop( Mobile from, Item dropped )
		{
			if (APS_PossibleReagents.ContainsKey(dropped.GetType()))
			{
				if ( ReagentsCount + dropped.Amount > MaxReagents )
				{
					from.SendMessage( "Il n'y a plus de place pour cela dans le mortier...");
				} else {
					from.SendMessage( "Vous pilez le réactif" );
					Formula = AddToFormula(Formula,dropped.Amount,Lookup(dropped.GetType()));
					dropped.Delete();
					ReagentsCount = ReagentsCount + dropped.Amount;
					Effects.PlaySound(from.Location, from.Map, 0x242); 
					// 0x242 is the mortar sound, 0x240 is the sound of falling liquid in bottle 
				} 
			} else {
				from.SendMessage( "Piler ceci ne vous mènera à rien..." );
			}
			return false;
		}

		[Constructable]
		public APS_Mortier() : base( 0xE9B )
		{
			InitializeItemVaraiables();
		}

		public void InitializeItemVaraiables()
		{
			Weight = 1.0;
			Name = "Un mortier et son pilon";
			ReagentsCount = 0;
			Formula = APS_EmptyFormula;
		}
		
		public APS_Mortier( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (string) Formula );
			writer.Write( (int) ReagentsCount );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			Formula = reader.ReadString();
			ReagentsCount = reader.ReadInt();
			int version = reader.ReadInt();
		}
	}
}

// OLD CODE, TO BE DELETED IF TESTS PASSED
			/*
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(BlackPearl), APS_NumberOfReagents);APS_ReagentsNamesList+="BlackPearl|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(Bloodmoss), APS_NumberOfReagents);APS_ReagentsNamesList+="Bloodmoss|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(Garlic), APS_NumberOfReagents);APS_ReagentsNamesList+="Garlic|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(Ginseng), APS_NumberOfReagents);APS_ReagentsNamesList+="Ginseng|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(MandrakeRoot), APS_NumberOfReagents);APS_ReagentsNamesList+="MandrakeRoot|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(Nightshade), APS_NumberOfReagents);APS_ReagentsNamesList+="Nightshade|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(SpidersSilk), APS_NumberOfReagents);APS_ReagentsNamesList+="SpidersSilk|";
			APS_NumberOfReagents++; APS_PossibleReagents.Add(typeof(SulfurousAsh), APS_NumberOfReagents);APS_ReagentsNamesList+="SulfurousAsh|";
			*/
