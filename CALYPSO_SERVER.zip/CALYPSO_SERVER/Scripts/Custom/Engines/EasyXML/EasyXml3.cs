using System;
using System.Xml;
using System.IO;
using System.Collections;

namespace Server
{	
	public class EasyXml
	{
		public delegate ArrayList ConvertToType( string[] data );
		public delegate string[] ConvertFromType( Array array );

		private string[] CurrentList = null;
		public XmlNode root = null;
		public XmlNode newroot = null;
		public string CurrentDirectory = "";
		public string CurrentPath { get { return Path.Combine( CurrentDirectory, Filename ); } }
		public string Filename = "";
		public string Title = "";
		public XmlTextWriter Writer = null;

		public EasyXml( string directory, string filename, string title )
		{
			CurrentDirectory = directory;
			Filename = filename;
			Title = title;
		}

		public void StartWriting()
		{
			if ( !Directory.Exists( CurrentDirectory ) )
				Directory.CreateDirectory( CurrentDirectory );
			Writer = new XmlTextWriter( new StreamWriter( CurrentPath ) );
			Writer.Formatting = Formatting.Indented;
			Writer.IndentChar = '\t';
			Writer.Indentation = 1; 
			Writer.WriteStartDocument( true );
			Writer.WriteStartElement( Title );
		}

		public void StopWriting()
		{
			Writer.WriteEndElement();
			Writer.Close();
			Writer = null;
		}

		public void WriteCatagory( string name )
		{
			name = ChangeToFormat( name );
			Writer.WriteStartElement( name );
		}

		public void CloseCatagory()
		{
			if ( Writer != null )
				Writer.WriteEndElement();
			else if ( newroot.ParentNode == root )
				newroot = null;
			else
				newroot = newroot.ParentNode;	
		}

		public void Write( string name, object value )
		{
			name = ChangeToFormat( name );
			Writer.WriteStartElement( name );
			Writer.WriteString( value.ToString() );
			Writer.WriteEndElement();
		}

		public void ClearList()
		{
			CurrentList = null;
		}

		public void AddToList( string s )
		{
			if ( CurrentList == null )
			{
				CurrentList = new string[] { s };
				return;
			}
			string[] list = new string[ CurrentList.Length + 1 ];
			for ( int i = 0; i < CurrentList.Length; ++i )
			{
				list[i] = CurrentList[i];
			}
			list[ CurrentList.Length ] = s;
			CurrentList = list;
		}

		public void AddToList( Array array, bool convert )
		{
			Type type = array.GetType();
			if ( !convert || type.ToString() == "System.String[]" || type.ToString() == "System.Int16[]" || type.ToString() == "System.Int32[]" || type.ToString() == "System.Int64[]" || type.ToString() == "System.Boolean[]" || type.ToString() == "System.DateTime[]" )
			{
				foreach ( object o in array )
					AddToList( o.ToString() );
			}
			else
				AddToList( ConverterInfo.Handle( array ), false );
		}

		public void AddToList( ArrayList array, Type type, bool convert )
		{
			if ( !convert || type.ToString() == "System.String[]" || type.ToString() == "System.Int16[]" || type.ToString() == "System.Int32[]" || type.ToString() == "System.Int64[]" || type.ToString() == "System.Boolean[]" || type.ToString() == "System.DateTime[]" )
			{
				foreach ( object o in array )
					AddToList( o.ToString() );
			}
			else
				AddToList( ConverterInfo.Handle( array.ToArray( type ) ), false );
		}

		public void WriteList( string name )
		{
			name = ChangeToFormat( name );
			if ( CurrentList == null )
				return;
			Writer.WriteStartElement( name );

			for ( int i = 0; i < CurrentList.Length; ++i )
			{
				Writer.WriteStartElement( "list" );
				Writer.WriteString( CurrentList[i] );
				Writer.WriteEndElement();
			}
			Writer.WriteEndElement();
		}

		public void StartReading()
		{
			if ( !File.Exists( CurrentPath ) )
			{
				Console.WriteLine( CurrentPath + " does not exist when EasyXML: Reader : tryed to open it for loading" );
				return;
			}
			XmlDocument loaddoc = new XmlDocument();
			loaddoc.Load( CurrentPath );
			root = loaddoc[ Title ];
		}

		public void StopReading()
		{
			root = null;
			newroot = null;
		}

		private string ChangeToFormat( string name )
		{
			string name2 = "";
			for ( int i = 0; i < name.Length; ++i )
			{
				if ( name[i] == ' ' )
					name2 += "_";
				else
					name2 += (name[i]).ToString();
			}
			return name2;
		}

		public string Read( string name )
		{
			name = ChangeToFormat( name );
			try {
 				if ( newroot == null )
					return (root[ name ]).InnerText;

				return (newroot[ name ]).InnerText;
			}
			catch { return ""; }
		}

		public void OpenCatagory( string name )
		{
			name = ChangeToFormat( name );
			try {
				if ( newroot == null )
					newroot = root[ name ];
				else
					newroot = newroot[ name ];
			} catch {}
		}

		private string[] ReadList( string name )
		{
			name = ChangeToFormat( name );
			try {
				XmlElement myroot;
				if ( newroot == null )
					myroot = root[name] as XmlElement;
				else
					myroot = newroot[name] as XmlElement;
				XmlNodeList list = myroot.GetElementsByTagName( "list" );
				string[] result = new string[ list.Count ];
				for ( int i = 0; i < list.Count; ++i )
					result[i] = list[i].InnerText;

				return result;
			}
			catch { return new string[0]; }
		}

		public ArrayList ReadList( string name, Type type )
		{
			ArrayList result = new ArrayList();
			string[] list = ReadList( name );
			if ( type == null )
				type = typeof( string );
			switch ( type.ToString() )
			{
				case "System.String" :
				{
					foreach ( string s in list )
						result.Add( s );
					break;
				}
				case "System.Int16" :
				{
					foreach ( string s in list )
						result.Add( Convert.ToInt16( s ) );
					break;
				}
				case "System.Int32" :
				{
					foreach ( string s in list )
						result.Add( Convert.ToInt32( s ) );
					break;
				}
				case "System.Int64" :
				{
					foreach ( string s in list )
						result.Add( Convert.ToInt64( s ) );
					break;
				}
				case "System.Boolean" :
				{
					foreach ( string s in list )
						result.Add( Convert.ToBoolean( s ) );
					break;
				}
				case "System.DateTime" :
				{
					foreach ( string s in list )
						result.Add( Convert.ToDateTime( s ) );
					break;
				}
				default:
				{
					result = ConverterInfo.Handle( type, list );
					break;
				}
			}

			return result;
		}

		public class ConverterInfo
		{
			private static ArrayList m_Converters = new ArrayList();
			public static ArrayList Converters { get { return m_Converters; } }

			public static ArrayList Handle( Type type, string[] list )
			{
				foreach ( ConverterInfo info in m_Converters )
				{
					foreach ( Type t in info.Types )
						if ( info.ExactType ? t == type : type.IsSubclassOf( t ) )
							return info.ConvertTo( list );
				}
				Console.WriteLine( "No converter was found for the type " + type.ToString() + ", while loading, returning blank list" );
				return new ArrayList();
			}

			public static string[] Handle( Array array )
			{
				string temp = array.GetType().ToString();
				string typename = "";
				for ( int i = 0; i < temp.Length - 2; ++i )
					typename += temp[i];
				Type type = Type.GetType( typename );
				foreach ( ConverterInfo info in m_Converters )
				{
					foreach ( Type t in info.Types )
						if ( info.ExactType ? t == type : type.IsSubclassOf( t ) )
							return info.ConvertFrom( array );
				}
				Console.WriteLine( "No converter was found for the type " + typename + ", while saving, returning blank list" );
				return new string[0];
			}

			public static void Add( Type type, EasyXml.ConvertToType convertto, ConvertFromType convertfrom, bool exacttype )
			{
				m_Converters.Add( new ConverterInfo( new Type[] { type }, convertto, convertfrom, exacttype ) );
			}

			public static void Add( Type[] type, EasyXml.ConvertToType convertto, EasyXml.ConvertFromType convertfrom, bool exacttype )
			{
				m_Converters.Add( new ConverterInfo( type, convertto, convertfrom, exacttype ) );
			}

			public Type[] Types;
			public EasyXml.ConvertToType ConvertTo;
			public EasyXml.ConvertFromType ConvertFrom;
			public bool ExactType;

			private ConverterInfo( Type[] type, EasyXml.ConvertToType convertto, EasyXml.ConvertFromType convertfrom, bool exacttype )
			{
				Types = type;
				ConvertTo = convertto;
				ConvertFrom = convertfrom;
				ExactType = exacttype;
			}
		}
	}
}