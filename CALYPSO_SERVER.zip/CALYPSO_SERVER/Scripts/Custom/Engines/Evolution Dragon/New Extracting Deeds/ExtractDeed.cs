using System; 
using Server.Network; 
using Server.Prompts; 
using Server.Items; 
using Server.Mobiles;
using Server.Targeting; 

namespace Server.Items 
{ 
   public class ExtractTarget : Target 
   { 
      private ExtractTool m_Deed; 

      public ExtractTarget( ExtractTool deed ) : base( 1, false, TargetFlags.None ) 
      { 
         m_Deed = deed; 
      } 

      protected override void OnTarget( Mobile from, object target ) 
      { 
	  
         if ( target is DNADragonBlack ) 
         { 
            DNADragonBlack t = ( DNADragonBlack ) target; 

            if ( t.ControlMaster != from ) 
            { 
               from.SendMessage( "That is not your pet!" ); 
            } 
            else  
             
               { 

			t.Delete();
			from.SendMessage( "You Extract DNA From The Black Dragon!" );
		   from.AddToBackpack(new BlackDNA());
           m_Deed.Delete(); // Delete the deed 
               } 
            
         } 
         if ( target is DNADragonBlaze ) 
         { 
            DNADragonBlaze t = ( DNADragonBlaze ) target; 

            if ( t.ControlMaster != from ) 
            { 
               from.SendMessage( "That is not your pet!" ); 
            } 
            else  
             
               { 

			t.Delete();
			from.SendMessage( "Blaze Dragon" );
		   from.AddToBackpack(new BlazeDNA());
           m_Deed.Delete(); // Delete the deed 
               } 
            
         } 
         if ( target is DNADragonGolden ) 
         { 
            DNADragonGolden t = ( DNADragonGolden ) target; 
            if ( t.ControlMaster != from ) 
            { 
               from.SendMessage( "That is not your pet!" ); 
            } 
            else  
             
               { 

			t.Delete();
			from.SendMessage( "Golden Dragon!" );
		   from.AddToBackpack(new GoldenDNA());
           m_Deed.Delete(); // Delete the deed 
               } 
            
         } 
         if ( target is DNADragonLightning ) 
         { 
            DNADragonLightning t = ( DNADragonLightning ) target; 

            if ( t.ControlMaster != from ) 
            { 
               from.SendMessage( "That is not your pet!" ); 
            } 
            else  
             
               { 

			t.Delete();
			from.SendMessage( "You bond with the pet!" );
		   from.AddToBackpack(new LightningDNA());
           m_Deed.Delete(); // Delete the deed 
               } 
            
         } 
         if ( target is DNADragonPoison ) 
         { 
            DNADragonPoison t = ( DNADragonPoison ) target; 
            if ( t.ControlMaster != from ) 
            { 
               from.SendMessage( "That is not your pet!" ); 
            } 
            else  
             
               { 

			t.Delete();
			from.SendMessage( "Poison Dragon!" );
		   from.AddToBackpack(new PoisonDNA());
           m_Deed.Delete(); // Delete the deed 
               } 
            
         } 
         if ( target is DNADragonSnow ) 
         { 
            DNADragonSnow t = ( DNADragonSnow ) target; 

            if ( t.ControlMaster != from ) 
            { 
               from.SendMessage( "That is not your pet!" ); 
            } 
            else  
             
               { 

			t.Delete();
			from.SendMessage( "You bond with the pet!" );
		   from.AddToBackpack(new SnowDNA());
           m_Deed.Delete(); // Delete the deed 
               } 
            
         } 
         else 
         { 
            from.SendMessage( "That is not a valid traget." );  
         } 
      } 
   } 

   public class ExtractTool : Item // Create the item class which is derived from the base item class 
   { 
      [Constructable] 
      public ExtractTool() : base( 0x0F91 ) 
      { 
         Weight = 1.0; 
         Name = "Single Use Dna Extracting Tool"; 
	   Hue = 33;
      } 

      public ExtractTool( Serial serial ) : base( serial ) 
      { 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 
         LootType = LootType.Blessed; 

         int version = reader.ReadInt(); 
      } 

      public override bool DisplayLootType{ get{ return false; } } 

      public override void OnDoubleClick( Mobile from ) // Override double click of the deed to call our target 
      { 
         if ( !IsChildOf( from.Backpack ) ) // Make sure its in their pack 
         { 
             from.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it. 
         } 
		else if  (from.Skills[SkillName.AnimalTaming].Value > 115.0)
         { 
            from.SendMessage( "Choose the Dragon u Want To Extract DNA From." );  
            from.Target = new ExtractTarget( this ); // Call our target 
         } 
         else 
         { 
            from.SendMessage( "You can not use this." );  
          } 
      }    
   } 
}