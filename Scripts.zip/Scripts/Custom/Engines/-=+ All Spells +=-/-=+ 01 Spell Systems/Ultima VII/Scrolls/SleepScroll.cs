using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class SleepScroll : SpellScroll
	{
		[Constructable]
		public SleepScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public SleepScroll( int amount ) : base( 357, 0x1F43, amount )
		{
			Name = "Sleep";
		}
		
		public SleepScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel <= AccessLevel.Counselor )
			{
				//--<Optional Restrictions>----------<Start>
				from.SendMessage( "Low level staff and players are not allowed to have this scroll." );
				Delete();
			}
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new SleepScroll( amount ), amount );
		}
	}
}
