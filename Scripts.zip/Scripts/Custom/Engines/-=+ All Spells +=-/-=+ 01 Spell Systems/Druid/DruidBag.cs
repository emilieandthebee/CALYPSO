using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class DruidBag : Bag
	{
		[Constructable]
		public DruidBag()
		{
			PlaceItemIn( 30, 35, new BlendWithForestScroll() );
			PlaceItemIn( 50, 35, new EnchantedGroveScroll() );
			PlaceItemIn( 70, 35, new DruidFamiliarScroll() );
			PlaceItemIn( 90, 35, new GraspingRootsScroll() );
			PlaceItemIn( 30, 55, new HollowReedScroll() );
			PlaceItemIn( 50, 55, new LureStoneScroll() );
			PlaceItemIn( 70, 55, new MushroomGatewayScroll() );
			PlaceItemIn( 90, 55, new NaturesPassageScroll() );
			PlaceItemIn( 30, 75, new PackOfBeastScroll() );
			PlaceItemIn( 50, 75, new RestorativeSoilScroll() );
			PlaceItemIn( 70, 75, new ShieldOfEarthScroll() );
			PlaceItemIn( 90, 75, new SpringOfLifeScroll() );
			PlaceItemIn( 30, 95, new StoneCircleScroll() );
			PlaceItemIn( 50, 95, new SwarmOfInsectsScroll() );
			PlaceItemIn( 70, 95, new LeafWhirlwindScroll() );
			PlaceItemIn( 90, 95, new VolcanicEruptionScroll() );
		}

		private void PlaceItemIn( int x, int y, Item item )
		{
			AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public DruidBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}