using System;
using Server;

namespace Server.Items
{

	public class ClueRuleBook: BaseBook
	{
		private const string TITLE = "Kloedu";
		private const string AUTHOR = "Dr. Lenoir";
		private const int PAGES = 20;
		private const bool WRITABLE = true;
		
		[Constructable]
		public ClueRuleBook() : base( Utility.RandomList( 0xFEF, 0xFF0, 0xFF1, 0xFF2 ), TITLE, AUTHOR, PAGES, WRITABLE )
		{
			Name="Regles du Kloedu";
		
			Pages[0].Lines = new string[]
				{
					"Mr.Lenoir - ",
					"la victim d'un",
					"crime a ete trouve",
					"dans une salle du",
					"vaisseau. Pour ",
					"gagner vous dever",
					"repondre aux 3",
					"questions:"
				};

			Pages[1].Lines = new string[]
				{
					"Qui l'as tue?",
					"Ou?",
					"L'arme du crime?",
					"",
					"SE DEPLACER:",
					"A chaque tour,",
					"essayer d'aller",
					"dans une salle"
				};


			Pages[2].Lines = new string[]
				{
					"du vaisseau.",
					"Pour se deplacer",
					"faites rouler",
					"les des ou",
					"utiliser un",
					"passage secret",
					"si vous etes",
					"dans une salle"
					
				};

			Pages[3].Lines = new string[]
				{
					"en coin.",
					"",
					"LANCER LES DES:",
					"Lancer les des",
					"et bouger du",
					"nombre de salles",
					"correspondant,",
					"mais vous ne"
					
				};


			Pages[4].Lines = new string[]
				{
					"pouvez bouger",
					"en diagonales.",
					"",
					"PASSAGE SECRET:",
					"Les salles dans",
					"les coins",
					"opposes sont",
					"relies par"
					
				};


			Pages[5].Lines = new string[]
				{
					"un passage.",
					"Si vous etes",
					"dans une de",
					"ces salles au",
					"debut du tour",
					"vous pouvez",
					"utiliser le",
					"passage secret"
					
				};


			Pages[6].Lines = new string[]
				{
					"au lieu des des.",
					"",
					"HYPOTHESES:",
					"Des que vous",
					"entrez dans une",
					"piece, vous",
					"pouvez effectuer",
					"une hypothese"
					
				};


			Pages[7].Lines = new string[]
				{
					"en procdant",
					"par elimination",
					"pour determiner",
					"quelles sont les",
					"cartes dans la",
					"boite secrete.",
					"Pour faire une",
					"hypothese,"
					
				};


			Pages[8].Lines = new string[]
				{
					"mettre une arme",
					"et un suspect",
					"dans la salle.",
					"Ensuite faite",
					"l'hypothese",
					"voulue dans",
					"cette salle",
					"avec le suspect"
					
				};


			Pages[9].Lines = new string[]
				{
					"et l'arme.",
					"",
					"PROUVER UNE",
					"HYPOTHESE:",
					"si un opposant",
					"prouve une fausse",
					"hypothese, le",
					"joueur regarde"
					
				};


			Pages[10].Lines = new string[]
				{
					"cartes pour",
					"trouver un",
					"element cite",
					"si ce joueur",
					"a une de ces",
					"cartes nommee",
					"il doit dire",
					"a la personne"
					
				};


			Pages[11].Lines = new string[]
				{
					"et SEULEMENT ",
					"CETTE PERSONNE.",
					"Sim un joueur",
					"a une plus d'une",
					"carte nommee, il",
					"choisit un seul",
					"joueur.",
					"Des qu'une carte"
					
				};

			Pages[12].Lines = new string[]
				{
					"d'un opposant",
					"vous est montree",
					"ceci est la",
					"preuve que la",
					"carte n'est pas",
					"dans la boite",
					"confidentielle.",
					"Finissez votre"
					
				};

			Pages[13].Lines = new string[]
				{
					"tour en notant",
					"la carte dans",
					"votre bloc-note.",
					"Si personne ne",
					"peut prouver une",
					"fausse hypothese",
					"vous pouvez finir",
					"votre tour ou en"
					
				};

			Pages[14].Lines = new string[]
				{
					"faire une autre.",
					"",
					"ACCUSATION:",
					"Lorsque vous",
					"pensez savoir",
					"quelles sont les",
					"3 cartes de la",
					"boite, vous"
					
				};

			Pages[15].Lines = new string[]
				{
					"pouvez, lors de",
					"votre tour faire",
					"une accusation ",
					"et nommer les 3",
					"elements que ",
					"vous voulez.",
					"<<J'accuse (Sus)",
					"du meurtre de"
					
				};

			Pages[16].Lines = new string[]
				{
					"Mr Lenoir",
					"dans (Salle) avec",
					"(Arme).>>",
					"",
					"Lors d'une",
					"accusation, vous",
					"pouvez dire ",
					"n'importe quelle"
					
				};

			Pages[17].Lines = new string[]
				{
					"salle. Si c'est",
					"faux vous etes",
					"elimine du jeu",
					"mais devez",
					"toujours prouver",
					"les fausses",
					"hypotheses de vos",
					"opposant."
					
				};

			Pages[18].Lines = new string[]
				{
					"GAGNER:",
					"Vous gagnez le",
					"jeu si votre",
					"accusation est",
					"entierement",
					"correct: vous",
					"trouver toutes",
					"les informations"
					
				};

			Pages[19].Lines = new string[]
				{
					"des cartes de",
					"la boite. Si",
					"cela arrive,",
					"prenez les 3",
					"cartes et",
					"montrez-les aux",
					"autres.",
					"Bonne chance!"
					
				};

		}

		public ClueRuleBook( Serial serial ) : base( serial )
		{
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int)0 ); 
		}
	}
}