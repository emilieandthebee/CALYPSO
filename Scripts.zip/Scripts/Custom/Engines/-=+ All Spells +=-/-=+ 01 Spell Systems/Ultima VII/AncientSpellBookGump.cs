using System;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Spells;
using Server.Spells.Linear;
using Server.Spells.First;
using Server.Spells.Second;
using Server.Spells.Third;
using Server.Spells.Fourth;
using Server.Spells.Fifth;
using Server.Spells.Sixth;
using Server.Spells.Seventh;
using Server.Spells.Eighth;
using Server.Prompts;

namespace Server.Gumps
{
	public class AncientSpellbookGump : Gump
	{
		private AncientSpellbook m_Book;
		
		int gth = 0x903;
		public static bool HasSpell( Mobile from, int spellID )
		{
			Spellbook book = Spellbook.Find( from, spellID );
			return ( book != null && book.HasSpell( spellID ) );
		}
		
		public AncientSpellbookGump( Mobile from, AncientSpellbook book ) : base( 179, 200 )
		{
			int sbtn = 0x93A;
			int dby = 40;
			m_Book = book;
			
			AddPage( 0 );
			AddImage( 100, 10, 0x89B, 0 );
			
			AddPage( 1 );
			AddLabel( 170, 17, gth, "Linear" );
			AddButton( 396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 2 );
			
			if (HasSpell( from, 340) )
			{
				AddLabel( 145, dby, gth, "Fireworks" );
				AddButton( 125, dby + 3, sbtn, sbtn, 340, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 341) )
			{
				AddLabel( 145, dby, gth, "Glimmer" );
				AddButton( 125, dby + 3, sbtn, sbtn, 341, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 342) )
			{
				AddLabel( 145, dby, gth, "Awaken" );
				AddButton( 125, dby + 3, sbtn, sbtn, 342, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 343) )
			{
				AddLabel( 145, dby, gth, "Thunder" );
				AddButton( 125, dby + 3, sbtn, sbtn, 343, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 344) )
			{
				AddLabel( 145, dby, gth, "Weather" );
				AddButton( 125, dby + 3, sbtn, sbtn, 344, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 345) )
			{
				AddLabel( 145, dby, gth, "Ignite" );
				AddButton( 125, dby + 3, sbtn, sbtn, 345, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 346) )
			{
				AddLabel( 145, dby, gth, "Douse" );
				AddButton( 125, dby + 3, sbtn, sbtn, 346, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			
			dby = 40;
			AddLabel( 310, 17, gth, "First Circle" );
			
			if (HasSpell( from, 348) )
			{
				AddLabel( 315, dby, gth, "Locate" );
				AddButton( 295, dby + 3, sbtn, sbtn, 348, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 349) )
			{
				AddLabel( 315, dby, gth, "Awaken All" );
				AddButton( 295, dby + 3, sbtn, sbtn, 349, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 350) )
			{
				AddLabel( 315, dby, gth, "Detect Trap" );
				AddButton( 295, dby + 3, sbtn, sbtn, 350, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 351) )
			{
				AddLabel( 315, dby, gth, "Great Douse" );
				AddButton( 295, dby + 3, sbtn, sbtn, 351, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 352) )
			{
				AddLabel( 315, dby, gth, "Great Ignite" );
				AddButton( 295, dby + 3, sbtn, sbtn, 352, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			
			AddPage( 2 );
			AddLabel( 170, 17, gth, "Second Circle" );
			dby = 40;
			AddButton( 396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 3 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 1 );
			
			if (HasSpell( from, 353) )
			{
				AddLabel( 145, dby, gth, "Enchant" );
				AddButton( 125, dby + 3, sbtn, sbtn, 353, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 354) )
			{
				AddLabel( 145, dby, gth, "False Coin" );
				AddButton( 125, dby + 3, sbtn, sbtn, 354, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 355) )
			{
				AddLabel( 145, dby, gth, "Great Light" );
				AddButton( 125, dby + 3, sbtn, sbtn, 355, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 356) )
			{
				AddLabel( 145, dby, gth, "Destroy Trap" );
				AddButton( 125, dby + 3, sbtn, sbtn, 356, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			
			AddLabel( 310, 17, gth, "Third Circle" );
			dby = 40;
			
			if (HasSpell( from, 357) )
			{
				AddLabel( 315, dby, gth, "Sleep" );
				AddButton( 295, dby + 3, sbtn, sbtn, 357, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 358) )
			{
				AddLabel( 315, dby, gth, "Swarm" );
				AddButton( 295, dby + 3, sbtn, sbtn, 358, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 359) )
			{
				AddLabel( 315, dby, gth, "Peer" );
				AddButton( 295, dby + 3, sbtn, sbtn, 359, GumpButtonType.Reply, 1 );
			}
			
			AddPage( 3 );
			AddLabel( 170, 17, gth, "Fouth Circle" );
			dby = 40;
			AddButton( 396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 4 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 2 );
			
			if (HasSpell( from, 360) )
			{
				AddLabel( 145, dby, gth, "Seance" );
				AddButton( 125, dby + 3, sbtn, sbtn, 360, GumpButtonType.Reply, 1 );
			}
			
			AddLabel( 310, 17, gth, "Fifth Circle" );
			dby = 40;
			
			if (HasSpell( from, 361) )
			{
				AddLabel( 315, dby, gth, "Charm" );
				AddButton( 295, dby + 3, sbtn, sbtn, 361, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 362) )
			{
				AddLabel( 315, dby, gth, "Dance" );
				AddButton( 295, dby + 3, sbtn, sbtn, 362, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 363) )
			{
				AddLabel( 315, dby, gth, "Mass Sleep" );
				AddButton( 295, dby + 3, sbtn, sbtn, 363, GumpButtonType.Reply, 1 );
			}
			
			AddPage( 4 );
			AddLabel( 170, 17, gth, "Sixth Circle" );
			dby = 40;
			AddButton( 396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 5 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 3 );
			
			if (HasSpell( from, 364) )
			{
				AddLabel( 145, dby, gth, "Clone" );
				AddButton( 125, dby + 3, sbtn, sbtn, 364, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 365) )
			{
				AddLabel( 145, dby, gth, "Cause Fear" );
				AddButton( 125, dby + 3, sbtn, sbtn, 365, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 366) )
			{
				AddLabel( 145, dby, gth, "Fire Ring" );
				AddButton( 125, dby + 3, sbtn, sbtn, 366, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 368) )
			{
				AddLabel( 145, dby, gth, "Tremor" );
				AddButton( 125, dby + 3, sbtn, sbtn, 368, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 369) )
			{
				AddLabel( 145, dby, gth, "Sleep Field" );
				AddButton( 125, dby + 3, sbtn, sbtn, 369, GumpButtonType.Reply, 1 );
			}
			
			AddLabel( 310, 17, gth, "Seventh Circle" );
			dby = 40;
			
			if (HasSpell( from, 370) )
			{
				AddLabel( 315, dby, gth, "Mass Might" );
				AddButton( 295, dby + 3, sbtn, sbtn, 370, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 372) )
			{
				AddLabel( 315, dby, gth, "Mass Charm" );
				AddButton( 295, dby + 3, sbtn, sbtn, 372, GumpButtonType.Reply, 1 );
			}
			
			AddPage( 5 );
			AddLabel( 170, 17, gth, "Eighth Circle" );
			dby = 40;
			AddButton( 396, 14, 0x89E, 0x89E, 17, GumpButtonType.Page, 6 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 4 );
			
			if (HasSpell( from, 373) )
			{
				AddLabel( 145, dby, gth, "Invisibility All" );
				AddButton( 125, dby + 3, sbtn, sbtn, 373, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 374) )
			{
				AddLabel( 145, dby, gth, "Death Vortex" );
				AddButton( 125, dby + 3, sbtn, sbtn, 374, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 380) )
			{
				AddLabel( 145, dby, gth, "Mass Death" );
				AddButton( 125, dby + 3, sbtn, sbtn, 380, GumpButtonType.Reply, 1 );
				dby = dby + 20;
			}
			if (HasSpell( from, 382) )
			{
				AddLabel( 145, dby, gth, "Armageddon" );
				AddButton( 125, dby + 3, sbtn, sbtn, 382, GumpButtonType.Reply, 1 );
			}
			
			AddPage( 6 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 7 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 5 );
			AddLabel( 170, 20, gth, "Fireworks" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>1<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell creates an impressive display of multi-colored moving lights." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Glimmer" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>3<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell creates a small light source that lasts for a short period of time." +
			        "</BODY>", false, true);
			
			AddPage( 7 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 8 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 6 );
			AddLabel( 170, 20, gth, "Awaken" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>5<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell awakens one sleeping or unconscious creature." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Thunder" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>2<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell causes a single thunderclap to be heard, as if a terrible storm is imminent." +
			        "</BODY>", false, true);
			
			AddPage( 8 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 9 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 7 );
			AddLabel( 170, 20, gth, "Weather" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>8<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell can create a storm or cause an existing storm to stop." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Ignite" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>6<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell generates a tiny missile of sparks that can ignite flammable material." +
			        "</BODY>", false, true);
			
			AddPage( 9 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 10 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 8 );
			AddLabel( 170, 20, gth, "Douse" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>None<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Skill:  <BASEFONT COLOR=BLACK>0<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Required Mana:  <BASEFONT COLOR=BLACK>6<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell extinguishes any small, non-magical fire." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Locate" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>1<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell reveals the sextant position of the mage, even when underground." +
			        "</BODY>", false, true);
			
			AddPage( 10 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 11 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 9 );
			AddLabel( 170, 20, gth, "Awaken All" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Garlic, Ginseng<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>1<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell awakens all unconscious members of the mage's party." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Detect Trap" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Spider's Silk, Nightshade<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>1<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell allows the mage to see any nearby traps." +
			        "</BODY>", false, true);
			
			AddPage( 11 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 12 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 10 );
			AddLabel( 170, 20, gth, "Great Douse" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Spider's Silk, Garlic<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>1<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is a more potent version of the Linear spell Douse." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Great Ignite" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Spider's Silk, Sulfurous Ash<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>1<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is a more potent version of the Linear spell Ignite." +
			        "</BODY>", false, true);
			
			AddPage( 12 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 13 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 11 );
			AddLabel( 170, 20, gth, "Enchant" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Black Pearl, Mandrake Root<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>2<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell causes a ranged weapon to become enchanted and glow blue. Enchanted weapons will always hit their target." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "False Coin" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Sulfurous Ash<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>2<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>When cast upon any coin, this spell creates five duplicate coins." +
			        "</BODY>", false, true);
			
			AddPage( 13 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 14 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 12 );
			AddLabel( 170, 20, gth, "Great Light" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Mandrake Root, Sulfurous Ash<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>2<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is a more potent version of the First Circle spell Nightsight, and has a substantially longer duration." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Destroy Trap" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Blood Moss, Sulfurous Ash<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>2<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell destroys any one specific trap upon which it is cast." +
			        "</BODY>", false, true);
			
			AddPage( 14 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 15 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 13 );
			AddLabel( 170, 20, gth, "Sleep" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Spider's Silk, Black Pearl<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>3<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell causes the enchanted person to fall asleep." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Swarm" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Mandrake Root, Blood Moss<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>3<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell summons swarms of insects to attack the enemies of the mage from all directions." +
			        "</BODY>", false, true);
			
			AddPage( 15 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 16 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 14 );
			AddLabel( 170, 20, gth, "Peer" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Mandrake Root<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>3<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell enables the mage's vision to leave his body and scout the area." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Seance" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Mandrake Root, Blood Moss, Spider's Silk, Sulfurous Ash<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>4<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell enables the mage to move as a ghost." +
			        "</BODY>", false, true);
			
			AddPage( 16 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 17 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 15 );
			AddLabel( 170, 20, gth, "Charm" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Black Pearl, Spider's Silk<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>5<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell can be used either to control an enemy or creature, or to free a charmed one." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Dance" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Mandrake Root, Garlic, Blood Moss<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>5<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell makes everyone in sight (except the mage and his party) start to dance." +
			        "</BODY>", false, true);
			
			AddPage( 17 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 18 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 16 );
			AddLabel( 170, 20, gth, "Mass Sleep" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Ginseng, Nightshade, Spider's Silk<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>5<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is a more potent version of the Third Circle spell Sleep. It puts to sleep a group of targets." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Clone" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Ginseng, Nightshade, Spider's Silk, Blood Moss, Sulfurous Ash, Mandrake Root<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>6<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell creates an exact duplicate of any mortal creature, who will then fight for the mage." +
			        "</BODY>", false, true);
			
			AddPage( 18 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 19 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 17 );
			AddLabel( 170, 20, gth, "Fire Ring" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Black Pearl, Sulfurous Ash, Mandrake Root<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>6<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell create a ring of fire that will encircle the mage's target." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Tremor" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Blood Moss, Sulfurous Ash, Mandrake Root<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>6<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell creates violent tremors in the earth that will cause the mage's enemies to tremble frantically." +
			        "</BODY>", false, true);
			
			AddPage( 19 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 20 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 18 );
			AddLabel( 170, 20, gth, "Sleep Field" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Ginseng, Spider's Silk, Black Pearl<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>6<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell creates a thick wall of energy field where the mage desires. All who enter this energy field will fall asleep." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Mass Might" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Ginseng, Mandrake Root, Black Pearl<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>7<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell works the same way as the Bless spell, but for everyone in the mageâ€™s party." +
			        "</BODY>", false, true);
			
			AddPage( 20 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 21 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 19 );
			AddLabel( 170, 20, gth, "Mass Charm" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Mandrake Root, Black Pearl, Spider's Silk<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>7<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is similar to the Fifth Circle spell Charm, but it affects more powerful monsters, based on the mage's intellect." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Invivibility All" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Mandrake Root, Black Pearl, Blood Moss<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>8<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is the equivalent of casting the Fifth Circle spell Invisibility upon the mage and everyone in his party." +
			        "</BODY>", false, true);
			
			AddPage( 21 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 22 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 20 );
			AddLabel( 170, 20, gth, "Death Vortex" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Nightshade, Mandrake Root, Sulfurous Ash<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Spell Circle:    <BASEFONT COLOR=BLACK>8<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell creates a swirling black vortex at the point the mage designates, which will thereafter move at random." +
			        "</BODY>", false, true);
			
			AddLabel( 315, 20, gth, "Mass Death" );
			AddHtml( 285, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Uknown<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Forbidden Spell<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is rumoured to kill everything within the mage's sight" +
			        "</BODY>", false, true);
			
			AddPage( 22 );
			AddButton( 396, 14, 0x89E, 0x89E, 18, GumpButtonType.Page, 23 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 21 );
			AddLabel( 170, 20, gth, "Armageddon" );
			AddHtml( 130, 40, 140, 170,   "<BODY>" +
			        "<BASEFONT COLOR=#7B6D20>Reagents: <BASEFONT COLOR=BLACK>Uknown<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Forbidden Spell<BR>" +
			        "<BASEFONT COLOR=#7B6D20>Description: <BASEFONT COLOR=BLACK>This spell is believed to be so powerful that it may be capable of destroying all known living things in the entire world." +
			        "</BODY>", false, true);
			
			AddPage( 23 );
			AddButton( 123, 15, 0x89D, 0x89D, 19, GumpButtonType.Page, 22 );
			
			AddHtml( 285, 5, 125, 130, "<BASEFONT COLOR=BLACK><CENTER><BR>All Spells 4.0", false, false);
			
			AddHtml( 293, 40, 130, 135, "<BODY>" +
			        "<BASEFONT COLOR=BLACK>Made Possible by:<BR>" +
			        "<BASEFONT COLOR=GREY>Voran<BR>" +
			        "<BASEFONT COLOR=GREY>Darsden<BR>" +
			        "<BASEFONT COLOR=GREY>TheOutcastDev<BR>" +
			        "<BASEFONT COLOR=GREY>wstsdwgrrr<BR>" +
			        "<BASEFONT COLOR=GREY>joshw<BR>" +
			        "<BASEFONT COLOR=GREY>ssalter<BR>" +
			        "<BASEFONT COLOR=GREY>Lucid Nagual<BR>" +
			        "<BASEFONT COLOR=GREY>A_Li_N<BR>" +
			        "<BASEFONT COLOR=GREY><BR>" +
			        "<BASEFONT COLOR=GREY>and finally myself...<BR>" +
			        "<BASEFONT COLOR=GREY>X-SirSly-X<BR>" +
			        "<BASEFONT COLOR=BLACK>www.johnsly.com<BR>" +
			        "</BODY>", false, true );
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			Mobile from = state.Mobile;
			int BID = info.ButtonID;
			
			if( BID >= 340 && BID <= 382 )
			{
				Spell spell = SpellRegistry.NewSpell( BID, from, null );
				if( spell != null )
					spell.Cast();
			}
		}
	}
}
