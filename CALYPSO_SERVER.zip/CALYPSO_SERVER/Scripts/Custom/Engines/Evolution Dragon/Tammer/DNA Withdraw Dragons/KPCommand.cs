    //////////////////////////////////
   //			           //
  //      Scripted by Raelis      //
 //		             	 //
//////////////////////////////////
using System; 
using System.Collections; 
using Server; 
using Server.Mobiles; 
using Server.Network; 
using Server.Targeting;


namespace Server.Mobiles
{ 
	public class KPSystem
	{ 

		public static void Initialize()
		{
			Server.Commands.Register( "KP", AccessLevel.Administrator, new CommandEventHandler( KP_OnCommand ) );    
		} 

		public static void KP_OnCommand( CommandEventArgs args )
		{ 
			Mobile m = args.Mobile; 
			PlayerMobile from = m as PlayerMobile; 
          
			if( from != null ) 
			{  
				from.SendMessage ( "Target a dragon that you own to get their kill point amount." );
				m.Target = new InternalTarget();
			} 
		} 

		private class InternalTarget : Target
		{
			public InternalTarget() : base( 8, false, TargetFlags.None )
			{
			}

			protected override void OnTarget( Mobile from, object obj )
			{
				if ( !from.Alive )
				{
					from.SendMessage( "You may not do that while dead." );
				}
                  //         	else if ( obj is EvolutionDragon && obj is BaseCreature ) 
                   //        	{ 
					//BaseCreature bc = (BaseCreature)obj;
					//EvolutionDragon ed = (EvolutionDragon)obj;

					//if ( ed.Controled == true && ed.ControlMaster == from )
					//{
					//	ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					//}
					//else
					//{
					//	from.SendMessage( "You do not control this dragon!" );
					//}
                          // 	} 
                           	else if ( obj is DNADragonBlaze && obj is DNADragonBlaze ) 
                           	{ 
					BaseCreature bc = (BaseCreature)obj;
					DNADragonBlaze ed = (DNADragonBlaze)obj;

					if ( ed.Controled == true && ed.ControlMaster == from )
					{
						ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					}
					else
					{
						from.SendMessage( "You do not control this dragon!" );
					}
                           	} 
                           	else if ( obj is DNADragonBlack && obj is DNADragonBlack ) 
                           	{ 
					BaseCreature bc = (BaseCreature)obj;
					DNADragonBlack ed = (DNADragonBlack)obj;

					if ( ed.Controled == true && ed.ControlMaster == from )
					{
						ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					}
					else
					{
						from.SendMessage( "You do not control this dragon!" );
					}
                           	} 
                           	else if ( obj is DNADragonGolden && obj is DNADragonGolden ) 
                           	{ 
					BaseCreature bc = (BaseCreature)obj;
					DNADragonGolden ed = (DNADragonGolden)obj;

					if ( ed.Controled == true && ed.ControlMaster == from )
					{
						ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					}
					else
					{
						from.SendMessage( "You do not control this dragon!" );
					}
                           	} 
                           	else if ( obj is DNADragonLightning && obj is DNADragonLightning ) 
                           	{ 
					BaseCreature bc = (BaseCreature)obj;
					DNADragonLightning ed = (DNADragonLightning)obj;

					if ( ed.Controled == true && ed.ControlMaster == from )
					{
						ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					}
					else
					{
						from.SendMessage( "You do not control this dragon!" );
					}
                           	} 
                           	else if ( obj is DNADragonPoison && obj is DNADragonPoison ) 
                           	{ 
					BaseCreature bc = (BaseCreature)obj;
					DNADragonPoison ed = (DNADragonPoison)obj;

					if ( ed.Controled == true && ed.ControlMaster == from )
					{
						ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					}
					else
					{
						from.SendMessage( "You do not control this dragon!" );
					}
                           	} 
                           	else if ( obj is DNADragonSnow && obj is DNADragonSnow ) 
                           	{ 
					BaseCreature bc = (BaseCreature)obj;
					DNADragonSnow ed = (DNADragonSnow)obj;

					if ( ed.Controled == true && ed.ControlMaster == from )
					{
						ed.PublicOverheadMessage( MessageType.Regular, ed.SpeechHue, true, ed.Name +" has "+ ed.KP +" kill points.", false );
					}
					else
					{
						from.SendMessage( "You do not control this dragon!" );
					}
                           	} 
                           	else 
                           	{ 
                              		from.SendMessage( "That is not a dragon!" );
			   	}
			}
		}
	} 
} 
