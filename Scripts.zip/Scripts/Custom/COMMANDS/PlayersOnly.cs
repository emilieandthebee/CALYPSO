using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;
using Server.Accounting;

namespace Server.Scripts.Commands
{
	public class PlayersOnly
	{
		public static void Initialize()
		{
			Server.Commands.Register( "PlayersOnly", AccessLevel.Administrator, new CommandEventHandler( PlayersOnly_OnCommand ) );
		}

		[Usage( "PlayersOnly" )]
		[Description( "Pour n'autoriser que l'admin et les joueurs a se connecter" )]
		private static void PlayersOnly_OnCommand( CommandEventArgs e )
		{
			 Misc.AccountHandler.PlayersOnly=!Misc.AccountHandler.PlayersOnly;
			 if ( Misc.AccountHandler.PlayersOnly)
			 {
				e.Mobile.SendMessage("Seul les joueurs et l'admin ont le droit de se connecter.");
				ArrayList clients = NetState.Instances;
				for ( int i = 0; i < clients.Count; ++i )
				{
					NetState ns = (NetState)clients[i];
					Account a = ns.Account as Account;
					if ( a == null )
						continue;
					if (( a.AccessLevel > AccessLevel.Player ) && ( a.AccessLevel < AccessLevel.Administrator ))
					{
						ns.Dispose();
					}
				}
			 } else {
				e.Mobile.SendMessage("Tout le monde peut se connecter.");
			 }
		}
	}
}