using System;
using Server;
using Server.Mobiles;

namespace Server.Items
{
	[Flipable( 0x14F5, 0x14F6 )]
	public class APS_LongueVue : Item
	{
		[Constructable]
		public APS_LongueVue() : base( 0x14F5 )
		{
			Weight = 3.0;
		}

		public override void OnDoubleClick( Mobile from )
		{
			MoonPhase phase=Clock.GetMoonPhase(from.Map, from.X, from.Y);
			switch(phase)
			{
				case MoonPhase.NewMoon:
					from.SendMessage("C'est la nouvelle lune...");
					break;
				case MoonPhase.WaxingCrescentMoon:
					from.SendMessage("C'est le premier croissant de la lune.");
					break;
				case MoonPhase.FirstQuarter:
					from.SendMessage("C'est le premier quartier de la lune.");
					break;
				case MoonPhase.WaxingGibbous:
					from.SendMessage("La lune est gibbeuse croissante.");
					break;
				case MoonPhase.FullMoon:
					from.SendMessage("C'est la pleine lune.");
					break;
				case MoonPhase.WaningGibbous:
					from.SendMessage("La lune est gibbeuse décroissante.");
					break;
				case MoonPhase.LastQuarter:
					from.SendMessage("C'est le dernier quartier de la lune.");
					break;
				case MoonPhase.WaningCrescent:
					from.SendMessage("C'est le dernier croissant de la lune.");
					break;
				default:
					break;
			}
		}

		public APS_LongueVue( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}