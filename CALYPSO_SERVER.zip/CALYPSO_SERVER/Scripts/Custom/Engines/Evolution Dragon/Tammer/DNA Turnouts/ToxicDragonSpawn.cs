using System; 
using Server.Mobiles;
using Server.Misc; 
using Server.Network; 
using System.Collections; 
using Server.Items; 
using Server.Targeting;

namespace Server.Items 
{ 
   public class ToxicDragonSpawn : Item
   {
      [Constructable]
      public ToxicDragonSpawn() : base( 0xED4 )
      {
			Name = "Toxic Dragon takes 3 Pet Slots";
			ItemID= 9684;
      }

      public override void OnDoubleClick( Mobile from )
      {
         if ( !IsChildOf( from.Backpack ) ) // Make sure its in their pack 
         { 
             from.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it.
		//	 return false; 
         }  
			else if( !from.CheckAlive() )
			{
				from.SendLocalizedMessage( 1060190 );	//You cannot do that while dead!
			}
		 else if ( from.Followers == 3 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
		 else if ( from.Followers == 4 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
		 else if ( from.Followers == 5 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
	//PlayerMobile pm = from as PlayerMobile;
			else if  (from.Skills[SkillName.AnimalTaming].Value > 115.0)
		        {
           		from.FixedParticles( 0x373A, 10, 15, 5036, EffectLayer.Head ); 
               		from.PlaySound( 710 );
        		ToxicDragon ToxicDragon = new ToxicDragon();
        		ToxicDragon.ControlTarget = from;
        		ToxicDragon.SetControlMaster ( from );
        		ToxicDragon.Location = from.Location;
				ToxicDragon.ControlOrder = OrderType.None;
        		ToxicDragon.Map = from.Map;
        		World.AddMobile( ToxicDragon );
				this.Delete();
				} 
else// ( from.Skills[SkillName.Magery].Value > 100.0 )
{
         from.SendMessage( "You Are Not Certified For use of This pet" );
}
      }

      public ToxicDragonSpawn( Serial serial ) : base( serial )
      {
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );

         writer.Write( (int) 0 ); // version
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );

         int version = reader.ReadInt();
      }
   }
}
