using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using System.IO;

namespace Server.Scripts.Commands
{
	public class AddTreasureRegion
	{
		public static void Initialize()
		{
			Server.Commands.Register( "AddTreasureRegion", AccessLevel.Administrator, 
				new CommandEventHandler( AddTreasureRegion_OnCommand ) );
		}

		[Usage( "AddTreasureRegion" )]
		[Description( "Add a region where treasure can be found" )]
		private static void AddTreasureRegion_OnCommand( CommandEventArgs e )
		{
			e.Mobile.SendMessage("Please select the treasure place.");
			e.Mobile.Target = new AddTreasureRegionCallback();
		}

		private class AddTreasureRegionCallback : Target
		{
			public AddTreasureRegionCallback () : base( -1, true, TargetFlags.None )
			{
			}

			protected override void OnTarget( Mobile from, object targeted )
			{
				try
				{
					if (targeted is IPoint3D)
					{
						Point3D point=new Point3D ((IPoint3D)targeted);
						StreamWriter writer = File.AppendText("Data/TREASURE.CFG");
						writer.WriteLine("{0} {1}",point.X,point.Y);
						writer.Close();
						from.SendMessage("Treasure place has been added.");
					} else {
						from.SendMessage("Not a location...");
					}
				} catch {
					from.SendMessage("Error while trying to log the coordinates into the file.");
				}
			}
		}
	}
}