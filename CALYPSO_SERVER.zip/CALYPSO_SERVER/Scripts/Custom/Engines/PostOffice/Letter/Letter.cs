using System;
using Server;
using Server.Gumps;

namespace Server.Items
{
	[Flipable( 0x14ED, 0x14EE )]
	public class Letter : Item
	{
		public string i_message;
		public string i_from;
		public string i_to;
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Message
		{
			get{ return i_message; }
			set{ i_message = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string From
		{
			get{ return i_from; }
			set{ i_from = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string To
		{
			get{ return i_to; }
			set{ i_to = value; }
		}
		
		[Constructable]
		public Letter() : base( 0x14ED )
		{
			Name = "a Letter";
			Weight = 1.0;
			Hue = 1150;
		}
		
		public override void OnDoubleClick( Mobile m )
		{
			if ( !this.IsChildOf( m.Backpack ) && !this.IsChildOf( m.BankBox ) )
			{
				m.SendMessage("This must be in your backpack or bank to use.");
				return;
			}
			if ( m.Name == i_to )
			{
				m.SendGump( new LetterReadGump( m, i_from, i_message, i_to ) );
				return;
			}
			else
			{
				if ( m.Name == i_from )
				{
					m.SendGump( new ChangeLetterGump( m, i_to, i_message, i_from ) );
					this.Delete();
					return;
				}
				else
				{
					m.SendGump( new LetterWriteGump( m ) );
					this.Delete();
					return;
				}
			}
		}
		
		public Letter( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 

			writer.Write( (int) 0 ); // version 
			
			writer.Write( i_message );
			writer.Write( i_from );
			writer.Write( i_to );
		}

		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 

			int version = reader.ReadInt(); 
			
			i_message = reader.ReadString();
			i_from = reader.ReadString();
			i_to = reader.ReadString();
		}
	}
}
