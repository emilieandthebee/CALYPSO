// Mega Spawner v1.15
// By: Morxeton

using System;
using Server;
using System.Collections;
using Server.Mobiles;
using Server.Gumps;
using Server.Scripts.Commands;

namespace Server.Items
{
	public class MegaSpawner : Item
	{
		public ArrayList CreatureList = new ArrayList();
		public ArrayList SpawnRangeList = new ArrayList();
		public ArrayList WalkRangeList = new ArrayList();
		public ArrayList AmountList = new ArrayList();
		public ArrayList MinDelayList = new ArrayList();
		public ArrayList MaxDelayList = new ArrayList();
		public ArrayList SpawnCounterList = new ArrayList();
		public ArrayList Creatures = new ArrayList();
		private bool m_Active, m_Imported;
		public MegaSpawnerTimer m_MegaSpawnerTimer;

		[CommandProperty( AccessLevel.GameMaster )]
		public bool Active
		{
			get { return m_Active; }
			set
			{
				m_Active = value;

				if ( !value && m_MegaSpawnerTimer != null )
				{
					m_MegaSpawnerTimer.Stop();
					DeleteCreatures();
				}
				else if ( value && m_MegaSpawnerTimer == null )
				{
					m_MegaSpawnerTimer = new MegaSpawnerTimer( this );
					m_MegaSpawnerTimer.Start();
					Respawn();
				}
				else if ( value && !m_MegaSpawnerTimer.Running )
				{
					m_MegaSpawnerTimer.Start();
					Respawn();
				}
			}
		}

		public bool Imported
		{
			get { return m_Imported; }
			set{ m_Imported = value; }
		}

		[Constructable]
		public MegaSpawner() : base( 0x1f13 )
		{
			Active = true;
			Imported = false;
			Visible = false;
			Movable = false;
			Name = "A Mega Spawner";

			MegaSpawnerGump.SpawnerList.Add( this );
		}

		public MegaSpawner( Serial serial ) : base( serial )
		{
		}

		public override void OnDoubleClick( Mobile from )
		{
			from.SendGump( new MegaSpawnerEditGump( from, this, false ) );
		}

		public override void OnDelete()
		{
			base.OnDelete();

			CheckCreatures();
			DeleteCreatures();

			if ( m_MegaSpawnerTimer != null )
				m_MegaSpawnerTimer.Stop();
		}

		public void CheckCreatures()
		{
			for ( int check = 0; check < Creatures.Count; check++ )
			{
				object o = Creatures[check];

				if ( o is Mobile )
				{
					Mobile mob = (Mobile) o;

					if ( mob.Deleted )
					{
						Creatures.RemoveAt(check);
						check--;
					}
					else if ( mob is BaseCreature )
					{
						if ( ((BaseCreature)mob).Controled || ((BaseCreature)mob).IsStabled )
						{
							Creatures.RemoveAt(check);
							check--;
						}
					}
				}
			}
		}

		public int CountCreatures( int i )
		{
			int creatureCount = 0;

			for ( int cnt = 0; cnt < Creatures.Count; cnt++ )
				if ( Insensitive.Equals( (string) CreatureList[i], Creatures[cnt].GetType().Name ) )
					creatureCount++;

			return creatureCount;
		}

		public void DeleteCreatures()
		{
			for ( int i = 0; i < Creatures.Count; i++ )
			{
				object o = Creatures[i];

				if ( o is Mobile )
					( (Mobile) o ).Delete();
			}
		}

		public void DeleteCreatures( int index )
		{
			string creatureName = (string) CreatureList[index];

			for ( int i = 0; i < Creatures.Count; i++ )
			{
				object o = Creatures[i];

				if ( Insensitive.Equals( creatureName, o.GetType().Name ) )
				{
					if ( o is Mobile )
						( (Mobile) o ).Delete();
				}
			}
		}

		public void ClearSpawner()
		{
			CheckCreatures();
			DeleteCreatures();

			if ( m_MegaSpawnerTimer != null )
				m_MegaSpawnerTimer.Stop();

			int count = CreatureList.Count;

			for ( int i = 0; i < count; i++ )
			{
				CreatureList.RemoveAt(0);
				SpawnRangeList.RemoveAt(0);
				WalkRangeList.RemoveAt(0);
				AmountList.RemoveAt(0);
				MinDelayList.RemoveAt(0);
				MaxDelayList.RemoveAt(0);
				SpawnCounterList.RemoveAt(0);
			}
		}

		public void Respawn()
		{
			DeleteCreatures();

			for ( int i = 0; i < CreatureList.Count; i++ )
				SpawnCounterList[i] = 0;
		}

		public void BringToHome()
		{
			foreach( Mobile mobile in Creatures )
				mobile.Location = this.Location;
		}

		public void SpawnCreatures( int i )
		{
			bool success = false;

			Type spawnType = ScriptCompiler.FindTypeByName( (string) CreatureList[i] );

			if ( spawnType != null )
			{
				try
				{
					object obj = Activator.CreateInstance( spawnType );

					if ( obj is Mobile )
					{
						BaseCreature creature = (BaseCreature) obj;
						Creatures.Add( creature );
						creature.Map = Map;
						int range = (int) SpawnRangeList[i];

						for ( int cnt = 0; cnt < 20; cnt++ )
						{
							int x = Location.X + ( Utility.Random( ( (int) range * 2 ) + 1 ) - range );
							int y = Location.Y + ( Utility.Random( ( (int) range * 2 ) + 1 ) - range );
							int z = Map.GetAverageZ( x, y );

							if ( Map.CanSpawnMobile( new Point2D( x, y ), Location.Z ) )
							{
								success = true;
								creature.Location = new Point3D( x, y, Location.Z );
								creature.Home = Location;
								creature.RangeHome = (int) WalkRangeList[i];

								break;
							}
							else if ( Map.CanSpawnMobile( new Point2D( x, y ), z ) )
							{
								success = true;
								creature.Location = new Point3D( x, y, z );
								creature.Home = Location;
								creature.RangeHome = (int) WalkRangeList[i];

								break;
							}
						}

						if ( !success )
							creature.Delete();
					}
				}
				catch{}
			}
		}

		public void TimerTick()
		{
			for ( int i = 0; i < CreatureList.Count; i++ )
			{
				int countDown = (int) SpawnCounterList[i];

				if ( countDown <= 0 )
				{
					SpawnCounterList[i] = Utility.Random( (int) MinDelayList[i], (int) MaxDelayList[i] - (int) MinDelayList[i] );

					CheckCreatures();
					int creatureCount = CountCreatures( i );

					if ( creatureCount < (int) AmountList[i] )
					{
						int difference = (int) AmountList[i] - creatureCount;

						for ( int diffCount = 0; diffCount < difference; diffCount++ )
							SpawnCreatures( i );
					}
				}

				SpawnCounterList[i] = (int) SpawnCounterList[i] - 1;
			}
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 1 ); // version

			writer.Write( Active );
			writer.Write( Imported );

			writer.Write( CreatureList.Count );

			for ( int i = 0; i < CreatureList.Count; i++ )
				writer.Write( (string) CreatureList[i] );

			for ( int i = 0; i < SpawnRangeList.Count; i++ )
				writer.Write( (int) SpawnRangeList[i] );

			for ( int i = 0; i < WalkRangeList.Count; i++ )
				writer.Write( (int) WalkRangeList[i] );

			for ( int i = 0; i < AmountList.Count; i++ )
				writer.Write( (int) AmountList[i] );

			for ( int i = 0; i < MinDelayList.Count; i++ )
				writer.Write( (int) MinDelayList[i] );

			for ( int i = 0; i < MaxDelayList.Count; i++ )
				writer.Write( (int) MaxDelayList[i] );

			for ( int i = 0; i < SpawnCounterList.Count; i++ )
				writer.Write( (int) SpawnCounterList[i] );

			writer.Write( Creatures.Count );

			for ( int i = 0; i < Creatures.Count; i++ )
			{
				object o = Creatures[i];

				if ( o is Mobile )
					writer.Write( (Mobile)o );
				else
					writer.Write( Serial.MinusOne );
			}

		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			switch ( version )
			{
				case 1:
				{
					Active = reader.ReadBool();
					Imported = reader.ReadBool();

					int count = reader.ReadInt();

					CreatureList = new ArrayList( count );
					SpawnRangeList = new ArrayList( count );
					WalkRangeList = new ArrayList( count );
					AmountList = new ArrayList( count );
					MinDelayList = new ArrayList( count );
					MaxDelayList = new ArrayList( count );
					SpawnCounterList = new ArrayList( count );
					Creatures = new ArrayList();

					for ( int i = 0; i < count; i++ )
						CreatureList.Add( reader.ReadString() );

					for ( int i = 0; i < count; i++ )
						SpawnRangeList.Add( reader.ReadInt() );

					for ( int i = 0; i < count; i++ )
						WalkRangeList.Add( reader.ReadInt() );

					for ( int i = 0; i < count; i++ )
						AmountList.Add( reader.ReadInt() );

					for ( int i = 0; i < count; i++ )
						MinDelayList.Add( reader.ReadInt() );

					for ( int i = 0; i < count; i++ )
						MaxDelayList.Add( reader.ReadInt() );

					for ( int i = 0; i < count; i++ )
						SpawnCounterList.Add( reader.ReadInt() );

					int creatureCount = reader.ReadInt();

					for ( int i = 0; i < creatureCount; i++ )
					{
						IEntity e = World.FindEntity( reader.ReadInt() );

						if ( e != null )
							Creatures.Add( e );
					}

					if ( Active )
					{
						m_MegaSpawnerTimer = new MegaSpawnerTimer( this );
						m_MegaSpawnerTimer.Start();
					}

					goto case 0;
				}
				case 0:
				{
					break;
				}

			}

			MegaSpawnerGump.SpawnerList.Add( this );
		}

		public class MegaSpawnerTimer : Timer
		{ 
			private MegaSpawner m_MegaSpawner;

			public MegaSpawnerTimer( MegaSpawner megaSpawner ) : base( TimeSpan.Zero, TimeSpan.FromSeconds( 1.0 ) )
			{
				m_MegaSpawner = megaSpawner;
			}

			protected override void OnTick()
			{
				if ( !m_MegaSpawner.Active || m_MegaSpawner.Deleted || m_MegaSpawner.Map == null || m_MegaSpawner.Map == Map.Internal )
					Stop();

				m_MegaSpawner.TimerTick();
			}
		}
	}
}