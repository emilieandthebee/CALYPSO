using System;
using Server;

namespace Server.Items
{

	public class ClueNotepad: BaseBook
	{
		[Constructable]
		public ClueNotepad() : base( Utility.Random( 0xFF1, 2 ), "Clue NotePad", "Clue", 20, true )
		{
			Name="Bloc-Notes de Kloedu";

			Pages[0].Lines = new string[]
				{
					"PERSONNAGES:",
					"Mlle Rose",
					"Col. Moutarde",
					"Mme Leblanc",
					"Dr. Olive",
					"Mme Pervenche",
					"Pr. Violet",
					""
				};

			Pages[1].Lines = new string[]
				{
					"ARMES:",
					"Pistolaser",
					"Vibro-dague",
					"Matrakoton",
					"Bombe Plasma",
					"Pouding Anglais",
					"Syntolacereur",
					""
				};


			Pages[2].Lines = new string[]
				{
					"PIECES:",
					"Salle machines",
					"Pont",
					"Quartiers",
					"Infra-cafe",
					"Ecoutilles",
					"Soutes",
					"Salle-Com"
				};

			Pages[3].Lines = new string[]
				{
					"Messe",
					"Salle d'armes",
					"",
					"",
					"",
					"",
					"",
					""
					
				};


		}

		public ClueNotepad( Serial serial ) : base( serial )
		{
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int)0 ); 
		}
	}
}