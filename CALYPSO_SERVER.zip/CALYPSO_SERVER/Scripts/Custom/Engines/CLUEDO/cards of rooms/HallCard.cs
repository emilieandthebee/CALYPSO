using System; 
using Server; 

namespace Server.Items 
{ 
	public class HallCard : Item
	{ 
		[Constructable]
		public HallCard() : base( 0x12AB ) 
		{
			Hue = 1167;
			Weight = 1.0;
			Name = "Une carte nommee Ecoutilles";
		} 

		public HallCard( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 0 ); 
		} 
       
		public override void Deserialize(GenericReader reader) 
		{ 
			base.Deserialize( reader ); 
			int version = reader.ReadInt(); 
		}
	} 
}