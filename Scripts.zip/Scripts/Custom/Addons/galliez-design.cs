using System;
using Server;

namespace Server.Items
{
	public class NewDesignAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new NewDesignDeed(); } }

		[Constructable]
		public NewDesignAddon()
		{
			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 1, 10 + y, 0 );

			for ( int x = 0; x < 11; ++x )
				AddComponent( new AddonComponent( 0x076C ), 1 + x, 15, 0 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 1, 16 + y, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 2 + x, 10 + y, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 2 + x, 16 + y, 0 );

			AddComponent( new AddonComponent( 0x0775 ), 5, 3, 0 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 5, 4 + y, 0 );

			for ( int y = 0; y < 7; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 5, 21 + y, 0 );

			AddComponent( new AddonComponent( 0x0777 ), 5, 28, 0 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 6 + x, 3, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 11; ++y )
					AddComponent( new AddonComponent( 0x076C ), 6 + x, 4 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 8; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 6 + x, 11 + y, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 12; ++y )
					AddComponent( new AddonComponent( 0x076C ), 6 + x, 16 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 6 + x, 28, 0 );

			for ( int y = 0; y < 14; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 9, 11 + y, 0 );

			AddComponent( new AddonComponent( 0x077C ), 9, 28, 0 );
			AddComponent( new AddonComponent( 0x0777 ), 9, 29, 0 );
			AddComponent( new AddonComponent( 0x0775 ), 10, 1, 0 );
			AddComponent( new AddonComponent( 0x0770 ), 10, 2, 0 );
			AddComponent( new AddonComponent( 0x0779 ), 10, 3, 0 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x076C ), 10, 4 + y, 0 );

			for ( int x = 0; x < 14; ++x )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 10 + x, 6, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 3; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 10 + x, 7 + y, 0 );

			for ( int y = 0; y < 10; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 10, 10 + y, 0 );

			AddComponent( new AddonComponent( 0x0778 ), 10, 10, 0 );
			AddComponent( new AddonComponent( 0x076E ), 10, 11, 0 );
			AddComponent( new AddonComponent( 0x077F ), 10, 12, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 10 + x, 13 + y, 0 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076C ), 10 + x, 16, 0 );

			AddComponent( new AddonComponent( 0x077E ), 10, 17, 0 );
			AddComponent( new AddonComponent( 0x076E ), 10, 18, 0 );
			AddComponent( new AddonComponent( 0x0776 ), 10, 19, 0 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 10, 20 + y, 0 );

			for ( int x = 0; x < 10; ++x )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 10 + x, 24, 0 );

			for ( int x = 0; x < 5; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 10 + x, 24 + y, 0 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076D ), 10 + x, 29, 0 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 11 + x, 1, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 11 + x, 2 + y, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 9; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 11 + x, 10 + y, 0 );

			AddComponent( new AddonComponent( 0x076F ), 11, 12, 0 );
			AddComponent( new AddonComponent( 0x076D ), 11, 17, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 11 + x, 19 + y, 0 );

			AddComponent( new AddonComponent( 0x0778 ), 12, 12, 0 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 12, 13 + y, 0 );

			AddComponent( new AddonComponent( 0x0776 ), 12, 17, 0 );

			for ( int y = 0; y < 10; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 13, 10 + y, 0 );

			AddComponent( new AddonComponent( 0x076C ), 13, 10, 0 );
			AddComponent( new AddonComponent( 0x076C ), 13, 19, 0 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 13, 20 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 14 + x, 7 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 8; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 14 + x, 11 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 14 + x, 19 + y, 0 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 1 + y, 0 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 24 + y, 0 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 16 + x, 1, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 2 + y, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 24 + y, 0 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076D ), 16 + x, 29, 0 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 17, 7 + y, 0 );

			for ( int y = 0; y < 10; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 17, 10 + y, 0 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076C ), 17 + x, 10, 0 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076C ), 17 + x, 19, 0 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 17, 20 + y, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 8; ++y )
					AddComponent( new AddonComponent( 0x076C ), 18 + x, 2 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 17; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 18 + x, 7 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 18 + x, 11, 0 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 18 + x, 18, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 9; ++y )
					AddComponent( new AddonComponent( 0x076C ), 18 + x, 20 + y, 0 );

			AddComponent( new AddonComponent( 0x0778 ), 20, 1, 0 );
			AddComponent( new AddonComponent( 0x076E ), 20, 2, 0 );
			AddComponent( new AddonComponent( 0x077B ), 20, 3, 0 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 20, 4 + y, 0 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 21 + x, 3, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 3; ++y )
					AddComponent( new AddonComponent( 0x076C ), 21 + x, 4 + y, 0 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 21, 7 + y, 0 );

			for ( int y = 0; y < 10; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 21, 10 + y, 0 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 21, 20 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 21 + x, 24 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( 0x076C ), 21 + x, 24 + y, 0 );

			AddComponent( new AddonComponent( 0x077A ), 21, 28, 0 );
			AddComponent( new AddonComponent( 0x0776 ), 21, 29, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 22 + x, 7 + y, 0 );

			for ( int x = 0; x < 5; ++x )
				for ( int y = 0; y < 8; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0529, 4 ) ), 22 + x, 11 + y, 0 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( Utility.Random( 0x0525, 4 ) ), 22 + x, 19 + y, 0 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 22 + x, 28, 0 );

			for ( int y = 0; y < 24; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 4 + y, 0 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 11; ++y )
					AddComponent( new AddonComponent( 0x076C ), 25 + x, 10 + y, 0 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076E ), 29, 10 + y, 0 );

			AddComponent( new AddonComponent( 0x076C ), 29, 15, 0 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076E ), 29, 16 + y, 0 );

			for ( int x = 0; x < 7; ++x )
				AddComponent( new AddonComponent( 0x076C ), 1 + x, 15, 7 );

			for ( int x = 0; x < 7; ++x )
				AddComponent( new AddonComponent( 0x076C ), 1 + x, 15, 12 );

			for ( int x = 0; x < 7; ++x )
				AddComponent( new AddonComponent( 0x076C ), 1 + x, 15, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076C ), 1 + x, 15, 22 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 2, 10 + y, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 2, 16 + y, 7 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 3 + x, 10 + y, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 3, 10 + y, 12 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 3 + x, 16 + y, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 3, 16 + y, 12 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 4 + x, 10 + y, 12 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 4, 10 + y, 17 );

			AddComponent( new AddonComponent( 0x076E ), 4, 15, 22 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 4 + x, 16 + y, 12 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 4, 16 + y, 17 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 5 + x, 10 + y, 17 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 5 + x, 16 + y, 17 );

			AddComponent( new AddonComponent( 0x0775 ), 6, 4, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 6, 5 + y, 7 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 6, 21 + y, 7 );

			AddComponent( new AddonComponent( 0x0777 ), 6, 27, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 7 + x, 4, 7 );

			for ( int y = 0; y < 10; ++y )
				AddComponent( new AddonComponent( 0x076C ), 7, 5 + y, 7 );

			AddComponent( new AddonComponent( 0x0775 ), 7, 5, 12 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 7, 6 + y, 12 );

			for ( int y = 0; y < 11; ++y )
				AddComponent( new AddonComponent( 0x076C ), 7, 16 + y, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 7, 21 + y, 12 );

			AddComponent( new AddonComponent( 0x0777 ), 7, 26, 12 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 7 + x, 27, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 7; ++y )
					AddComponent( new AddonComponent( 0x076C ), 8 + x, 5 + y, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 8 + x, 5, 12 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 6; ++y )
					AddComponent( new AddonComponent( 0x076C ), 8 + x, 6 + y, 12 );

			AddComponent( new AddonComponent( 0x0775 ), 8, 6, 17 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 8, 7 + y, 17 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 8, 10 + y, 17 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 8; ++y )
					AddComponent( new AddonComponent( 0x076C ), 8 + x, 19 + y, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 7; ++y )
					AddComponent( new AddonComponent( 0x076C ), 8 + x, 19 + y, 12 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 8, 19 + y, 17 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x0770 ), 8, 21 + y, 17 );

			AddComponent( new AddonComponent( 0x0777 ), 8, 25, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 8 + x, 26, 12 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 9 + x, 6, 17 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076C ), 9, 7 + y, 17 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 9, 19 + y, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 9 + x, 25, 17 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 10 + x, 5 + y, 7 );

			for ( int x = 0; x < 15; ++x )
				AddComponent( new AddonComponent( 0x076C ), 10 + x, 6, 12 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x076C ), 10, 24 + y, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 10 + x, 24 + y, 12 );

			for ( int x = 0; x < 15; ++x )
				AddComponent( new AddonComponent( 0x076C ), 10 + x, 24, 17 );

			AddComponent( new AddonComponent( 0x077C ), 10, 27, 7 );
			AddComponent( new AddonComponent( 0x0777 ), 10, 28, 7 );
			AddComponent( new AddonComponent( 0x0775 ), 11, 2, 7 );
			AddComponent( new AddonComponent( 0x0770 ), 11, 3, 7 );
			AddComponent( new AddonComponent( 0x0779 ), 11, 4, 7 );

			for ( int x = 0; x < 4; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( 0x076C ), 11 + x, 24 + y, 7 );

			AddComponent( new AddonComponent( 0x077C ), 11, 26, 12 );
			AddComponent( new AddonComponent( 0x0777 ), 11, 27, 12 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076D ), 11 + x, 28, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 12 + x, 2, 7 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( 0x076C ), 12 + x, 3 + y, 7 );

			AddComponent( new AddonComponent( 0x0775 ), 12, 3, 12 );
			AddComponent( new AddonComponent( 0x0770 ), 12, 4, 12 );
			AddComponent( new AddonComponent( 0x0779 ), 12, 5, 12 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 3; ++y )
					AddComponent( new AddonComponent( 0x076C ), 12 + x, 24 + y, 12 );

			AddComponent( new AddonComponent( 0x077C ), 12, 25, 17 );
			AddComponent( new AddonComponent( 0x0777 ), 12, 26, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 12 + x, 27, 12 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076F ), 13 + x, 3, 12 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 13 + x, 4 + y, 12 );

			AddComponent( new AddonComponent( 0x0775 ), 13, 4, 17 );
			AddComponent( new AddonComponent( 0x0770 ), 13, 5, 17 );
			AddComponent( new AddonComponent( 0x0779 ), 13, 6, 17 );
			AddComponent( new AddonComponent( 0x076C ), 13, 10, 7 );
			AddComponent( new AddonComponent( 0x076C ), 13, 10, 12 );
			AddComponent( new AddonComponent( 0x076C ), 13, 10, 17 );
			AddComponent( new AddonComponent( 0x076C ), 13, 10, 22 );
			AddComponent( new AddonComponent( 0x076C ), 13, 19, 7 );
			AddComponent( new AddonComponent( 0x076C ), 13, 19, 12 );
			AddComponent( new AddonComponent( 0x076C ), 13, 19, 17 );
			AddComponent( new AddonComponent( 0x076C ), 13, 19, 22 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076C ), 13 + x, 25, 17 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076D ), 13 + x, 26, 17 );

			AddComponent( new AddonComponent( 0x076F ), 14, 4, 17 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 14, 5 + y, 17 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 1 + y, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 1 + y, 12 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 1 + y, 17 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 1 + y, 22 );

			AddComponent( new AddonComponent( 0x076D ), 15, 4, 22 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 24 + y, 7 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 24 + y, 12 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 26 + y, 17 );

			AddComponent( new AddonComponent( 0x076F ), 15, 26, 22 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x076C ), 15, 27 + y, 22 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 16 + x, 2, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 3 + y, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 16 + x, 3, 12 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 4 + y, 12 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076F ), 16 + x, 4, 17 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 5 + y, 17 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 4; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 24 + y, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 3; ++y )
					AddComponent( new AddonComponent( 0x076C ), 16 + x, 24 + y, 12 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076D ), 16 + x, 26, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 16 + x, 27, 12 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076D ), 16 + x, 28, 7 );

			AddComponent( new AddonComponent( 0x076C ), 17, 10, 7 );
			AddComponent( new AddonComponent( 0x076C ), 17, 10, 12 );
			AddComponent( new AddonComponent( 0x076C ), 17, 10, 17 );
			AddComponent( new AddonComponent( 0x076C ), 17, 10, 22 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 7 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 12 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 17 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 22 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 7; ++y )
					AddComponent( new AddonComponent( 0x076C ), 18 + x, 3 + y, 7 );

			AddComponent( new AddonComponent( 0x0778 ), 18, 4, 17 );
			AddComponent( new AddonComponent( 0x076E ), 18, 5, 17 );
			AddComponent( new AddonComponent( 0x077B ), 18, 6, 17 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 18 + x, 7 + y, 12 );

			for ( int x = 0; x < 7; ++x )
				AddComponent( new AddonComponent( 0x076C ), 18 + x, 7, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 18 + x, 8, 17 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 18 + x, 9, 12 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 18 + x, 10, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 18 + x, 19, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 8; ++y )
					AddComponent( new AddonComponent( 0x076C ), 18 + x, 20 + y, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 18 + x, 20, 12 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 18, 21 + y, 12 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 18 + x, 21, 17 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 2; ++y )
					AddComponent( new AddonComponent( 0x076C ), 18 + x, 22 + y, 17 );

			AddComponent( new AddonComponent( 0x077A ), 18, 25, 17 );
			AddComponent( new AddonComponent( 0x0776 ), 18, 26, 17 );
			AddComponent( new AddonComponent( 0x0778 ), 19, 3, 12 );
			AddComponent( new AddonComponent( 0x076E ), 19, 4, 12 );
			AddComponent( new AddonComponent( 0x077B ), 19, 5, 12 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076F ), 19 + x, 6, 17 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 5; ++y )
					AddComponent( new AddonComponent( 0x076C ), 19 + x, 21 + y, 12 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076D ), 19 + x, 25, 17 );

			AddComponent( new AddonComponent( 0x077A ), 19, 26, 12 );
			AddComponent( new AddonComponent( 0x0776 ), 19, 27, 12 );
			AddComponent( new AddonComponent( 0x0778 ), 20, 2, 7 );
			AddComponent( new AddonComponent( 0x076E ), 20, 3, 7 );
			AddComponent( new AddonComponent( 0x077B ), 20, 4, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076C ), 20, 5 + y, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076F ), 20 + x, 5, 12 );

			for ( int y = 0; y < 7; ++y )
				AddComponent( new AddonComponent( 0x076C ), 20, 20 + y, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076D ), 20 + x, 26, 12 );

			AddComponent( new AddonComponent( 0x077A ), 20, 27, 7 );
			AddComponent( new AddonComponent( 0x0776 ), 20, 28, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076F ), 21 + x, 4, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076C ), 21 + x, 5, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076C ), 21 + x, 8, 17 );

			AddComponent( new AddonComponent( 0x076C ), 21, 10, 7 );
			AddComponent( new AddonComponent( 0x076C ), 21, 10, 12 );

			for ( int x = 0; x < 6; ++x )
				AddComponent( new AddonComponent( 0x076C ), 21 + x, 10, 17 );

			AddComponent( new AddonComponent( 0x076C ), 21, 10, 22 );
			AddComponent( new AddonComponent( 0x076C ), 21, 19, 7 );
			AddComponent( new AddonComponent( 0x076C ), 21, 19, 12 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076C ), 21, 19 + y, 17 );

			AddComponent( new AddonComponent( 0x076C ), 21, 19, 22 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 21, 25 + y, 7 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076C ), 21 + x, 25, 12 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076D ), 21 + x, 27, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076C ), 22 + x, 9, 17 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 13; ++y )
					AddComponent( new AddonComponent( 0x076C ), 22 + x, 11 + y, 17 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 3; ++y )
					AddComponent( new AddonComponent( 0x076C ), 22 + x, 24 + y, 7 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076C ), 22 + x, 24, 12 );

			AddComponent( new AddonComponent( 0x076C ), 24, 4, 7 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 4 + y, 12 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 5 + y, 17 );

			for ( int y = 0; y < 22; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 6 + y, 7 );

			for ( int y = 0; y < 5; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 6 + y, 22 );

			for ( int y = 0; y < 17; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 7 + y, 12 );

			for ( int y = 0; y < 6; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 20 + y, 22 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 25 + y, 17 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 24, 26 + y, 12 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 11; ++y )
					AddComponent( new AddonComponent( 0x076C ), 25 + x, 10 + y, 7 );

			for ( int x = 0; x < 2; ++x )
				for ( int y = 0; y < 11; ++y )
					AddComponent( new AddonComponent( 0x076C ), 25 + x, 10 + y, 12 );

			AddComponent( new AddonComponent( 0x076C ), 25, 10, 22 );

			for ( int y = 0; y < 10; ++y )
				AddComponent( new AddonComponent( 0x076C ), 25, 11 + y, 17 );

			AddComponent( new AddonComponent( 0x076C ), 25, 20, 22 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 26, 11 + y, 17 );

			for ( int x = 0; x < 4; ++x )
				AddComponent( new AddonComponent( 0x076C ), 26 + x, 15, 17 );

			AddComponent( new AddonComponent( 0x0770 ), 26, 15, 22 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 26, 16 + y, 17 );

			AddComponent( new AddonComponent( 0x076C ), 26, 20, 17 );
			AddComponent( new AddonComponent( 0x076C ), 27, 10, 12 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 27, 11 + y, 12 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076C ), 27 + x, 15, 12 );

			for ( int x = 0; x < 3; ++x )
				AddComponent( new AddonComponent( 0x076C ), 27 + x, 15, 22 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 27, 16 + y, 12 );

			AddComponent( new AddonComponent( 0x076C ), 27, 20, 12 );
			AddComponent( new AddonComponent( 0x076C ), 28, 10, 7 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 28, 11 + y, 7 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076C ), 28 + x, 15, 7 );

			for ( int y = 0; y < 4; ++y )
				AddComponent( new AddonComponent( 0x076E ), 28, 16 + y, 7 );

			AddComponent( new AddonComponent( 0x076C ), 28, 20, 7 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 27 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 32 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 37 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 42 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x015F ), 8, 11 + y, 27 );

			AddComponent( new AddonComponent( 0x0162 ), 8, 14, 27 );

			for ( int y = 0; y < 3; ++y )
				AddComponent( new AddonComponent( 0x015F ), 8, 15 + y, 27 );

			AddComponent( new AddonComponent( 0x0162 ), 8, 18, 27 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x015F ), 8, 19 + y, 27 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x015F ), 9, 7 + y, 27 );

			AddComponent( new AddonComponent( 0x0162 ), 9, 9, 27 );
			AddComponent( new AddonComponent( 0x015F ), 9, 10, 27 );
			AddComponent( new AddonComponent( 0x076C ), 9, 11, 27 );
			AddComponent( new AddonComponent( 0x076C ), 9, 11, 32 );
			AddComponent( new AddonComponent( 0x076C ), 9, 11, 37 );
			AddComponent( new AddonComponent( 0x076C ), 9, 11, 42 );
			AddComponent( new AddonComponent( 0x076C ), 9, 20, 27 );
			AddComponent( new AddonComponent( 0x076C ), 9, 20, 32 );
			AddComponent( new AddonComponent( 0x076C ), 9, 20, 37 );
			AddComponent( new AddonComponent( 0x076C ), 9, 20, 42 );
			AddComponent( new AddonComponent( 0x015F ), 9, 21, 27 );
			AddComponent( new AddonComponent( 0x0162 ), 9, 22, 27 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x015F ), 9, 23 + y, 27 );

			for ( int x = 0; x < 8; ++x )
				AddComponent( new AddonComponent( 0x0161 ), 10 + x, 6, 27 );

			for ( int x = 0; x < 8; ++x )
				AddComponent( new AddonComponent( 0x0161 ), 10 + x, 24, 27 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076C ), 13 + x, 10, 27 );

			AddComponent( new AddonComponent( 0x076C ), 13, 10, 32 );
			AddComponent( new AddonComponent( 0x076C ), 13, 10, 37 );
			AddComponent( new AddonComponent( 0x076C ), 13, 10, 42 );

			for ( int x = 0; x < 5; ++x )
				AddComponent( new AddonComponent( 0x076C ), 13 + x, 19, 27 );

			AddComponent( new AddonComponent( 0x076C ), 13, 19, 32 );
			AddComponent( new AddonComponent( 0x076C ), 13, 19, 37 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 27 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 32 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 37 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 42 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 27 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 32 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 37 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 42 );
			AddComponent( new AddonComponent( 0x076C ), 17, 10, 32 );
			AddComponent( new AddonComponent( 0x076C ), 17, 10, 37 );
			AddComponent( new AddonComponent( 0x076C ), 17, 10, 42 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 32 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 37 );
			AddComponent( new AddonComponent( 0x076C ), 17, 19, 42 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076C ), 21 + x, 10, 27 );

			AddComponent( new AddonComponent( 0x076C ), 21, 10, 32 );
			AddComponent( new AddonComponent( 0x076C ), 21, 10, 37 );
			AddComponent( new AddonComponent( 0x076C ), 21, 10, 42 );

			for ( int x = 0; x < 2; ++x )
				AddComponent( new AddonComponent( 0x076C ), 21 + x, 19, 27 );

			AddComponent( new AddonComponent( 0x076C ), 21, 19, 32 );
			AddComponent( new AddonComponent( 0x076C ), 21, 19, 37 );
			AddComponent( new AddonComponent( 0x076C ), 21, 19, 42 );
			AddComponent( new AddonComponent( 0x076C ), 22, 9, 27 );

			for ( int y = 0; y < 8; ++y )
				AddComponent( new AddonComponent( 0x0161 ), 22, 11 + y, 27 );

			AddComponent( new AddonComponent( 0x076C ), 22, 20, 27 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 27 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 32 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 37 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 42 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 47 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 52 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 57 );
			AddComponent( new AddonComponent( 0x076C ), 1, 15, 62 );

			for ( int y = 0; y < 15; ++y )
				AddComponent( new AddonComponent( 0x076C ), 9, 10 + y, 47 );

			for ( int x = 0; x < 8; ++x )
				for ( int y = 0; y < 18; ++y )
					AddComponent( new AddonComponent( 0x076C ), 10 + x, 7 + y, 47 );

			for ( int x = 0; x < 6; ++x )
				for ( int y = 0; y < 16; ++y )
					AddComponent( new AddonComponent( 0x076C ), 12 + x, 7 + y, 52 );

			AddComponent( new AddonComponent( 0x076C ), 12, 10, 57 );
			AddComponent( new AddonComponent( 0x076C ), 12, 10, 62 );
			AddComponent( new AddonComponent( 0x076C ), 12, 16, 57 );
			AddComponent( new AddonComponent( 0x076C ), 12, 16, 62 );
			AddComponent( new AddonComponent( 0x076C ), 12, 22, 57 );
			AddComponent( new AddonComponent( 0x076C ), 12, 22, 62 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 47 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 52 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 57 );
			AddComponent( new AddonComponent( 0x076C ), 15, 1, 62 );
			AddComponent( new AddonComponent( 0x076C ), 15, 10, 57 );
			AddComponent( new AddonComponent( 0x076C ), 15, 10, 62 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 47 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 52 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 57 );
			AddComponent( new AddonComponent( 0x076C ), 15, 29, 62 );
			AddComponent( new AddonComponent( 0x076C ), 17, 22, 57 );
			AddComponent( new AddonComponent( 0x076C ), 17, 22, 62 );

			for ( int y = 0; y < 15; ++y )
				AddComponent( new AddonComponent( 0x076C ), 18, 7 + y, 47 );

			for ( int y = 0; y < 15; ++y )
				AddComponent( new AddonComponent( 0x076C ), 18, 7 + y, 52 );

			for ( int y = 0; y < 12; ++y )
				AddComponent( new AddonComponent( 0x076C ), 19, 10 + y, 47 );

			for ( int y = 0; y < 12; ++y )
				AddComponent( new AddonComponent( 0x076C ), 19, 10 + y, 52 );

			AddComponent( new AddonComponent( 0x076C ), 19, 10, 57 );
			AddComponent( new AddonComponent( 0x076C ), 19, 10, 62 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 19, 15 + y, 57 );

			for ( int y = 0; y < 2; ++y )
				AddComponent( new AddonComponent( 0x076C ), 19, 15 + y, 62 );

			AddComponent( new AddonComponent( 0x076C ), 19, 21, 57 );
			AddComponent( new AddonComponent( 0x076C ), 19, 21, 62 );

			for ( int x = 0; x < 3; ++x )
				for ( int y = 0; y < 11; ++y )
					AddComponent( new AddonComponent( 0x076C ), 20 + x, 10 + y, 47 );

			AddComponent( new AddonComponent( 0x076C ), 22, 10, 52 );
			AddComponent( new AddonComponent( 0x076C ), 22, 10, 57 );
			AddComponent( new AddonComponent( 0x076C ), 22, 20, 52 );
			AddComponent( new AddonComponent( 0x076C ), 22, 20, 57 );
			AddComponent( new AddonComponent( 0x076C ), 22, 20, 62 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 47 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 52 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 57 );
			AddComponent( new AddonComponent( 0x076C ), 29, 15, 62 );
		}

		public NewDesignAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class NewDesignDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new NewDesignAddon(); } }

		[Constructable]
		public NewDesignDeed()
		{
			Name = "New Design";
		}

		public NewDesignDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}