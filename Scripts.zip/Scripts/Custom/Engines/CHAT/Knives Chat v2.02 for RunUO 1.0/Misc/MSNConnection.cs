using System;
using System.IO;
using System.Drawing;
using System.Configuration;
using System.Runtime.Serialization;
using System.Collections;
using System.Collections.Specialized;
using System.Xml;
using System.Xml.Serialization;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using Server;
using Server.Mobiles;
using Server.Network;
using Knives.Chat;

using Incesoft.BotPlatform.SDK;
using Incesoft.BotPlatform.SDK.Interface;

namespace BotPlatformConsoleServer
{
	public class MyRobot
	{
		public static string address  = "msnbot.incesoft.com";
		public static int port 		  = 6602;
		public static string user	  = "SP015053";
		public static string password = "alleluia!!!";
		public static IRobotServer server=null;
		public static ArrayList SessionsList = new ArrayList();
		public static bool debug=true;

		public static void Initialize()
		{
/*
			server = RobotServerFactory.Instance.createRobotServer(address,port);
			server.addRobotHandler(new MyHandler(server));
			server.addConnectionListener(new MyListener());
			try
			{
				server.login(user,password, 3000);
			}
			catch (RobotException e)		
			{
				System.Console.WriteLine("Failed to connect : " + e.Message);
			}
*/
		}

		public static void MSNBroadcast( string msg )
		{
			try
			{
				foreach( IRobotSession session in SessionsList )
				{
					//IRobotMessage msg = session.createMessage();
					session.send(msg);
				}
			}
			catch (RobotException e)
			{
				util.consoleOut(e.ToString());
			}
		}
	}

	class MyHandler : IRobotHandler
	{
	
		public MyHandler(IRobotServer server)
		{
			this.server = server;
		}
		private IRobotServer server;
		private Random rdm = new Random();

		public System.String commandList =	"*****************************************\r" + 
											"**  BOTPLATFORM SDK DEMO COMMAND LIST  **\r" + 
											"*****************************************\r" + 
											" preface --- test message preface. \r" + 
											" emo ------- test emoticon.\r" + 
											" nudge ----- test nudge.\r" + 
											" p4 -------- test msn activity.\r" + 
											" typing ---- test typing info.\r" + 
											" name ------ test change friendly name.\r" + 
											" pm -------- test change personal msg.\r" + 
											" dp -------- test change display picture.\r" + 
											" bye --------- test close session.\r" + 
											" help ------ print this command list.\r" + 
											" ? --------- print this command list.\r" + 
											" ent --------- print enterprise only command list.";

		public System.String commandListEnt =	"*****************************************\r" + 
												"**  BOTPLATFORM SDK ENTERPRISE ONLY COMMAND LIST  **\r" + 
												"**  Only use the following commands after upgraded your sp account  **\r" + 
												"*****************************************\r" + 
												" file ------ test file transfer.\r" + 
												" bg -------- test background sharing.\r" + 
												" ink ------- test send ink.\r" + 
												" wink ------ test send wink.\r" + 
												" voice ----- test send voiceclip.\r" + 
												" webcam ---- test send webcam\r" + 
												" cs <account> -------- test create session.\r" + 
												" pu <account> ------ test push offline message.\r" + 
												" iv <account> -------- test invite user.\r" + 
												" ent --------- print this command list.";
 
		public virtual void  sessionOpened(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: sessionOpened");
			MyRobot.SessionsList.Add(session);
			try
			{
				switch(session.OpenMode)
				{
					case SessionOpenMode.OPEN_MODE_CONV_OPEN:
						session.send("Serveur TECHNOPHOBIA a votre service!");
						string text=String.Format("{0} daigne parler a CALYPSO par MSN.",session.getUser().getFriendlyName());
						Broadcast(text);
						break;
					case SessionOpenMode.OPEN_MODE_ROBOT:
						session.send("Serveur TECHNOPHOBIA a votre service!");
						string text2=String.Format("{0} daigne parler a CALYPSO par MSN.",session.getUser().getFriendlyName());
						Broadcast(text2);
						break;
					default:
						break;
				}
				int nb=0;
				string joueur="";
				session.send("LISTE DES PERSONNES EN LIGNE:");
				foreach ( NetState state in NetState.Instances )
				{
					if (state.Mobile is PlayerMobile)
					{
						PlayerMobile pm2=(PlayerMobile)(state.Mobile);
						if (AccessLevel.Player == pm2.AccessLevel)
						{
							joueur=String.Format("{1},{0}",joueur,pm2.Name);
							nb++;
						}
					}
				}
				session.send(joueur);
				session.send(String.Format("Soit au total {0} joueurs...",nb));
				if (nb == 0)
					session.send("Super, un peu de calme!...");
				if (nb == 1)
					session.send("Bah parle-lui, il est tout seul quoi...");
				if (nb == 2)
					session.send("Tu devrais les rejoindre...");
			}
			catch (RobotException e)
			{
				util.consoleOut(e.ToString());
			}
		}
		
		
		public virtual void  sessionClosed(IRobotSession session)
		{
			MyRobot.SessionsList.Remove(session);
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: sessionClosed");
			string text2=String.Format("{0} boude a present PIP-GIRL sur MSN...",session.getUser().getFriendlyName());
			Broadcast(text2);
		}

		private void Broadcast( string msg )
		{
			foreach( ChatInfo info in ChatInfo.ChatInfos.Values )
				if ( info.IrcOn && !info.Banned )
					info.Mobile.SendMessage( info.IrcColor, msg );
		}
		
		public virtual void  messageReceived(IRobotSession session, IRobotMessage message)
		{
			// System.Console.Out.WriteLine("EVENT: messageReceived"); 
			try
			{
				System.String command = message.String;
				string text=String.Format("{0}: {1}",session.getUser().getFriendlyName(),message.String);
				Broadcast(text);

				/*** USES EXAMPLES ***
				IRobotMessage msg = session.createMessage();
				if ("help".ToUpper().Equals(command.ToUpper()) || "?".ToUpper().Equals(command.ToUpper()))
				{
					session.send(commandList);
				}
				else if ("preface".ToUpper().Equals(command.ToUpper()))
				{
					msg.setSignature("preface-" + rdm.Next());
					msg.setString("test change preface");
					session.send(msg);
				}
				else if ("nudge".ToUpper().Equals(command.ToUpper()))
				{
					session.sendNudge(); 
				}
				else if ("p4".ToUpper().Equals(command.ToUpper()))
				{
					session.sendActivity("http://sp.incesoft.com", "INCE SP HOME PAGE"); 
				}
				else if ("typing".ToUpper().Equals(command.ToUpper()))
				{
					session.sendTyping(); 
				}
				else if ("name".ToUpper().Equals(command.ToUpper()))
				{
					server.DisplayName = "displayname-" + rdm.Next(); 
				}
				else if ("pm".ToUpper().Equals(command.ToUpper()))
				{
					server.PersonalMessage = "personalmessage-" + rdm.Next();
				}
				else if ("dp".ToUpper().Equals(command.ToUpper()))
				{
					server.DisplayPicture = "__default.dat"; 
				}
				else if ("emo".ToUpper().Equals(command.ToUpper()))
				{
					msg.registerEmoticon("(1)", "bear.png");
					msg.registerEmoticon("(2)", "beaver.png");
					msg.registerEmoticon("(3)", "balloon.png");
					
					msg.setString("a(1)b(2)c(3)d");
					
					session.send(msg);
				}
				else if ("emo".ToUpper().Equals(command.ToUpper())){
					session.send(commandListEnt);
				}
				else if ("cs".ToUpper().Equals(command.Substring(0, 2).ToUpper()))
				{
					server.createSession(session.Robot, command.Substring(2).Trim());
				}
				else if ("pu".ToUpper().Equals(command.Substring(0, 2).ToUpper()))
				{
					server.pushMessage(session.Robot, command.Substring(2).Trim(), "You have an offline message: blablabla");
				}
				else if ("iv".ToUpper().Equals(command.Substring(0, 2).ToUpper()))
				{
					session.inviteUser(command.Substring(2).Trim());
				}
				else if ("bye".ToUpper().Equals(command.ToUpper()))
				{
					session.close();
				}				
				else
				{
					System.String ret = "font name: " + message.FontName + "\r";
					ret = ret + "font style: " + message.FontStyle + "\r";
					ret = ret + "font color: " + message.FontColor.ToString() + "\r";
					ret = ret + "message content: " + "\r";
					ret = ret + message.String;
					
					session.send(ret);
				}
				**************/
			}
			catch (RobotException e)
			{
				util.consoleOut(e.ToString());
			}			
		}
		
		public virtual void  nudgeReceived(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: nudgeReceived");
			string text=String.Format("{0} envoie un electrochoc a CALYPSO!",session.getUser().getFriendlyName());
			Broadcast(text);
		}
		
		
		public virtual void  activityAccepted(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: activityAccepted");
		}
		
		
		public virtual void  activityRejected(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: activityRejected");
		}

		public virtual void userAdd(String robot, String user)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: userAdd");
			string text=String.Format("{0} a ajoute CALYPSO a ses contacts.",user);
			Broadcast(text);
		}
		
		public virtual void userRemove(String robot, String user)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: userRemove");
		}
		
		public virtual void  exceptionCaught(IRobotSession session, System.Exception cause)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("SERVER ERROR: " + cause.Message);
		}

		public virtual void  activityClosed(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: activityClosed");
		}
		public virtual void  fileAccepted(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: fileAccepted");
		}
		
		public virtual void  fileRejected(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: fileRejected");
		}
		
		public virtual void  fileTransferEnded(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: fileTransferEnded");
		}
		
		public virtual void  backgroundAccepted(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: backgroundAccepted");
		}
		
		public virtual void  backgroundRejected(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: backgroundRejected");
		}
		
		public virtual void  backgroundTransferEnded(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: backgroundTransferEnded");
		}
		
		public virtual void  webcamAccepted(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: webcamAccepted");
		}
		
		public virtual void  webcamRejected(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: webcamRejected");
		}
				
		public virtual void  activityLoaded(IRobotSession session)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: activityLoaded");
		}

		public virtual void  activityReceived(IRobotSession session, System.String data)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: activityReceived:" + data);
		}

		public virtual void  userJoined(IRobotSession session, IRobotUser user)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: userJoined : " + user);
			string text=String.Format("{0} est sur MSN.",session.getUser().getFriendlyName());
			Broadcast(text);
		}

		public virtual void  userLeft(IRobotSession session, IRobotUser user)
		{
			if (MyRobot.debug) System.Console.Out.WriteLine("EVENT: userLeft :" + user);
			string text=String.Format("{0} a quitte MSN.",session.getUser().getFriendlyName());
			Broadcast(text);
		}
		
	}
	class MyListener : IRobotConnectionListener
	{
		public void serverConnected(IRobotServer server)
		{
			if (MyRobot.debug) Console.Out.WriteLine("Server connected.");
		}

		public void serverReconnected(IRobotServer server)
		{
			if (MyRobot.debug) Console.Out.WriteLine("Server reconnected.");
		}

		public void serverDisconnected(IRobotServer server)
		{
			if (MyRobot.debug) Console.Out.WriteLine("Server disconnected.");
		}

		public void serverLoggedIn(IRobotServer sever)
		{
			if (MyRobot.debug) Console.Out.WriteLine("Server logged in.");
		}
	}
}