using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;

namespace Server.Gumps
{
	public class NewMailGump : Gump
	{
		public NewMailGump( Mobile from, MailBox mailbox ) : base( 25, 25)
		{
            mailbox.NewMail = "false";
			from.CloseGump( typeof( NewMailGump ) );
			
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;

			AddPage(0);
			AddBackground(100, 50, 300, 200, 3500);
			AddHtml( 120, 70, 260, 160, @"<BR><BR><center>You have received new mail!<BR><BR>Please check for the items in your mailbox.</center>", true, false);
		}
	}
}
