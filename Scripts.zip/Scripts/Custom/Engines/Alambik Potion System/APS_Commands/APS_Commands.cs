using System;
using Server;
using Server.Items;

/*2.0*
namespace Server.Commands
*1.0*/
namespace Server.Scripts.Commands
{
	public class APS_Commands
	{
		public static void Initialize()
		{
/*2.0*
			CommandSystem.Register( "APS_GenerateList", AccessLevel.Administrator, new CommandEventHandler( APS_GenerateList_OnCommand ) );
*1.0*/
			Server.Commands.Register( "APS_GenerateList", AccessLevel.Administrator, new CommandEventHandler( APS_GenerateList_OnCommand ) );
/****/
		}

		[Usage( "APS_GenerateList" )]
		[Description( "Generates a raw file list of available potions formula" )]
		private static void APS_GenerateList_OnCommand( CommandEventArgs e )
		{
			APS_Mortier.GenerateList();
		}
	}
}