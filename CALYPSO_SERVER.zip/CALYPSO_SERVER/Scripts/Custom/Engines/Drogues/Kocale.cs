using System; 
using Server; 
using Server.Network; 
using Server.Items; 
using Server.Mobiles; 
using Server.Misc;
using Server.Spells;

namespace Server.Items
{ 
   public class Kokale : Item 
   { 
       
      [Constructable]
      public Kokale() : base ( 3983 ) 
      { 
         Hue    = 0;
         Name = "Du Kokale"; 
      } 

      public Kokale( Serial serial ) : base( serial ) 
      { 
      } 
    
      public override void OnDoubleClick( Mobile from ) 
        { 
		TimerInvisible timer = new TimerInvisible(from,1);
        timer.Start(); 
		from.PlaySound( 1092 ); 
		from.SendMessage("Vous snifez le kokale et commencez a vous sentire flotter.");
		SpellHelper.AddStatBonus( from, from, StatType.Dex, -(5+Utility.Random(10)), TimeSpan.FromSeconds(110) );
		Delete();
		} 
  
      public override void Serialize( GenericWriter writer ) 
        { 
           base.Serialize( writer ); 
           writer.Write( (int) 0 ); // version 
        } 

      public override void Deserialize( GenericReader reader ) 
        { 
           base.Deserialize( reader ); 
         int version = reader.ReadInt(); 
        } 
   } 
} 

public class TimerInvisible : Timer 
{ 

   private Mobile m;//on dit que les mobile sont nomm� m 
   private int Temp; //on initialise un entier de type priv� 
   private int puissance; //on initialise un entier de type priv� 

   public TimerInvisible(Mobile from, int PuissanceDonne) : base 
   //( TimeSpan.FromMinutes (1.0), TimeSpan.FromMinutes (1.0) ) si on avait voulut des minutes ;) 
   ( TimeSpan.FromSeconds (1.0), TimeSpan.FromSeconds (1.0) ) // timer +1 toute les 2 secondes 
      { 
         m = from; 
         puissance = PuissanceDonne; 
      } 

   private void action()
   {
		switch( Utility.Random(5) )
		{
		case 1:
			m.Say( "*Rit*" ); 
			if ( m.Female )
				m.PlaySound( 801 );
			else if ( !m.Female )
				m.PlaySound( 1073 );
			m.Direction = (Direction)Utility.Random( 8 );
			break;
		case 2:
			m.Say( "*grogne*" );
			if ( m.Female )
			{
				m.PlaySound( 795 );
				if ( !m.Mounted )
					m.Animate( 6, 5, 1, true, false, 0 );
			}
			else if ( !m.Female )
			{
				m.PlaySound( 1067 );
				if ( !m.Mounted )
				m.Animate( 6, 5, 1, true, false, 0 );
			}
			m.Direction = (Direction)Utility.Random( 8 );
			break;
		case 3:
			m.Say( "*Ricane*" ); 
			if ( m.Female )
				m.PlaySound( 794 );
			else if ( !m.Female )
				m.PlaySound( 1066 );
			m.Direction = (Direction)Utility.Random( 8 );
			break;
		case 4:
			if ( m.Female )
				m.PlaySound( 779 );
			else if ( !m.Female )
				m.PlaySound( 1050 );
			m.Say( "*ah-ha!*" );
			m.Direction = (Direction)Utility.Random( 8 );
			break;
		default:
			break;
		}
   }
	  
   protected override void OnTick() 
      { 

	  if (m == null)
		return;
		
	  if (m.Deleted)
		return;
		
	  if (!(m.Alive))
		return;
		
      Temp++;

      if (Temp == 1) 
		action();
      if (Temp == 16) 
		action();
      if (Temp == 26) 
		action();
      if (Temp == 31) 
		action();
      if (Temp == 34) 
		action();
      if (Temp == 35) 
         { 
			m.Emote( "*A les yeux injectes de sang*" );
			action();
         }   
      if (Temp == 38) 
		action();
      if (Temp == 43) 
		action();
      if (Temp == 53) 
		action();
      if (Temp == 73) 
		action();
      if (Temp == 103) 
		action();
	} 
}