using System;
using Server.Items;

namespace Server.ContextMenus
{
	public class OpenMailEntry : ContextMenuEntry
	{
		private Mobile m_PostalWorker;
		private Mobile m_from;

		public OpenMailEntry( Mobile from, Mobile postalworker ) : base( 2141, 12 )
		{
			m_PostalWorker = postalworker;
			m_from = from;
		}

		public override void OnClick()
		{
			if ( !Owner.From.CheckAlive() )
				return;

			if ( Owner.From.Criminal )
			{
				m_PostalWorker.Say( "Thou art a criminal and cannot access thy mail." );
			}
			else
			{
				MailBox box = m_from.BankBox.FindItemByType( typeof( MailBox ) ) as MailBox;

				if ( box != null )
					box.OnDoubleClick( m_from );
				
			}
		}
	}
}
