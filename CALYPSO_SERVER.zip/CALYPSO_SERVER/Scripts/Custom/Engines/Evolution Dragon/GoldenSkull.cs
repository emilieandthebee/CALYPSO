using System;
using Server;

namespace Server.Items
{
	public class GoldenSkull : Item
	{
		[Constructable]
		public GoldenSkull() : base( 0x1AE1 )
		{
			Name = "A Golden Skull";
			
			Hue = 0x8A5;
			Weight = 2.0;
		}

		public GoldenSkull( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}