using System;
using System.Collections;
using Server;
using Server.Items;
using Server.Gumps;
using Server.Network;
using Server.Misc;


namespace Server.Mobiles
{
	public class AlcoholicVendor : BaseVendor
	{
		private ArrayList m_SBInfos = new ArrayList();
		protected override ArrayList SBInfos{ get { return m_SBInfos; } }
		public override bool ClickTitle{ get{ return false; } }
		public override bool IsActiveBuyer{ get{ return false; } }
		public override bool IsActiveSeller{ get{ return true; } }
		public override bool OnBuyItems( Mobile buyer, ArrayList list )
		{
			return false;
		}
		public static readonly object From = new object();
		public static readonly object Vendor = new object();
		public static readonly object Price = new object();
		private bool m_CanRes;
		public override NpcGuild NpcGuild{ get{ return NpcGuild.None; } }
		public override bool CanTeach{ get{ return false; } }

		private static bool m_Talked;

		string[] kfcsay = new string[]
		{
		"Beer, helping ugly people get laid since 1876!",
		"Please drink responsibly.",
		"P-A-R-T-Y!!!!",
		"Open the kegs!"
		};

		public override void VendorBuy( Mobile from )
		{
			from.SendGump( new Gump_AlcoholicVendor( from, this ) );
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public bool CanRessurect
		{
			get { return m_CanRes; }
			set { m_CanRes = value; }
		}

		[Constructable]
		public AlcoholicVendor() : base( "The Alcoholic Vendor" )
		{
			//CantWalk = true;
			Name = "The Alcoholic Vendor";
		}

		public override VendorShoeType ShoeType
		{
			get{ return VendorShoeType.Sandals; }
		}

		public override int GetShoeHue()
		{
			return 0;
		}

		public override  void InitBody() 
		{
			base.InitBody();
		}

		public override void InitOutfit()
		{
			AddItem( new Server.Items.Shirt( Utility.RandomRedHue() ) );
			AddItem( new Server.Items.SkullCap( Utility.RandomBlueHue() ) );
			AddItem( new Server.Items.ShortPants( Utility.RandomBlueHue() ) );
			int hairHue=0;
			switch ( Utility.Random( 9 ) )
			{
				case 0: AddItem( new Afro( hairHue ) ); break;
				case 1: AddItem( new KrisnaHair( hairHue ) ); break;
				case 2: AddItem( new PageboyHair( hairHue ) ); break;
				case 3: AddItem( new PonyTail( hairHue ) ); break;
				case 4: AddItem( new ReceedingHair( hairHue ) ); break;
				case 5: AddItem( new TwoPigTails( hairHue ) ); break;
				case 6: AddItem( new ShortHair( hairHue ) ); break;
				case 7: AddItem( new LongHair( hairHue ) ); break;
				case 8: AddItem( new BunsHair( hairHue ) ); break;
			}
		}

		private DateTime m_NextResurrect;
		private static TimeSpan ResurrectDelay = TimeSpan.FromSeconds( 2.0 );

		public override void OnMovement( Mobile m, Point3D oldLocation )
			{                                                    

			if ( m_CanRes )
			{
				if ( !m.Frozen && !m.Alive && DateTime.Now >= m_NextResurrect && InRange( m, 4 ) && !InRange( oldLocation, 4 ) && InLOS( m ) )
				{
					m_NextResurrect = DateTime.Now + ResurrectDelay;

					if ( m.Map == null || !m.Map.CanFit( m.Location, 16, false, false ) )
					{
						m.SendLocalizedMessage( 502391 ); // Thou can not be resurrected there!
					}
					else
					{
						Direction = GetDirectionTo( m );
						Say( 501224 ); // Thou hast strayed from the path of virtue, but thou still deservest a second chance.

						m.PlaySound( 0x214 );
						m.FixedEffect( 0x376A, 10, 16 );

						m.CloseGump( typeof( ResurrectGump ) );
						m.SendGump( new ResurrectGump( m, ResurrectMessage.Healer ) );
					}
				}
			}
			else                                                    
         			if( m_Talked == false ) 
        		 	{ 
          		 	if ( m.InRange( this, 4 ) ) 
          			{                
          			m_Talked = true; 
              		SayRandom( kfcsay, this ); 
					this.Move( GetDirectionTo( m.Location ) ); 
					SpamTimer t = new SpamTimer(); 
					t.Start(); 
            		} 
				} 
			}

		public override void InitSBInfo()
		{
		}

		public AlcoholicVendor( Serial serial ) : base( serial )
		{
		}

		private class SpamTimer : Timer 
		{ 
			public SpamTimer() : base( TimeSpan.FromSeconds( 8 ) ) 
			{ 
				Priority = TimerPriority.OneSecond; 
			} 

			protected override void OnTick() 
			{ 
				m_Talked = false; 
			} 
		} 

		private static void SayRandom( string[] say, Mobile m ) 
		{ 
			m.Say( say[Utility.Random( say.Length )] ); 
		} 

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}

//--Traveling Agent Gump Start----------------------------------------------------
	
	public class Gump_AlcoholicVendor : Gump
	{
		private Mobile m_From;
		private Mobile m_Vendor;

		public Gump_AlcoholicVendor( Mobile from, Mobile vendor ) : base( 50, 50 )
		{
			m_From = from;
			m_Vendor = vendor;

			int balance = Banker.GetBalance( from );

			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;
			AddPage(0);
			AddBackground(375, 77, 254, 379, 9200);
			AddLabel(405, 90, 139, @"Drinks on the house!!!");
			AddLabel(405, 140, 0, @"Champagne 20 gp");
			AddLabel(405, 170, 0, @"Tequila 20 gp");
			AddLabel(405, 200, 0, @"Jack Daniels 20 gp");
			AddLabel(405, 230, 0, @"Moonshine 20 gp");
			AddLabel(405, 260, 0, @"Vodka 20 gp");
			AddLabel(405, 290, 0, @"Rum 20 gp");
			AddLabel(405, 320, 0, @"Jimmy Bean 20 gp");
			AddLabel(405, 421, 52, @"Do not drink and drive!");
			AddImage(523, 385, 10430);
			AddButton(390, 143, 1210, 248, 1, GumpButtonType.Reply, 0);
			AddButton(390, 173, 1210, 248, 2, GumpButtonType.Reply, 0);
			AddButton(390, 203, 1210, 248, 3, GumpButtonType.Reply, 0);
			AddButton(390, 233, 1210, 248, 4, GumpButtonType.Reply, 0);
			AddButton(390, 393, 4012, 248, 5, GumpButtonType.Reply, 0);
			AddButton(390, 263, 1210, 248, 6, GumpButtonType.Reply, 0);
			AddButton(390, 293, 1210, 248, 7, GumpButtonType.Reply, 0);
			AddButton(390, 323, 1210, 248, 8, GumpButtonType.Reply, 0);
			AddImage(325, 40, 10400);
			AddImage(325, 221, 10401);
			AddImage(325, 399, 10402);
		}

		public override void OnResponse( NetState sender, RelayInfo info )
		{

			if ( info.ButtonID == 1) // Champagne
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new champagne());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of champagne is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			}

			if ( info.ButtonID == 2) // Tequila
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new tequila());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of Tequila is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			}

			if ( info.ButtonID == 3) // Jack Daniels
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new jackdaniels());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of Jack Daniels is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			}

			if ( info.ButtonID == 4) // Moonshine
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new moonshine());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of Moonshine is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			}

			if ( info.ButtonID == 5 ) // Cancel
			{	
				return;
			}
			if ( info.ButtonID == 6) // Vodka
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new Vodka());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of Vodka is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			}
			if ( info.ButtonID == 7) // Rum
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new rum());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of Rum is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			
			}
				if ( info.ButtonID == 8) // Jimmy Bean
			{
				if ( Banker.Withdraw( m_From, 20 ) )
				{
					m_From.AddToBackpack(new jimmybean());
					m_From.PrivateOverheadMessage( MessageType.Label, 090, true,"A bottle of Jimmy Bean is placed in your backpack.", m_From.NetState );
				}
				else
				m_Vendor.PrivateOverheadMessage( MessageType.Label, 090, true,"You don't have enough money in your bank.", m_From.NetState );
			}
		}
	}
}