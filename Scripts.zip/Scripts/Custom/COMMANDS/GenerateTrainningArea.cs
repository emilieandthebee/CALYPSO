using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class GenerateTrainningArea
	{

		public static void Initialize()
		{
			Server.Commands.Register( "GenerateTrainningArea", AccessLevel.GameMaster, new CommandEventHandler( GenerateTrainningArea_OnCommand ) );
		}

		[Usage( "GenerateTrainningArea" )]
		[Description( "Genere une aire de NPC et de livre pour le trainning pour toutes les skills." )]
		private static void GenerateTrainningArea_OnCommand( CommandEventArgs e )
		{
			int MaxSkill=0;
			if ( e.Length != 1 )
			{
				e.Mobile.SendMessage("GenerateTrainningArea <Maximum Skill Level Value>");
				return;
			}
			
			try
			{
				MaxSkill= (int)e.GetInt32( 0 );
			}
			catch
			{
				e.Mobile.SendMessage("GenerateTrainningArea <Maximum Skill Level Value>");
				return;
			}
			if ((e.Mobile.X<5380) || (e.Mobile.Y<970) || (e.Mobile.X>6130) || (e.Mobile.Y>1366))
			{
				e.Mobile.SendMessage("Seulement dans Green Acre, s'il te plait!");
				return;
			}
			for (int i=(int)SkillName.Alchemy;i<=(int)SkillName.Ninjitsu;i++)
			{
				Habitant m=new Habitant();
				m.MoveToWorld(new Point3D(e.Mobile.X+i%10,e.Mobile.Y+3*(i/10),e.Mobile.Z),e.Mobile.Map);
				m.Home=new Point3D(e.Mobile.X+i%10,e.Mobile.Y+3*(i/10),e.Mobile.Z);
				m.RangeHome=0;
				m.Direction=Direction.South;
				m.CanTeach=true;
				m.Title="(Maitre)";
				m.Blessed=true;
				m.SetSkill( (SkillName)i, 60.0+(double)MaxSkill, 65.0+(double)MaxSkill );
				TrainningBook book=new TrainningBook();
				book.SkillTarget=(SkillName)i;
				book.MaxSkill=MaxSkill;
				book.Movable=false;
				book.MoveToWorld(new Point3D(e.Mobile.X+i%10,e.Mobile.Y+3*(i/10)+1,e.Mobile.Z),e.Mobile.Map);
			}
		}
	}
}