using System;
using Server.Items;

namespace Server.Engines.Craft
{
	public class DefNec : CraftSystem
	{
		public override SkillName MainSkill
		{
			get	{ return SkillName.Necromancy;	}
		}

	//	public override int GumpTitleNumber
	//	{
	//		get { return 1044004; } // <CENTER>CARPENTRY MENU</CENTER>
	//	}

		private static CraftSystem m_CraftSystem;

		public static CraftSystem CraftSystem
		{
			get
			{
				if ( m_CraftSystem == null )
					m_CraftSystem = new DefNec();

				return m_CraftSystem;
			}
		}

		public override double GetChanceAtMin( CraftItem item )
		{
			return 0.3; // 30%
		}

		private DefNec() : base( 1, 1, 1.25 )// base( 1, 1, 3.0 )
		{
		}
		public override int CanCraft( Mobile from, BaseTool tool, Type itemType )
		{
			if ( tool.Deleted || tool.UsesRemaining < 0 )
				return 1044038; // You have worn out your tool!
			//else if ( !BaseTool.CheckAccessible( tool, from ) )
				//return 1044263; // The tool must be on your person to use.

			return 0;
		}

		public override void PlayCraftEffect( Mobile from )
		{
			from.PlaySound( 0x242 );
		}

		public override int PlayEndingEffect( Mobile from, bool failed, bool lostMaterial, bool toolBroken, int quality, bool makersMark, CraftItem item )
		{
			if ( toolBroken )
				from.SendLocalizedMessage( 1044038 ); // You have worn out your tool

			if ( failed )
			{
				from.AddToBackpack( new Bottle() );

				return 500287; // You fail to create a useful potion.
			}
			else
			{
				from.PlaySound( 0x240 ); // Sound of a filling bottle

				if ( quality == -1 )
					return 1048136; // You create the potion and pour it into a keg.
				else
					return 500279; // You pour the potion into a bottle...
			}
		}

		public override void InitCraftList()
		{
			int index = -1;

			index = AddCraft( typeof( ExtractTool ), "DNA Extractor", "Single Use Extractor", 100.0, 100.0, typeof( PigIron ), @"Pig Iron", 500, 0 );
			AddSkill( index, SkillName.SpiritSpeak, 100.0, 100.0 );
			AddRes( index, typeof( GoldenSkull ), @"Golden Skull", 1, 0 );
			
			index = AddCraft( typeof( DNAPoolMixer ), "DNA Pooling", "DNA Pooling Tool", 120.0, 120.0, typeof( LargeFlask ), @"LargeFlask", 5, 0 );
			AddSkill( index, SkillName.SpiritSpeak, 110.0, 110.0 );
			AddRes( index, typeof( DyeTub ), @"Dye Tub", 5, 0 );
		}
	}
}