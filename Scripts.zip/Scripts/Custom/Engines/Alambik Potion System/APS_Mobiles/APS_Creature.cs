using System;
using System.Collections;
using Server.Items;
using Server.Targeting;

namespace Server.Mobiles
{

	public class APS_Creature : BaseCreature
	{
//		private BaseAI forced;
		
		[Constructable]
		public APS_Creature() : base( AIType.AI_Foolish, FightMode.Closest, 30, 1, 0.1, 0.2 )
		{
			VirtualArmor = 8;
			Tamable = false;
			ControlSlots = 0;
		}
/*
		protected override BaseAI ForcedAI { get { 
			if ( forced == null )
				forced=new MeleeAI(this);
			return forced; }
		}
*/
		public override void GenerateLoot()
		{}

		public APS_Creature( Serial serial ) : base( serial )
		{}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
