using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;
using Server.Regions;

namespace Server.Scripts.Commands
{
	public class Sleep
	{
		public static void Initialize()
		{
			Server.Commands.Register( "Sleep", AccessLevel.Player, new CommandEventHandler( Sleep_OnCommand ) );
		}

		[Usage( "Sleep" )]
		[Description( "Fait dormir votre personnage." )]
		private static void Sleep_OnCommand( CommandEventArgs e )
		{
			if ( e.Mobile is PlayerMobile )
			{
				PlayerMobile pm=(PlayerMobile)e.Mobile;
				if (!pm.Deleted && pm.Alive)
				{
					if ( pm.Region is CustomRegion )
						if ( !(((CustomRegion)(pm.Region)).CanSleep()) )
						{
							pm.PlaySound(0x213);
							pm.SendMessage( "Impossible de dormir ici...");			
							return;
						}
					bool found = false;
					IPooledEnumerable eable = pm.Map.GetMobilesInRange( pm.Location, 50 );
					ArrayList list = new ArrayList();
					foreach( Mobile mob in eable )
					{
						if (mob.Combatant == pm)
							found = true;
					}
					eable.Free();
					if (found) {
							pm.SendMessage("Il y a un ennemi dans les parages...");
					} else {
						if (pm.Sleeping)
						{
							pm.SendMessage("Vous dormez d�j�.");
							return;
						}
						if (!pm.SecuredSleep)
						{
							pm.SendMessage("Vous dormez, mais sans avoir s�curiser de campement.");
							pm.SendMessage("Les autres joueurs pourront vous voler.");
							pm.SendMessage("Faites plutot un feu de camp, ou allez dormir sur le lit d'une auberge ou chez vous.");
						}
						pm.Sleep(pm.Map,pm.SecuredSleep);
					}
				}
			}
		}
	}
}