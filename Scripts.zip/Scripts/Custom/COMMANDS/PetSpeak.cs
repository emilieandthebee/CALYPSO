using System;
using Server;
using Server.Targeting;
using Server.Mobiles;


namespace Server.Scripts.Commands
{
	public class PetThisCmd
	{
		public static void Initialize()
		{
			Register( "PetSpeak", AccessLevel.Player, new CommandEventHandler( PetSpeak_OnCommand ) );
		}
		
		public static void Register( string command, AccessLevel access, CommandEventHandler handler )
		{
			Server.Commands.Register( command, access, handler );
		}
		
		[Usage( "PetSpeak <text>" )]
		[Description( "Allows owner of his/her pet to speak." )]
		public static void PetSpeak_OnCommand( CommandEventArgs e )
		{
			string toSay = e.ArgString.Trim();
			
			if( toSay.Length > 0 )
				e.Mobile.Target = new SayThisTarget( toSay );
			else
				e.Mobile.SendMessage( "Format: PetSpeak \"<text>\"" );
		}
		
		private class SayThisTarget : Target
		{
			private string m_toSay;
			
			public SayThisTarget( string s ) : base( -1, false, TargetFlags.None )
			{
				m_toSay = s;
			}
			
			protected override void OnTarget( Mobile from, object targeted )
			{
				if( targeted is BaseCreature )
				{
					BaseCreature targ = (BaseCreature)targeted;
					
					if( targ.ControlMaster == from )
					{
						CommandLogging.WriteLine( from, "{0} {1} forcing speech on {2}", from.AccessLevel, CommandLogging.Format( from ), CommandLogging.Format( targ ) );
						targ.Say( m_toSay );
					}
					else
					{
						from.SendMessage( "You do not own this pet." );
					}
				}
			}
		}
	}
}
			