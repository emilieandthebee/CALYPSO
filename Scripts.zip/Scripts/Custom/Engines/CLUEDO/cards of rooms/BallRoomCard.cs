using System; 
using Server; 

namespace Server.Items 
{ 
	public class BallRoomCard : Item
	{ 
		[Constructable]
		public BallRoomCard() : base( 0x12AB ) 
		{
			Hue = 1167;
			Weight = 1.0;
			Name = "Une carte nommee Salle machines";
		} 

		public BallRoomCard( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 0 ); 
		} 
       
		public override void Deserialize(GenericReader reader) 
		{ 
			base.Deserialize( reader ); 
			int version = reader.ReadInt(); 
		}
	} 
}