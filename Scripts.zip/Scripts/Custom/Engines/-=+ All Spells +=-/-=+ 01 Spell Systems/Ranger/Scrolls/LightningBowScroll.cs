using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class LightningBowScroll : SpellScroll
	{
		[Constructable]
		public LightningBowScroll() : this( 1 )
		{
		}

		[Constructable]
		public LightningBowScroll( int amount ) : base( 905, 3828, amount )
		{
			Name = "Lightning Bow";
			Hue = 2001;
		}

		public LightningBowScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new LightningBowScroll( amount ), amount );
		}
	}
}
