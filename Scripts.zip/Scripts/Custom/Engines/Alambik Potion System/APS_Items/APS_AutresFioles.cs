/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;

namespace Server.Items
{

	public class APS_Fiole3835 : APS_Potion {
		[Constructable]
		public APS_Fiole3835() : base() {ItemID=3835;}		
		[Constructable]
		public APS_Fiole3835( int amount ) : this() { Amount = amount; }
		public APS_Fiole3835( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3836 : APS_Potion {
		[Constructable]
		public APS_Fiole3836() : base() {ItemID=3836;}		
		[Constructable]
		public APS_Fiole3836( int amount ) : this() { Amount = amount; }
		public APS_Fiole3836( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3837 : APS_Potion {
		[Constructable]
		public APS_Fiole3837() : base() {ItemID=3837;}		
		[Constructable]
		public APS_Fiole3837( int amount ) : this() { Amount = amount; }
		public APS_Fiole3837( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3838 : APS_Potion {
		[Constructable]
		public APS_Fiole3838() : base() {ItemID=3838;}		
		[Constructable]
		public APS_Fiole3838( int amount ) : this() { Amount = amount; }
		public APS_Fiole3838( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3839 : APS_Potion {
		[Constructable]
		public APS_Fiole3839() : base() {ItemID=3839;}		
		[Constructable]
		public APS_Fiole3839( int amount ) : this() { Amount = amount; }
		public APS_Fiole3839( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3840 : APS_Potion {
		[Constructable]
		public APS_Fiole3840() : base() {ItemID=3840;}		
		[Constructable]
		public APS_Fiole3840( int amount ) : this() { Amount = amount; }
		public APS_Fiole3840( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3841 : APS_Potion {
		[Constructable]
		public APS_Fiole3841() : base() {ItemID=3841;}		
		[Constructable]
		public APS_Fiole3841( int amount ) : this() { Amount = amount; }
		public APS_Fiole3841( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3842 : APS_Potion {
		[Constructable]
		public APS_Fiole3842() : base() {ItemID=3842;}		
		[Constructable]
		public APS_Fiole3842( int amount ) : this() { Amount = amount; }
		public APS_Fiole3842( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3843 : APS_Potion {
		[Constructable]
		public APS_Fiole3843() : base() {ItemID=3843;}		
		[Constructable]
		public APS_Fiole3843( int amount ) : this() { Amount = amount; }
		public APS_Fiole3843( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

	public class APS_Fiole3844 : APS_Potion {
		[Constructable]
		public APS_Fiole3844() : base() {ItemID=3844;}		
		[Constructable]
		public APS_Fiole3844( int amount ) : this() { Amount = amount; }
		public APS_Fiole3844( Serial serial ) : base(serial) {}
		public override void Serialize( GenericWriter writer )
		{ base.Serialize( writer );
		  writer.Write( (int) 0 );  }
		public override void Deserialize( GenericReader reader )
		{ base.Deserialize( reader );
		  int version = reader.ReadInt(); } }

}