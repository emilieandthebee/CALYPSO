using System;
using Server;
using System.Collections;
using Server.Mobiles;
using Server.Items;
using Server.Scripts.Commands;

namespace Server.Gumps
{
	public class MegaSpawnerEditGump : Gump
	{
		public MegaSpawner megaSpawner;
		public bool fromSpawnerList = false;

		public MegaSpawnerEditGump( Mobile mobile, MegaSpawner megaspawner, bool fromspawnerlist ) : base( 0,0 )
		{
			megaSpawner = megaspawner;
			fromSpawnerList = fromspawnerlist;

			AddPage(0); // Page 0

			AddBackground( 80, 80, 600, 450, 0 );
			AddImageTiled( 80, 80, 600, 450, 2624 );
			AddAlphaRegion( 100, 100, 560, 330 );
			AddAlphaRegion( 100, 450, 560, 60 );
			AddImage( 30, 50, 10440);
			AddImage( 648, 50, 10441);
			AddLabel( 140, 80, 60, "Mega Spawner At Location: " + megaSpawner.Location.ToString() );
			AddButton( 630, 490, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddPage(1); // Page 1

			AddLabel( 540, 80, 60, "Page: 1" );

			AddLabel( 140, 450, 10, "Respawn" );
			AddButton( 100, 450, 9904, 9905, 1, GumpButtonType.Reply, 0 );

			AddLabel( 140, 470, 10, "Wipe Entire Spawner" );
			AddButton( 100, 470, 9904, 9905, 2, GumpButtonType.Reply, 0 );

			AddLabel( 140, 490, 10, "Add Creature" );
			AddButton( 100, 490, 9904, 9905, 3, GumpButtonType.Reply, 0 );

			AddLabel( 340, 450, 10, "Bring To Home" );
			AddButton( 300, 450, 9904, 9905, 4, GumpButtonType.Reply, 0 );

			if ( megaSpawner.Active )
			{
				AddLabel( 340, 470, 10, "Turn Off Spawner" );
				AddButton( 300, 470, 9904, 9905, 5, GumpButtonType.Reply, 0 );
			}
			else
			{
				AddLabel( 340, 470, 10, "Turn On Spawner" );
				AddButton( 300, 470, 9904, 9905, 5, GumpButtonType.Reply, 0 );
			}

			AddLabel( 340, 490, 10, "Go To Location" );
			AddButton( 300, 490, 9904, 9905, 6, GumpButtonType.Reply, 0 );

			AddLabel( 540, 450, 10, "Delete Spawner" );
			AddButton( 500, 450, 9904, 9905, 7, GumpButtonType.Reply, 0 );

			int listX = 140;
			int listY = 100;
			int page = 1;
			int newColumn = 16;
			int newPage = 32;

			if ( megaSpawner.CreatureList.Count == 0 )
			{
				AddLabel( 140, 100, 10, "There are no entries." );
			}
			else
			{
				for ( int i = 0; i < megaSpawner.CreatureList.Count; i++ )
				{
					if ( i == newPage )
					{
						listX = -130;
						listY = 100;
						newPage += 32;
						page += 1;

						AddLabel( 430, 450, 10, "Page " + page.ToString() );
						AddButton( 380, 450, 4005, 4007, 0, GumpButtonType.Page, page );

						AddPage(page); // New Page

						AddLabel( 540, 80, 60, "Page: " + page.ToString() );

						AddLabel( 280, 450, 10, "Page " + ( page - 1 ).ToString() );
						AddButton( 340, 450, 4014, 4016, 0, GumpButtonType.Page, page - 1 );

						AddLabel( 140, 450, 10, "Respawn" );
						AddButton( 100, 450, 9904, 9905, 1, GumpButtonType.Reply, 0 );

						AddLabel( 140, 470, 10, "Wipe Entire Spawner" );
						AddButton( 100, 470, 9904, 9905, 2, GumpButtonType.Reply, 0 );

						AddLabel( 140, 490, 10, "Add Creature" );
						AddButton( 100, 490, 9904, 9905, 3, GumpButtonType.Reply, 0 );

						AddLabel( 340, 450, 10, "Bring To Home" );
						AddButton( 300, 450, 9904, 9905, 4, GumpButtonType.Reply, 0 );

						if ( megaSpawner.Active )
						{
							AddLabel( 340, 470, 10, "Turn Off Spawner" );
							AddButton( 300, 470, 9904, 9905, 5, GumpButtonType.Reply, 0 );
						}
						else
						{
							AddLabel( 340, 470, 10, "Turn On Spawner" );
							AddButton( 300, 470, 9904, 9905, 5, GumpButtonType.Reply, 0 );
						}

						AddLabel( 340, 490, 10, "Go To Location" );
						AddButton( 300, 490, 9904, 9905, 6, GumpButtonType.Reply, 0 );

						AddLabel( 540, 450, 10, "Delete Spawner" );
						AddButton( 500, 450, 9904, 9905, 7, GumpButtonType.Reply, 0 );
					}

					if ( i == newColumn )
					{
						listX += 270;
						listY = 100;
						newColumn += 16;
					}

					AddButton( listX - 40, listY, 9904, 9905, i + 8, GumpButtonType.Reply, 0 );
					AddLabel( listX, listY, 10, megaSpawner.CreatureList[i].ToString() );

					listY += 20;
				}
			}
		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;
			int index = (int) info.ButtonID - 8;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					if ( fromSpawnerList )
					{
						mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
						mobile.SendGump( new MegaSpawnerGump( mobile ) );
					}
					else
						mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );

					break;
				}
				case 1: // Respawn
				{
					if ( megaSpawner.Active )
					{
						megaSpawner.Respawn();

						mobile.SendMessage( "Spawner has now been respawned." );
					}
					else
						mobile.SendMessage( "Spawner is not currently active and cannot be respawned." );

					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 2: // Wipe Entire Spawner
				{
					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new ConfirmSpawnerWipeGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 3: // Add Creature
				{
					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new EditSpawnGump( mobile, fromSpawnerList, true, 0, megaSpawner, "", 10, 10, 1, 30, 60 ) );

					break;
				}
				case 4: // Bring To Home
				{
					megaSpawner.BringToHome();

					mobile.SendMessage( "All creatures are now at spawner's location." );

					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 5: // Toggle Spawner On/Off
				{
					if ( megaSpawner.Active )
					{
						megaSpawner.Active = false;

						mobile.SendMessage( "Spawner has now been turned off." );
					}
					else
					{
						megaSpawner.Active = true;

						mobile.SendMessage( "Spawner has now been turned on." );
					}
					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 6: // Go To Location
				{
					mobile.Location = megaSpawner.Location;
					mobile.SendMessage( "You have been moved to the spawner's location " + megaSpawner.Location.ToString() + "." );

					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 7: // Delete Spawner
				{
					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new ConfirmDeleteSpawnerGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				default:
				{
					mobile.CloseGump( typeof ( MegaSpawnerEditGump ) );
					mobile.SendGump( new EditSpawnGump( mobile, fromSpawnerList, false, index, megaSpawner, (string) megaSpawner.CreatureList[index], (int) megaSpawner.SpawnRangeList[index], (int) megaSpawner.WalkRangeList[index], (int) megaSpawner.AmountList[index], (int) megaSpawner.MinDelayList[index], (int) megaSpawner.MaxDelayList[index] ) );

					break;
				}
			}
		}
	}

	public class ConfirmSpawnerWipeGump : Gump
	{
		public MegaSpawner megaSpawner;
		public bool fromSpawnerList = false;

		public ConfirmSpawnerWipeGump( Mobile mobile, MegaSpawner megaspawner, bool fromspawnerlist ) : base( 0,0 )
		{
			megaSpawner = megaspawner;
			fromSpawnerList = fromspawnerlist;

			AddPage(0); // Page 0

			AddBackground( 180, 180, 320, 90, 0 );
			AddImageTiled( 180, 180, 320, 90, 2624 );
			AddAlphaRegion( 200, 200, 280, 20 );
			AddAlphaRegion( 200, 230, 280, 20 );
			AddLabel( 240, 180, 60, "Confirmation Of Spawner Wipe" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Are you sure you want to wipe the spawner?" );

			AddLabel( 440, 230, 10, "Cancel" );
			AddButton( 400, 230, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 230, 10, "Ok" );
			AddButton( 200, 230, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ConfirmSpawnerWipeGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					mobile.SendMessage( "You have cancelled the spawner wipe." );

					break;
				}
				case 1: // Wipe Entire Spawner
				{
					megaSpawner.ClearSpawner();

					mobile.CloseGump( typeof ( ConfirmSpawnerWipeGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					mobile.SendMessage( "The spawner has now been cleared." );

					break;
				}
			}
		}
	}

	public class ConfirmDeleteSpawnerGump : Gump
	{
		public MegaSpawner megaSpawner;
		public bool fromSpawnerList = false;

		public ConfirmDeleteSpawnerGump( Mobile mobile, MegaSpawner megaspawner, bool fromspawnerlist ) : base( 0,0 )
		{
			megaSpawner = megaspawner;
			fromSpawnerList = fromspawnerlist;

			AddPage(0); // Page 0

			AddBackground( 180, 180, 330, 90, 0 );
			AddImageTiled( 180, 180, 330, 90, 2624 );
			AddAlphaRegion( 200, 200, 290, 20 );
			AddAlphaRegion( 200, 230, 290, 20 );
			AddLabel( 240, 180, 60, "Confirmation Of Deleting Spawner" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Are you sure you want to delete the spawner?" );

			AddLabel( 440, 230, 10, "Cancel" );
			AddButton( 400, 230, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 230, 10, "Ok" );
			AddButton( 200, 230, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ConfirmDeleteSpawnerGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					mobile.SendMessage( "You have chosen not to delete the spawner." );

					break;
				}
				case 1: // Delete Spawner
				{
					megaSpawner.Delete();

					mobile.SendMessage( "The spawner has now been deleted." );

					mobile.CloseGump( typeof ( ConfirmDeleteSpawnerGump ) );

					if ( fromSpawnerList )
						mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
			}
		}
	}
}