using System; 
using Server; 
using Server.Gumps; 
using Server.Network;
using Server.Items;
using Server.Mobiles;

namespace Server.Gumps
{ 
   public class EggLootGump : Gump 
   { 
   		private const int LabelColor = 0x7FFF;
		private const int SelectedColor = 0x421F;
		private const int DisabledColor = 0x4210;

		private const int LabelColor32 = 0xFFFFFF;
		private const int SelectedColor32 = 0x8080FF;
		private const int DisabledColor32 = 0x808080;

		private const int LabelHue = 0x480;
		private const int YellowHue = 1161;
		private const int RedHue = 0x20;
public EggLootGump( Mobile owner ) : base( 300,100 )
{
this.Closable=false;
this.Disposable=false;
this.Dragable=true;
this.Resizable=false;
this.AddPage(0);
this.AddBackground(15, 40, 190, 150, 3000);///Middle lable background
this.AddBackground(15, 200, 190, 80, 3000);///bottom lable background
this.AddBackground(15, 15, 190, 20, 3000);///Top Lable BackGround
this.AddLabel(30, 15, 32, @"Evolution DNA Dragon Eggs");
this.AddButton(25, 50, 1209, 1210, 0, GumpButtonType.Reply, 0);
this.AddButton(25, 70, 1209, 1210, 2, GumpButtonType.Reply, 0);
this.AddButton(25, 90, 1209, 1210, 3, GumpButtonType.Reply, 0);
this.AddButton(25, 110, 1209, 1210, 4, GumpButtonType.Reply, 0);
this.AddButton(25, 130, 1209, 1210, 1, GumpButtonType.Reply, 0);
this.AddButton(25, 150, 1209, 1210, 5, GumpButtonType.Reply, 0);
this.AddLabel(50, 50, 115, @"Black");
this.AddLabel(50, 70, 115, @"Blaze");
this.AddLabel(50, 90, 115, @"Snow");
this.AddLabel(50, 110, 115, @"Lightning");
this.AddLabel(50, 130, 115, @"Gold");
this.AddLabel(50, 150, 115, @"Poison");
this.AddLabel(60, 210, 32, @"DNA System By");
this.AddLabel(30, 230, 32, @"Created By Paige & Viago");
this.AddLabel(35, 250, 32, @"Http://www.fallensouls.org");


}

public override void OnResponse( NetState state, RelayInfo info )  
      { 
         Mobile from = state.Mobile; 

         switch ( info.ButtonID ) 
         { 
            case 0: 
            { 
		   from.AddToBackpack(new BlackDNADragonEgg());
               from.SendMessage( "A Black Evolution DNA Dragon Egg has been placed into your backpack." );
			   from.PlaySound( 521 ); 
               break; 
            } 

            case 1:  
            { 
		   from.AddToBackpack(new GoldenDNADragonEgg());
               from.SendMessage( "A Golden Evolution DNA Dragon Egg has been placed into your backpack." );
			   from.PlaySound( 521 ); 
		   break;
            } 
            case 2:
            { 
		   from.AddToBackpack(new BlazeDNADragonEgg());
               from.SendMessage( "A Blaze Evolution DNA Dragon Egg has been placed into your backpack." );
			   from.PlaySound( 521 ); 
		   break;
            } 

            case 3:
            { 
		   from.AddToBackpack(new SnowDNADragonEgg());
               from.SendMessage( "A Snow Evolution DNA Dragon Egg has been placed into your backpack." );
			   from.PlaySound( 521 ); 
		   break;
            } 
            case 4:
            { 
		   from.AddToBackpack(new LightningDNADragonEgg());
               from.SendMessage( "A Lightning Evolution DNA Dragon Egg has been placed into your backpack." );
			   from.PlaySound( 521 ); 
		   break;
            }
            case 5:
            { 
		   from.AddToBackpack(new PoisonDNADragonEgg());
               from.SendMessage( "A Poison Evolution DNA Dragon Egg has been placed into your backpack." );
			   from.PlaySound( 521 ); 
		   break;
            } 
         }
      }
   }
}
