using System;
using System.Collections;
using Server.Network;
using Server.Items;
using Server.Targeting;
using Server.Mobiles;
using Server.Spells.Necromancy;

namespace Server.Spells.Sixth
{
	public class CauseFearSpell : Spell
	{
		private static SpellInfo m_Info = new SpellInfo(
				"Cause Fear", "Quas Wis",
				SpellCircle.Sixth,
				230,
				9022,
				Reagent.Garlic,
				Reagent.Nightshade,
				Reagent.MandrakeRoot
			);

		public CauseFearSpell( Mobile caster, Item scroll ) : base( caster, scroll, m_Info )
		{
		}

		public override void OnCast()
		{
			if ( CheckSequence() )
			{
				ArrayList targets = new ArrayList();

				foreach ( Mobile m in Caster.GetMobilesInRange( 8 ) )
				{
					if ( Caster != m && SpellHelper.ValidIndirectTarget( Caster, m ) && Caster.CanBeHarmful( m, false ) )
						targets.Add( m );
				}

				Caster.PlaySound( 0x245);
				Caster.PlaySound( 0x3EA);
				Caster.FixedParticles( 0x2109, 1, 25, 9922, 14, 3, EffectLayer.Head );
					IEntity from = new Entity( Serial.Zero, new Point3D( Caster.X, Caster.Y, Caster.Z ), Caster.Map );
				IEntity to = new Entity( Serial.Zero, new Point3D( Caster.X, Caster.Y, Caster.Z + 32 ), Caster.Map );
				Effects.SendMovingParticles( from, to, 0x3192, 1, 0, false, false, 33, 3, 9501, 1, 0, EffectLayer.Head, 0x100 );
			

				int dispelSkill = Caster.Int;

				double mag = Caster.Skills.Magery.Value;

				for ( int i = 0; i < targets.Count; ++i )
				{
					Mobile m = (Mobile)targets[i];
					BaseCreature bc = m as BaseCreature;

					if ( bc != null )
					{
						bool dispellable = bc.Summoned && !bc.IsAnimatedDead;

						if ( dispellable )
						{
							double dispelChance = (50.0 + ((100 * (mag - bc.DispelDifficulty)) / (bc.DispelFocus*2))) / 100;
							dispelChance *= dispelSkill / 100.0;

							if ( dispelChance > Utility.RandomDouble() )
							{
								Effects.SendLocationParticles( EffectItem.Create( m.Location, m.Map, EffectItem.DefaultDuration ), 0x3728, 8, 20, 5042 );
								Effects.PlaySound( m, m.Map, 0x201 );

								m.Delete();
								continue;
							}
						}

						bool evil = !bc.Controled && !bc.Blessed;

						if ( evil )
						{
							
							double fleeChance = (100 - Math.Sqrt( m.Fame / 2 )) * mag * dispelSkill;
							fleeChance /= 1000000;

							if ( fleeChance > Utility.RandomDouble() )
							{
								bc.PlaySound(bc.Female ?  814:1088 );
								bc.BeginFlee( TimeSpan.FromSeconds( 15.0 ) );
							}
						}
					}

				
				}
			}

			FinishSequence();
		}

	}
}
