using System;
using Server.Mobiles;

namespace Server.ContextMenus
{
	public class PriceEntry : ContextMenuEntry
	{
		private Mobile m_From;
		private Mobile m_Hired;

		public PriceEntry( Mobile hired, Mobile from ) : base( 377, 1 )
		{
			m_From = from;
			m_Hired = hired;
		}

		public override void OnClick()
		{
			if ( m_From.Deleted || !m_From.Alive || m_Hired.Deleted || !m_Hired.Alive )
				return;

			if ( (m_From is PlayerMobile) && (m_Hired is BaseCreature) )
			{
				switch (Utility.Random(5))
				{
				case 0:
					((BaseCreature)m_Hired).Say("Je peux travailler pour vous pour, disons, {0} caps par jours, payable d'avance.",
						((BaseCreature)m_Hired).HiringCost);
					break;
				case 1:
					((BaseCreature)m_Hired).Say("{0} caps par jours, payable d'avance. C'est mon prix",
						((BaseCreature)m_Hired).HiringCost);
					break;
				case 2:
					((BaseCreature)m_Hired).Say("Mes services? {0} caps chaque jour, et en avance de paie, bien evidemment.",
						((BaseCreature)m_Hired).HiringCost);
					break;
				case 3:
					((BaseCreature)m_Hired).Say("Si vous me payez par avance {0} caps par jours, je suis avec vous.",
						((BaseCreature)m_Hired).HiringCost);
					break;
				default:
					((BaseCreature)m_Hired).Say("{0} caps la journee. Payable a l'avance. C'est mon prix.",
						((BaseCreature)m_Hired).HiringCost);
					break;
				}
			}
		}
	}
}