////////////////////////////////////////////
//This instance was made by Kwwres10.     //
// Feel free to use it but, DONT CLAIM IT!//
//Contact me at Kwwres10@hotmail.com      //
//If you spam me you will be blocked.     //
//Ideas are welcome and help is free!     //
////////////////////////////////////////////

using System;
using Server;

namespace Server.Factions
{
	public class AngryFarmers : Faction
	{
		private static Faction m_Instance;

		public static Faction Instance{ get{ return m_Instance; } }

		public AngryFarmers()
		{
			m_Instance = this;

			Definition =
				new FactionDefinition(
					4,
					1180, // red and black
					1157, // Blood Red
					0, // join stone : Red and Black
					38, // broadcast :  Red
					1180, 1157, // war horse
					"TechnoGlaive", "farmers",
					new TextDefinition( "TechnoGlaive" ),
					new TextDefinition( "Guilde du TechnoGlaive" ),
					new TextDefinition( "<center>L'Ordre De La Technologie</center>" ),
					new TextDefinition(
						"La guilde du TechnoGlaive prone la suprematie de la technoplogie. " +
						"L'ordre et les armes, voila ce qui apportera enfin la paix au monde. " +
						"Chaque membre y possede un grade, et une fonction. Toute la guilde" +
						"est supervisee par l'etre supreme, le Tetramgnus. " +
						"Un ordre est un ordre. Voila pourquoi la guilde est puissante." ),
					new TextDefinition( "La cille est controllee par le TechnoGlaive." ),
					new TextDefinition( "Le maire a ete corrompu par le TechnoGlaive" ),
					new TextDefinition( "Le registre de la guilde du TechnoGlaive" ),
					new TextDefinition( "La console generale de la guilde du TechnoGlaive" ),
					new TextDefinition( ": TechnoGlaive" ),
					new TextDefinition( "Les membres du TechnoGlaive sont maintenant ignores." ),
					new TextDefinition( "Les membres du TechnoGlaives sont etre averti de quitter les lieux." ),
					new TextDefinition( "Les memnbres du TechnoGlaive seront attaques a vu." ),
					new StrongholdDefintion(
						new Rectangle2D[]
						{
							new Rectangle2D( 960, 688, 8, 9 ),
							new Rectangle2D( 944, 697, 24, 23 )
						},
						new Point3D( 1521, 1507, 0 ),
						new Point3D( 1525, 1425, 55 ),
						new Point3D[]
						{
							new Point3D( 1525, 1429, 55 ),
							new Point3D( 1525, 1431, 55 ),
							new Point3D( 1525, 1433, 55 ),
							new Point3D( 1525, 1435, 55 ),
							new Point3D( 1529, 1429, 55 ),
							new Point3D( 1529, 1431, 55 ),
							new Point3D( 1529, 1433, 55 ),
							new Point3D( 1529, 1435, 55  )
						} ),
					new RankDefinition[]
					{
						new RankDefinition( 10, 991, 8, new TextDefinition( "Tetramagnus" ) ),
						new RankDefinition(  9, 950, 7, new TextDefinition( "General" ) ),
						new RankDefinition(  8, 900, 6, new TextDefinition( "Lieutenant" ) ),
						new RankDefinition(  7, 800, 6, new TextDefinition( "Lieutenant" ) ),
						new RankDefinition(  6, 700, 5, new TextDefinition( "Capitaine" ) ),
						new RankDefinition(  5, 600, 5, new TextDefinition( "Capitaine" ) ),
						new RankDefinition(  4, 500, 5, new TextDefinition( "Capitaine" ) ),
						new RankDefinition(  3, 400, 4, new TextDefinition( "Soldat" ) ),
						new RankDefinition(  2, 200, 4, new TextDefinition( "Soldat" ) ),
						new RankDefinition(  1,   0, 4, new TextDefinition( "Soldat" ) )
					},
					new GuardDefinition[]
					{
						new GuardDefinition( typeof( FactionHenchman ),		0x1403, 5000, 1000, 10,		new TextDefinition( 1011526, "HOMME DE MAIN" ),		new TextDefinition( 1011510, "Enroler Homme de main" ) ),
						new GuardDefinition( typeof( FactionMercenary ),	0x0F62, 6000, 2000, 10,		new TextDefinition( 1011527, "MERCENAIRE" ),		new TextDefinition( 1011511, "Payer Mercenaire" ) ),
					}
				);
		}
	}
}