using System;
using Server.Network;
using Server.Gumps;
using Server.Spells;

namespace Server.Items
{
	public class AncientSpellbook : Spellbook
	{
		public override SpellbookType SpellbookType{ get{ return SpellbookType.Ancient; } }
		public override int BookOffset{ get{ return 340; } }
		public override int BookCount{ get{ return 35; } }

		public override Item Dupe( int amount )
		{
			Spellbook book = new AncientSpellbook();

			book.Content = this.Content;

			return base.Dupe( book, amount );
		}

		[Constructable]
		public AncientSpellbook() : this( (ulong)0 )
		{
		}

		[Constructable]
		public AncientSpellbook( ulong content ) : base( content, 0xEFA )
		{
			Hue = 1355;
			Name = "Ancient Spellbook";
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel <= AccessLevel.Counselor )
			{
				//--<Optional Restrictions>----------<Start>
				from.SendMessage( "Low level staff and players are not allowed to have this book." );
				Delete();
				return;
			}

			from.CloseGump( typeof( AncientSpellbookGump ) );
			from.SendGump( new AncientSpellbookGump( from, this ) );
		}

		public AncientSpellbook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
