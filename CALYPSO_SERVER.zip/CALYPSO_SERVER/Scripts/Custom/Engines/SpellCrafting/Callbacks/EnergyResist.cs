using System;
using Server;
using Server.Items;
using Server.SpellCrafting;

namespace Server.SpellCrafting.Crafts
{
	public class EnergyResist
	{
		private static readonly int Minimum = 1;
		private static readonly int Maximum = 15;

		public static void Callback( Mobile from, object target )
		{
			if ( !(target is BaseWeapon || target is BaseJewel || (target is BaseArmor && !(target is BaseShield)) ) )
			{
				from.SendMessage( "This craft cannot be placed on that item" );
			}
			else if ( !SpellCraft.CheckSpellCrafted( from, target ) )
			{
				return;
			}
			else
			{
				int scalar = (int)( (from.Skills[SkillName.Inscribe].Value + from.Skills[SkillName.Alchemy].Value) / 200.0 );

				if ( target is BaseArmor )
					AddResist( (BaseArmor)target, scalar );

				else if ( target is BaseJewel )
					AddResist( (BaseJewel)target, scalar );

				else if ( target is BaseWeapon )
					AddResist( (BaseWeapon)target, scalar );
			}
		}

		private static void AddResist( BaseArmor armor, int scalar )
		{
			SpellCraft.ApplyResistance( armor, 20 * scalar, 100 * scalar, ResistanceType.Energy, Minimum, Maximum );
		}

		private static void AddResist( BaseJewel jewel, int scalar )
		{
			SpellCraft.ApplyAttribute( jewel.Resistances, 20 * scalar, 100 * scalar, AosElementAttribute.Energy, Minimum, Maximum );
		}

		private static void AddResist( BaseWeapon weapon, int scalar )
		{
			SpellCraft.ApplyAttribute( weapon.WeaponAttributes, 20 * scalar, 100 * scalar, AosWeaponAttribute.ResistEnergyBonus, Minimum, Maximum );
		}
	}
}