using System;
using System.Collections;
using Server.Items;
using Server.Targeting;
using Server.Spells;
using Server.Network;
/*2.0*
using System.Collections.Generic;
******/

namespace Server.Mobiles
{
/*** CHANGED FOR UO TEMRAEL ***
	[CorpseName( "un corps de gaz etrange" )]
******************************/
	[CorpseName( "un corps de un gaz etrange" )]
/*****************************/
	public class APS_StrangeEffusion : APS_Creature
	{
		[Constructable]
		public APS_StrangeEffusion() : base()
		{
/*** CHANGED FOR UO TEMRAEL ***
			Name = "un gaz etrange";
			Body = 298;
******************************/
			Name = "un gaz etrange";
			Body = 261;
			Hue = 120;
/*****************************/
			SetStr( 22, 34 );
			SetDex( 5, 21 );
			SetInt( 8, 20 );
			SetHits( 17, 19 );
			SetDamage( 3, 8 );
			SetDamageType( ResistanceType.Physical, 100 );
			SetResistance( ResistanceType.Physical, 5, 10 );
			SetResistance( ResistanceType.Poison, 10, 20 );
			SetSkill( SkillName.Poisoning, 20.1, 60.0 );
			SetSkill( SkillName.MagicResist, 5.1, 10.0 );
			SetSkill( SkillName.Tactics, 12.3, 20.0 );
			SetSkill( SkillName.Wrestling, 30.3, 40.0 );
			VirtualArmor = 2;
		}

		public override Poison PoisonImmune{ get{ return Poison.Lethal; } }

		public override void OnDamage( int oldValue, Mobile from, bool willKill )
		{
			base.OnDamage(oldValue, from, willKill);
/*2.0*
			List<Mobile> toDamage = new List<Mobile>();
*1.0*/
			ArrayList toDamage = new ArrayList();
/****/
			foreach ( Mobile m in GetMobilesInRange( 0 ) )
			{
				if ( m.Alive && !m.IsDeadBondedPet && m.CanBeDamaged() )
					toDamage.Add( m );
			}
			for ( int j = 0; j < toDamage.Count; ++j )
			{
/*2.0*
				List<Item> items = ( toDamage[j] ).Items;
*1.0*/
				ArrayList items = ( (Mobile)(toDamage[j]) ).Items;
/****/
				bool damaged = false;
				for ( int i = 0; i < items.Count; ++i )
				{
					if (items[i] is BaseArmor)
					{
						BaseArmor wearable=((BaseArmor)items[i]);
						if ( wearable.HitPoints >= 10 && Utility.RandomDouble() < 0.25 )
						{
							wearable.HitPoints -= Utility.Random( 1, 5 );
							damaged = true;
						}
					} else if (items[i] is BaseWeapon) {
						BaseWeapon wearable=((BaseWeapon)items[i]);
						if ( wearable.Hits >= 10 && Utility.RandomDouble() < 0.25 )
						{
							wearable.Hits -= Utility.Random( 1, 5 );
							damaged = true;
						}
					}						
				}
				if ( damaged )
				{
					if ( Core.AOS )
						( (Mobile)(toDamage[j]) ).FixedParticles( 0x3735, 1, 30, 9503, EffectLayer.Waist );
					else
						( (Mobile)(toDamage[j]) ).FixedEffect( 0x3735, 6, 30 );
					( (Mobile)(toDamage[j]) ).SendMessage("Le gaz acide qui se degage de cette gelatine attaque ce que vous portez.");
				}
			}
		}
		
		public override int GetAngerSound()
		{
			return 0x56d;
		}

		public override int GetIdleSound()
		{
			return 0x56b;
		}

		public override int GetAttackSound()
		{
			return 0x56c;
		}

		public override int GetHurtSound()
		{
			return 0x56c;
		}

		public override int GetDeathSound()
		{
			return 0x56e;
		}

		public APS_StrangeEffusion( Serial serial ) : base( serial )
		{}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
