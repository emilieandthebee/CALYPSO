/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items
{
	[Flipable( 2420 , 2421, 2541 )]
	public class APS_Chaudron : APS_Tonnelet
	{		
		[Constructable]
		public APS_Chaudron() : base()
		{
			Name = "Un chaudron";
			Stackable = false;
			if (Utility.Random(0,1) == 0)
				ItemID = 2420 + Utility.Random(0,1);
			else
				ItemID = 2541;
			Weight = 50.0;
		}
		
		public APS_Chaudron( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}