using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class CurePoisonScroll : SpellScroll
	{
		[Constructable]
		public CurePoisonScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public CurePoisonScroll( int amount ) : base( 118, 0x226F, amount )
		{
			Name = "Cure Poison Scroll";
			Hue = 0x44;
		}
		
		public CurePoisonScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new CurePoisonScroll( amount ), amount );
		}
	}
}
