using System;
using Server;
using Server.Gumps;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Targeting;
using System.Collections;
using Server.Scripts.Commands;
using Server.Prompts;
using Server.Guilds;

namespace Server.Items
{
	public class miniGM_BackHomeStone : BlueBook
	{
		private Mobile m_NPC;
		[CommandProperty( AccessLevel.Administrator )]
		public Mobile NPC
		{
			get{ return m_NPC; }
			set{ m_NPC = value; }
		}

		[Constructable]
		public miniGM_BackHomeStone() : base()
		{
			ItemID=3023;
			Hue=2067;
			Name = "Background";
			Movable = false;
			ShardControler.All_miniGM_BackHomeStone.Add(this);
		}
		
		public override void OnDoubleClick(Mobile from)
		{
			if (from is PlayerMobile)
				if ( ((PlayerMobile)from).IsMiniGM )
				{
					if ( (NPC == null) || NPC.Deleted || !NPC.Alive)
					{
						Mobile m = new Habitant();
						NPC=m;
					}
					NPC.MoveToWorld(Location, Map);
					if (NPC is BaseCreature)
					{
						((BaseCreature)(NPC)).Home=Location;
						((BaseCreature)(NPC)).RangeHome=0;
						((BaseCreature)(NPC)).Direction=Direction.South;
						((BaseCreature)(NPC)).CurrentSpeed	=((BaseCreature)(NPC)).PassiveSpeed;
						((BaseCreature)(NPC)).AIObject.Action = ActionType.Wander;
					}
					from.SendGump( new PlayerVendorCustomizeGump(NPC,from) );
					Title = "Background de "+NPC.Name;
					base.OnDoubleClick(from);
				}
		}

		public miniGM_BackHomeStone(Serial serial) : base(serial)
		{
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int) 0);
			writer.Write(m_NPC);
		}

		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
			m_NPC=reader.ReadMobile();
			ShardControler.All_miniGM_BackHomeStone.Add(this);
		}
	}
}
