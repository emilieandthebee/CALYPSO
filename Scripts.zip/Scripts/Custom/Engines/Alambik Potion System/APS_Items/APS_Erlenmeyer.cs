/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items
{
	public class APS_Erlenmeyer : Item
	{
		
/********************
Erlenmeyer ItemID's
6186 Bleu
6187 Jaune
6188 Rouge
6189 VIDE
6212 Bleu BOUILLANT
*********************/
	
		[CommandProperty( AccessLevel.GameMaster )]
		public virtual string CurrentFormula
		{
			get { return Formula; }
			set { Formula = value; }
		}
		public string Formula;
		public int ReagentsCount;
		
		public override void OnDoubleClick( Mobile from )
		{ if ( Utility.RandomDouble() < APS_Mortier.APS_ChanceToBreak )
			{
				from.SendMessage("Oups... ça s'est cassé...");
				Delete();
				return;
			}
		  from.SendMessage("Selectionnez quelquechose que vous voulez mettre dedans.");
		  from.Target = new InternalTarget( this ); }
		private class InternalTarget : Target
		{
			private APS_Erlenmeyer m_thing;
			public InternalTarget( APS_Erlenmeyer thing ) : base( -1, false, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( !( targeted is Item ) ) {
					from.SendMessage( "Il faut que ce soit un objet..." );
					return;					
				}
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else {
					m_thing.LikeDragDrop( from, (Item)targeted );
				}
			}
		}

		public void SelfClick( Mobile from )
		{
			if (ItemID == 6189) /*Empty*/
			{
				from.SendMessage("Il est déjà vide...");
			} else {
				from.SendMessage("Vous videz l'erlenmeyer...");
				ItemID = 6189;
				Formula = APS_Mortier.APS_EmptyFormula;
				ReagentsCount = 0;
				Effects.PlaySound(from.Location, from.Map, 0x240);
			}			
		}

		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}
		
		public bool LikeDragDrop( Mobile from, Item dropped )
		{
				if (dropped is APS_Mortier)
				{
					if (ItemID != 6189) /*Not Empty*/
					{
						from.SendMessage("Il y a déjà quelquechose dans cet erlenmeyer...");	
					} else if (((APS_Mortier)dropped).ReagentsCount == 0) {
						from.SendMessage("Vous devriez broyer quelquechose dans le mortier avant...");							
					} else {
						from.SendMessage("Vous faites une solution à base du contenu du mortier...");	
						Formula = ((APS_Mortier)dropped).Formula;
						ReagentsCount = ((APS_Mortier)dropped).ReagentsCount;
						((APS_Mortier)dropped).ReagentsCount = 0;
						((APS_Mortier)dropped).Formula=APS_Mortier.APS_EmptyFormula;
						Effects.PlaySound(from.Location, from.Map, 0x240); 
						ItemID = 6186 + (int)(APS_Mortier.ComputeFormula(Formula) % 3); // Pseudo-random color, uniq per formula
					}
				} else {
						from.SendMessage("Non, ca ne marchera pas... Essayez plutôt de mettre le contenu d'un mortier..");
				}
			return true;
		}

		[Constructable]
		public APS_Erlenmeyer() : base( 6189 )
		{
			InitializeItemVaraiables();
		}

		public void InitializeItemVaraiables()
		{
			Name = "Un erlenmeyer";
			Formula = APS_Mortier.APS_EmptyFormula;
			ReagentsCount = 0;
			Weight = 1.0;
		}
		
		public APS_Erlenmeyer( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (string) Formula );
			writer.Write( (int) ReagentsCount );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			Formula = reader.ReadString();
			ReagentsCount = reader.ReadInt();
			int version = reader.ReadInt();
		}
	}
}