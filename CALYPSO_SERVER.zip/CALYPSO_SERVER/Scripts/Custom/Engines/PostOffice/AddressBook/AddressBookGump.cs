using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;
using Server.Targeting;
using Server.Accounting;

namespace Server.Gumps
{
	public class AddressBookGump : Gump
	{
		private Mobile m_from;
		private AddressBook i_from;
				
		public AddressBookGump( Mobile from, AddressBook i ) : base( 25, 25)
		{
			from.CloseGump( typeof( AddressBookGump ) );
			
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;
			
			AddPage(0);
			AddBackground(0, 0, 0, 0, 0);
			AddImage(39, 90, 2201, 0);
			AddLabel(93, 109, 0, "Address Book");
			AddLabel(67, 150, 0, "Here you can store");
			AddLabel(67, 165, 0, "The names of your");
			AddLabel(67, 180, 0, "Friends so that there");
			AddLabel(67, 195, 0, "Is no mix-up on people");
			AddLabel(67, 210, 0, "With the same name");
			AddLabel(67, 225, 0, "as Your Friends...");
			AddButton(230, 110, 2117, 2118, 1, GumpButtonType.Reply, 0);
			AddButton(230, 130, 2117, 2118, 2, GumpButtonType.Reply, 0);
			AddButton(230, 150, 2117, 2118, 3, GumpButtonType.Reply, 0);
			AddButton(230, 170, 2117, 2118, 4, GumpButtonType.Reply, 0);
			AddButton(230, 190, 2117, 2118, 5, GumpButtonType.Reply, 0);
			AddButton(230, 210, 2117, 2118, 6, GumpButtonType.Reply, 0);
			AddButton(230, 230, 2117, 2118, 7, GumpButtonType.Reply, 0);
			AddButton(230, 250, 2117, 2118, 8, GumpButtonType.Reply, 0);
			AddLabel( 250, 110, 0, i.Friend1);
			AddLabel( 250, 130, 0, i.Friend2);
			AddLabel( 250, 150, 0, i.Friend3);
			AddLabel( 250, 170, 0, i.Friend4);
			AddLabel( 250, 190, 0, i.Friend5);
			AddLabel( 250, 210, 0, i.Friend6);
			AddLabel( 250, 230, 0, i.Friend7);
			AddLabel( 250, 250, 0, i.Friend8);
			
			i_from = i;
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			Mobile m = state.Mobile;
			
			if ( info.ButtonID >= 1 )
			{
				m.SendMessage("Please choose the friend to add.");
				m.Target = new AddressBookTarget( m, info.ButtonID, i_from );
			}
		}

		private class AddressBookTarget : Target
		{
			private int b_ID;
			private AddressBook addrbk;

			public AddressBookTarget( Mobile m, int b, AddressBook i ) : base( -1, true, TargetFlags.None )
			{
				b_ID = b;
				addrbk = i;
			}

			protected override void OnTarget( Mobile from, object o )
			{
				Mobile m;
				Account a;

				if ( o is Mobile )
				{
					m = (Mobile)o;
					a = m.Account as Account;
					
					if ( m == from )
					{
						from.SendMessage("You can not add yourself.");
						from.SendGump( new AddressBookGump( from, addrbk ) );
						return;
					}

					if ( m.Account != null )
					{
						Type t = addrbk.GetType();
						
						ConstructorInfo[] info = t.GetConstructors();
						
						foreach ( ConstructorInfo c in info )
						{
							ParameterInfo[] paramInfo = c.GetParameters();

							if ( paramInfo.Length == 0 )
							{
								object[] objParams = new object[0];

								try 
								{
									object d = c.Invoke( objParams );

									if ( d != null && d is AddressBook )
									{
										AddressBook newItem = (AddressBook)d;
										CopyProperties( newItem, addrbk );
										newItem.Parent = null;
										switch ( b_ID )
										{
											case 1:
												{
													newItem.Friend1 = m.Name;
													newItem.Acct1 = a.Username;
													break;
												}
											case 2:
												{
													newItem.Friend2 = m.Name;
													newItem.Acct2 = a.Username;
													break;
												}
											case 3:
												{
													newItem.Friend3 = m.Name;
													newItem.Acct3 = a.Username;
													break;
												}
											case 4:
												{
													newItem.Friend4 = m.Name;
													newItem.Acct4 = a.Username;
													break;
												}
											case 5:
												{
													newItem.Friend5 = m.Name;
													newItem.Acct5 = a.Username;
													break;
												}
											case 6:
												{
													newItem.Friend6 = m.Name;
													newItem.Acct6 = a.Username;
													break;
												}
											case 7:
												{
													newItem.Friend7 = m.Name;
													newItem.Acct7 = a.Username;
													break;
												}
											case 8:
												{
													newItem.Friend8 = m.Name;
													newItem.Acct8 = a.Username;
													break;
												}
											default:
												{
													break;
												}
										}
						
										addrbk.Delete();
										from.AddToBackpack( newItem );
										from.SendGump( new AddressBookGump( from, newItem ) );
									}
								}
								catch
								{
								}
							}
						}
					}
					else
					{
						from.SendMessage("You can only add player characters.");	
						from.SendGump( new AddressBookGump( from, addrbk ) );
					}
				}
			}
		}
		
		private static void CopyProperties ( Item dest, Item src ) 
		{ 
			PropertyInfo[] props = src.GetType().GetProperties(); 

			for ( int i = 0; i < props.Length; i++ ) 
			{ 
				try
				{
					if ( props[i].CanRead && props[i].CanWrite )
					{
						props[i].SetValue( dest, props[i].GetValue( src, null ), null ); 
					}
				}
				catch
				{
				}
			}
		}
	}
}
