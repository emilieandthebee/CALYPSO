using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;
using Server.Targeting;
using Server.Accounting;

namespace Server.Gumps
{
	public class PostOfficeGump : Gump
	{
		private Mobile m_from;
		string m_acct, m_to;
		
		public PostOfficeGump( Mobile from, string to, string a ) : base( 25, 25)
		{
			from.CloseGump( typeof( PostOfficeGump ) );
			
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;
			
			AddPage(0);
			
			AddBackground(27, 22, 400, 400, 3500);
			
			AddImage(-20, -1, 10440, 0);
			AddImage(316, 53, 5536, 0);
			AddLabel(148, 84, 0, @".::Post Office::.");
			AddImage(95, 80, 92, 0);
			AddImage(147, 80, 93, 0);
			AddImage(154, 80, 93, 0);
			AddImage(265, 80, 94, 0);
			AddImage(110, 155, 1418, 0);
			AddTextEntry( 93, 340, 110, 20, 1149, 0, to );
			AddButton(60, 260, 4030, 4031, 1, GumpButtonType.Reply, 0);
			AddButton(60, 290, 4018, 4019, 0, GumpButtonType.Reply, 0);
			AddLabel(100, 260, 0, @"Send Item");
			AddLabel(100, 290, 0, @"Close");
			AddLabel(89, 126, 0, "To Send an Item is 50 Gold Pieces.");
			AddImage(41, 336, 52, 0);
			AddButton( 56, 351, 2117, 2118, 2, GumpButtonType.Reply, 0);
			AddLabel(137, 155, 0, @"Thanks for using,");
			AddLabel(127, 183, 0, @"Raisor's Post Office.");
			AddLabel(44, 315, 0, "Type \"recievers\" name here");

			m_acct = a;
			m_to = to;
		}
		
		public override void OnResponse( NetState state, RelayInfo info ) //Function for GumpButtonType.Reply Buttons 
		{ 
			m_from = state.Mobile; 

			if ( info.ButtonID == 1 ) 
			{ 
				if ( m_to == "" )
					m_from.SendMessage("You did not specify a person to send to.");
				else
				{
					m_from.SendMessage("Choose the Item to send to {0}", m_to);
					m_from.Target = new PackageTarget( m_from, m_to, m_acct );
				}
			}

			if ( info.ButtonID == 2 )
			{
				m_from.SendGump( new SendToGump( m_from ) );
			}
		}
		
		private class PackageTarget : Target
		{
			private string m_to, m_acct;
			
			public PackageTarget( Mobile m, string n, string a ) : base( -1, true, TargetFlags.None )
			{
				m_to = n;
				m_acct = a;
			}
			
			protected override void OnTarget( Mobile from, object o )
			{
				//bool done = false;
				bool sent = false;
				Container bank = from.BankBox;
				MailBox mailbox;
				Account a;
				Gold g = new Gold();
				g.Amount = 50;
				
				if ( o is Item )
				{
					Item i_package = (Item)o;
					
					if ( !i_package.IsChildOf( from.Backpack ) && !i_package.IsChildOf( from.BankBox ) )
					{
						from.SendMessage( "This must be in your backpack or bank to send it." );
						return;
					}
					else
					{
						if ( o is Container ) 
						{ 
							from.SendMessage( "You can't send Container's" );
							return;
						}
						
						if ( !bank.ConsumeTotal( typeof( Gold ), 50 ))
						{
							from.SendMessage("You must have 50 gold in your bank to send items");
							return;
						}
						
                        ArrayList mobs = new ArrayList( World.Mobiles.Values );
										
						foreach ( Mobile m in mobs )
						{
							a = m.Account as Account;
							mailbox = m.BankBox.FindItemByType( typeof( MailBox ) ) as MailBox;

							if ( m.Player && m != null && m.Name == m_to && a.Username == m_acct && i_package != null )
							{
								mailbox.DropItem( i_package );
								mailbox.NewMail = "true";
                                if ( m.NetState != null ) 
                                    m.SendGump(new NewMailGump(m, mailbox));
                                sent = true;
                			}
						}
                        //done = true;
                    }
                    if (sent)
                    {
                        from.SendMessage("Item sent.");
                        g.Delete();
                    }
                    else
                    {
                        from.SendMessage("Item not sent");
                        from.BankBox.DropItem(g);
                    }
                }
				else
					from.SendMessage("You can only send Items");
			}
		}
	}
}
