using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;
using Server.Gumps;

namespace Server.Scripts.Commands
{
	public class Info
	{
		public static void Initialize()
		{
			Server.Commands.Register( "Info", AccessLevel.Player, new CommandEventHandler( Info_OnCommand ) );
		}

		[Usage( "Info" )]
		[Description( "Donne les informations de votre personnage." )]
		private static void Info_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)e.Mobile;
				
				string ihtml = "";
				
				ihtml = ihtml+"<B>CHARISME</B><BR>";
				if (pm.Charism<10)
					ihtml=ihtml+"Votre n'avez vraiement aucun charisme!<br>";
				else if (pm.Charism<20)
					ihtml=ihtml+"Vous n'etes pas tres charismatique...<br>";
				else if (pm.Charism<30)
					ihtml=ihtml+"Vous avez un charisme d'un commun navrant...<br>";
				else if (pm.Charism<40)
					ihtml=ihtml+"Vous avez un certain charisme...<br>";
				else if (pm.Charism<50)
					ihtml=ihtml+"Vous etes une personne assez charismatique.<br>";
				else if (pm.Charism<60)
					ihtml=ihtml+"Votre avez un fort charisme.<br>";
				else if (pm.Charism<70)
					ihtml=ihtml+"Votre charisme est tres fort et influe sur tout votre environnement.<br>";
				else if (pm.Charism<80)
					ihtml=ihtml+"Vous etes incroyablement charismatique et votre influence peut etre grande!<br>";
				else if (pm.Charism<90)
					ihtml=ihtml+"Votre extraordinaire charisme est une arme redoutable!<br>";
				else 
					ihtml=ihtml+"Avec cet charisme inclassable, meme les pierres vous suivraient!<br>";
				
				ihtml = ihtml+"<BR><B>CONDITION PHYSIQUE</B><BR>";
				if ( pm.Hunger == 0 )
					ihtml=ihtml+"Vous etes completement affame(e)! Pret(e) a mourir!...<br>";
				else if ( pm.Hunger < 3 )
					ihtml=ihtml+"Vous avez extremement faim et avez des vertiges!...<br>";
				else if ( pm.Hunger < 6 )
					ihtml=ihtml+"Vous avez tres faim!...<br>";
				else if ( pm.Hunger < 10 )
					ihtml=ihtml+"Vous avez faim...<br>";
				else
					ihtml=ihtml+"Vous n'avez pas faim.<br>";

				if ( pm.Thirst == 0 )
					ihtml=ihtml+"Vous avez la langue assechee et les levres gonflees! Pret(e) a mourir de soif!...<br>";
				else if ( pm.Thirst < 3 )
					ihtml=ihtml+"Vous etes assoiffe!...<br>";
				else if ( pm.Thirst < 6 )
					ihtml=ihtml+"Vous avez tres soif!...<br>";
				else if ( pm.Thirst < 10 )
					ihtml=ihtml+"Vous avez soif...<br>";
				else
					ihtml=ihtml+"Vous n'avez pas soif.<br>";

				if (pm.Radiation>9*30)
					ihtml=ihtml+"Vous etes tellement malade que vous etes pret a mourir...<br>";
				else if (pm.Radiation>7*30)
					ihtml=ihtml+"Vous etes tres malade!... Vous crachez du sang, avez des pustules et des plaques, Vous avez d'enormes migraines.<br>";
				else if (pm.Radiation>5*30)
					ihtml=ihtml+"Vous etes malade!... Vous avez des migraines, plaques rouges sur le corps, et mal aux os.<br>";
				else if (pm.Radiation>3*30)
					ihtml=ihtml+"Vous etes malade!... Vous avez des migraines, des frissons, et mal aux articulations.<br>";
				else if (pm.Radiation>2*30)
					ihtml=ihtml+"Vous etes malade... Vous avez des migraines.<br>";
				else if (pm.Radiation>30)
					ihtml=ihtml+"Vous ne vous sentez pas tres bien...<br>";

				switch ( pm.DeathState )
				{
				case DeathStateEnum.Assome:
					{
						ihtml=ihtml+"Vous etes actuellement assome(e).<br>";
						break;
					}
				case DeathStateEnum.Comat:
					{
						ihtml=ihtml+"Vous etes actuellement dans le comat:<br>";
						ihtml=ihtml+"Vos chances de guérison sont actuellement de "+String.Format("{0}",100-pm.Blessure)+"%.<br>";
						ihtml=ihtml+"Un médecin pourrait vous aider a augmenter ces chances.<br>";
						ihtml=ihtml+"Le prochain evenement quant a votre etat se fera dans "+String.Format("{0}",pm.NextDeathState-DateTime.Now)+"%.<br>";
						ihtml=ihtml+"Vous serez alors soit guéri(e), soit mort, soit encore dans le comat.<br>";
						ihtml=ihtml+"Vous pouvez decider d'utiliser un point de destinee pour avoir une guerison immediate.<br>";
						ihtml=ihtml+"Vous pouvez decider d'utiliser un point de destinee pour avoir une guerison immediate.<br>";
						break;
					}
				case DeathStateEnum.Destin:
					{
						ihtml=ihtml+"Votre destin vous guide...<br>";
						break;
					}
				case DeathStateEnum.Mort:
					{
						ihtml=ihtml+"Vous etes mort.<br>";
						break;
					}
				default:
					{
						ihtml=ihtml+"<BR>";
						break;
					}
				}
				
				ihtml = ihtml+"<BR><B>DESTIN</B><BR>";
				ihtml=ihtml+"Vous avez "+String.Format("{0}",pm.Destin)+" points de destinee.<BR><BR>";
				ihtml=ihtml+"Pour information, vous pouvez avoir au maximum "+String.Format("{0}",PlayerMobile.DestinMax)+
					" points de destinee. Si vous n'etes pas a ce maximum, tout les "+String.Format("{0}",PlayerMobile.DestinDays)+
					" jours, un point vous est ajouté. Si vous mourez et que vous n'avez plus de point de destinée, votre personnage est mort definitivement.<BR>";
				if (pm.Destin == 0)
				{
					ihtml=ihtml+"La prochaine fois que vous \"mourez\", cette mort sera définitive.<BR>";
					ihtml=ihtml+"Une fois par mois, vous recuperer 1 point de destin, jusqu'a un maximum. de "+String.Format("{0}",PlayerMobile.DestinMax)+"<BR>";
				}

				pm.SendGump(new InfoHtml(ihtml));
				pm.SendDeathStateGump();				
			}
		}
	}
}