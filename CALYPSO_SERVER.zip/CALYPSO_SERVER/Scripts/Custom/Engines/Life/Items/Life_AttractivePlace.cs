/********************************************
 *
 * Alambik Life System
 *
 ********************************************/
using System;
using Server.Items;
using Server.Mobiles;

namespace Server.Items
{	
	public class Life_AttractivePlace : Life_Item
	{	
		private int m_Range;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public int Range { get { return m_Range; } set { m_Range = value; } }
	
		[Constructable]
		public Life_AttractivePlace() : base( 4342 )
		{
			Name  = "[LIFE] Attractive place";
			Range = 10;
			Visible = false;
		}

		public Life_AttractivePlace( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
    	{
        	base.Serialize( writer );
        	writer.Write( (int) 1 );
        	writer.Write( Range );
    	}
		
		public override void Deserialize(GenericReader reader)
		{        
			base.Deserialize( reader );
			int version = reader.ReadInt();
			switch ( version )
			{
				case 1:
				{
					Range = reader.ReadInt();
					break;
				}
			}
		}
	}
}
