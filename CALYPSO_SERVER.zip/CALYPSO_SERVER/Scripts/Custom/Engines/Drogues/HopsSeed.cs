using System;
using Server.Network;
using Server.Mobiles;
using Server.SkillHandlers;
namespace Server.Items
{ 
	public class HopsSeed : Item 
	{
		[Constructable] 
		public HopsSeed() : base( 0x0F7F ) 
		{ 
			Movable = true; 
			Weight = 0.1; 
			Stackable = true; 
			Name = "une graine de mielesse"; 
		} 

		public HopsSeed( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 0 ); 
		} 

		public override void Deserialize( GenericReader reader ) 
		{
			base.Deserialize( reader ); 
			int version = reader.ReadInt();
		} 

		public override void OnDoubleClick( Mobile from ) 
		{ 
			Map pmap = from.Map; 
			int playerX = from.X; 
			int playerY = from.Y; 
	
			Tile FarmTile = pmap.Tiles.GetLandTile( playerX, playerY ); 

			if ( !IsChildOf( from.Backpack ) ) 
			{ 
				from.SendMessage("Vous devez l'avoir dans votre sac"); 
			} 
			else 
			{ 
				if ( FarmTile.ID == 9 ) 
				{ 
					from.SendMessage("Vous plantez une graine!"); 
					this.Consume(); 
					Item item = new PlantedSeedHops(); 
					item.Location = from.Location; 
					item.Map = from.Map; 
				} 
				else
				{
					from.SendMessage("Vous ne pouvez planter une graine que sur un terrain laboure."); 
				}
			} 
		} 
	}

public class PlantedSeedHops : Item, IChopable
{
	public bool m_Harvestable;

	[CommandProperty( AccessLevel.GameMaster )]
	public bool Harvestable
	{
		get{ return m_Harvestable; }
		set{ m_Harvestable = value; }
	}

	[Constructable] 
	public PlantedSeedHops() : base( 0x187E ) 
	{ 
		Movable = false; 
		Name = "Un graine plantee"; 
		ItemGrowTimer growTimer = new ItemGrowTimer( this ); 
		growTimer.Start();
	} 
	public PlantedSeedHops( Serial serial ) : base( serial ) 
	{ 
	}

	public void OnChop( Mobile from )
	{
		if ( this != null && from.InRange( GetWorldLocation(), 3 ) )
		{
			this.Consume();
			from.SendMessage("Vous detruisez la plante.");

			switch ( Utility.Random( 9 ) )
			{
				case 0: break;
				case 1: break;
				case 2: break;
				case 3: HopsSeed HopsSeed = new HopsSeed();
					if (!from.AddToBackpack(HopsSeed)) 
						HopsSeed.Consume();
					from.SendMessage("Vous recoltez une graine de la plante."); break;
				case 4: break;
				case 5: break;
				case 6: break;
				case 7: break;
				case 8: break;
			}
		}
		else
		{
			from.SendLocalizedMessage( 500446 ); // That is too far away.
		}
	}

	public class ItemGrowTimer : Timer 
	{ 
		private Item i_item; 
		//The time of the growth cycle; 
		public ItemGrowTimer( Item item ) : base( TimeSpan.FromSeconds( 540 ) ) 
		{ 
			Priority = TimerPriority.OneSecond; 
			i_item = item; 
		} 

		protected override void OnTick() 
		{
			ItemFruitionTimer fruitionTimer = new ItemFruitionTimer( i_item ); 
			if (( i_item != null ) && ( !i_item.Deleted )) 
			{ 
				i_item.ItemID = 0x1A9E;
				i_item.Name = "De la mielesse";
				fruitionTimer.Start();
			} 
		} 
	}

	public class ItemFruitionTimer : Timer 
	{
		public bool Harvestable;
		private Item i_item; 

		//The time of the fruition cycle
		public ItemFruitionTimer( Item item ) : base( TimeSpan.FromSeconds( 540 ) ) 
		{ 
			Priority = TimerPriority.OneSecond; 
			i_item = item; 
		}

		protected override void OnTick()
		{ 
			if (( i_item != null ) && ( !i_item.Deleted )) 
			{
				((PlantedSeedHops)i_item).Harvestable = true;
			} 
		} 
	} 

	public override void OnDoubleClick( Mobile from ) 
	{
		ItemFruitionTimer fruitionTimer = new ItemFruitionTimer( this ); 

			if (!this.Harvestable)
			{
				from.SendMessage("Cette plante n'a pas encore produit de graine."); 
			}
			else if (from.InRange(this.GetWorldLocation(),1))
			{
				if ( from.CheckSkill( SkillName.Lumberjacking, 0.0, 50.0 ) )
				{
			            		if ( !from.Mounted ) 
        	      					from.Animate( 32, 5, 1, true, true, 0 ); 
					//Set number of Hops that one plant generates; 
					Hops Hops = new Hops();
					if (!from.AddToBackpack(Hops)) 
						Hops.Consume();
					from.SendMessage("You pick the crops and place them in your pack."); 
					this.Harvestable = false;
					fruitionTimer.Start();
				}
				else
				{
					from.SendMessage("Vous n'arrivez pas a recuperer quoique ce soit de cette plante."); 
				} 
			} 
			else 
			{ 
				from.SendMessage("La plante n'est pas accessible."); 
			} 
	}

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 1 ); // version

			writer.Write( (bool)m_Harvestable ); 
		} 
		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 
			int version = reader.ReadInt();

			switch ( version )
			{
				case 1:
				{
					m_Harvestable = reader.ReadBool();
					goto case 0;
				}

				case 0:
				{
					break;
				}
			}
		} 
	}
}