/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items
{
	public class APS_Tonnelet : Item
	{		
		[CommandProperty( AccessLevel.GameMaster )]
		public virtual string CurrentFormula
		{
			get { return Formula; }
		}
		public string Formula;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_Potion.APS_PotionEffect PotionEffect
		{
			get { return m_PotionEffect; }
			set { m_PotionEffect = value; }
		}
		public APS_Potion.APS_PotionEffect m_PotionEffect;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual double Power
		{
			get { return m_Power; }
			set { m_Power = value; }
		}
		public double m_Power;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_Potion.APS_PotionEffect SecondPotionEffect
		{
			get { return m_SecondPotionEffect; }
			set { m_SecondPotionEffect = value; }
		}
		public APS_Potion.APS_PotionEffect m_SecondPotionEffect;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual double SecondPower
		{
			get { return m_SecondPower; }
			set { m_SecondPower = value; }
		}
		public double m_SecondPower;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual bool IsEnhanced
		{
			get { return Enhanced; }
			set { Enhanced = value; }
		}
		public bool Enhanced;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int Quantity
		{
			get { return m_Quantity; }
			set { m_Quantity = value; }
		}
		public int m_Quantity;
		
		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int PotionItemID
		{
			get { return m_PotionItemID; }
			set { m_PotionItemID = value; }
		}
		public int m_PotionItemID;
		
		public override void GetProperties( ObjectPropertyList list )
		{
			base.GetProperties( list );
			int number;
			if ( m_Quantity <= 0 )
				number = 502246; // The keg is empty.
			else if ( m_Quantity < 5 )
				number = 502248; // The keg is nearly empty.
			else if ( m_Quantity < 20 )
				number = 502249; // The keg is not very full.
			else if ( m_Quantity < 30 )
				number = 502250; // The keg is about one quarter full.
			else if ( m_Quantity < 40 )
				number = 502251; // The keg is about one third full.
			else if ( m_Quantity < 47 )
				number = 502252; // The keg is almost half full.
			else if ( m_Quantity < 54 )
				number = 502254; // The keg is approximately half full.
			else if ( m_Quantity < 70 )
				number = 502253; // The keg is more than half full.
			else if ( m_Quantity < 80 )
				number = 502255; // The keg is about three quarters full.
			else if ( m_Quantity < 96 )
				number = 502256; // The keg is very full.
			else if ( m_Quantity < 100 )
				number = 502257; // The liquid is almost to the top of the keg.
			else
				number = 502258; // The keg is completely full.
			list.Add( number );
		}

		public override void OnSingleClick( Mobile from )
		{
			base.OnSingleClick( from );

			int number;
			if ( m_Quantity <= 0 )
				number = 502246; // The keg is empty.
			else if ( m_Quantity < 5 )
				number = 502248; // The keg is nearly empty.
			else if ( m_Quantity < 20 )
				number = 502249; // The keg is not very full.
			else if ( m_Quantity < 30 )
				number = 502250; // The keg is about one quarter full.
			else if ( m_Quantity < 40 )
				number = 502251; // The keg is about one third full.
			else if ( m_Quantity < 47 )
				number = 502252; // The keg is almost half full.
			else if ( m_Quantity < 54 )
				number = 502254; // The keg is approximately half full.
			else if ( m_Quantity < 70 )
				number = 502253; // The keg is more than half full.
			else if ( m_Quantity < 80 )
				number = 502255; // The keg is about three quarters full.
			else if ( m_Quantity < 96 )
				number = 502256; // The keg is very full.
			else if ( m_Quantity < 100 )
				number = 502257; // The liquid is almost to the top of the keg.
			else
				number = 502258; // The keg is completely full.
			this.LabelTo( from, number );

		}

		public override void OnDoubleClick( Mobile from )
		{
		  from.SendMessage("Selectionnez quelquechose que vous voulez mettre dedans.");
		  from.Target = new InternalTarget( this ); 
		}
		
		private class InternalTarget : Target
		{
			private APS_Tonnelet m_thing;
			public InternalTarget( APS_Tonnelet thing ) : base( -1, false, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( !( targeted is Item ) ) {
					from.SendMessage( "Il faut que ce soit un objet..." );
					return;					
				}
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else {
					m_thing.LikeDragDrop( from, (Item)targeted );
				}
			}
		}

		private class InternalTarget2 : Target
		{
			private APS_Tonnelet m_thing;
			private APS_Melangeur m_melangeur;
			public InternalTarget2( APS_Tonnelet thing, APS_Melangeur melangeur ) : base( -1, false, TargetFlags.None )
			{
				m_thing = thing;
				m_melangeur = melangeur;
			}
			protected override void OnTarget( Mobile from, object targeted )
			{
				Container cont=null;
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( ( targeted is PlayerMobile ) ) {
					if ((Mobile)targeted == from)
						cont=(Container)(((PlayerMobile)targeted).Backpack);
					else
						from.SendMessage( "Il faut que ce soit un contenant, comme votre sac a dos, une boite, une armoire, etc..." );
				} else if ( !( targeted is Container ) ) {
					from.SendMessage( "Il faut que ce soit un contenant, comme votre sac a dos, une boite, une armoire, etc..." );
					return;					
				} else {
					cont=(Container)targeted;
				}
				m_thing.MakePotionsInKeg( from, cont, m_melangeur );
			}
		}

		public void SelfClick( Mobile from )
		{
			if (m_Quantity == 0) /*Empty*/
			{
				from.SendMessage("Il est déjà vide...");
			} else {
				from.SendMessage("Vous videz le tonnelet...");
				Weight = 10.0;
				m_Quantity = 0;
				Formula = APS_Mortier.APS_EmptyFormula;
				m_PotionEffect=APS_Potion.APS_PotionEffect.EmptyBottle;
				Effects.PlaySound(from.Location, from.Map, 0x240);
			}			
		}
		
		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}
		
		public bool LikeDragDrop( Mobile from, Item dropped )
		{
				if (dropped is APS_Melangeur) {
					APS_Melangeur melangeur=((APS_Melangeur)dropped);
					if (m_PotionEffect != APS_Potion.APS_PotionEffect.EmptyBottle) /*Not Empty*/
					{
						from.SendMessage("Il y a déjà quelquechose dans ce tonnelet...");	
					} else if (melangeur.ItemID == 6205) {
						from.SendMessage("Le mélangeur est vide...");	
					} else {
						if (melangeur.Formula != APS_Mortier.LookupPlayerLastFormula(from.Serial.Value)) {
							from.SendMessage("Ce n'est pas la derniere formule que vous avez effectue depuis la derniere fois.");
							from.SendMessage("(ou depuis le dernier redemarrage du serveur)");
							from.SendMessage("Vous devez refaire cette formule.");
						} else if (melangeur.Formula == APS_Mortier.APS_EmptyFormula) {
							from.SendMessage("Difficile de faire des potion sans formule...");
						} else {
							MoonPhase phase=Clock.GetMoonPhase(from.Map,from.X,from.Y);
							bool compatible=false;
							switch (melangeur.FormulaMoonPhase) {
								case MoonPhase.NewMoon:
								case MoonPhase.FullMoon:
									compatible = ( phase == melangeur.FormulaMoonPhase );
									break;
								case MoonPhase.WaxingCrescentMoon:
								case MoonPhase.FirstQuarter:
								case MoonPhase.WaxingGibbous:
									compatible = (( phase == MoonPhase.WaxingCrescentMoon ) ||
												  ( phase == MoonPhase.FirstQuarter ) ||
												  ( phase == MoonPhase.WaxingGibbous ));
									break;
								case MoonPhase.WaningGibbous:
								case MoonPhase.LastQuarter:
								case MoonPhase.WaningCrescent:
									compatible = (( phase == MoonPhase.WaningGibbous ) ||
												  ( phase == MoonPhase.LastQuarter ) ||
												  ( phase == MoonPhase.WaningCrescent ));
									break;
								default:
									break;
							}
							if (!compatible) {
								from.SendMessage("Cette formule n'a pas ete faite a la meme periode lunaire...");
							} else {
								from.SendMessage("Selectionnez le contenant dans lequel se trouve des ingredients.");
								from.SendMessage("Cela peut etre votre sac a dos, une boite, une armoire, etc...");
								from.SendMessage("Vous pouvez aussi selectionnez votre propre personnage.");
								from.Target = new InternalTarget2( this, melangeur );
							}
						}
					}
				} else {
						from.SendMessage("Non, ca ne marchera pas... Essayez plutôt de mettre le contenu d'un mélangeur..");
				}
			return true;
		}

		
		// CONSUME THE RIGHT NUMBER OF REAGENTS
		public void MakePotionsInKeg( Mobile from, Container cont, APS_Melangeur melangeur )
		{
			if ( cont == null )
				return;

			int CanMakeThisQuantity=100; // Maximum by default
			int[] AvailableQuantities = new int[APS_Mortier.APS_NumberOfReagents];
			int[] NeededForOnePotion = new int[APS_Mortier.APS_NumberOfReagents];
			Item[][] items = new Item[APS_Mortier.APS_NumberOfReagents][];

			// First, check what quantity we cando with all those stuff of reagents in the bag
			for (int i=0;i<APS_Mortier.APS_NumberOfReagents;i++)
			{
				items[i] = cont.FindItemsByType( APS_Mortier.InvLookup(i+1), true );
				AvailableQuantities[i]=0;
				for (int j=0;j<items[i].Length;j++)
					AvailableQuantities[i]=AvailableQuantities[i]+items[i][j].Amount;
				NeededForOnePotion[i]=APS_Mortier.GetReageantsNumberFromFormula(melangeur.Formula,i+1);
				if (NeededForOnePotion[i]<0) 
					NeededForOnePotion[i]=-NeededForOnePotion[i];
				if (NeededForOnePotion[i] != 0)
					CanMakeThisQuantity = Math.Min(CanMakeThisQuantity,AvailableQuantities[i]/NeededForOnePotion[i]);
			}
			
			// Ok, now lets consume the reagents
			for (int i=0;i<APS_Mortier.APS_NumberOfReagents;i++)
			{
				int ToBeConsumed=CanMakeThisQuantity*NeededForOnePotion[i];
				for (int j=0;j<items[i].Length;j++)
				{
					if (ToBeConsumed>0)
					{
						int amount = items[i][j].Amount;
						if (amount<=ToBeConsumed)
							items[i][j].Delete();
						else
							items[i][j].Amount = items[i][j].Amount - ToBeConsumed;
						ToBeConsumed = ToBeConsumed - amount;
					}
				}
			}
			double skillValue = from.Skills[SkillName.Alchemy].Value;
			int WillMakeThisQuantity = CanMakeThisQuantity*(int)skillValue/100;
			if (Enhanced)
				WillMakeThisQuantity = WillMakeThisQuantity*(int)skillValue/150;
			if (WillMakeThisQuantity <=0) {
				from.SendMessage("Vous n'y arrivez pas... Pas assez d'ingredient vu votre talent d'alchimiste.");	
			} else {
				from.SendMessage("Vous remplissez le tonnelet...");	
				Quantity=WillMakeThisQuantity;
				Weight = 10.0+Quantity*(APS_Potion.FullWeight-APS_Potion.EmptyWeight);
				Effects.PlaySound(from.Location, from.Map, 0x240);
			}
			Formula 			= melangeur.Formula;
			Enhanced 			= melangeur.Enhanced;
			PotionItemID 		= melangeur.PotionItemID;
			PotionEffect 		= melangeur.PotionEffect;
			Power 				= melangeur.Power;
			SecondPotionEffect 	= melangeur.SecondPotionEffect;
			SecondPower 		= melangeur.SecondPower;
			PotionEffect 		= melangeur.PotionEffect;
			PotionEffect 		= melangeur.PotionEffect;
			melangeur.ItemID = 6205;
			melangeur.ReagentsCount=0;
			melangeur.Bruleur=false;
			melangeur.Enhanced=false;
			melangeur.Formula = APS_Mortier.APS_EmptyFormula;
			melangeur.PotionEffect = APS_Potion.APS_PotionEffect.NoEffect;
		}

		[Constructable]
		public APS_Tonnelet() : base(0x1940)
		{
			Name = "Un tonnelet";
			Stackable = false;
			Weight = 10.0;
		}
		
		public APS_Tonnelet( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 	m_PotionItemID );
			writer.Write( (int) 	m_Quantity );
			writer.Write( (string) 	Formula );
			writer.Write( (bool) 	Enhanced );
			writer.Write( (double)	m_SecondPower );
			writer.Write( (int) 	m_SecondPotionEffect );
			writer.Write( (double) 	m_Power );
			writer.Write( (int) 	m_PotionEffect );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			m_PotionItemID			= reader.ReadInt();
			m_Quantity 				= reader.ReadInt();
			Formula 				= reader.ReadString();
			Enhanced 				= reader.ReadBool();
			m_SecondPower 			= reader.ReadDouble();
			m_SecondPotionEffect 	= (APS_Potion.APS_PotionEffect)(reader.ReadInt());
			m_Power 				= reader.ReadDouble();
			m_PotionEffect 			= (APS_Potion.APS_PotionEffect)(reader.ReadInt());
			int version = reader.ReadInt();
		}
	}
}