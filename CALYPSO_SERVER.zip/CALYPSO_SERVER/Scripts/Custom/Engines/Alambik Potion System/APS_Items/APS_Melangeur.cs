/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items
{
	public class APS_Melangeur : Item
	{
		
/********************
Mélangeur
6203 Jaune 
6204 Rose
6205 VIDE
6209 Rose BOUILLANT
*********************/
	
		[CommandProperty( AccessLevel.GameMaster )]
		public virtual string CurrentFormula
		{
			get { return Formula; }
			set { Formula = value; }
		}
		public string Formula;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual MoonPhase FormulaMoonPhase
		{
			get { return m_FormulaMoonPhase; }
			set { m_FormulaMoonPhase = value; }
		}
		MoonPhase m_FormulaMoonPhase;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int PotionItemID
		{
			get { return m_PotionItemID; }
			set { m_PotionItemID = value; }
		}
		int m_PotionItemID;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_Potion.APS_PotionEffect PotionEffect
		{
			get { return m_PotionEffect; }
			set { m_PotionEffect = value; }
		}
		public APS_Potion.APS_PotionEffect m_PotionEffect;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual double Power
		{
			get { return m_Power; }
			set { m_Power = value; }
		}
		public double m_Power;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_Potion.APS_PotionEffect SecondPotionEffect
		{
			get { return m_SecondPotionEffect; }
			set { m_SecondPotionEffect = value; }
		}
		public APS_Potion.APS_PotionEffect m_SecondPotionEffect;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual double SecondPower
		{
			get { return m_SecondPower; }
			set { m_SecondPower = value; }
		}
		public double m_SecondPower;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual bool IsEnhanced
		{
			get { return Enhanced; }
			set { Enhanced = value; }
		}
		public bool Enhanced;

		public int ReagentsCount;
		public bool Bruleur;
		public ulong ComputedFormula;

		public bool BuildIfItIsADedicatedFormula(MoonPhase phase,Mobile from)
		{
			bool isADedicatedFormula = false;
 			if (APS_Mortier.APS_UseDecicatedFormulaReagent)
			{
////////////////////////////////////////////
// CUSTOM CODE OF SPECIFIC FORMULA GOES HERE
				if (phase == MoonPhase.NewMoon)
					if (Formula=="110|001|001|010|111|001|010|110|110")
					{
						double skillValue = from.Skills[SkillName.ItemID].Value;
						if ( skillValue >= 100.0 )
						{
							if (Utility.RandomDouble() > 0.5)
							{
								isADedicatedFormula = true;
								m_PotionEffect = APS_Potion.APS_PotionEffect.MAX_Unused;
								m_SecondPotionEffect = APS_Potion.APS_PotionEffect.NoEffect;
								PotionItemID = 3846; // Black power
							} else {
								from.SendMessage("Quelquechose semble se passer, mais il semble que cela ai raté");
								from.SendMessage("Il vaudrait mieux ne pas reessayer...");
							}
						} else {
							from.SendMessage("Etrange sentiment de tricher avec la realite... Mais peut-etre pas assez...");
							from.SendMessage("Il vaudrait mieux ne pas reessayer...");
						}
					}
////////////////////////////////////////////
			}
			return isADedicatedFormula;
		}

		public void CheckResult(Mobile from)
		{
			m_FormulaMoonPhase=Clock.GetMoonPhase(from.Map,from.X,from.Y);
			bool customPotion=false;
			// First we check if it is a specific formula
			customPotion = BuildIfItIsADedicatedFormula(m_FormulaMoonPhase,from);
			if (!customPotion)
				BuildPotion(m_FormulaMoonPhase);
			if (m_PotionEffect != APS_Potion.APS_PotionEffect.NoEffect)
			{
				double skillValue = from.Skills[SkillName.Alchemy].Value;
				double chance = skillValue;
				if ( chance > Utility.RandomDouble() * 110.0 )
				{
					ItemID=6209; // That's something! (bubble)
					from.SendMessage("Oh! Quelquechose se passe! Ca bouillonne...");	
				} else {
					ItemID=6203; // Missed because of skill... (yellow)
					from.SendMessage("Ca avait l'air de faire quelquechose, mais ça a raté...");
					m_PotionEffect = APS_Potion.APS_PotionEffect.NoEffect;
				}
			} else {
				ItemID=6204; // No, not yet... (pink)
			}
			if (!customPotion)
			{
				// Save the latest formula done (volatile: forgotten at first restart)
				int SerialNumber = from.Serial.Value;
/*2.0
				if (APS_Mortier.APS_PlayerLastFormula.ContainsKey(SerialNumber))
*1.0*/
				if (APS_Mortier.APS_PlayerLastFormula.Contains(SerialNumber))
/****/
					APS_Mortier.APS_PlayerLastFormula.Remove(SerialNumber);
				APS_Mortier.APS_PlayerLastFormula.Add(SerialNumber,Formula);
			}
		}
		
		// BUILD POTION ACCORDING TO FORMULA
		public void BuildPotion(MoonPhase phase)
		{
			bool rabbish = true;
			ulong FormulaValue=0;
			// Is it a potion or just rabbish?
			if (APS_Mortier.PreCheckFormula(Formula))
			{
				FormulaValue=APS_Mortier.ComputeFormula(Formula);
				if (APS_Mortier.CheckFormula(FormulaValue,phase))
					rabbish=false;
			}
			if (rabbish)
			{
				PotionItemID 	= 3846; // Black
				m_PotionEffect	= APS_Potion.APS_PotionEffect.NoEffect;
			} else{
				ulong val0 = APS_Mortier.FirstPseudoAlea(FormulaValue,phase); // Color
	/*************************************************************************************************************/
				ulong val1 = APS_Mortier.NextPseudoAlea (val0); 		// Effect category (+/-/Neutral), Double effect check
				ulong val2 = APS_Mortier.NextPseudoAlea (val1); 		// Effect
				ulong val3 = APS_Mortier.NextPseudoAlea (val2);			// Power
				ulong val4 = APS_Mortier.NextPseudoAlea (val3); 		// Second Effect
				ulong val5 = APS_Mortier.NextPseudoAlea (val4);			// Second Power
				/******** COLOR ********/			
				PotionItemID = 3847 + (int)(val0 % 7); // Pseudo-random color, uniq per formula
				/******** EFFECT CATEGORY ********/			
				int EffectCategory = ((int)(val1/10) % 3)-1; // -1 = negative , 0 = Neutral , +1 = Positive
				/******** DOUBLE EFFECT CHECK ********/
				bool IsDoubleEffect = ((int)((val1/100) % 3) == 0); // The "Modulo 3 = zero" equivalent to 25% chance 
				/******** EFFECT ********/
				switch (EffectCategory)
				{
/*2.0*
					case 1: 
						m_PotionEffect=APS_Potion.PositiveEffect[(int)(val2 % (ulong)APS_Potion.PositiveEffect.Count)]; break;
					case 0: 
						m_PotionEffect=APS_Potion.NeutralEffect[(int)(val2 % (ulong)APS_Potion.NeutralEffect.Count)]; break;
					case -1: 
						m_PotionEffect=APS_Potion.NegativeEffect[(int)(val2 % (ulong)APS_Potion.NegativeEffect.Count)]; break;
*1.0*/
					case 1: 
						m_PotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.PositiveEffect[(int)(val2 % (ulong)APS_Potion.PositiveEffect.Count)]); break;
					case 0: 
						m_PotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.NeutralEffect[(int)(val2 % (ulong)APS_Potion.NeutralEffect.Count)]); break;
					case -1: 
						m_PotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.NegativeEffect[(int)(val2 % (ulong)APS_Potion.NegativeEffect.Count)]); break;
/****/
					default: 
						break;
				}
				/******** POWER ********/
				m_Power=((double)(val2%1000))/1000.0;
				/******** Second EFFECT ********/
				if (IsDoubleEffect)
				{
					// We must find an effect that is DIFFERENT from the primary effect.
					// Moreover, if it is a positive effect, it should be a negative one (and inverse)
					bool otherEffectFound = false;
					switch (EffectCategory)
					{
						case 1: 
							for (int i=0;(!otherEffectFound && ( i < APS_Potion.NegativeEffect.Count ));i++)
							{
								m_SecondPotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.NegativeEffect[(int)(val4+(ulong)i) % APS_Potion.NegativeEffect.Count]);
								if ( m_SecondPotionEffect != m_PotionEffect)
									otherEffectFound = true;
							}
							break;
						case 0:
							otherEffectFound = false;
							break;
						case -1: 
							for (int i=0;(!otherEffectFound && ( i < APS_Potion.PositiveEffect.Count ));i++)
							{
								m_SecondPotionEffect=(APS_Potion.APS_PotionEffect)(APS_Potion.PositiveEffect[(int)(val4+(ulong)i) % APS_Potion.PositiveEffect.Count]);
								if ( m_SecondPotionEffect != m_PotionEffect)
									otherEffectFound = true;
							}
							break;
						default: 
							break;
					}
					if (!otherEffectFound)
						m_SecondPotionEffect = APS_Potion.APS_PotionEffect.NoEffect; // May occur, so let's deal with it.					
				} else {
					m_SecondPotionEffect = APS_Potion.APS_PotionEffect.NoEffect;
				}
				/******** Second POWER ********/
				if (IsDoubleEffect)
				{
					if (m_SecondPotionEffect != APS_Potion.APS_PotionEffect.NoEffect)
					{
						m_SecondPower=((double)(val5%1000))/1000.0;
						// A double effect has a drawback effect but it increases the main power 
						m_Power=m_Power*(1.0+m_SecondPower*APS_Mortier.APS_SecondPowerImpactOnMainPower);
					}
				}
				if ( phase == MoonPhase.FullMoon)
				{
					m_Power=m_Power*(1.0+APS_Mortier.APS_FullMoonEffectIncrease);
					m_SecondPower=m_SecondPower*(1.0+APS_Mortier.APS_FullMoonEffectIncrease);
				} else if ( phase == MoonPhase.NewMoon)
				{
					m_Power=m_Power*(1.0+APS_Mortier.APS_NewMoonEffectIncrease);
					m_SecondPower=m_SecondPower*(1.0+APS_Mortier.APS_NewMoonEffectIncrease);
				}
	/*************************************************************************************************************/
			}
		}

		public override void OnDoubleClick( Mobile from )
		{ if ( Utility.RandomDouble() < APS_Mortier.APS_ChanceToBreak )
			{
				from.SendMessage("Oups... ça s'est cassé...");
				Delete();
				return;
			}
		  from.SendMessage("Selectionnez quelquechose que vous voulez mettre dedans.");
		  from.Target = new InternalTarget( this ); }
		private class InternalTarget : Target
		{
			private APS_Melangeur m_thing;
			public InternalTarget( APS_Melangeur thing ) : base( -1, false, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( !( targeted is Item ) ) {
					from.SendMessage( "Il faut que ce soit un objet..." );
					return;					
				}
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else {
					m_thing.LikeDragDrop( from, (Item)targeted );
				}
			}
		}

		public void SelfClick( Mobile from )
		{
				if (ItemID == 6205) /*Empty*/
				{
					from.SendMessage("Il est déjà vide...");
				} else {
					from.SendMessage("Vous videz le melangeur...");
					ItemID = 6205;
					ReagentsCount=0;
					Bruleur=false;
					Enhanced=false;
					Formula = APS_Mortier.APS_EmptyFormula;
					Effects.PlaySound(from.Location, from.Map, 0x240);
				}
		}

		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}
		
		public bool LikeDragDrop( Mobile from, Item dropped )
		{
			int MaxReagents = APS_Mortier.APS_MaxNumberForOneReagent*APS_Mortier.APS_NumberOfReagents;
			if (Bruleur)
			{
				from.SendMessage("Le melange est raté de toute façon. Vous devriez le jeter...");	
			} else {
				if (dropped is APS_Erlenmeyer)
				{
					if (ReagentsCount + ((APS_Erlenmeyer)dropped).ReagentsCount > MaxReagents) /*Overdose...*/
					{
						from.SendMessage("Ca va deborder si vous mettez ca en plus...");	
					} else if (((APS_Erlenmeyer)dropped).ReagentsCount == 0) {
						from.SendMessage("Vous devriez mettre quelquechose dans l'erlenmeyer avant...");							
					} else {
						from.SendMessage("Vous melangez les solutions...");	
						Formula = APS_Mortier.AddToFormula(Formula,((APS_Erlenmeyer)dropped).Formula);
						ReagentsCount = ReagentsCount + ((APS_Erlenmeyer)dropped).ReagentsCount;
						((APS_Erlenmeyer)dropped).ReagentsCount = 0;
						((APS_Erlenmeyer)dropped).ItemID=6189;
						((APS_Erlenmeyer)dropped).Formula=APS_Mortier.APS_EmptyFormula;
						Effects.PlaySound(from.Location, from.Map, 0x240); 
						CheckResult(from);
					}
				} else if (dropped is APS_FioleAVide) {
					if (ReagentsCount + ((APS_FioleAVide)dropped).ReagentsCount > MaxReagents) /*Overdose...*/
					{
						from.SendMessage("Ca va deborder si vous mettez ca en plus...");	
					} else if (((APS_FioleAVide)dropped).ReagentsCount == 0) {
						from.SendMessage("Vous devriez mettre quelquechose dans l'erlenmeyer avant...");							
					} else {
						from.SendMessage("Vous melangez les solutions...");	
						Formula = APS_Mortier.AddToFormula(Formula,((APS_FioleAVide)dropped).Formula);
						ReagentsCount = ReagentsCount + ((APS_FioleAVide)dropped).ReagentsCount;
						((APS_FioleAVide)dropped).ReagentsCount = 0;
						((APS_FioleAVide)dropped).Formula=APS_Mortier.APS_EmptyFormula;
						if (((APS_FioleAVide)dropped).ItemID > 6197)
							((APS_FioleAVide)dropped).ItemID = 6197;
						else
							((APS_FioleAVide)dropped).ItemID = 6194;
						Effects.PlaySound(from.Location, from.Map, 0x240); 
						CheckResult(from);
					}
				} else {
						from.SendMessage("Non, ca ne marchera pas... Essayez plutôt de mettre le contenu d'un erlenmeyer ou d'une fiole a vide...");		
				}
			}
			return true;
		}
		
		[Constructable]

		public APS_Melangeur() : base( 6205 )
		{
			InitializeItemVaraiables();
		}

		public void InitializeItemVaraiables()
		{
			Name = "Un melangeur";
			ReagentsCount = 0;
			Bruleur = false;
			Enhanced = false;
			ComputedFormula=0;
			Formula = APS_Mortier.APS_EmptyFormula;
			Weight = 1.0;
		}
		
		public APS_Melangeur( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 	m_PotionItemID );
			writer.Write( (double)	m_SecondPower );
			writer.Write( (int) 	m_SecondPotionEffect );
			writer.Write( (double) 	m_Power );
			writer.Write( (int) 	m_PotionEffect );
			writer.Write( (int) 	m_FormulaMoonPhase);
			writer.Write( (bool) 	Enhanced );
			writer.Write( (bool) 	Bruleur );
			writer.Write( (ulong) 	ComputedFormula );
			writer.Write( (string)	Formula );
			writer.Write( (int) 	ReagentsCount );
			writer.Write( (int) 	0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			m_PotionItemID		 	= reader.ReadInt();
			m_SecondPower 			= reader.ReadDouble();
			m_SecondPotionEffect 	= (APS_Potion.APS_PotionEffect)(reader.ReadInt());
			m_Power 				= reader.ReadDouble();
			m_PotionEffect 			= (APS_Potion.APS_PotionEffect)(reader.ReadInt());
			m_FormulaMoonPhase		= (MoonPhase)reader.ReadInt();;
			Enhanced 				= reader.ReadBool();
			Bruleur 				= reader.ReadBool();
			ComputedFormula 		= reader.ReadULong();
			Formula 				= reader.ReadString();
			ReagentsCount 			= reader.ReadInt();
			int version 			= reader.ReadInt();
		}
	}
}