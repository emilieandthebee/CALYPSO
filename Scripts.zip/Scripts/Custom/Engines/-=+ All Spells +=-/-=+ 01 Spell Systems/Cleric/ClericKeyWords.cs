using System;
using Server;
using Server.Items;

namespace Server.Spells.Cleric
{
	public class ClericKeyWords : BrownBook
	{
		private int i_charges;

		[CommandProperty( AccessLevel.GameMaster )]
		public int Charges
		{
			get { return i_charges; }
			set { i_charges = value; InvalidateProperties(); }
		}

		[Constructable]
		public ClericKeyWords() : base( "Cleric Keywords", "Staff ", 24, false )

		{
		// NOTE: There are 8 lines per page and
		// approx 22 to 24 characters per line!
		//		0----+----1----+----2----+
		int cnt = 0;
			string[] lines;
			lines = new string[]
			{
				"This book is a quick",
				"list of the keywords",
				"used for setting spell",
				"hot keys. To use the",
				"keywords say [cs followed",
				"by the name of the sell",
				"ex: [cs AngelicFaith",
				"",
			};
			Pages[cnt++].Lines = lines;
		//		0----+----1----+----2----+
			lines = new string[]
			{
				"The other keywords are:",
				"",
				"AngelicFaith,",
				"BanishEvil,",
				"DampenSpirit,",
				"DivineFocus,",
				"HammerOfFaith,",
				"Purge,",
			};
			Pages[cnt++].Lines = lines;
		//		0----+----1----+----2----+
			lines = new string[]
			{
				"Restoration,",
				"SacredBoon,",
				"Sacrifice,",
				"Smite,",
				"TouchOfLife,",
				"TrialByFire,",
				"",
				"",
			};
			Pages[cnt++].Lines = lines;
		//		0----+----1----+----2----+
			lines = new string[]
			{
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
			};
			Pages[cnt++].Lines = lines;
			//		0----+----1----+----2----+
			lines = new string[]
			{
				"Warning:",
				"Book only has 5",
				"uses until its gone.",
				"",
				"",
				"",
			};
			Pages[cnt++].Lines = lines;
		Hue = Utility.RandomYellowHue();
		Charges = 5;
		}

		public override void GetProperties( ObjectPropertyList list )
		{
			base.GetProperties( list );

			list.Add( 1060658, "Uses Remaining \t{0}", this.Charges );
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( this.Charges < 1 )
				{
				from.SendMessage( "The magic of the book has run out and the book is ruined." );
				from.FixedParticles( 0x36BD, 20, 10, 5044, EffectLayer.Waist );
				Delete();
				from.PlaySound( 775);
				}
			from.Send( new BookHeader( from, this ) );
			from.Send( new BookPageDetails( this ) );
			this.Charges = this.Charges - 1;

		}

		public ClericKeyWords( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int)0 ); // version
			writer.Write( (int) i_charges );

		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			i_charges = reader.ReadInt();
		}

	}
}