using System;
using System.Collections;

namespace Server.Items
{
	
	public class Dictionary_int_string : DictionaryBase  {
	   public string this[ int key ]  { 
		get  { return( (string) Dictionary[key] ); }
		set  { Dictionary[key] = value; }
	   }
	   public ICollection Keys  					{ get  { return( Dictionary.Keys ); } }
	   public ICollection Values  					{ get  { return( Dictionary.Values ); } }
	   public void Add( int key, string value )  	{ Dictionary.Add( key, value ); }
	   public bool Contains( int key )  			{ return( Dictionary.Contains( key ) ); }
	   public void Remove( int key )  				{ Dictionary.Remove( key ); }
	   public bool ContainsKey ( int key ) {
		   bool found=false;
		   foreach ( object akey in Keys)
		   { if (key == (int)akey) {found=true; break; }}
		   return found;
	   }
	}

	public class Dictionary_int_Type : DictionaryBase  {
	   public Type this[ int key ]  { 
		get  { return( (Type) Dictionary[key] ); }
		set  { Dictionary[key] = value; }
	   }
	   public ICollection Keys  					{ get  { return( Dictionary.Keys ); } }
	   public ICollection Values  					{ get  { return( Dictionary.Values ); } }
	   public void Add( int key, Type value )  		{ Dictionary.Add( key, value ); }
	   public bool Contains( int key )  			{ return( Dictionary.Contains( key ) ); }
	   public void Remove( int key )  				{ Dictionary.Remove( key ); }
	   public bool ContainsKey ( int key ) {
		   bool found=false;
		   foreach ( object akey in Keys)
		   { if (key == (int)akey) {found=true; break; }}
		   return found;
	   }
	}

	public class Dictionary_Type_int : DictionaryBase  {
	   public int this[ Type key ]  { 
		get  { return( (int) Dictionary[key] ); }
		set  { Dictionary[key] = value; }
	   }

	   public ICollection Keys  					{ get  { return( Dictionary.Keys ); } }
	   public ICollection Values  					{ get  { return( Dictionary.Values ); } }
	   public void Add( Type key, int value )  		{ Dictionary.Add( key, value ); }
	   public bool Contains( Type key )  			{ return( Dictionary.Contains( key ) ); }
	   public void Remove( Type key )  				{ Dictionary.Remove( key ); }
	   public bool ContainsKey ( Type key ) {
		   bool found=false;
		   foreach ( object akey in Keys)
		   { if (key == (Type)akey) {found=true; break; }}
		   return found;
	   }
	}

}
