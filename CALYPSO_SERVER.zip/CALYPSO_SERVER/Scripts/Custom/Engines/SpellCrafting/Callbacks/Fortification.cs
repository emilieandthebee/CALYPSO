using System;
using Server;
using Server.Items;
using Server.SpellCrafting;

namespace Server.SpellCrafting.Crafts
{
	public class Fortification
	{
		private static readonly double MinSkill = 80.0;
		private static readonly double MaxSkill = 130.0;

		public static void Callback( Mobile from, object target )
		{
			if ( !(target is BaseArmor) )
			{
				from.SendMessage( "This craft cannot be placed on that item" );
			}
			else if ( !SpellCraft.CheckSpellCrafted( from, target ) )
			{
				return;
			}
			else
			{
				if ( !( from.CheckSkill( SkillName.Alchemy, MinSkill, MaxSkill ) || from.CheckSkill( SkillName.Inscribe, MinSkill, MaxSkill ) ) )
				{
					from.SendMessage( "You fail to apply the craft to the item and some materials were lost." );
				}
				else
				{
					((BaseArmor)target).ProtectionLevel = ArmorProtectionLevel.Fortification;
					((BaseArmor)target).Identified = true;
				}
			}
		}
	}
}