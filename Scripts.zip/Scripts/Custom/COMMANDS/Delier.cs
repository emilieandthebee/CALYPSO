using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class Delier
	{
		public static void Initialize()
		{
			Server.Commands.Register( "Delier", AccessLevel.Player, new CommandEventHandler( Delier_OnCommand ) );
		}

		[Usage( "Delier" )]
		[Description( "Pour que votre personnage essaie de se delier." )]
		private static void Delier_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)e.Mobile;
				if (pm.Ligote)
				if (pm.Alive)
				{
					if (pm.Stam<=5)
					{
						pm.SendMessage("Vous etes trop fatigue(e)...");
					}
					else 
					{
						pm.Stam=pm.Stam-Utility.Random(5);
						if (Utility.Random(1000) == 1)
						{
							pm.Emote("Delie ses liens");
							pm.Ligote=false;
						}
					}
				}
			}
		}
	}
}