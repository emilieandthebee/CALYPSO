using System; 
using Server;
using Server.Gumps;
using Server.Mobiles;

namespace Server.Items
{
	[Flipable( 0x9A8, 0xE80 )]
	public class MailBox : BaseContainer
	{
		private string newmail = "false";
		
		public override int DefaultGumpID{ get{ return 0x4B; } }
		public override int DefaultDropSound{ get{ return 0x42; } }

		public override Rectangle2D Bounds
		{
			get{ return new Rectangle2D( 16, 51, 168, 73 ); }
		}
			
		[CommandProperty( AccessLevel.GameMaster )]
		public string NewMail
		{
			get{ return newmail; }
			set{ newmail = value; }
		}

		[Constructable]
		public MailBox() : base( 0x9A8 )
		{
			Name= "Mailbox";
			Weight = 0.0;
			Movable = false;
		}

		public MailBox( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
	
			writer.Write( (int) 0 ); // version
				
			writer.Write( newmail );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
				
			newmail = reader.ReadString();
		}
	}
}
