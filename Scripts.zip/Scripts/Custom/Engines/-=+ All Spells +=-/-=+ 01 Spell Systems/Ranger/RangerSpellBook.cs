using System;
using Server.Spells;
using Server.Spells.Ranger;

namespace Server.Items
{
	public class RangerSpellbook : Spellbook
	{
		public override SpellbookType SpellbookType{ get{ return SpellbookType.Ranger; } }
		public override int BookOffset{ get{ return 900; } }
		public override int BookCount{ get{ return 7; } }

		public override Item Dupe( int amount )
		{
			Spellbook book = new RangerSpellbook();
			book.Content = this.Content;
			return base.Dupe( book, amount );
		}

		[Constructable]
		public RangerSpellbook() : this( (ulong)0 )
		{
		}

		[Constructable]
		public RangerSpellbook( ulong content ) : base( content, 0xEFA )
		{
			Hue = 2001;
			Name = "Ranger Survival Guide";
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel == AccessLevel.Player )
			{
				Container pack = from.Backpack;
				if( !(Parent == from || (pack != null && Parent == pack)) )
				{
					from.SendMessage( "The spellbook must be in your backpack [and not in a container within] to open." );
					return;
				}
				else if( UseRestrictions && !SpellRestrictions.CheckRestrictions( from, this ) )
				{
					return;
				}
			}

			from.CloseGump( typeof( RangerSpellbookGump ) );
			from.SendGump( new RangerSpellbookGump( from, this ) );
		}

		public RangerSpellbook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
