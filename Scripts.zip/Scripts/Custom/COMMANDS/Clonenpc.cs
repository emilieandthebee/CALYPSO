using System;
using Server.Mobiles;

namespace Server.Mobiles
{
	[CorpseName( " " )]
	public class Cloner : BaseCreature
	{

		[Constructable]
		public Cloner() : base( AIType.AI_Animal, FightMode.Agressor, 10, 1, 0.2, 0.4 )
		{
			Name = " ";
			Body = 0xD9;
		}
  
		public Cloner(Serial serial) : base(serial)
		{
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int) 0);
		}

		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
		}
	}
}
