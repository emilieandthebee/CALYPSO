using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class BloodPactScroll : SpellScroll
	{
		[Constructable]
		public BloodPactScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public BloodPactScroll( int amount ) : base( 125, 0x226F, amount )
		{
			Name = "Blood Pact";
			Hue = 0x44;
		}
		
		public BloodPactScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new BloodPactScroll( amount ), amount );
		}
	}
}
