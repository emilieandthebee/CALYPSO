using System;
using Server;
using System.Collections;
using Server.Mobiles;
using Server.Items;

namespace Server.Gumps
{
	public class EditSpawnGump : Gump
	{
		public string creatureType;
		public int spawnRange, walkRange, amount, minDelay, maxDelay;

		public bool bCreatureType, bSpawnRange, bWalkRange, bAmount, bMinDelay, bMaxDelay;

		public MegaSpawner megaSpawner;
		public bool AddToSpawner;
		public bool fromSpawnerList;
		public int index;

		public EditSpawnGump( Mobile mobile, bool fromspawnerlist, bool addToSpawner, int i, MegaSpawner megaspawner, string creaturetype, int spawnrange, int walkrange, int amountspawn, int mindelay, int maxdelay ) : base( 0,0 )
		{
			megaSpawner = megaspawner;
			AddToSpawner = addToSpawner;
			fromSpawnerList = fromspawnerlist;
			index = i;

			if ( !bCreatureType )
				creatureType = creaturetype;

			if ( !bSpawnRange )
				spawnRange = spawnrange;

			if ( !bWalkRange )
				walkRange = walkrange;

			if ( !bAmount )
				amount = amountspawn;

			if ( !bMinDelay )
				minDelay = mindelay;

			if ( !bMaxDelay )
				maxDelay = maxdelay;

			AddPage(0); // Page 0

			AddBackground( 80, 80, 600, 450, 0 );
			AddImageTiled( 80, 80, 600, 450, 2624 );
			AddAlphaRegion( 100, 100, 560, 350 );
			AddAlphaRegion( 100, 470, 560, 40 );
			AddImage( 30, 50, 10440);
			AddImage( 648, 50, 10441);

			if ( AddToSpawner )
				AddLabel( 140, 80, 60, "Add Creature" );
			else
				AddLabel( 140, 80, 60, "Editting Creature: " + creatureType );

			AddButton( 630, 490, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddPage(1); // Page 1

			AddLabel( 100, 100, 10, "Creature Type:" );
			AddImageTiled( 300, 100, 150, 18, 2604 );
			AddTextEntry( 300, 100, 150, 15, 1153, 0, creatureType );

			AddLabel( 100, 120, 10, "Spawn Range:" );
			AddImageTiled( 300, 120, 60, 18, 2604 );
			AddTextEntry( 300, 120, 60, 15, 1153, 1, spawnRange.ToString() );

			AddLabel( 100, 140, 10, "Walk Range:" );
			AddImageTiled( 300, 140, 60, 18, 2604 );
			AddTextEntry( 300, 140, 60, 15, 1153, 2, walkRange.ToString() );

			AddLabel( 100, 160, 10, "Amount To Spawn:" );
			AddImageTiled( 300, 160, 60, 18, 2604 );
			AddTextEntry( 300, 160, 60, 15, 1153, 3, amount.ToString() );

			AddLabel( 100, 180, 10, "Min Seconds To Next Spawn:" );
			AddImageTiled( 300, 180, 60, 18, 2604 );
			AddTextEntry( 300, 180, 60, 15, 1153, 4, minDelay.ToString() );

			AddLabel( 100, 200, 10, "Max Seconds To Next Spawn:" );
			AddImageTiled( 300, 200, 60, 18, 2604 );
			AddTextEntry( 300, 200, 60, 15, 1153, 5, maxDelay.ToString() );

			if ( !AddToSpawner )
			{
				AddLabel( 140, 470, 10, "Delete Entry" );
				AddButton( 100, 470, 9904, 9905, 2, GumpButtonType.Reply, 0 );
			}
			AddLabel( 140, 490, 10, "Submit Entry" );
			AddButton( 100, 490, 9904, 9905, 1, GumpButtonType.Reply, 0 );
		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( EditSpawnGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 1: // Submit Entry
				{
					bool invalid = false;

					bool fCreatureType=false, fSpawnRange=false, fWalkRange=false, fAmount=false, fMinDelay=false, fMaxDelay=false;

					string checkCreatureType, checkSpawnRange, checkWalkRange, checkAmount, checkMinDelay, checkMaxDelay;

					string stringCreatureType = null;
					int intSpawnRange=0, intWalkRange=0, intAmount=0, intMinDelay=0, intMaxDelay=0;
					
					TextRelay textInput = info.GetTextEntry( 0 );
					checkCreatureType = Convert.ToString( textInput.Text ).ToLower();

					textInput = info.GetTextEntry( 1 );
					checkSpawnRange = Convert.ToString( textInput.Text );

					textInput = info.GetTextEntry( 2 );
					checkWalkRange = Convert.ToString( textInput.Text );

					textInput = info.GetTextEntry( 3 );
					checkAmount = Convert.ToString( textInput.Text );

					textInput = info.GetTextEntry( 4 );
					checkMinDelay = Convert.ToString( textInput.Text );

					textInput = info.GetTextEntry( 5 );
					checkMaxDelay = Convert.ToString( textInput.Text );

// *************** First Check ***************

					stringCreatureType = Convert.ToString( ScriptCompiler.FindTypeByName( checkCreatureType ) );

					if ( stringCreatureType == "" )
					{
						invalid = true;
						bCreatureType = false;
						fCreatureType = true;
						mobile.SendMessage( "Invalid input for [Creature Type]. You must specify a valid creature type." );
					}

					if ( AddToSpawner )
					{
						for ( int i = 0; i < megaSpawner.CreatureList.Count; i++ )
						{
							if ( checkCreatureType == (string) megaSpawner.CreatureList[i] )
							{
								invalid = true;
								bCreatureType = false;
								fCreatureType = true;
								mobile.SendMessage( "Invalid input for [Creature Type]. That entry already exists! Please choose another creature." );
							}
						}
					}

					try{ intSpawnRange = Convert.ToInt32( checkSpawnRange ); }
					catch
					{
						invalid = true;
						bSpawnRange = false;
						fSpawnRange = true;
						mobile.SendMessage( "Invalid input for [Spawn Range]. You must specify an integer only." );
					}

					try{ intWalkRange = Convert.ToInt32( checkWalkRange ); }
					catch
					{
						invalid = true;
						bWalkRange = false;
						fWalkRange = true;
						mobile.SendMessage( "Invalid input for [Walk Range]. You must specify an integer only." );
					}

					try{ intAmount = Convert.ToInt32( checkAmount ); }
					catch
					{
						invalid = true;
						bAmount = false;
						fAmount = true;
						mobile.SendMessage( "Invalid input for [Amount To Spawn]. You must specify an integer only." );
					}

					try{ intMinDelay = Convert.ToInt32( checkMinDelay ); }
					catch
					{
						invalid = true;
						bMinDelay = false;
						fMinDelay = true;
						mobile.SendMessage( "Invalid input for [Min Seconds To Next Spawn]. You must specify an integer only." );
					}

					try{ intMaxDelay = Convert.ToInt32( checkMaxDelay ); }
					catch
					{
						invalid = true;
						bMaxDelay = false;
						fMaxDelay = true;
						mobile.SendMessage( "Invalid input for [Max Seconds To Next Spawn]. You must specify an integer only." );
					}

// *************** Second Check ***************

					if ( intSpawnRange < 0 && !fSpawnRange )
					{
						invalid = true;
						bSpawnRange = false;
						fSpawnRange = true;
						mobile.SendMessage( "Invalid input for [Spawn Range]. Must be greater than or equal to 0." );
					}

					if ( intWalkRange < 0 && !fWalkRange )
					{
						invalid = true;
						bWalkRange = false;
						fWalkRange = true;
						mobile.SendMessage( "Invalid input for [Walk Range]. Must be greater than or equal to 0." );
					}

					if ( intAmount <= 0 && !fAmount )
					{
						invalid = true;
						bAmount = false;
						fAmount = true;
						mobile.SendMessage( "Invalid input for [Amount]. Must be greater than 0." );
					}

					if ( ( intMinDelay < 0 || intMinDelay > intMaxDelay ) && !fMinDelay )
					{
						invalid = true;
						bMinDelay = false;
						fMinDelay = true;
						mobile.SendMessage( "Invalid input for [Min Seconds To Next Spawn]. Must be greater than or equal to 0 and less than [Max Seconds To Next Spawn]." );
					}

					if ( ( intMaxDelay < 0 || intMaxDelay < intMinDelay ) && !fMaxDelay )
					{
						invalid = true;
						bMaxDelay = false;
						fMaxDelay = true;
						mobile.SendMessage( "Invalid input for [Max Seconds To Next Spawn]. Must be greater than or equal to 0 and less than [Min Seconds To Next Spawn]." );
					}

// *************** Final Check ***************

					if ( invalid )
					{
						if ( !fCreatureType )
						{
							bCreatureType = true;
							creatureType = checkCreatureType;
						}

						if ( !fSpawnRange )
						{
							bSpawnRange = true;
							spawnRange = intSpawnRange;
						}

						if ( !fWalkRange )
						{
							bWalkRange = true;
							walkRange = intWalkRange;
						}

						if ( !fAmount )
						{
							bAmount = true;
							amount = intAmount;
						}

						if ( !fMinDelay )
						{
							bMinDelay = true;
							minDelay = intMinDelay;
						}

						if ( !fMaxDelay )
						{
							bMaxDelay = true;
							maxDelay = intMaxDelay;
						}

						mobile.CloseGump( typeof ( EditSpawnGump ) );
						mobile.SendGump( new EditSpawnGump( mobile, fromSpawnerList, AddToSpawner, index, megaSpawner, creatureType, spawnRange, walkRange, amount, minDelay, maxDelay ) );

						return;
					}

// *************** Applying Settings ***************

					creatureType = checkCreatureType;
					spawnRange = intSpawnRange;
					walkRange = intWalkRange;
					amount = intAmount;
					minDelay = intMinDelay;
					maxDelay = intMaxDelay;

					if ( AddToSpawner )
					{
						megaSpawner.CreatureList.Add( creatureType );
						megaSpawner.SpawnRangeList.Add( spawnRange );
						megaSpawner.WalkRangeList.Add( walkRange );
						megaSpawner.AmountList.Add( amount );
						megaSpawner.MinDelayList.Add( minDelay );
						megaSpawner.MaxDelayList.Add( maxDelay );
						megaSpawner.SpawnCounterList.Add( 0 );

						mobile.SendMessage( "Entry has been added." );
					}
					else
					{
						megaSpawner.DeleteCreatures( index );
						megaSpawner.CreatureList[index] = creatureType;
						megaSpawner.SpawnRangeList[index] = spawnRange;
						megaSpawner.WalkRangeList[index] = walkRange;
						megaSpawner.AmountList[index] = amount;
						megaSpawner.MinDelayList[index] = minDelay;
						megaSpawner.MaxDelayList[index] = maxDelay;
						megaSpawner.SpawnCounterList[index] = 0;

						mobile.SendMessage( "Entry has been updated." );
					}

					if ( megaSpawner.m_MegaSpawnerTimer != null && megaSpawner.Active )
					{
						if ( !megaSpawner.m_MegaSpawnerTimer.Running )
							megaSpawner.m_MegaSpawnerTimer.Start();
					}
					else if ( megaSpawner.m_MegaSpawnerTimer == null && megaSpawner.Active )
					{
						megaSpawner.m_MegaSpawnerTimer = new MegaSpawner.MegaSpawnerTimer( megaSpawner );
						megaSpawner.m_MegaSpawnerTimer.Start();
					}

					mobile.CloseGump( typeof ( EditSpawnGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
				case 2: // Delete Entry
				{
					mobile.CloseGump( typeof ( EditSpawnGump ) );
					mobile.SendGump( new ConfirmDeleteEntryGump( mobile, megaSpawner, fromSpawnerList, AddToSpawner, index, creatureType, spawnRange, walkRange, amount, minDelay, maxDelay ) );

					break;
				}
			}
		}
	}

	public class ConfirmDeleteEntryGump : Gump
	{
		public MegaSpawner megaSpawner;
		public bool fromSpawnerList = false;
		public bool AddToSpawner;
		public int index;

		public string creatureType;
		public int spawnRange, walkRange, amount, minDelay, maxDelay;

		public ConfirmDeleteEntryGump( Mobile mobile, MegaSpawner megaspawner, bool fromspawnerlist, bool addToSpawner, int i, string creaturetype, int spawnrange, int walkrange, int amountspawn, int mindelay, int maxdelay ) : base( 0,0 )
		{
			megaSpawner = megaspawner;
			AddToSpawner = addToSpawner;
			fromSpawnerList = fromspawnerlist;
			index = i;

			creatureType = creaturetype;
			spawnRange = spawnrange;
			walkRange = walkrange;
			amount = amountspawn;
			minDelay = mindelay;
			maxDelay = maxdelay;

			AddPage(0); // Page 0

			AddBackground( 180, 180, 320, 90, 0 );
			AddImageTiled( 180, 180, 320, 90, 2624 );
			AddAlphaRegion( 200, 200, 280, 20 );
			AddAlphaRegion( 200, 230, 280, 20 );
			AddLabel( 240, 180, 60, "Confirmation Of Spawner Wipe" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Are you sure you want to delete the entry?" );

			AddLabel( 440, 230, 10, "Cancel" );
			AddButton( 400, 230, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 230, 10, "Ok" );
			AddButton( 200, 230, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ConfirmSpawnerWipeGump ) );
					mobile.SendGump( new EditSpawnGump( mobile, fromSpawnerList, AddToSpawner, index, megaSpawner, creatureType, spawnRange, walkRange, amount, minDelay, maxDelay ) );

					mobile.SendMessage( "You have chosen not to delete the entry." );

					break;
				}
				case 1: // Delete Entry
				{
					megaSpawner.DeleteCreatures( index );
					megaSpawner.CreatureList.RemoveAt( index );
					megaSpawner.SpawnRangeList.RemoveAt( index );
					megaSpawner.WalkRangeList.RemoveAt( index );
					megaSpawner.AmountList.RemoveAt( index );
					megaSpawner.MinDelayList.RemoveAt( index );
					megaSpawner.MaxDelayList.RemoveAt( index );
					megaSpawner.SpawnCounterList.RemoveAt( index );

					mobile.SendMessage( "Entry has been removed." );

					mobile.CloseGump( typeof ( EditSpawnGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, fromSpawnerList ) );

					break;
				}
			}
		}
	}
}