using System;
using System.Text.RegularExpressions; 
using Server; 
using Server.Gumps; 
using Server.Network; 
using Server.Prompts; 
using Server.Targeting;
using Server.Mobiles; 

namespace Server.Scripts.Commands
{ 

   /// Function .tip, allowing a GM to notify something to a player 

   public class Forum_Command 
   { 

      /// Handler initialization 
 
      public static void Initialize() 
      { 
         Server.Commands.Register( "Forum", AccessLevel.Player, new CommandEventHandler( Forum_OnCommand ) ); 
      } 

      [Usage( "Forum" )] 
      [Description( "Donne acces au forum, wiki, site du jeu" )] 
      private static void Forum_OnCommand(CommandEventArgs e) 
      { 
		if (e.Mobile is PlayerMobile)
		{
			PlayerMobile pm = (PlayerMobile)e.Mobile;
			Accounting.Account acct = pm.Account as Accounting.Account;
			if ( (acct.TotalGameTime > TimeSpan.FromHours(1.0)) ||
			      pm.NotFirstTimeInquisiteurKill )
			{
				pm.LaunchBrowser( "http://s15.zetaboards.com/CALYPSO/index/" );
			}
			else {
				pm.SendGump( new InfoHtml("<CENTER>ACCESS AU FORUM EN ATTENTE</CENTER><BR<BR>Pour avoir acces au forum, ainsi qu'a la precieuse enceclopedie documentaire, il vous faut:<BR><BR>- soit avoir suffisament joue avce ce compte (au moins 1 heures du jeu)<BR><BR>- soit avoir v�cu une experience speciale (non, je n'en dirai pas plus!)<BR><BR>Bonne chance! :-)"));
			}
		}
      } 
   } 
}