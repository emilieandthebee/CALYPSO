using System;
using System.Collections;
using Server;

namespace Server
{
	public class EasyXmlRunUOAddon
	{
		public static void Configure()
		{
			EasyXml.ConverterInfo.Add( typeof( Item ), new EasyXml.ConvertToType( ConvertToItem ), new EasyXml.ConvertFromType( ConvertFromItem ), false );
			EasyXml.ConverterInfo.Add( typeof( Mobile ), new EasyXml.ConvertToType( ConvertToMobile ), new EasyXml.ConvertFromType( ConvertFromMobile ), false );
		}

		public static ArrayList ConvertToItem( string[] data )
		{
			ArrayList result = new ArrayList();

			foreach ( string s in data )
				result.Add( World.FindItem( (Serial)( Convert.ToInt32( s ) ) ) );

			return result;
		}

		public static string[] ConvertFromItem( Array array )
		{
			string[] result = new string[ array.Length ];

			for ( int i = 0; i < array.Length; ++i )
				result[i] = ((Item[])array)[i].Serial.Value.ToString();

			return result;
		}

		public static ArrayList ConvertToMobile( string[] data )
		{
			ArrayList result = new ArrayList();

			foreach ( string s in data )
				result.Add( World.FindMobile( (Serial)( Convert.ToInt32( s ) ) ) );

			return result;
		}

		public static string[] ConvertFromMobile( Array array )
		{
			string[] result = new string[ array.Length ];

			for ( int i = 0; i < array.Length; ++i )
				result[i] = ((Mobile[])array)[i].Serial.Value.ToString();

			return result;
		}
	}
}