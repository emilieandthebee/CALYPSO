/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using System.Collections;
/*2.0*
using System.Collections.Generic;
using Server.Commands;
*****/
using Server.Network;
using Server.Targeting;
using Server.Spells;
using Server.Misc;

namespace Server.Items
{
	public class APS_Potion : Item
	{	
		/////////////////////////////////////////////////////////////////////////////
		// This value is globaly added to all the other cooldawon duration
		private static TimeSpan CooldownGlobalDuration = TimeSpan.FromSeconds( 20.0 ); 
		/////////////////////////////////////////////////////////////////////////////
	
		public enum APS_PotionEffect
		{
			EmptyBottle,
			NoEffect,
			// RANDOM NEUTRL EFFECT 
			StrangeEffect,		// N
			// STATS MODIFIERS 		(Intelligence, Dexterity, Strength)
			Increase_Int,		// +
			Increase_Dex,		// +
			Increase_Str,		// +
			Decrease_Int,		// -
			Decrease_Dex,		// -
			Decrease_Str,		// -
			// CAPACITY MODIFIERS 	(Mana, Stamina, Hits)
			Refresh_Mana,		// +
			Refresh_Stam,		// +
			Refresh_Hits,		// +
			Use_Mana,			// -
			Use_Stam,			// -
			Use_Hits,			// -
			// POISONS and CURE
			Poison,				// -
			Cure,				// +
			// EXPLOSIONS
			Explode,			// N (Throwable)
			// CREATE A CREATURE
			StrangeSlime,		// N (Throwable)
			StrangeEssence,		// N (Throwable)
			StrangeEffusion,	// N (Throwable)
			// MISC
			Confusion,			// N (Throwable)
			Invisibility,		// + 
			NightSight,			// + 
			Levitate,			// + 
			Mute,				// -
			Paralyze,			// -
			Unfreeze,			// +
			Truth,				// -
			Love,				// -
			MAX_Unused
		} // Don't forget to add the effect in the right list in the Initialize() too...

/*2.0
		public static List<APS_PotionEffect> NeutralEffect;
		public static List<APS_PotionEffect> PositiveEffect;
		public static List<APS_PotionEffect> NegativeEffect;		
*1.0*/
		public static ArrayList NeutralEffect;
		public static ArrayList PositiveEffect;
		public static ArrayList NegativeEffect;		
/****/
		public static void Initialize()
		{
/*2.0
			NeutralEffect=new List<APS_PotionEffect>();
			PositiveEffect=new List<APS_PotionEffect>();
			NegativeEffect=new List<APS_PotionEffect>();
*1.0*/
			NeutralEffect=new ArrayList();
			PositiveEffect=new ArrayList();
			NegativeEffect=new ArrayList();
/****/
			/////////////////////////////////////////////////////////
			// Here you assign for each effect one of the 3 categories: Neutral, Positive and Negative
			NeutralEffect.Add(APS_PotionEffect.StrangeEffect);		// N
			PositiveEffect.Add(APS_PotionEffect.Increase_Int);		// +
			PositiveEffect.Add(APS_PotionEffect.Increase_Dex);		// +
			PositiveEffect.Add(APS_PotionEffect.Increase_Str);		// +
			NegativeEffect.Add(APS_PotionEffect.Decrease_Int);		// -
			NegativeEffect.Add(APS_PotionEffect.Decrease_Dex);		// -
			NegativeEffect.Add(APS_PotionEffect.Decrease_Str);		// -
			PositiveEffect.Add(APS_PotionEffect.Refresh_Mana);		// +
			PositiveEffect.Add(APS_PotionEffect.Refresh_Stam);		// +
			PositiveEffect.Add(APS_PotionEffect.Refresh_Hits);		// +
			NegativeEffect.Add(APS_PotionEffect.Use_Mana);			// -
			NegativeEffect.Add(APS_PotionEffect.Use_Stam);			// -
			NegativeEffect.Add(APS_PotionEffect.Use_Hits);			// -
			NegativeEffect.Add(APS_PotionEffect.Poison);			// -
			PositiveEffect.Add(APS_PotionEffect.Cure);				// +
			NeutralEffect.Add(APS_PotionEffect.Explode);			// N (Throwable)
			NeutralEffect.Add(APS_PotionEffect.StrangeSlime);		// N (Throwable)
			NeutralEffect.Add(APS_PotionEffect.StrangeEssence);		// N (Throwable)
			NeutralEffect.Add(APS_PotionEffect.StrangeEffusion);	// N (Throwable)
			NeutralEffect.Add(APS_PotionEffect.Confusion);			// N (Throwable)
			PositiveEffect.Add(APS_PotionEffect.Invisibility);		// + 
			PositiveEffect.Add(APS_PotionEffect.NightSight);		// + 
			PositiveEffect.Add(APS_PotionEffect.Levitate);			// + 
			NegativeEffect.Add(APS_PotionEffect.Mute);				// -
			NegativeEffect.Add(APS_PotionEffect.Paralyze);			// -
			NegativeEffect.Add(APS_PotionEffect.Unfreeze);			// +
			NegativeEffect.Add(APS_PotionEffect.Truth);				// -
			NegativeEffect.Add(APS_PotionEffect.Love);				// -
			/////////////////////////////////////////////////////////
		}

		private static CureLevelInfo[] VeryLowCureInfo = new CureLevelInfo[]
		{
				new CureLevelInfo( Poison.Lesser,  0.50 ), // 75% chance to cure lesser poison
				new CureLevelInfo( Poison.Regular, 0.15 ) // 50% chance to cure regular poison
		};		
		private static CureLevelInfo[] LowCureInfo = new CureLevelInfo[]
		{
				new CureLevelInfo( Poison.Lesser,  0.75 ), // 75% chance to cure lesser poison
				new CureLevelInfo( Poison.Regular, 0.50 ), // 50% chance to cure regular poison
				new CureLevelInfo( Poison.Greater, 0.15 )  // 15% chance to cure greater poison
		};
		private static CureLevelInfo[] MiddleCureInfo = new CureLevelInfo[]
		{
				new CureLevelInfo( Poison.Lesser,  1.00 ), // 100% chance to cure lesser poison
				new CureLevelInfo( Poison.Regular, 0.75 ), //  75% chance to cure regular poison
				new CureLevelInfo( Poison.Greater, 0.50 ), //  50% chance to cure greater poison
				new CureLevelInfo( Poison.Deadly,  0.15 )  //  15% chance to cure deadly poison
		};
		private static CureLevelInfo[] HighCureInfo = new CureLevelInfo[]
		{
				new CureLevelInfo( Poison.Lesser,  1.00 ), // 100% chance to cure lesser poison
				new CureLevelInfo( Poison.Regular, 1.00 ), // 100% chance to cure regular poison
				new CureLevelInfo( Poison.Greater, 0.75 ), // 100% chance to cure greater poison
				new CureLevelInfo( Poison.Deadly,  0.50 ), //  75% chance to cure deadly poison
				new CureLevelInfo( Poison.Lethal,  0.15 )  //  25% chance to cure lethal poison
		};
		private static CureLevelInfo[] VeryHighCureInfo = new CureLevelInfo[]
		{
				new CureLevelInfo( Poison.Lesser,  1.00 ), // 100% chance to cure lesser poison
				new CureLevelInfo( Poison.Regular, 1.00 ), // 100% chance to cure regular poison
				new CureLevelInfo( Poison.Greater, 1.00 ), // 100% chance to cure greater poison
				new CureLevelInfo( Poison.Deadly,  0.75 ), //  75% chance to cure deadly poison
				new CureLevelInfo( Poison.Lethal,  0.50 )  //  25% chance to cure lethal poison
		};
		
		public static double EmptyWeight = 0.1; 
		public static double FullWeight = 0.3; 
		public Timer m_Timer;
				
		public static bool IsThrowable(APS_PotionEffect effect)
		{
			bool result;
			switch(effect)
			{
			/////////////////////////////////////////////////////////
			// Here you say if a potion effect is a done by throwing the potion
				case APS_PotionEffect.Confusion:
				case APS_PotionEffect.Explode:
				case APS_PotionEffect.StrangeSlime:
				case APS_PotionEffect.StrangeEssence:
				case APS_PotionEffect.StrangeEffusion:
				case APS_PotionEffect.MAX_Unused:
			/////////////////////////////////////////////////////////
					result=true;
					break;
				default:
					result=false;
					break;
			}
			return result;
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual string CurrentFormula
		{
			get { return Formula; }
		}
		public string Formula;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int PotionItemID
		{
			get { return m_PotionItemID; }
			set { m_PotionItemID = value; }
		}
		int m_PotionItemID;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_PotionEffect PotionEffect
		{
			get { return m_PotionEffect; }
			set { m_PotionEffect = value; }
		}
		public APS_PotionEffect m_PotionEffect;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual double Power
		{
			get { return m_Power; }
			set { m_Power = value; }
		}
		public double m_Power;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_PotionEffect SecondPotionEffect
		{
			get { return m_SecondPotionEffect; }
			set { m_SecondPotionEffect = value; }
		}
		public APS_PotionEffect m_SecondPotionEffect;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual double SecondPower
		{
			get { return m_SecondPower; }
			set { m_SecondPower = value; }
		}
		public double m_SecondPower;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual bool IsEnhanced
		{
			get { return Enhanced; }
			set { Enhanced = value; }
		}
		public bool Enhanced;

		// PLAY DRINK EFFECT...
		public void PlayDrinkEffect( Mobile m )
		{
			m.RevealingAction();
			m.PlaySound( 0x2D6 );
			Empty();
			if ( m.Body.IsHuman && !m.Mounted )
				m.Animate( 34, 5, 1, true, false, 0 );
		}
		
		// FREE HANDS ???
		public bool HasFreeHand( Mobile m )
		{
			Item handOne = m.FindItemOnLayer( Layer.OneHanded );
			Item handTwo = m.FindItemOnLayer( Layer.TwoHanded );
/*
			if ( handTwo is BaseWeapon )
				handOne = handTwo;
			if ( handTwo is BaseRanged )
			{
				BaseRanged ranged = (BaseRanged) handTwo;
				if ( ranged.Balanced )
					return true;
			}	
*/
			return ( handOne == null || handTwo == null );
		}

		// WHAT IS HOLDING THIS?
		public virtual object FindParent( Mobile from )
		{
			Mobile m = this.HeldBy;

			if ( m != null && m.Holding == this )
				return m;

			object obj = this.RootParent;

			if ( obj != null )
				return obj;

			if ( Map == Map.Internal )
				return from;

			return this;
		}

		// DUPE THE POTION TO GET ONLY ONE
		public void GetOneIfStacked()
		{
			if (Amount > 1)
					{
						Container pack;
						if ( Parent is Container )
							pack = (Container)Parent;
						else if ( Parent is Mobile )
							pack = ( (Mobile)Parent ).Backpack;
						else
							pack = null;
//						APS_Potion RemainingPotions = new APS_Potion();
						APS_Potion RemainingPotions = (APS_Potion)(GetType().GetConstructor( Type.EmptyTypes ).Invoke( null ));
						Server.Scripts.Commands.Dupe.CopyProperties(RemainingPotions,this);
/*2.0*
						OnAfterDuped( RemainingPotions );
******/
						RemainingPotions.Parent = null;
						if ( pack != null )
							pack.DropItem( RemainingPotions );
						else
							RemainingPotions.MoveToWorld(Location,Map);
						RemainingPotions.InvalidateProperties();
						RemainingPotions.Amount = Amount - 1;
						Amount=1;
					}
		}
		
		// THE WEIGHT SHALL CHANGE ACOORDINGLY
		public new void OnAmountChange( int oldValue )
		{
			if ( m_PotionEffect == APS_PotionEffect.EmptyBottle)
				Weight = EmptyWeight * Amount;
			else
				Weight = FullWeight * Amount;				
		}

		// DOUBLE CLICK!
		public override void OnDoubleClick( Mobile from )
		{
			if ( !Movable )
				return;

			if ( from.Paralyzed || from.Frozen || (from.Spell != null && from.Spell.IsCasting) )
			{
				from.SendMessage("Vous ne pouvez utilisez cette fiole en ce moment.");
				return;
			}

			if ( from.InRange( this.GetWorldLocation(), 1 ) )
			{
				if (HasFreeHand(from))
				{
					GetOneIfStacked();
					if (m_PotionEffect == APS_PotionEffect.EmptyBottle)
					{
						// EMPTY BOTTLE: TRY TO FILL IT
						from.SendMessage("Selectionnez quelquechose que vous voulez mettre dedans.");
						from.Target = new InternalTarget( this );
					} else {
						if ( from.CanBeginAction( typeof( APS_Potion ) ) ) 
						{
							// Throw it, Drink it, or whatever...
							from.SendMessage("Sur quoi ou sur qui voulez-vous l'utiliser?");
							from.SendMessage("Sélectionnez cette meme potion si vous voulez vider la fiole.");
							from.Target = new InternalTarget( this );
						} else {
							from.SendMessage("L'effet de la precedente potion ne s'est pas entierement dissipee...");
							from.SendMessage("Vous decidez de ne pas l'utiliser.");
							from.SendMessage("(restriction de delai d'utilisation)");
						}			
					}
				}
				else
				{
					from.SendMessage("Vous devez avoir les mains vides pour utiliser cette potion.");
				}
			}
			else
			{
				from.SendMessage("Cette fiole est trop loin de vous pour pouvoir l'utiliser.");
			}
		}
		
		private class InternalTarget : Target
		{
			private APS_Potion m_thing;
			public InternalTarget( APS_Potion thing ) : base( -1, true, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted || m_thing.Map == Map.Internal )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				}
				from.RevealingAction();
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else if (targeted == from) {
					// Drink it
					m_thing.DrinkIt(from);
				} else {
					/******* Check if the player wants to launch it *******/
					bool isAFarPoint = true;
					IPoint3D p = targeted as IPoint3D;
					if ( p == null ) isAFarPoint=false;
					Map map = from.Map;
					if ( map == null ) isAFarPoint=false;
					if (isAFarPoint)
					{
						SpellHelper.GetSurfaceTop( ref p );	
						if( p is Mobile ) p = ((Mobile)targeted).Location;
						if( targeted is Item ) {
							if ((targeted is APS_Melangeur) || (targeted is APS_Tonnelet) || (targeted is APS_Potion))
									isAFarPoint = false;
							else
									p = ((Item)targeted).Location;;
						}
						if (from.InRange(p,1)) isAFarPoint = false;
					}
					if (isAFarPoint)
					{
						// Throw it away
						IEntity to;
						to = new Entity( Serial.Zero, new Point3D( p ), map );
						// PLAY THE THROW EFFECT
						Effects.SendMovingEffect( from, to, m_thing.ItemID & 0x3FFF, 7, 0, false, false, m_thing.Hue, 0 );
						// MAKE SURE THE POTION IS MOVED TO THE PLACE
						m_thing.Internalize();
						Timer.DelayCall( TimeSpan.FromSeconds(0.5),new TimerStateCallback(m_thing.Reposition_OnTick),new object[]{from,p,map});
						if (APS_Potion.IsThrowable(m_thing.PotionEffect))
							// COUNT DOWN IF THE EFFECT IS RIGHT
							m_thing.m_Timer=Timer.DelayCall(TimeSpan.FromSeconds(1.0),TimeSpan.FromSeconds(1.0),7,new TimerStateCallback( m_thing.Detonate_OnTick ),new object[]{from,3});
					} else if ((targeted is Mobile) && ( ((Mobile)targeted).Frozen ) && ( ((Mobile)targeted).Alive ) ) {
						// Give to drink to...
						from.SendMessage("Vous faites boire la potion à "+((Mobile)targeted).Name);
						((Mobile)targeted).SendMessage(from.Name+" vous fait boire une potion");
						m_thing.DrinkIt(((Mobile)targeted));
					} else if (targeted is Item) {
						// Apply to the item...
						m_thing.LikeDragDrop(from,(Item)targeted);
					}
				}
			}
		}
		
		// DRINT IT!
		public void DrinkIt(Mobile from)
		{
			// Throwable potions may not be drinken
			if (IsThrowable(m_PotionEffect))
			{
				from.SendMessage("Burp! Pas sure que cette potion soit faite pour etre bue...");
				// Undesirable effect of a throwable potion when drinken...
				if ( Utility.RandomDouble() < 0.5 )
				{
					PotionEffect=APS_PotionEffect.StrangeEffect;
					DoEffect(false, from);
				}				
			} else {
				// PRIMARY EFFECT
				DoEffect(false, from);
				if (!IsThrowable(m_SecondPotionEffect))
					// SECONDARY EFFECT
					DoEffect(true, from);
			}
			Empty();
			return;
		}

		// THROWN POTION SHALL EXPLODE OR WHATEVER...
		public void Explode( Mobile from )
		{
			// Throwable potions may not be drinken
			if (IsThrowable(m_PotionEffect))
			{
				DoEffect(false, from); // No secondary effect for a thrown potion
				Effects.PlaySound( Location, Map, 0x3E );
				Delete();
			} else {
				// Chance that the potion will not break
				if ( Utility.RandomDouble() < 0.5 )
				{
					from.SendMessage("La fiole se casse...");
					Effects.PlaySound( Location, Map, 0x3E );
					Delete();
				}
			}
			return;
		}

		// MOVE POTION ON THROWED TARGET
		// After showing the throwing effect of the potion, move it to the right location
		public void Reposition_OnTick( object state )
		{
			if ( Deleted )
				return;
			object[] states = (object[])state;
			Mobile from = (Mobile)states[0];
			IPoint3D p = (IPoint3D)states[1];
			Map map = (Map)states[2];
			Point3D loc = new Point3D( p );
			MoveToWorld( loc, map );
			// If this is not a throwable potion, there is no countdown. Do whatever...
			if (!(IsThrowable(m_PotionEffect)))
				Explode(from);
		}

		// THROWN POTION COUNT DOWN
		public void Detonate_OnTick( object state )
		{
			if ( Deleted )
				return;
			object[] states = (object[])state;
			Mobile from = (Mobile)states[0];
			int timer = (int)states[1];
			object parent = FindParent( from );
			if ( timer == 0 )
			{
				Point3D loc;
				Map map;
				if ( parent is Item )
				{
					Item item = (Item)parent;
					loc = item.GetWorldLocation();
					map = item.Map;
				}
				else if ( parent is Mobile )
				{
					Mobile m = (Mobile)parent;
					loc = m.Location;
					map = m.Map;
				}
				else
				{
					return;
				}
				Explode(from);
			}
			else
			{
				if ( parent is Item )
					((Item)parent).PublicOverheadMessage( MessageType.Regular, 0x22, false, timer.ToString() );
				else if ( parent is Mobile )
					((Mobile)parent).PublicOverheadMessage( MessageType.Regular, 0x22, false, timer.ToString() );
				states[1] = timer - 1;
			}
		}
		
		public void DoEffect(bool IsSecondEffect, Mobile from)
		{
			if ( Deleted )
				return;
			APS_PotionEffect effect;
			double power;
			if (IsSecondEffect) {
				effect = m_SecondPotionEffect;
				power  = m_SecondPower;
			} else {
				effect = m_PotionEffect;
				power  = m_Power;
			}
			TimeSpan Duration = TimeSpan.FromMinutes( 1.0 ); // DEFAULT PERIOD OF COOL DOWN
			switch(effect)
			{
				case APS_PotionEffect.EmptyBottle:
					break;
				case APS_PotionEffect.NoEffect:
					break;
				case APS_PotionEffect.StrangeEffect: {
						/********************** CONFIG *************************************************************/
						double TimeMinValue = 8.0;
						double TimeMaxValue = 120.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						double timing = power*10-((double)((int)power*10));
						if (timing<0.0) timing=-timing;
						while (timing>1.0) { timing=timing-1.0; }
						Duration 	= TimeSpan.FromSeconds( TimeMinValue + (timing*(TimeMaxValue-TimeMinValue)) );
						int Counter = (int)TimeMinValue +(int)(timing*((int)TimeMaxValue-(int)TimeMinValue));
						if (power < 0.1) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,1);
							from.SendMessage("Votre peau prend une étrange couleur...");
						} else if (power < 0.2) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,2);
							from.SendMessage("Vous vous sentez balonne(e)...");
						} else if (power < 0.3) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,3);
							from.SendMessage("Vous avez des nausee...");
						} else if (power < 0.4) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,4);
							from.SendMessage("Vous vous sentez deseoriente(e)...");
						} else if (power < 0.5) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,5);
							from.SendMessage("Vous cheveux tombent peu à peu...");
						} else if (power < 0.6) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,6);
							from.SendMessage("Vous avec comme des tiques verbaux...");
						} else if (power < 0.7) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,7);
							from.SendMessage("Vous ne pouvez vous empecher de lancer des insultes...");
						} else if (power < 0.8) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,8);
							from.SendMessage("Vous tremblez...");
						} else if (power < 0.9) {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,9);
							from.SendMessage("Vous avez la bougeotte...");
						} else {
							APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,10);
							from.SendMessage("Vous ne pouvez vous empecher de repeter a voix haute tout ce que vous entendez...");
						}
					} break;
				case APS_PotionEffect.Increase_Int: {
						/********************** CONFIG *************************************************************/
						int StatMinValue = 5; 	// Classical regular stat potion is 10
						int StatMaxValue = 15; 	// Classical greater stat potion is 20
						double TimeMinValue = 20.0; // Classical stat potion is 2.0 minutes
						double TimeMaxValue = 60.0; // Classical stat potion is 2.0 minutes
						////////////////////////////////////////////////////////////////////////////////////////////
						int StrOffset 		= 						StatMinValue +(int)(power*(StatMaxValue-StatMinValue));
						Duration 	= TimeSpan.FromSeconds( TimeMinValue +     (power*(TimeMaxValue-TimeMinValue)) );
						if ( Spells.SpellHelper.AddStatOffset( from, StatType.Int, StrOffset, Duration ) )
						{
							//from.FixedEffect( 0x375A, 10, 15 );
							from.PlaySound( 0x1E7 );
						}
					} break;
				case APS_PotionEffect.Increase_Dex: {
						/********************** CONFIG *************************************************************/
						int StatMinValue = 5; 	// Classical regular agility potion is 10
						int StatMaxValue = 20; 	// Classical greater agility potion is 20
						double TimeMinValue = 20.0; // Classical stat potion is 2.0 minutes
						double TimeMaxValue = 60.0; // Classical stat potion is 2.0 minutes
						////////////////////////////////////////////////////////////////////////////////////////////
						int StrOffset 		= 						StatMinValue +(int)(power*(StatMaxValue-StatMinValue));
						Duration 	= TimeSpan.FromSeconds( TimeMinValue +     (power*(TimeMaxValue-TimeMinValue)) );
						if ( Spells.SpellHelper.AddStatOffset( from, StatType.Dex, StrOffset, Duration ) )
						{
							//from.FixedEffect( 0x375A, 10, 15 );
							from.PlaySound( 0x1E7 );
						}
					} break;
				case APS_PotionEffect.Increase_Str: {
						/********************** CONFIG *************************************************************/
						int StatMinValue = 5; 	// Classical regular strength potion is 10
						int StatMaxValue = 20; 	// Classical greater strength potion is 20
						double TimeMinValue = 20.0; // Classical stat potion is 2.0 minutes
						double TimeMaxValue = 60.0; // Classical stat potion is 2.0 minutes
						////////////////////////////////////////////////////////////////////////////////////////////
						int StrOffset 		= 						StatMinValue +(int)(power*(StatMaxValue-StatMinValue));
						Duration 	= TimeSpan.FromSeconds( TimeMinValue +     (power*(TimeMaxValue-TimeMinValue)) );
						if ( Spells.SpellHelper.AddStatOffset( from, StatType.Str, StrOffset, Duration ) )
						{
							//from.FixedEffect( 0x375A, 10, 15 );
							from.PlaySound( 0x1E7 );
						}
					} break;
				case APS_PotionEffect.Decrease_Int: {
						/********************** CONFIG *************************************************************/
						int StatMinValue = 5; 	// Classical regular strength potion is 10
						int StatMaxValue = 20; 	// Classical greater strength potion is 20
						double TimeMinValue = 0.5; // Classical strength potion is 2.0 minutes
						double TimeMaxValue = 3.0; // Classical strength potion is 2.0 minutes
						////////////////////////////////////////////////////////////////////////////////////////////
						int StrOffset 		= 						StatMinValue +(int)(power*(StatMaxValue-StatMinValue));
						Duration 	= TimeSpan.FromMinutes( TimeMinValue +     (power*(TimeMaxValue-TimeMinValue)) );
						if ( Spells.SpellHelper.AddStatOffset( from, StatType.Int, -StrOffset, Duration  ))
						{
							//from.FixedEffect( 0x375A, 10, 15 );
							from.PlaySound( 1450 );
						}
					} break;
				case APS_PotionEffect.Decrease_Dex: {
						/********************** CONFIG *************************************************************/
						int StatMinValue = 5; 	// Classical regular stat potion is 10
						int StatMaxValue = 20; 	// Classical greater stat potion is 20
						double TimeMinValue = 0.5; // Classical stat potion is 2.0 minutes
						double TimeMaxValue = 3.0; // Classical stat potion is 2.0 minutes
						////////////////////////////////////////////////////////////////////////////////////////////
						int StrOffset 		= 						StatMinValue +(int)(power*(StatMaxValue-StatMinValue));
						Duration 	= TimeSpan.FromMinutes( TimeMinValue +     (power*(TimeMaxValue-TimeMinValue)) );
						if ( Spells.SpellHelper.AddStatOffset( from, StatType.Dex, -StrOffset, Duration  ) )
						{
							//from.FixedEffect( 0x375A, 10, 15 );
							from.PlaySound( 1450 );
						}
					} break;
				case APS_PotionEffect.Decrease_Str: {
						/********************** CONFIG *************************************************************/
						int StatMinValue = 5; 	// Classical regular stat potion is 10
						int StatMaxValue = 20; 	// Classical greater stat potion is 20
						double TimeMinValue = 0.5; // Classical stat potion is 2.0 minutes
						double TimeMaxValue = 3.0; // Classical stat potion is 2.0 minutes
						////////////////////////////////////////////////////////////////////////////////////////////
						int StrOffset 		= 						StatMinValue +(int)(power*(StatMaxValue-StatMinValue));
						Duration 	= TimeSpan.FromMinutes( TimeMinValue +     (power*(TimeMaxValue-TimeMinValue)) );
						if ( Spells.SpellHelper.AddStatOffset( from, StatType.Str, -StrOffset, Duration ))
						{
							//from.FixedEffect( 0x375A, 10, 15 );
							from.PlaySound( 1450 );
						}
					} break;
				case APS_PotionEffect.Refresh_Mana: {
						/********************** CONFIG *************************************************************/
						double PurcentMinValue = 0.1; // Classical refresh potion is 0.25 (25%)
						double PurcentMaxValue = 0.7; // Classical full refresh potion is 1.0 (100%)
						double TimeMinValue = 30.0;   // Classical refresh potion has no cool down
						double TimeMaxValue = 120.0;  // Classical refresh potion has no cool down
						////////////////////////////////////////////////////////////////////////////////////////////
						double Purcentage = PurcentMinValue + (power*(PurcentMaxValue-PurcentMinValue));
						Duration 	= TimeSpan.FromSeconds( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.Mana += (int)(Purcentage * from.ManaMax);
					} break;
				case APS_PotionEffect.Refresh_Stam: {
						/********************** CONFIG *************************************************************/
						double PurcentMinValue = 0.1; // Classical refresh potion is 0.25 (25%)
						double PurcentMaxValue = 1.0; // Classical full refresh potion is 1.0 (100%)
						double TimeMinValue = 20.0;   // Classical refresh potion has no cool down
						double TimeMaxValue = 50.0;   // Classical refresh potion has no cool down
						////////////////////////////////////////////////////////////////////////////////////////////
						double Purcentage = PurcentMinValue + (power*(PurcentMaxValue-PurcentMinValue));
						Duration 	= TimeSpan.FromSeconds( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.Stam += (int)(Purcentage * from.StamMax);
					} break;
				case APS_PotionEffect.Refresh_Hits: {
						/********************** CONFIG *************************************************************/
						int MinValueFrom = 3;  // Classical lesser heal potion is 3 (non AOS)
						int MinValueTo 	= 10; // Classical lesser heal potion is 10 (non AOS)
						int MaxValueFrom = 9;  // Classical lesser heal potion is 3 (non AOS)
						int MaxValueTo 	= 30; // Classical lesser heal potion is 10 (non AOS)
						double TimeMinValue = 20.0; // Classical heal potion is 10.0 seconds
						double TimeMaxValue = 50.0; // Classical heal potion is 10.0 seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int ValueFrom 	= MinValueFrom + (int)(power*(MaxValueFrom-MinValueFrom));
						int ValueTo 	= MinValueTo   + (int)(power*(MaxValueTo-MinValueTo));
						Duration 	= TimeSpan.FromSeconds( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						if ( from.Poisoned || MortalStrike.IsWounded( from ) )
						{
							from.SendMessage("Cette potion n'a pas d'effet etant donne votre etat...");
						} else {
							from.Heal( Utility.RandomMinMax( ValueFrom, ValueTo ) );
						}
					} break;
				case APS_PotionEffect.Use_Mana: {
						/********************** CONFIG *************************************************************/
						double MinValue = 0.5;
						double MaxValue = 0.95;
						double TimeMinValue = 0.5;
						double TimeMaxValue = 3.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						double 	 Value  	= MinValue +(power*(MaxValue-MinValue));
						Duration 	= TimeSpan.FromMinutes( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.Mana=(int)(from.Mana*(1.0-Value));
						from.PlaySound( 1450 );
					} break;
				case APS_PotionEffect.Use_Stam: {
						/********************** CONFIG *************************************************************/
						double MinValue = 0.5;
						double MaxValue = 0.95;
						double TimeMinValue = 0.5;
						double TimeMaxValue = 3.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						double 	 Value  	= MinValue +(power*(MaxValue-MinValue));
						Duration 	= TimeSpan.FromMinutes( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.Stam=(int)(from.Stam*(1.0-Value));
						from.PlaySound( 1450 );
					} break;
				case APS_PotionEffect.Use_Hits: {
						/********************** CONFIG *************************************************************/
						int MinValue = 5;
						int MaxValue = 50;
						double TimeMinValue = 0.5;
						double TimeMaxValue = 3.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						int 	 Value  	= MinValue +(int)(power*(MaxValue-MinValue));
						Duration 	= TimeSpan.FromMinutes( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.PlaySound( 1450 );
						from.Damage(Value);
					} break;
				case APS_PotionEffect.Poison: {
						/********************** CONFIG *************************************************************/
						Poison ThePoison;
						if      (power < 50.0)
							ThePoison = Poison.Lesser;
						else if (power < 70.0)
							ThePoison = Poison.Regular;
						else if (power < 90.0)
							ThePoison = Poison.Greater;
						else if (power < 98.0)
							ThePoison = Poison.Deadly;
						else
							ThePoison = Poison.Lethal;
						////////////////////////////////////////////////////////////////////////////////////////////
						from.ApplyPoison( from, ThePoison );
						from.PlaySound( 1450 );
					} break;
				case APS_PotionEffect.Cure: {
						bool cure = false;
						CureLevelInfo[] info;
						/********************** CONFIG *************************************************************/
						if (power < 40.0)
							info=VeryLowCureInfo;
						else if (power < 70.0)
							info=LowCureInfo;
						else if (power < 80.0)
							info=MiddleCureInfo;
						else if (power < 98.0)
							info=HighCureInfo;
						else
							info=VeryHighCureInfo;
						////////////////////////////////////////////////////////////////////////////////////////////
						for ( int i = 0; i < info.Length; ++i )
						{
							CureLevelInfo li = info[i];
							if ( li.Poison == from.Poison && li.Chance > Utility.RandomDouble() )
							{
								cure = true;
								break;
							}
						}
						if ( cure && from.CurePoison( from ) )
							from.SendLocalizedMessage( 500231 ); // You feel cured of poison!
						else if ( !cure )
							from.SendLocalizedMessage( 500232 ); // That potion was not strong enough to cure your ailment!
						from.FixedParticles( 0x373A, 10, 15, 5012, EffectLayer.Waist );
						from.PlaySound( 0x1E0 );
					} break;
				case APS_PotionEffect.Explode: {
						/********************** CONFIG *************************************************************/
						int MinDamageFrom = 2; 	// Classical lesser explosion potion is 5 (no AOS)
						int MinDamageTo = 5; 	// Classical lesser explosion potion is 10(no AOS)
						int MaxDamageFrom = 30; // Classical lesser explosion potion is 15(no AOS)
						int MaxDamageTo = 50; 	// Classical lesser explosion potion is 30(no AOS)
						////////////////////////////////////////////////////////////////////////////////////////////
						int DamageFrom 	= MinDamageFrom +(int)(power*(MaxDamageFrom-MinDamageFrom));
						int DamageTo 	= MinDamageFrom +(int)(power*(MaxDamageTo-MinDamageTo));
						bool LeveledExplosion = false; 	// Should explosion potions explode other nearby potions?
						int  ExplosionRange   = 2; 		// How long is the blast radius?
						if ( Map == null )
							return;
						Effects.PlaySound(Location, Map, 0x305 + Utility.Random(0,4));
						Effects.SendLocationEffect(Location, Map, 0x36B0, 9, 10, 0, 0);
						IPooledEnumerable eable = LeveledExplosion ? Map.GetObjectsInRange( Location, ExplosionRange ) : Map.GetMobilesInRange( Location, ExplosionRange );
						ArrayList toExplode = new ArrayList();
						int toDamage = 0;
						foreach ( object o in eable )
						{
							if ( o is Mobile && (from == null || (SpellHelper.ValidIndirectTarget( from, (Mobile)o ) && from.CanBeHarmful( (Mobile)o, false ))))
							{
								toExplode.Add( o );
								++toDamage;
							} else if ( o is APS_Potion && o != this ) {
								toExplode.Add( o );
							}
						}
						eable.Free();
						for ( int i = 0; i < toExplode.Count; ++i )
						{
							object o = toExplode[i];
							if ( o is Mobile )
							{
								Mobile m = (Mobile)o;
								if ( from != null )
									from.DoHarmful( m );
								int damage = Utility.RandomMinMax( DamageFrom, DamageTo );
								AOS.Damage( m, from, damage, 0, 100, 0, 0, 0 );
							}
							else if ( o is APS_Potion )
							{
								APS_Potion pot = (APS_Potion)o;
								if (pot.PotionEffect == APS_PotionEffect.Explode)
									pot.Explode(from);
							}
						}
					} break;
				case APS_PotionEffect.StrangeSlime: {
						/********************** CONFIG *************************************************************/
						double TimeMinValue = 0.5;
						double TimeMaxValue = 3.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						Duration 	= TimeSpan.FromMinutes( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.SendMessage("Le liquide visqueux semble se mouvoir dangereusement!");
						APS_StrangeSlime creature = new APS_StrangeSlime();
						Point3D p = new Point3D( Location );
						BaseCreature.Summon( creature, false, from, p, 456, Duration );
					} break;
				case APS_PotionEffect.StrangeEssence: {
						/********************** CONFIG *************************************************************/
						double TimeMinValue = 0.5;
						double TimeMaxValue = 3.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						Duration 	= TimeSpan.FromMinutes( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.SendMessage("Cette... chose globuleuse... semble etre dangereuse... ");
						APS_StrangeEssence creature = new APS_StrangeEssence();
						Point3D p = new Point3D( Location );
						BaseCreature.Summon( creature, false, from, p, 456, Duration );
					} break;
				case APS_PotionEffect.StrangeEffusion: {
						/********************** CONFIG *************************************************************/
						double TimeMinValue = 0.5;
						double TimeMaxValue = 3.0;
						////////////////////////////////////////////////////////////////////////////////////////////
						Duration 	= TimeSpan.FromMinutes( TimeMinValue + (power*(TimeMaxValue-TimeMinValue)) );
						from.SendMessage("Ce gaz imprédictible semble etre attire par des formes vivantes!");
						APS_StrangeEffusion creature = new APS_StrangeEffusion();
						Point3D p = new Point3D( Location );
						BaseCreature.Summon( creature, false, from, p, 456, Duration );
					} break;
				case APS_PotionEffect.Confusion: {
						/********************** CONFIG *************************************************************/
						double MinTimeValue = 10.0; 	// Classical confusion potion is 5.0
						double MaxTimeValue = 20.0; // Classical confusion potion is 5.0
						////////////////////////////////////////////////////////////////////////////////////////////
						TimeSpan PacifyDuration = TimeSpan.FromSeconds( MinTimeValue + (power*(MaxTimeValue-MinTimeValue)) );
						Duration = TimeSpan.FromSeconds( (MinTimeValue + (power*(MaxTimeValue-MinTimeValue)))*5 ) ;
						Effects.PlaySound( Location, Map, 0x207 );
/*2.0*
						Geometry.Circle2D( Location, Map, 6, new DoEffect_Callback( BlastEffect ), 270, 90 );
						Timer.DelayCall( TimeSpan.FromSeconds( 0.3 ), new TimerStateCallback( CircleEffect2 ), new object[] { Location, Map } );
******/
						Effects.SendLocationEffect( Location, Map, 0x376A, 4, 9 );
						foreach ( Mobile mobile in Map.GetMobilesInRange( Location, 6 ) )
						{
							mobile.Combatant = null;
							mobile.Warmode = false;
							if ( mobile is BaseCreature )
							{
								BaseCreature mon = (BaseCreature) mobile;
								mon.Pacify( from, DateTime.Now + Duration );
							}
						}
					} break;
				case APS_PotionEffect.Invisibility: {
						/********************** CONFIG *************************************************************/
						int MinTime = 2;  // in seconds
						int MaxTime = 60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.Hidden = true;
						from.Combatant = null;
						from.Warmode = false;
						from.PlaySound(552);
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.NightSight: { 
						/********************** CONFIG *************************************************************/
						int MinTime = 5;  	// in seconds
						int MaxTime = 3*60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						int level = LightCycle.DungeonLevel;
						if ( level < 0 )
							level = 0;
						from.PlaySound(1454);
						from.LightLevel = level;
						from.FixedParticles( 0x376A, 9, 32, 5007, EffectLayer.Waist );
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.Levitate: {
						/********************** CONFIG *************************************************************/
						int MinTime = 5;  	// in seconds
						int MaxTime = 3*60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						if (from is PlayerMobile) ((PlayerMobile)from).Flying=true;
						from.PlaySound(1479);
						from.SendMessage("Woaw... C'est cool... Vous levitez!...");
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.Mute: {
						/********************** CONFIG *************************************************************/
						int MinTime = 5;  	// in seconds
						int MaxTime = 3*60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.Squelched=true;
						from.PlaySound(1453);
						from.SendMessage("Vous ne pouvez plus parler...");
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.Paralyze: {
						/********************** CONFIG *************************************************************/
						int MinTime = 5;  	// in seconds
						int MaxTime = 3*60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.Frozen=true;
						from.PlaySound(516);
						from.SendMessage("Vous etes paralyse(e)...");
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.Unfreeze: {
						/********************** CONFIG *************************************************************/
						int MinTime = 3;  	// in seconds
						int MaxTime = 30; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.PlaySound(1452);
						if (from.Frozen)
							from.SendMessage("Vos doigts commencent à bouger...");
						else
							from.SendMessage("Cet potion a un effet... Mais lequel est-il?...");
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.Truth: {
						/********************** CONFIG *************************************************************/
						int MinTime = 5;  	// in seconds
						int MaxTime = 3*60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.PlaySound(1471);
						from.SendMessage("Vous etes sous l'effet d'une potion de verite:");
						from.SendMessage("Vous ne pouvez mentir!... (ceci est votre 'roleplay'");
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.Love: {
						/********************** CONFIG *************************************************************/
						int MinTime = 5;  	// in seconds
						int MaxTime = 3*60; // in seconds
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = MinTime +(int)(power*(MaxTime-MinTime));
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.SendMessage("Quelquechose se passe en vous... Comme si...");
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				case APS_PotionEffect.MAX_Unused: {
						/********************** CONFIG *************************************************************/
						////////////////////////////////////////////////////////////////////////////////////////////
						int Counter = 5*60;
						Duration 	= TimeSpan.FromSeconds( (double)Counter );
						from.SendMessage("Quelquechose de noir se forme, vous etes aspire(e) vers la source...");
						from.MoveToWorld(Location,Map);
						Effects.PlaySound(Location, Map, 1111);
						APS_DurationActionStone item = new APS_DurationActionStone(from,effect,Counter,0);
					} break;
				default:
					  break;
			}
			Duration = Duration + CooldownGlobalDuration;
			if (!IsSecondEffect) if (from.BeginAction( typeof( APS_Potion ) )) Timer.DelayCall( Duration, new TimerStateCallback( ReleaseLock ), from );
		}

		public static void ReleaseLock( object state )
		{
			((Mobile)state).EndAction( typeof( APS_Potion ) );
			((Mobile)state).SendMessage("=== Fin d'effet de potion ===");
		}

		public void SelfClick( Mobile from )
		{
			if (ItemID == 3854) /*Empty*/
			{
				from.SendMessage("Elle est déjà vide...");
			} else {
				from.SendMessage("Vous videz la fiole...");
				Effects.PlaySound(from.Location, from.Map, 0x240);
				Empty();
			}			
		}

		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}

		public bool LikeDragDrop( Mobile from, Item dropped )
		{
				if (dropped.Amount > 1)
				{
					from.SendMessage("Il y a {0} elements de la cible, il n'en faut qu'un...",dropped.Amount);
					return false;
				}
				GetOneIfStacked();
				if (dropped is APS_Melangeur) {
					APS_Melangeur melangeur = ((APS_Melangeur)dropped);
					if (m_PotionEffect != APS_PotionEffect.EmptyBottle) /*Not Empty*/
					{
						from.SendMessage("Il y a déjà quelquechose dans cette fiole...");	
					} else if (melangeur.ItemID == 6205) {
						from.SendMessage("Ce mmélangeur est vide...");	
					} else {
						from.SendMessage("Vous remplissez la fiole...");	
						Weight 				= FullWeight;
						Name 				= "Une fiole pleine";
						Formula 			= melangeur.Formula;
						Enhanced 			= melangeur.Enhanced;
						PotionItemID 		= melangeur.PotionItemID;
						if (ItemID == 3854)
							ItemID 				= melangeur.PotionItemID;
						PotionEffect		= melangeur.PotionEffect;
						Power 				= melangeur.Power;
						SecondPotionEffect	= melangeur.SecondPotionEffect;
						SecondPower 		= melangeur.SecondPower;
						melangeur.ItemID 		= 6205;
						melangeur.ReagentsCount	= 0;
						melangeur.Bruleur		= false;
						melangeur.Enhanced		= false;
						melangeur.Formula 		= APS_Mortier.APS_EmptyFormula;
						Effects.PlaySound(from.Location, from.Map, 0x240);
					}
				} else if (dropped is APS_Tonnelet) {
					APS_Tonnelet tonnelet = ((APS_Tonnelet)dropped);
					if (m_PotionEffect != APS_PotionEffect.EmptyBottle) {
						from.SendMessage("Il y a déjà quelquechose dans cette fiole...");	
					} else if (tonnelet.Quantity <= 0) {
						from.SendMessage("Ce tonnelet est vide...");				
					} else{							
						from.SendMessage("Vous remplissez la fiole...");	
						Weight = FullWeight;
						Name = "Une fiole pleine";
						PotionItemID 		= tonnelet.PotionItemID;
						if (ItemID == 3854)
							ItemID = tonnelet.PotionItemID;
						Formula 			= tonnelet.Formula;
						PotionEffect 		= tonnelet.PotionEffect;
						Power 				= tonnelet.Power;
						SecondPotionEffect	= tonnelet.SecondPotionEffect;
						SecondPower 		= tonnelet.SecondPower;
						Enhanced 			= tonnelet.Enhanced;
						tonnelet.Quantity	= tonnelet.Quantity - 1;
						tonnelet.Weight = 10.0+tonnelet.Quantity*(APS_Potion.FullWeight-APS_Potion.EmptyWeight);
						Effects.PlaySound(from.Location, from.Map, 0x240);
					}
				} else if (dropped is APS_Potion) {
					APS_Potion potion = ((APS_Potion)dropped);
					if (m_PotionEffect != APS_PotionEffect.EmptyBottle) {
						from.SendMessage("Il y a déjà quelquechose dans cette fiole...");
					} else if (potion.PotionEffect == APS_PotionEffect.EmptyBottle) {
						from.SendMessage("La fiole que vous avez choisie est vide...");	
					} else {
						from.SendMessage("Vous remplissez la fiole...");	
						Weight = FullWeight;
						Name = "Une fiole pleine";
						if (ItemID == 3854)
							ItemID = potion.PotionItemID;
						PotionItemID 		= potion.PotionItemID;
						Formula 			= potion.Formula;
						PotionEffect 		= potion.PotionEffect;
						Power 				= potion.Power;
						SecondPotionEffect	= potion.SecondPotionEffect;
						SecondPower 		= potion.SecondPower;
						Enhanced 			= potion.Enhanced;
						potion.Empty();
						Effects.PlaySound(from.Location, from.Map, 0x240);
					}
				} else {
						from.SendMessage("Non, ca ne marchera pas... Essayez plutôt de mettre le contenu d'un mélangeur ou d'un tonnelet..");
				}
			return true;
		}

		#region Effects
		public virtual void BlastEffect( Point3D p, Map map )
		{
			if ( map.CanFit( p, 12, true, false ) )
				Effects.SendLocationEffect( p, map, 0x376A, 4, 9 );
		}
		
		public void CircleEffect2( object state )
		{
			object[] states = (object[]) state;
			/*2.0*
			Geometry.Circle2D( (Point3D)states[0], (Map)states[1], 6, new DoEffect_Callback( BlastEffect ), 90, 270 );
			******/
		}
		#endregion

		public void Empty()
		{
				if (( ( ItemID >= 3846 ) && ( ItemID < 3854 ) ) || ( ItemID == 11057 ) || ( ItemID == 11059 ) )
					ItemID=3854;
				m_PotionEffect=APS_PotionEffect.EmptyBottle;
				Formula = APS_Mortier.APS_EmptyFormula;
				Weight=Amount*EmptyWeight;
				Name="Une fiole vide";
				Enhanced=false;
		}
		
		[Constructable]
		public APS_Potion() : base( 3854 )
		{
			InitializeItemVaraiables();
		}
		
		public void InitializeItemVaraiables()
		{
			Weight 			= EmptyWeight;
			Name 			= "Une fiole vide";
			Enhanced 		= false;
			Formula 		= APS_Mortier.APS_EmptyFormula;
			m_PotionEffect	= APS_PotionEffect.EmptyBottle;
			Stackable 		= true;
		}
		
		public APS_Potion( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 	m_PotionItemID );
			writer.Write( (string) 	Formula );
			writer.Write( (bool) 	Enhanced );
			writer.Write( (double)	m_SecondPower );
			writer.Write( (int) 	m_SecondPotionEffect );
			writer.Write( (double) 	m_Power );
			writer.Write( (int) 	m_PotionEffect );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			m_PotionItemID		 	= reader.ReadInt();
			Formula 				= reader.ReadString();
			Enhanced 				= reader.ReadBool();
			m_SecondPower 			= reader.ReadDouble();
			m_SecondPotionEffect 	= (APS_PotionEffect)(reader.ReadInt());
			m_Power 				= reader.ReadDouble();
			m_PotionEffect 			= (APS_PotionEffect)(reader.ReadInt());
			int version = reader.ReadInt();
		}
	}
}