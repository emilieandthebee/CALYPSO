using System;
using Server;
using Server.Items;
using Server.SpellCrafting;

namespace Server.SpellCrafting.Crafts
{
	public class AttackChance
	{
		private static readonly int Minimum = 1;
		private static readonly int Maximum = 15;

		public static void Callback( Mobile from, object target )
		{
			if ( !(target is BaseWeapon || target is BaseJewel || (target is BaseArmor && target is BaseShield) ) )
			{
				from.SendMessage( "This craft cannot be placed on that item" );
			}
			else if ( !SpellCraft.CheckSpellCrafted( from, target ) )
			{
				return;
			}
			else
			{
				int scalar = (int)( (from.Skills[SkillName.Inscribe].Value + from.Skills[SkillName.Alchemy].Value) / 200.0 );

				if ( target is BaseArmor )
					ApplyProp( (BaseArmor)target, scalar );

				else if ( target is BaseJewel )
					ApplyProp( (BaseJewel)target, scalar );

				else if ( target is BaseWeapon )
					ApplyProp( (BaseWeapon)target, scalar );
			}
		}

		private static void ApplyProp( BaseArmor item, int scalar )
		{
			SpellCraft.ApplyAttribute( item.Attributes, 20 * scalar, 100 * scalar, AosAttribute.AttackChance, Minimum, Maximum );
		}

		private static void ApplyProp( BaseWeapon item, int scalar )
		{
			SpellCraft.ApplyAttribute( item.Attributes, 20 * scalar, 100 * scalar, AosAttribute.AttackChance, Minimum, Maximum );
		}

		private static void ApplyProp( BaseJewel item, int scalar )
		{
			SpellCraft.ApplyAttribute( item.Attributes, 20 * scalar, 100 * scalar, AosAttribute.AttackChance, Minimum, Maximum );
		}
	}
}