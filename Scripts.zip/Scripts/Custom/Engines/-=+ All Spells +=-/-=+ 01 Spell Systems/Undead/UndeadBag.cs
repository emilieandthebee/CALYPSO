using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class UndeadBag : Bag
	{
		[Constructable]
		public UndeadBag()
		{
			PlaceItemIn( 30, 35, new BloodPactScroll() );
			PlaceItemIn( 50, 35, new CurePoisonScroll() );
			PlaceItemIn( 70, 35, new GraveyardGatewayScroll() );
			PlaceItemIn( 90, 35, new HordeMinionsEyesScroll() );
			PlaceItemIn( 30, 55, new NecroMassCurseScroll() );
			PlaceItemIn( 50, 55, new MisfitsOfMondainScroll() );
			PlaceItemIn( 70, 55, new NecroPoisonFieldScroll() );
			//PlaceItemIn( 90, 55, new PoisonIvyPatchScroll() );
			PlaceItemIn( 30, 75, new PoisonMarkScroll() );
			PlaceItemIn( 50, 75, new NecroPoisonScroll() );
			PlaceItemIn( 70, 75, new RevivalBySeanceScroll() );
			PlaceItemIn( 90, 75, new TravelByPoisonScroll() );
			PlaceItemIn( 30, 95, new WallOfSpikesScroll() );
		}

		private void PlaceItemIn( int x, int y, Item item )
		{
			AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public UndeadBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}