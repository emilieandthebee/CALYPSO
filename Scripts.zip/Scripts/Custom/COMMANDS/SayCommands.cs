using System;
using Server;
using Server.Network;
using Server.Targeting;
using Server.Mobiles;
using Server.Items;

namespace Server.Scripts.Commands
{
	public class CustomCmdHandlers
	{
		public static void Initialize()
		{
			Register( "Say", AccessLevel.GameMaster, new CommandEventHandler( Say_OnCommand ) );
		}

		public static void Register( string command, AccessLevel access, CommandEventHandler handler )
		{
			Server.Commands.Register( command, access, handler );
		}
		

		[Usage( "Say <text>" )]
		[Description( "Forces Targeted Mobile or Item to Say <text>." )]
		public static void Say_OnCommand( CommandEventArgs e )
		{
			string toSay = e.ArgString.Trim();

			if ( toSay.Length > 0 )
				e.Mobile.Target = new SayTarget( toSay );
			else
				e.Mobile.SendMessage( "Format: Say \"<text>\"" );
		}

		private class SayTarget : Target
		{
			private string m_toSay;

			public SayTarget( string say ) : base( -1, true, TargetFlags.None )
			{
				m_toSay = say;
			}

			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( targeted is Mobile )
				{
					Mobile targ = (Mobile)targeted;

					if ( from != targ && from.AccessLevel > targ.AccessLevel )
					{
						CommandLogging.WriteLine( from, "{0} {1} forcing speech on {2}", from.AccessLevel, CommandLogging.Format( from ), CommandLogging.Format( targ ) );
						targ.Say( m_toSay );
					}
				}
				else if ( targeted is Item )
				{
					Item targ = (Item)targeted;
					targ.PublicOverheadMessage( MessageType.Regular, Utility.RandomDyedHue(), false, m_toSay);
				}
				else if ( targeted is IPoint3D )
				{
					Item targ = new Blood();
					targ.ItemID = 0xEED;
					targ.Hue = 777;
					targ.MoveToWorld (new Point3D((IPoint3D)targeted),from.Map);
					targ.PublicOverheadMessage( MessageType.Regular, Utility.RandomDyedHue(), false, m_toSay);
				}
				else 
					from.SendMessage( "Invaild Target Type" );
			}
		}
	}
}