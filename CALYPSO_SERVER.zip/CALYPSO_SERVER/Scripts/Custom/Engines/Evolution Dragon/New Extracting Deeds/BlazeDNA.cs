using System; 
using Server.Items; 

namespace Server.Items 
{ 
   	public class BlazeDNA: Item 
   	{ 
		[Constructable]
		public BlazeDNA() : this( 1 )
		{
		}

		[Constructable]
		public BlazeDNA( int amount ) : base( 0x0F91 )
		{
			Stackable = true;
			Weight = 0.0;
			Amount = amount;
			Name = "Blaze DNA";
			Hue = 1161;
		}

            	public BlazeDNA( Serial serial ) : base ( serial ) 
            	{             
           	} 

		public override Item Dupe( int amount )
		{
			return base.Dupe( new BlazeDNA( amount ), amount );
		}

           	public override void Serialize( GenericWriter writer ) 
           	{ 
              		base.Serialize( writer ); 
              		writer.Write( (int) 0 ); 
           	} 
            
           	public override void Deserialize( GenericReader reader ) 
           	{ 
              		base.Deserialize( reader ); 
              		int version = reader.ReadInt(); 
           	} 
        } 
} 