using System;
using Server;
using Server.Network;
using Server.Items;

namespace Server.Spells.Song
{
   public abstract class Song : Spell
   {
	  public abstract double CastDelay{ get; }
      public abstract double RequiredSkill{ get; }
      public abstract int RequiredMana{ get; }

      public override SkillName CastSkill{ get{ return SkillName.Musicianship; } }
      public override SkillName DamageSkill{ get{ return SkillName.Musicianship; } }

      public override bool ClearHandsOnCast{ get{ return false; } }

      public Song( Mobile caster, Item scroll, SpellInfo info ) : base( caster, scroll, info )
      {
      }

      public override void GetCastSkills( out double min, out double max )
      {
         min = RequiredSkill;
         max = RequiredSkill + 30.0;
      }

      public override int GetMana()
      {
         return RequiredMana;
      }

	public override bool CheckCast()
	  {
		Container pack = Caster.Backpack;

		BaseInstrument ints = (BaseInstrument)pack.FindItemByType( typeof( BaseInstrument ) );

		if ( ints == null )
			{
			Caster.SendMessage("Need instrument in pack to play this.");
			return false;
			}

		if ( ints.UsesRemaining >= 2 )
			ints.UsesRemaining -= 1;

		if ( ints.UsesRemaining == 1 )
				ints.Delete();

        Caster.PlaySound( ints.SuccessSound );
		return true;
	 }

      public override TimeSpan GetCastDelay()
      {
         return TimeSpan.FromSeconds( CastDelay );
      }
   }
}