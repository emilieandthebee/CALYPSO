using System; 
using Server; 
using Server.Items;

namespace Server.Items	
{	
	[Furniture]
	[Flipable( 0xe43, 0xe42 )]
	public class Clueconfidentialchest : LockableContainer
	{
		public override int DefaultGumpID{ get{ return 0x49; } }
		public override int DefaultDropSound{ get{ return 0x42; } }

		public override Rectangle2D Bounds
		{
			get{ return new Rectangle2D( 18, 105, 144, 73 ); }
		}

		[Constructable]
		public Clueconfidentialchest() : base( 0xe43 )
		{
			Hue = 1174;
			Weight = 2.0;
			Name = "Boite Confidentielle de Kloedu";
		}

		public Clueconfidentialchest( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			if ( Weight == 15.0 )
				Weight = 2.0;
		}
	}
}