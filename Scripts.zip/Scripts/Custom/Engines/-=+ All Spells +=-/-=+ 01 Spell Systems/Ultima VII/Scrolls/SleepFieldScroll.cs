using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class SleepFieldScroll : SpellScroll
	{
		[Constructable]
		public SleepFieldScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public SleepFieldScroll( int amount ) : base( 369, 0x1F56, amount )
		{
			Name = "Sleep Field";
		}
		
		public SleepFieldScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel <= AccessLevel.Counselor )
			{
				//--<Optional Restrictions>----------<Start>
				from.SendMessage( "Low level staff and players are not allowed to have this scroll." );
				Delete();
			}
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new SleepFieldScroll( amount ), amount );
		}
	}
}
