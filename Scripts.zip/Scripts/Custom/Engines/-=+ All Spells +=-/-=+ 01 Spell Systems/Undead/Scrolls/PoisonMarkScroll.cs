using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class PoisonMarkScroll : SpellScroll
	{
		[Constructable]
		public PoisonMarkScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public PoisonMarkScroll( int amount ) : base( 116, 0x226F, amount )
		{
			Name = "Poison Mark";
			Hue = 0x44;
		}
		
		public PoisonMarkScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new PoisonMarkScroll( amount ), amount );
		}
	}
}
