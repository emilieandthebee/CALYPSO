using System;
using System.IO;
using System.Collections;
using Server;
using Server.Items;
using Server.Scripts.Commands;
using Arya.DialogEditor;

namespace Server.Mobiles
{
	public class AES_Location : WayPoint
	{
		private AES_Location m_ClosestAESLocation1;
		[CommandProperty( AccessLevel.GameMaster )]
		public AES_Location ClosestAESLocation1
		{
			get { return m_ClosestAESLocation1; }
			set { m_ClosestAESLocation1 = value; InvalidateProperties(); }
		}

		private AES_Location m_ClosestAESLocation2;
		[CommandProperty( AccessLevel.GameMaster )]
		public AES_Location ClosestAESLocation2
		{
			get { return m_ClosestAESLocation2; }
			set { m_ClosestAESLocation2 = value; InvalidateProperties(); }
		}

		private AES_Location m_ClosestAESLocation3;
		[CommandProperty( AccessLevel.GameMaster )]
		public AES_Location ClosestAESLocation3
		{
			get { return m_ClosestAESLocation3; }
			set { m_ClosestAESLocation3 = value; InvalidateProperties(); }
		}

		private WayPoint m_ClosestPathToLocation1;
		[CommandProperty( AccessLevel.GameMaster )]
		public WayPoint ClosestPathToLocation1
		{
			get { return m_ClosestPathToLocation1; }
			set { m_ClosestPathToLocation1 = value; InvalidateProperties(); }
		}

		private WayPoint m_ClosestPathToLocation2;
		[CommandProperty( AccessLevel.GameMaster )]
		public WayPoint ClosestPathToLocation2
		{
			get { return m_ClosestPathToLocation2; }
			set { m_ClosestPathToLocation2 = value; InvalidateProperties(); }
		}

		private WayPoint m_ClosestPathToLocation3;
		[CommandProperty( AccessLevel.GameMaster )]
		public WayPoint ClosestPathToLocation3
		{
			get { return m_ClosestPathToLocation3; }
			set { m_ClosestPathToLocation3 = value; InvalidateProperties(); }
		}

		private AES_Location m_EnnemyLocation;
		[CommandProperty( AccessLevel.GameMaster )]
		public AES_Location EnnemyLocation
		{
			get { return m_EnnemyLocation; }
			set { m_EnnemyLocation = value; InvalidateProperties(); }
		}

		private int m_EmptySince;
		[CommandProperty( AccessLevel.GameMaster )]
		public int EmptySince
		{
			get { return m_EmptySince; }
			set { m_EmptySince = value; InvalidateProperties(); }
		}

		private int m_Size;
		[CommandProperty( AccessLevel.GameMaster )]
		public int Size
		{
			get { return m_Size; }
			set { m_Size = value; InvalidateProperties(); }
		}

		private int m_CurrentType;
		[CommandProperty( AccessLevel.GameMaster )]
		public int CurrentType
		{
			get { return m_CurrentType; }
			set { m_CurrentType = value; InvalidateProperties(); }
		}

		private bool m_CanChangeType;
		[CommandProperty( AccessLevel.GameMaster )]
		public bool CanChangeType
		{
			get { return m_CanChangeType; }
			set { m_CanChangeType = value; InvalidateProperties(); }
		}

		private string m_GuildName;
		[CommandProperty( AccessLevel.GameMaster )]
		public string GuildName
		{
			get { return m_GuildName; }
			set { m_GuildName = value; InvalidateProperties(); }
		}

		private bool m_ReinforcementRequested;
		[CommandProperty( AccessLevel.GameMaster )]
		public bool ReinforcementRequested
		{
			get { return m_ReinforcementRequested; }
			set { m_ReinforcementRequested = value; InvalidateProperties(); }
		}

		private int temp_score;
		
		public const int Teams = 10;
		public static bool[] TeamIsStatic= new bool[Teams];
		public static ArrayList m_AESLocations=new ArrayList();
		public static void Initialize()
		{
			Server.Commands.Register( "AES", AccessLevel.Administrator, new CommandEventHandler( AES_OnCommand ) );
			Server.Commands.Register( "AESInitialize", AccessLevel.Administrator, new CommandEventHandler( InitializeAll_OnCommand ) );
			Server.Commands.Register( "AESDespawnAll", AccessLevel.Administrator, new CommandEventHandler( RemoveCreatures_OnCommand ) );
			Server.Commands.Register( "AESReevaluate", AccessLevel.Administrator, new CommandEventHandler( ReEvaluate_OnCommand ) );
			Server.Commands.Register( "AESReSpawnAll", AccessLevel.Administrator, new CommandEventHandler( ReSpawnAll_OnCommand ) );
			Server.Commands.Register( "AESNext", AccessLevel.Administrator, new CommandEventHandler( Next_OnCommand ) );
			TeamIsStatic[0]=true; //Guards
			TeamIsStatic[1]=true; //Guards
			TeamIsStatic[2]=true; //Guards
		}

		[Usage( "AES" )]
		[Description( "List the Alambik Ecosystem System" )]
		private static void AES_OnCommand( CommandEventArgs e )
		{
			e.Mobile.SendMessage("=====");
			e.Mobile.SendMessage("AES (Alambik Ecosystem System) COMMANDS FOR ADMIN:");
			e.Mobile.SendMessage("=====");
			e.Mobile.SendMessage("AESDespawnAll: Remove all creatures");
			e.Mobile.SendMessage("AESInitialize: Initialize paths and closest net");
			e.Mobile.SendMessage("AESReevaluate: Like a daily process, compute war and types locations changes");
			e.Mobile.SendMessage("AESReSpawnAll: Do a respawn of all AES Locations");
			e.Mobile.SendMessage("AESNext: Go to the next location (browse)");
		}
		
		private static int nextlocation;
		[Usage( "AESNext" )]
		[Description( "Go to the next AESlocation (browse)" )]
		private static void Next_OnCommand( CommandEventArgs e )
		{
			if (m_AESLocations.Count == 0)
				return;
			if (nextlocation>=m_AESLocations.Count)
				nextlocation=0;
			if (m_AESLocations[nextlocation] == null)
			{
				e.Mobile.SendMessage("LOCATION {0} is NULL (probably deleted)",nextlocation);
				return;
			}
			AES_Location loc = (AES_Location)(m_AESLocations[nextlocation]);
			if (loc.Deleted)
			{
				e.Mobile.SendMessage("LOCATION {0} is marked as DELETED",nextlocation);
				return;
			}
			e.Mobile.SendMessage("LOCATION {0} named as {1}",nextlocation,loc.Name);
			e.Mobile.MoveToWorld( loc.Location, loc.Map );
			nextlocation++;				
		}

		[Usage( "AESDespawnAll" )]
		[Description( "Remove all AES creatures" )]
		private static void RemoveCreatures_OnCommand( CommandEventArgs e )
		{
			foreach(object obj in AES_Location.m_AESLocations)
			{
				if (obj != null) 
				{
					AES_Location loc=(AES_Location)obj;
					if ( !loc.Deleted )
					{
						loc.RemoveCreatures();
					}
				}
			}
		}
		
		[Usage( "AESInitialize" )]
		[Description( "Initialise tout les localosation de l'ecosystem de spawners dynamiques AES" )]
		private static void InitializeAll_OnCommand( CommandEventArgs e )
		{
			foreach(object obj in AES_Location.m_AESLocations)
			{
				if (obj != null) 
				{
					AES_Location loc=(AES_Location)obj;
					if ( !loc.Deleted )
					{
						loc.SetupClosestAESLocations();
						loc.AssignAType();
						if (loc.CanChangeType)
							loc.Size=Utility.RandomMinMax(5,8);
						else
							loc.Size=Utility.RandomMinMax(1,3);
					}
				}
			}
			AES_Location.ReSpawnAll();
		}
		
		[Usage( "AESReevaluate" )]
		[Description( "Launch the daily reevaluation of ecosystem AES spawners." )]
		private static void ReEvaluate_OnCommand( CommandEventArgs e )
		{
			AES_Location.ReEvaluate();
		}

		[Usage( "AESReSpawnAll" )]
		[Description( "Launch the respawn process" )]
		private static void ReSpawnAll_OnCommand( CommandEventArgs e )
		{
			AES_Location.ReSpawnAll();
		}

		public static void ReSpawnAll()
		{
			foreach(object o in m_AESLocations)
			{
				if (o != null)
				{
					AES_Location loc = (AES_Location)o;
					if (!loc.Deleted)
					{
						loc.Count=loc.Size;
						loc.Defrag();
						loc.RemoveCreatures();
						while(loc.Creatures.Count>0) loc.Creatures.RemoveAt(0);
						while(loc.CreaturesName.Count>0) loc.CreaturesName.RemoveAt(0);
						for (int i=0;i<loc.Size;i++)
						{
							switch (loc.CurrentType)
							{
								case 0:
									loc.CreaturesName.Add( "TechnophobeGuardRingArmor" );
									break;
								case 1:
									loc.CreaturesName.Add( "TechnophobeGuardChainArmor" );
									break;
								case 2:
									loc.CreaturesName.Add( "TechnophobeGuardPlateArmor" );
									break;
								case 3:
									if (Utility.RandomDouble() < 0.5)
										loc.CreaturesName.Add( "Ratman" );
									else
										loc.CreaturesName.Add( "RatmanArcher" );
									break;
								case 4:
									if (Utility.RandomDouble() < 0.9)
										loc.CreaturesName.Add( "Orc" );
									else if (Utility.RandomDouble() < 0.5)
										loc.CreaturesName.Add( "OrcBomber" );
									else if (Utility.RandomDouble() < 0.7)
										loc.CreaturesName.Add( "OrcCaptain" );
									else if (Utility.RandomDouble() < 0.7)
										loc.CreaturesName.Add( "OrcishLord" );
									else
										loc.CreaturesName.Add( "OrcBrute" );
									break;
								case 5:
									loc.CreaturesName.Add( "Ettin" );	
									break;
								case 6:
									if (Utility.RandomDouble() < 0.9)
										loc.CreaturesName.Add( "Ogre" );
									else
										loc.CreaturesName.Add( "OgreLord" );
									break;
								case 7:
										loc.CreaturesName.Add( "Cyclops" ); break;
								case 8:
										loc.CreaturesName.Add( "Troll" ); break;
								case 9:
										loc.CreaturesName.Add( "Lizardman" ); break;
								default:
									break;
							}
						}
						loc.Respawn();
					}
				}
			}
		}
		
		[Constructable]
		public AES_Location() : base()
		{
			Name="AES Spawner";
			m_CurrentType = -1;
			m_CanChangeType = true;  
			m_Size=0;
			m_EnnemyLocation=null;
			ItemID=9006;
			AES_Location.m_AESLocations.Add(this);
			ArrayList creaturesName = new ArrayList();
			InitSpawn( 1, TimeSpan.FromMinutes( 5 ), TimeSpan.FromMinutes( 10 ), 0, 4, creaturesName );
		}

		public static void ReinforcementRequest( Mobile m, DialogNPC npc )
		{
			if (npc.TargetWayPoint != null)
			{
				if (npc.TargetWayPoint is AES_Location)
					((AES_Location)(npc.TargetWayPoint)).ReinforcementRequested=true;
			}
		}
		
		public static void ReEvaluate()
		{
			// ROUND 1: INITIALIZE SCORES
			for (int i=0;i<AES_Location.m_AESLocations.Count;i++)
			{
				if ( AES_Location.m_AESLocations[i] != null)
				{
					AES_Location loc = (AES_Location)(AES_Location.m_AESLocations[i]);
					if (!loc.Deleted)
					{
						if ( loc.CurrentType >= 0 )
						{
							// Initial score is the size...
							loc.temp_score=loc.Size;
							// ...plus the average size of its neighboors.
							if ( (	loc.ClosestAESLocation1 != null ) && 
									!loc.ClosestAESLocation1.Deleted && 
								 (	loc.ClosestAESLocation1.CurrentType == loc.CurrentType ) )
								loc.temp_score = loc.temp_score + loc.ClosestAESLocation1.Size/3;
							if ( (	loc.ClosestAESLocation2 != null ) && 
									!loc.ClosestAESLocation2.Deleted && 
								 (	loc.ClosestAESLocation2.CurrentType == loc.CurrentType ) )
								loc.temp_score = loc.temp_score + loc.ClosestAESLocation2.Size/3;
							if ( (	loc.ClosestAESLocation3 != null ) && 
									!loc.ClosestAESLocation3.Deleted && 
								 (	loc.ClosestAESLocation3.CurrentType == loc.CurrentType ) )
								loc.temp_score = loc.temp_score + loc.ClosestAESLocation3.Size/3;
						} else {
							loc.temp_score=0;
							loc.EmptySince++; // Empty location: take opportunity of the round to increase its counter
						}
					}
				}
			}
			// ROUND 2: COMPUTE WAR RESULTS
			for (int i=0;i<AES_Location.m_AESLocations.Count;i++)
			{
				if ( AES_Location.m_AESLocations[i] != null)
				{
					AES_Location loc = (AES_Location)(AES_Location.m_AESLocations[i]);
					if (!loc.Deleted)
					{
						if ( loc.CurrentType >= 0 )
						{
							if (loc.CanChangeType)
								loc.Size = loc.Size + Utility.Random(1); // NATURAL GROWTH
							else
								loc.Size = loc.Size - 2; // NATURAL GROWTH
							if ( (	loc.ClosestAESLocation1 != null ) && 
									!loc.ClosestAESLocation1.Deleted &&
								 (  (loc.CanChangeType || loc.ClosestAESLocation1.CanChangeType ) ) &&
								 (	loc.ClosestAESLocation1.CurrentType > 0 ) &&
								 (	loc.ClosestAESLocation1.CurrentType != loc.CurrentType ) )
							{
								int dif = loc.temp_score - loc.ClosestAESLocation1.temp_score;
								loc.Size = loc.Size + ((dif>=0)?1:-1)*Utility.Random( 1+(int)(Math.Abs(dif)) );
							}
							if ( (	loc.ClosestAESLocation2 != null ) && 
									!loc.ClosestAESLocation2.Deleted &&
								 (  (loc.CanChangeType || loc.ClosestAESLocation2.CanChangeType ) ) &&
								 (	loc.ClosestAESLocation2.CurrentType > 0 ) &&
								 (	loc.ClosestAESLocation2.CurrentType != loc.CurrentType ) )
							{
								int dif = loc.temp_score - loc.ClosestAESLocation2.temp_score;
								loc.Size = loc.Size + ((dif>=0)?1:-1)*Utility.Random( 1+(int)(Math.Abs(dif)) );
							}
							if ( (	loc.ClosestAESLocation3 != null ) && 
									!loc.ClosestAESLocation3.Deleted && 
								 (  (loc.CanChangeType || loc.ClosestAESLocation3.CanChangeType ) ) &&
								 (	loc.ClosestAESLocation3.CurrentType > 0 ) &&
								 (	loc.ClosestAESLocation3.CurrentType != loc.CurrentType ) )
							{
								int dif = loc.temp_score - loc.ClosestAESLocation3.temp_score;
								loc.Size = loc.Size + ((dif>=0)?1:-1)*Utility.Random( 1+(int)(Math.Abs(dif)) );
							}
						}
					}
				}
			}
			// ROUND 3: REMOVE THE LOOSERS AND CAP THE WINNERS
			for (int i=0;i<AES_Location.m_AESLocations.Count;i++)
			{
				if ( AES_Location.m_AESLocations[i] != null)
				{
					AES_Location loc = (AES_Location)(AES_Location.m_AESLocations[i]);
					if (!loc.Deleted)
					{
						if ( loc.CurrentType >= 0 )
						{
							if (loc.Size >30)
								loc.Size=30; // CAPPED POPULATION
							if (loc.Size <=3)
								if (loc.CanChangeType)
								{
									loc.CurrentType=-1; // REMOVED POPULATION
									loc.EmptySince=0;   // INITIALIZE THE JACHERE COUNTER
								} else {
									loc.Size = Utility.Random(3)+1; // SURVIVAL MODE...
								}								
						}
						if (!loc.CanChangeType && loc.ReinforcementRequested)
						{
							int ennemies=0;
							for (int j=0;j<AES_Location.m_AESLocations.Count;j++)
							{
								if ( AES_Location.m_AESLocations[j] != null )
								{
									AES_Location luc = (AES_Location)(AES_Location.m_AESLocations[j]);
									if (!luc.Deleted && (loc != luc) && ( luc.CurrentType >= 0 ) && (luc.CanChangeType))
									{
										if (luc.ClosestAESLocation1 == loc) ennemies=ennemies+luc.Size;
										if (luc.ClosestAESLocation2 == loc) ennemies=ennemies+luc.Size;
										if (luc.ClosestAESLocation3 == loc) ennemies=ennemies+luc.Size;
									}
								}
							}
							loc.Size=2+ennemies*120/100;
							loc.ReinforcementRequested=false;
							if (loc.Size >30)
								loc.Size=30; // CAPPED POPULATION
						}
					}
				}
			}
			// ROUND 4: ASSIGN EVENTUALY EMPTY PLACES AFTER A WHILE
			for (int i=0;i<AES_Location.m_AESLocations.Count;i++)
			{
				if ( AES_Location.m_AESLocations[i] != null)
				{
					AES_Location loc = (AES_Location)(AES_Location.m_AESLocations[i]);
					if (!loc.Deleted)
					{
						if ( loc.CurrentType == -1 )
						{
							if ((loc.EmptySince>10) || (Utility.Random(10-loc.EmptySince) == 0))
							{	// TRANSFER TROUPS
								double percent = 0.1+Utility.RandomDouble()*0.8;
								switch(Utility.Random(2))
								{
										case 0: 
											if (loc.ClosestAESLocation1.CanChangeType && (loc.ClosestAESLocation1.Size>9))
											{
												loc.CurrentType=loc.ClosestAESLocation1.CurrentType;
												loc.Size=(int)(loc.ClosestAESLocation1.Size*percent);
												loc.ClosestAESLocation1.Size=(int)(loc.ClosestAESLocation1.Size*(1-percent));
											}
											break;
										case 1:
											if (loc.ClosestAESLocation2.CanChangeType) 
											{
												loc.CurrentType=loc.ClosestAESLocation2.CurrentType;
												loc.Size=(int)(loc.ClosestAESLocation2.Size*percent);
												loc.ClosestAESLocation2.Size=(int)(loc.ClosestAESLocation2.Size*(1-percent));
											}
											break;
										case 2:										
											if (loc.ClosestAESLocation3.CanChangeType) 
											{
												loc.CurrentType=loc.ClosestAESLocation3.CurrentType;
												loc.Size=(int)(loc.ClosestAESLocation3.Size*percent);
												loc.ClosestAESLocation3.Size=(int)(loc.ClosestAESLocation3.Size*(1-percent));
											}
											break;
								}
							}
						}
					}
				}
			}
			// ROUND 5: ASSIGN ANY MISSING TYPE, AND RESPAWN ALL
			int[] scores = new int[AES_Location.Teams];
			foreach (object obj in AES_Location.m_AESLocations)
			{
				if (obj != null) {
					AES_Location loc = (AES_Location)obj;
					if (!loc.Deleted)
					{
						if ( loc.CurrentType >= 0 )
							scores[loc.CurrentType]=scores[loc.CurrentType]+1;
					}
				}
			}
			for (int i=0;i<AES_Location.Teams;i++)
			{
				if ( !TeamIsStatic[i] )
					if (scores[i] == 0)
					{
						int ok=50;
						while(ok>0)
						{
							int j=Utility.Random(AES_Location.m_AESLocations.Count);
							AES_Location luc = (AES_Location)(AES_Location.m_AESLocations[j]);
							if (luc.CanChangeType)
							{
								luc.CurrentType=i;
								ok=0;
							} else {
								ok--;
							}
						}
					}
			}
			ReSpawnAll();
		}

		public void OneMoreKill()
		{
			if (Utility.Random(3) == 1)
				if (Size > 0)
					Size--;
		}

		public double GetDistanceToSqrt( Point3D p )
		{
			int xDelta = Location.X - p.X;
			int yDelta = Location.Y - p.Y;
			return Math.Sqrt( (xDelta * xDelta) + (yDelta * yDelta) );
		}

		public void AssignAType()
		{
			if (CanChangeType)
			{
				int[] scores = new int[AES_Location.Teams];
				m_CurrentType=-1;
				foreach (object obj in m_AESLocations)
				{
					if (obj != null) {
						AES_Location loc = (AES_Location)obj;
						if (!loc.Deleted)
						{
							if ( loc.CurrentType >= 0 )
								scores[loc.CurrentType]=scores[loc.CurrentType]+1;
						}
					}
				}
				int lowerScore=10000;
				for (int i=0;i<AES_Location.Teams;i++)
				{
					if (!TeamIsStatic[i])
					{
						if ( scores[i] < lowerScore )
						{
							lowerScore=scores[i];
							CurrentType=i;
						} else if ( scores[i] == lowerScore ) {
							if ( Utility.Random( 2 ) == 1 )
								CurrentType=i;
						}
					}
				}
			}
			if (TeamIsStatic[m_CurrentType])
			{
				m_Team=0;
				m_GuildName="NO GUILD";
			}
			else
			{
				m_Team=m_CurrentType+100;
				m_GuildName="badguys";
			}
		}
		
		public void SetupClosestAESLocations()
		{
			int dist1=0;
			int dist2=0;
			int dist3=0;
			ClosestAESLocation1=null;
			ClosestAESLocation2=null;
			ClosestAESLocation3=null;
			//CLOSEST AES LOCATIONS
			foreach(object obj in AES_Location.m_AESLocations)
			{
				if (obj != null) 
				{
					AES_Location loc=(AES_Location)obj;
					if ( !loc.Deleted && (this != loc) )
					{
						int dist=(int)(GetDistanceToSqrt(loc.Location));
						bool next = false;
						if (ClosestAESLocation1 == null) {
							ClosestAESLocation1 = loc;
							dist1=dist;
							next=true;
						} else if (ClosestAESLocation2 == null) {
							ClosestAESLocation2 = loc;
							dist2=dist;
							next=true;
						} else if (ClosestAESLocation3 == null) {
							ClosestAESLocation3 = loc;
							dist3=dist;
							next=true;
						}
						if (!next)
						{
							if (dist < dist1) {
								ClosestAESLocation1 = loc;
								dist1=dist;								
							} else if (dist < dist2) {
								ClosestAESLocation2 = loc;
								dist2=dist;								
							} else if (dist < dist3) {
								ClosestAESLocation3 = loc;
								dist3=dist;																
							}
						}							
					}
				}
			}
			//CLOSEST PATH TO
			ClosestPathToLocation1=ClosestAESLocation1;
			ClosestPathToLocation2=ClosestAESLocation2;
			ClosestPathToLocation3=ClosestAESLocation3;
			IPooledEnumerable eable = GetItemsInRange( 5 );
			foreach ( Item item in eable )
			{
				if ( item is WayPoint )
				{
					WayPoint waypointfound = (WayPoint)item;
					bool fin = false;
					int counter = 0;
					WayPoint wp = waypointfound;
					while ( !fin )
					{
						counter++;
						if (counter>200) fin=true; // Loop probability is very high
						wp=wp.NextPoint;
						if (wp == null)
							fin = true;
						if (wp is AES_Location)
						{
							fin = true;
							AES_Location FoundAESLocation = (AES_Location)wp;
							if (FoundAESLocation == ClosestAESLocation1) {
								ClosestPathToLocation1=waypointfound;
							} else if (FoundAESLocation == ClosestAESLocation2) {
								ClosestPathToLocation2=waypointfound;
							} else if (FoundAESLocation == ClosestAESLocation3) {
								ClosestPathToLocation3=waypointfound;
							}
						}
					}
				}
			}
			eable.Free();
		}
		
		public AES_Location( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 3 ); // version
			writer.Write( m_GuildName );
			writer.Write( m_CurrentType );
			writer.Write( m_CanChangeType );
			writer.Write( m_ReinforcementRequested );
			writer.Write( m_Size );
			writer.Write( m_EmptySince );
			writer.Write( m_ClosestAESLocation1 );
			writer.Write( m_ClosestAESLocation2 );
			writer.Write( m_ClosestAESLocation3 );
			writer.Write( m_ClosestPathToLocation1 );
			writer.Write( m_ClosestPathToLocation2 );
			writer.Write( m_ClosestPathToLocation3 );
			writer.Write( m_EnnemyLocation );
			////// SPAWNER //////
			writer.Write( m_WayPoint );
			writer.Write( m_Group );
			writer.Write( m_MinDelay );
			writer.Write( m_MaxDelay );
			writer.Write( m_Count );
			writer.Write( m_Team );
			writer.Write( m_HomeRange );
			writer.Write( m_Running );
			if ( m_Running )
				writer.WriteDeltaTime( m_End );
			writer.Write( m_CreaturesName.Count );
			for ( int i = 0; i < m_CreaturesName.Count; ++i )
				writer.Write( (string)m_CreaturesName[i] );
			writer.Write( m_Creatures.Count );
			for ( int i = 0; i < m_Creatures.Count; ++i )
			{
				object o = m_Creatures[i];
				if ( o is Item )
					writer.Write( (Item)o );
				else if ( o is Mobile )
					writer.Write( (Mobile)o );
				else
					writer.Write( Serial.MinusOne );
			}
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			switch ( version )
			{
				case 3:
					m_GuildName    		 	 = reader.ReadString();
					goto case 2;
				case 2:
					m_CurrentType    		 = reader.ReadInt();
					m_CanChangeType  		 = reader.ReadBool();
					m_ReinforcementRequested = reader.ReadBool();
					m_Size           		 = reader.ReadInt();
					m_EmptySince     		 = reader.ReadInt();
					m_ClosestAESLocation1    = (AES_Location)reader.ReadItem();
					m_ClosestAESLocation2    = (AES_Location)reader.ReadItem();
					m_ClosestAESLocation3    = (AES_Location)reader.ReadItem();
					m_ClosestPathToLocation1 = (WayPoint)reader.ReadItem();
					m_ClosestPathToLocation2 = (WayPoint)reader.ReadItem();
					m_ClosestPathToLocation3 = (WayPoint)reader.ReadItem();
					m_EnnemyLocation = (AES_Location)reader.ReadItem();
					goto case 1;
				case 1:
					m_WayPoint = reader.ReadItem() as WayPoint;
					m_Group = reader.ReadBool();
					m_MinDelay = reader.ReadTimeSpan();
					m_MaxDelay = reader.ReadTimeSpan();
					m_Count = reader.ReadInt();
					m_Team = reader.ReadInt();
					m_HomeRange = reader.ReadInt();
					m_Running = reader.ReadBool();
					TimeSpan ts = TimeSpan.Zero;
					if ( m_Running )
						ts = reader.ReadDeltaTime() - DateTime.Now;
					int size = reader.ReadInt();
					m_CreaturesName = new ArrayList( size );
					for ( int i = 0; i < size; ++i )
					{
						string typeName = reader.ReadString();

						m_CreaturesName.Add( typeName );

						if ( SpawnerType.GetType( typeName ) == null )
						{
							if ( m_WarnTimer == null )
								m_WarnTimer = new WarnTimer();

							m_WarnTimer.Add( Location, Map, typeName );
						}
					}
					int count = reader.ReadInt();
					m_Creatures = new ArrayList( count );
					for ( int i = 0; i < count; ++i )
					{
						IEntity e = World.FindEntity( reader.ReadInt() );

						if ( e != null )
							m_Creatures.Add( e );
					}
					if ( m_Running )
						DoTimer( ts );
					break;
				default:
					break;
			}
			AES_Location.m_AESLocations.Add(this);
		}

/////////////////////////////////////////////////////////////////////////
// SPAWNER
/////////////////////////////////////////////////////////////////////////
		private int m_Team;
		private int m_HomeRange;
		private int m_Count;
		private TimeSpan m_MinDelay;
		private TimeSpan m_MaxDelay;
		private ArrayList m_CreaturesName;
		private ArrayList m_Creatures;
		private DateTime m_End;
		private InternalTimer m_Timer;
		private bool m_Running;
		private bool m_Group;
		private WayPoint m_WayPoint;

		public bool IsFull{ get{ return ( m_Creatures != null && m_Creatures.Count >= m_Count ); } }
		
		public ArrayList CreaturesName
		{
			get { return m_CreaturesName; }
			set
			{
				m_CreaturesName = value;
				if ( m_CreaturesName.Count < 1 )
					Stop();
				InvalidateProperties();
			}
		}
		
		public ArrayList Creatures
		{
			get { return m_Creatures; }
			set
			{
				m_Creatures = value;
				if ( m_Creatures.Count < 1 )
					Stop();
				InvalidateProperties();
			}
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public int Count
		{
			get { return m_Count; }
			set { m_Count = value; InvalidateProperties(); }
		}

		private Item FinalDestination;
		
		[CommandProperty( AccessLevel.GameMaster )]
		public WayPoint WayPoint
		{
			get
			{
				if (CanChangeType)
				{
					if (Utility.Random(3) == 1)
					{
						for(int i=0;i<3;i++)
						{
							switch (Utility.Random(3))
							{
								case 0:
									if (ClosestAESLocation1 != null)
									{
										AES_Location loc = (AES_Location)ClosestAESLocation1;
										if  (!loc.Deleted && 
											(loc.CurrentType != CurrentType))
										{
											FinalDestination=ClosestAESLocation1;
											if (ClosestPathToLocation1 == null)
												return ClosestAESLocation1;
											else
												return ClosestPathToLocation1;
										}
									}
									break;
								case 1:
									if (ClosestAESLocation2 != null)
									{
										AES_Location loc = (AES_Location)ClosestAESLocation2;
										if  (!loc.Deleted && 
											(loc.CurrentType != CurrentType))
										{
											FinalDestination=ClosestAESLocation2;
											if (ClosestPathToLocation2 == null)
												return ClosestAESLocation2;
											else
												return ClosestPathToLocation2;
										}
									}
									break;
								case 2:
									if (ClosestAESLocation3 != null)
									{
										AES_Location loc = (AES_Location)ClosestAESLocation3;
										if  (!loc.Deleted && 
											(loc.CurrentType != CurrentType))
										{
											FinalDestination=ClosestAESLocation3;
											if (ClosestPathToLocation3 == null)
												return ClosestAESLocation3;
											else
												return ClosestPathToLocation3;
										}
									}
									break;
							}
						}
					}
				}
				return m_WayPoint;
			}
			set
			{
				m_WayPoint = value;
			}
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public bool Running
		{
			get { return m_Running; }
			set
			{
				if ( value )
					Start();
				else
					Stop();

				InvalidateProperties();
			}
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public int HomeRange
		{
			get { return m_HomeRange; }
			set { m_HomeRange = value; InvalidateProperties(); }
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public int Team
		{
			get { return m_Team; }
			set { m_Team = value; InvalidateProperties(); }
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public TimeSpan MinDelay
		{
			get { return m_MinDelay; }
			set { m_MinDelay = value; InvalidateProperties(); }
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public TimeSpan MaxDelay
		{
			get { return m_MaxDelay; }
			set { m_MaxDelay = value; InvalidateProperties(); }
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public TimeSpan NextSpawn
		{
			get
			{
				if ( m_Running )
					return m_End - DateTime.Now;
				else
					return TimeSpan.FromSeconds( 0 );
			}
			set
			{
				Start();
				DoTimer( value );
			}
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public bool Group
		{
			get { return m_Group; }
			set { m_Group = value; InvalidateProperties(); }
		}

		public void InitSpawn( int amount, TimeSpan minDelay, TimeSpan maxDelay, int team, int homeRange, ArrayList creaturesName )
		{
			Visible = false;
			Movable = false;
			m_Running = true;
			m_Group = false;
			Name = "AES Spawner WayPoint";
			m_MinDelay = minDelay;
			m_MaxDelay = maxDelay;
			m_Count = amount;
			m_Team = team;
			m_HomeRange = homeRange;
			m_CreaturesName = creaturesName;
			m_Creatures = new ArrayList();
			DoTimer( TimeSpan.FromSeconds( 1 ) );
		}
			
		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel < AccessLevel.GameMaster )
				return;

			AES_SpawnerGump g = new AES_SpawnerGump( this );
			from.SendGump( g );
		}

		public override void GetProperties( ObjectPropertyList list )
		{
			base.GetProperties( list );

			if ( m_Running )
			{
				list.Add( 1060742 ); // active

				list.Add( 1060656, m_Count.ToString() ); // amount to make: ~1_val~
				list.Add( 1061169, m_HomeRange.ToString() ); // range ~1_val~

				list.Add( 1060658, "group\t{0}", m_Group ); // ~1_val~: ~2_val~
				list.Add( 1060659, "team\t{0}", m_Team ); // ~1_val~: ~2_val~
				list.Add( 1060660, "speed\t{0} to {1}", m_MinDelay, m_MaxDelay ); // ~1_val~: ~2_val~

				for ( int i = 0; i < 3 && i < m_CreaturesName.Count; ++i )
					list.Add( 1060661 + i, "{0}\t{1}", m_CreaturesName[i], CountCreatures( (string)m_CreaturesName[i] ) );
			}
			else
			{
				list.Add( 1060743 ); // inactive
			}
		}

		public override void OnSingleClick( Mobile from )
		{
			base.OnSingleClick( from );

			if ( m_Running )
				LabelTo( from, "[Running]" );
			else
				LabelTo( from, "[Off]" );
		}

		public void Start()
		{
			if ( !m_Running )
			{
				if ( m_CreaturesName.Count > 0 )
				{
					m_Running = true;
					DoTimer();
				}
			}
		}

		public void Stop()
		{
			if ( m_Running )
			{
				m_Timer.Stop();
				m_Running = false;
			}
		}

		public void Defrag()
		{
			bool removed = false;

			for ( int i = 0; i < m_Creatures.Count; ++i )
			{
				object o = m_Creatures[i];

				if ( o is Item )
				{
					Item item = (Item)o;

					if ( item.Deleted || item.Parent != null )
					{
						m_Creatures.RemoveAt( i );
						--i;
						removed = true;
					}
				}
				else if ( o is Mobile )
				{
					Mobile m = (Mobile)o;

					if ( m.Deleted )
					{
						m_Creatures.RemoveAt( i );
						--i;
						removed = true;
					}
					else if ( m is BaseCreature )
					{
						if ( ((BaseCreature)m).Controled || ((BaseCreature)m).IsStabled )
						{
							m_Creatures.RemoveAt( i );
							--i;
							removed = true;
						}
					}
				}
				else
				{
					m_Creatures.RemoveAt( i );
					--i;
					removed = true;
				}
			}

			if ( removed )
				InvalidateProperties();
		}

		public void OnTick()
		{
			DoTimer();

			if ( m_Group )
			{
				Defrag();

				if  ( m_Creatures.Count == 0 )
				{
					Respawn();
				}
				else
				{
					return;
				}
			}
			else
			{
				Spawn();
			}
		}
		
		public void Respawn()
		{
			RemoveCreatures();

			for ( int i = 0; i < m_Count; i++ )
				Spawn();
		}
		
		public void Spawn()
		{
			if ( m_CreaturesName.Count > 0 )
				Spawn( Utility.Random( m_CreaturesName.Count ) );
		}
		
		public void Spawn( string creatureName )
		{
			for ( int i = 0; i < m_CreaturesName.Count; i++ )
			{
				if ( (string)m_CreaturesName[i] == creatureName )
				{
					Spawn( i );
					break;
				}
			}
		}

		public void Spawn( int index )
		{
			Map map = Map;

			if ( map == null || map == Map.Internal || m_CreaturesName.Count == 0 || index >= m_CreaturesName.Count || Parent != null )
				return;

			Defrag();

			if ( m_Creatures.Count >= m_Count )
				return;

			Type type = SpawnerType.GetType( (string)m_CreaturesName[index] );

			if ( type != null )
			{
				try
				{
					object o = Activator.CreateInstance( type );

					if ( o is Mobile )
					{
						Mobile m = (Mobile)o;

						m_Creatures.Add( m );
						

						Point3D loc = ( m is BaseVendor ? this.Location : GetSpawnPosition() );

						m.OnBeforeSpawn( loc, map );
						InvalidateProperties();


						m.MoveToWorld( loc, map );

						if ( m is BaseCreature )
						{
							BaseCreature c = (BaseCreature)m;
							c.SpawnedByEcosystem = this;
							c.RangeHome = m_HomeRange;

							c.CurrentWayPoint = this.WayPoint;
							if (this.FinalDestination != null)
								c.Home = this.FinalDestination.Location;

							if ( m_Team > 0 )
								c.Team = m_Team;
							c.GuildName = m_GuildName;

							c.Home = this.Location;
						}

						m.OnAfterSpawn();
					}
					else if ( o is Item )
					{
						Item item = (Item)o;

						m_Creatures.Add( item );

						Point3D loc = GetSpawnPosition();

						item.OnBeforeSpawn( loc, map );
						InvalidateProperties();

						item.MoveToWorld( loc, map );

						item.OnAfterSpawn();
					}
				}
				catch
				{
				}
			}
		}

		public Point3D GetSpawnPosition()
		{
			Map map = Map;

			if ( map == null )
				return Location;

			// Try 10 times to find a Spawnable location.
			for ( int i = 0; i < 10; i++ )
			{
				int x = Location.X + (Utility.Random( (m_HomeRange * 2) + 1 ) - m_HomeRange);
				int y = Location.Y + (Utility.Random( (m_HomeRange * 2) + 1 ) - m_HomeRange);
				int z = Map.GetAverageZ( x, y );

				if ( Map.CanSpawnMobile( new Point2D( x, y ), this.Z ) )
					return new Point3D( x, y, this.Z );
				else if ( Map.CanSpawnMobile( new Point2D( x, y ), z ) )
					return new Point3D( x, y, z );
			}

			return this.Location;
		}

		public void DoTimer()
		{
			if ( !m_Running )
				return;

			int minSeconds = (int)m_MinDelay.TotalSeconds;
			int maxSeconds = (int)m_MaxDelay.TotalSeconds;

			TimeSpan delay = TimeSpan.FromSeconds( Utility.RandomMinMax( minSeconds, maxSeconds ) );
			DoTimer( delay );
		}

		public void DoTimer( TimeSpan delay )
		{
			if ( !m_Running )
				return;

			m_End = DateTime.Now + delay;

			if ( m_Timer != null )
				m_Timer.Stop();

			m_Timer = new InternalTimer( this, delay );
			m_Timer.Start();
		}

		private class InternalTimer : Timer
		{
			private AES_Location m_Spawner;

			public InternalTimer( AES_Location spawner, TimeSpan delay ) : base( delay )
			{
				if ( spawner.IsFull )
					Priority = TimerPriority.FiveSeconds;
				else
					Priority = TimerPriority.OneSecond;

				m_Spawner = spawner;
			}

			protected override void OnTick()
			{
				if ( m_Spawner != null )
					if ( !m_Spawner.Deleted )
						m_Spawner.OnTick();
			}
		}

		public int CountCreatures( string creatureName )
		{
			Defrag();

			int count = 0;

			for ( int i = 0; i < m_Creatures.Count; ++i )
				if ( Insensitive.Equals( creatureName, m_Creatures[i].GetType().Name ) )
					++count;

			return count;
		}

		public void RemoveCreatures( string creatureName )
		{
			Defrag();

			creatureName = creatureName.ToLower();

			for ( int i = 0; i < m_Creatures.Count; ++i )
			{
				object o = m_Creatures[i];

				if ( Insensitive.Equals( creatureName, o.GetType().Name ) )
				{
					if ( o is Item )
						((Item)o).Delete();
					else if ( o is Mobile )
						((Mobile)o).Delete();
				}
			}

			InvalidateProperties();
		}
		
		public void RemoveCreatures()
		{
			Defrag();

			for ( int i = 0; i < m_Creatures.Count; ++i )
			{
				object o = m_Creatures[i];

				if ( o is Item )
					((Item)o).Delete();
				else if ( o is Mobile )
					((Mobile)o).Delete();
			}

			InvalidateProperties();
		}
		
		public void BringToHome()
		{
			Defrag();

			for ( int i = 0; i < m_Creatures.Count; ++i )
			{
				object o = m_Creatures[i];

				if ( o is Mobile )
				{
					Mobile m = (Mobile)o;

					m.MoveToWorld( Location, Map );
				}
				else if ( o is Item )
				{
					Item item = (Item)o;

					item.MoveToWorld( Location, Map );
				}
			}
		}

		public override void OnDelete()
		{
			base.OnDelete();
			RemoveCreatures();
			if ( m_Timer != null )
				m_Timer.Stop();
		}
		
		private static WarnTimer m_WarnTimer;
		private class WarnTimer : Timer
		{
			private ArrayList m_List;

			private class WarnEntry
			{
				public Point3D m_Point;
				public Map m_Map;
				public string m_Name;

				public WarnEntry( Point3D p, Map map, string name )
				{
					m_Point = p;
					m_Map = map;
					m_Name = name;
				}
			}

			public WarnTimer() : base( TimeSpan.FromSeconds( 1.0 ) )
			{
				m_List = new ArrayList();
				Start();
			}

			public void Add( Point3D p, Map map, string name )
			{
				m_List.Add( new WarnEntry( p, map, name ) );
			}

			protected override void OnTick()
			{
				try
				{
					Console.WriteLine( "Warning: {0} bad spawns detected, logged: 'badspawn.log'", m_List.Count );

					using ( StreamWriter op = new StreamWriter( "badspawn.log", true ) )
					{
						op.WriteLine( "# Bad spawns : {0}", DateTime.Now );
						op.WriteLine( "# Format: X Y Z F Name" );
						op.WriteLine();

						foreach ( WarnEntry e in m_List )
							op.WriteLine( "{0}\t{1}\t{2}\t{3}\t{4}", e.m_Point.X, e.m_Point.Y, e.m_Point.Z, e.m_Map, e.m_Name );

						op.WriteLine();
						op.WriteLine();
					}
				}
				catch
				{
				}
			}
		}
	}
}
