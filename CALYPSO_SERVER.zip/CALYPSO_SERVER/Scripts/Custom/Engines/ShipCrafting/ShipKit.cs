//
// ShipKit.cs
//
// Released:	June 2 2004
//
// Version:	1.0
//
// Author:	awdball
//
// Expansion for Shipwright.cs adds pre-packaged kits for playing with your ship
// building skills.
//
// [add AdvancedShipKit
//
// or
//
// [add BasicShipKit
// 


using System;
using Server;
using Server.Items;
using Server.Engines.Craft;

namespace Server.Items
{
	public class AdvancedShipKit : LargeCrate
	{
		[Constructable]
		public AdvancedShipKit() : base()
		{
			Name = "Advanced Ship-ina-Crate";
			RedBook manual = new RedBook( "A.S.K. Instruction Manual", "AWDBall", 1, false );
			manual.Pages[0].Lines = new string[]
			{// 0123456789012345678901234
			   "Ger floogen bal, die",
			   "hooppen sie zurna.",
			   "",
			   "GA 3 urnches, porek",
			   "dye siggunder flou!",
			   ""
			};
			DropItem( manual );
			DropItem( new Shovel( 100 ) );
			DropItem( new Axe() );
			DropItem( new ShipwrightTools( 100 ) );
			DropItem( new Tongs( 100 ) );
			DropItem( new Dagger() );
			DropItem( new TinkerTools( 100 ));
		}

		public AdvancedShipKit(Serial serial) : base(serial) { } 
		public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int) 0); } 
		public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); }
	}

	public class BasicShipKit : LargeCrate
	{

		[Constructable]
		public BasicShipKit() : base()
		{
			Name = "Basic Ship-ina-Crate";
			RedBook manual = new RedBook( "B.S.K. Instruction Manual", "AWDBall", 17, false );

			manual.Pages[0].Lines = new string[]
			{// 0123456789012345678901234
			   "Welcome, You are now",
			   "the proud owner of a",
			   "AWD Ball Enterprises",
			   " Basic Ship-ina-Crate",
			   "",
			   "Please be sure to read",
			   "this whole manual",
			   "before starting."
			};
			manual.Pages[1].Lines = new string[]
			{// 0123456789012345678901234
			   "",
			   "     this ",
			   "     page ",
			   " intentionally  ",
			   "     left ",
			   "    blank. "
			};
			manual.Pages[2].Lines = new string[]
			{// 0123456789012345678901234
			   "",
			   "Warning, not suitable",
			   "for children under the",
			   "age of 3 years, this kit",
			   "contains small parts",
			   "that may pose a choking",
			   "risk.",
			};
			manual.Pages[3].Lines = new string[]
			{// 0123456789012345678901234
			   "",
			   "This kit should contain",
			   "all the parts you need",
			   "to make your very own",
			   "ship.",
			   "",
			   "Please fill in your ",
			   "registration card now"
			};
			manual.Pages[4].Lines = new string[]
			{// 0123456789012345678901234
			   "  Contents ",
			   "Setup            Pg  6",
			   "Ropes and knots  Pg  7",
			   "Preparing hull   Pg  8",
			   "Decking          Pg 12",
			   "Mast and Rigging Pg 14",
			   "A fine Prow      Pg 15",
			   "Final assembly   Pg 17"
			};
			manual.Pages[5].Lines = new string[]
			{// 0123456789012345678901234
			   "..\\",
			   "../",
			   "./",
			   ".|",
			   "..\\",
			   "....\\",
			   ".~~~",
			   "~"
			};


			DropItem( manual );
			DropItem( new Board( 2000 ) );
			DropItem( new Hinge( 4 ) );
			DropItem( new ShipwrightTools( 100 ) );
			DropItem( new RedScales( 8 ) );
			DropItem( new Nails( 30 ) );
			DropItem( new SpoolOfThread( 50 ) );
			DropItem( new IronIngot( 100 ) );
			DropItem( new Axle( 10 ) );
			DropItem( new Cloth( 100 ) );
		}

		public BasicShipKit(Serial serial) : base(serial) { } 
		public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int) 0); } 
		public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); }
	}

}
