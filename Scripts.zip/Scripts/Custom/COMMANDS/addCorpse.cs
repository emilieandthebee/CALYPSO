using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;

namespace Server.Scripts.Commands
{
	public class addCorpse
	{
		public static void Initialize()
		{
			Server.Commands.Register( "addCorpse", AccessLevel.Administrator, new CommandEventHandler( addCorpse_OnCommand ) );
		}

		[Usage( "addCorpse" )]
		[Description( "Add corpse from a Mobile reference" )]
		private static void addCorpse_OnCommand( CommandEventArgs e )
		{
			e.Mobile.SendMessage("Please select the Mobile you want to use as a reference.");
			e.Mobile.Target = new addCorpseSelector();
		}

		///// //// /// // / BEGIN TARGET / // /// //// /////
		private class addCorpseSelector : Target
		{
			public addCorpseSelector () : base( -1, false, TargetFlags.None )
			{
			}

			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( targeted is Mobile )
				{
					Mobile mob = (Mobile)targeted;
					ArrayList content = new ArrayList();
					ArrayList equip = new ArrayList();
					ArrayList moveToPack = new ArrayList();
					ArrayList itemsCopy = new ArrayList( mob.Items );
					Container pack = mob.Backpack;
					for ( int i = 0; i < itemsCopy.Count; ++i )
					{
						Item item = (Item)itemsCopy[i];
						if ( item == pack )
						continue;
						DeathMoveResult res = mob.GetParentMoveResultFor( item );
						switch ( res )
						{
							case DeathMoveResult.MoveToCorpse:
							{
								content.Add( item );
								equip.Add( item );
								break;
							}
							case DeathMoveResult.MoveToBackpack:
							{
								moveToPack.Add( item );
								break;
							}
						}
					}
					if ( pack != null )
					{
						ArrayList packCopy = new ArrayList( pack.Items );
						for ( int i = 0; i < packCopy.Count; ++i )
						{
							Item item = (Item)packCopy[i];
							DeathMoveResult res = mob.GetInventoryMoveResultFor( item );
							if ( res == DeathMoveResult.MoveToCorpse )
								content.Add( item );
							else
								moveToPack.Add( item );
						}
						for ( int i = 0; i < moveToPack.Count; ++i )
						{
							Item item = (Item)moveToPack[i];
							if ( mob.RetainPackLocsOnDeath && item.Parent == pack )
								continue;
							pack.DropItem( item );
						}
					}
					Container c = ( Mobile.CreateCorpseHandler == null ? null : Mobile.CreateCorpseHandler( mob, content, equip ) );
					c.MoveToWorld(mob.Location,mob.Map);					
				}
			}
		}
		///// //// /// // / END TARGET / // /// //// /////
	}
}