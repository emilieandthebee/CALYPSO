using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class RogueBag : Bag
	{
		[Constructable]
		public RogueBag()
		{
			PlaceItemIn( 30, 35, new RogueCharmScroll() );
			PlaceItemIn( 50, 35, new RogueFalseCoinScroll() );
			PlaceItemIn( 70, 35, new IntimidationScroll() );
			PlaceItemIn( 90, 35, new ShadowScroll() );
			PlaceItemIn( 30, 55, new SlyFoxScroll() );
		}

		private void PlaceItemIn( int x, int y, Item item )
		{
			AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public RogueBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}