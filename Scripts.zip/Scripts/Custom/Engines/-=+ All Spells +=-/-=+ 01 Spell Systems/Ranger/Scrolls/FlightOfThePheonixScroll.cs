using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class FlightOfThePheonixScroll : SpellScroll
	{
		[Constructable]
		public FlightOfThePheonixScroll() : this( 1 )
		{
		}

		[Constructable]
		public FlightOfThePheonixScroll( int amount ) : base( 901, 3828, amount )
		{
			Name = "Flight of the Pheonix";
			Hue = 2002;
		}

		public FlightOfThePheonixScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new FlightOfThePheonixScroll( amount ), amount );
		}
	}
}
