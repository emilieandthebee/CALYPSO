using System;
using System.Collections;
using Server;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class EnLigne
	{
		public static void Initialize()
		{
			Server.Commands.Register( "EnLigne", AccessLevel.Player, new CommandEventHandler( EnLigne_OnCommand ) );
		}

		[Usage( "EnLigne" )]
		[Description( "Liste les personnages des joueurs connectes." )]
		private static void EnLigne_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				int nb=0;
				PlayerMobile pm1 = (PlayerMobile)e.Mobile;
				pm1.SendMessage("LISTE DES PERSONNES EN LIGNE:");
				foreach ( NetState state in NetState.Instances )
				{
					if (state.Mobile is PlayerMobile)
					{
						PlayerMobile pm2=(PlayerMobile)(state.Mobile);
						if (pm1.AccessLevel >= pm2.AccessLevel)
						{
							pm1.SendMessage(pm2.Name);
							nb++;
						}
					}
				}
				pm1.SendMessage("FIN DE LA LISTE ({0} en ligne)",nb);
			}
		}
	}
}
