using System;
using Server.Network;
using Server.Gumps;
using Server.Spells;
using Server.Spells.Rogue;


namespace Server.Items
{
	public class RogueSpellbook : Spellbook
	{
		public override SpellbookType SpellbookType{ get{ return SpellbookType.Rogue; } }
		public override int BookOffset{ get{ return 150; } }
		public override int BookCount{ get{ return 5; } }

		public override Item Dupe( int amount )
		{
			Spellbook book = new RogueSpellbook();
			book.Content = this.Content;
			return base.Dupe( book, amount );
		}

		[Constructable]
		public RogueSpellbook() : this( (ulong)0 )
		{
		}

		[Constructable]
		public RogueSpellbook( ulong content ) : base( content, 0xEFA )
		{
			Hue = 0x20;
			Name = "Rogue Abilities";
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel == AccessLevel.Player )
			{
				Container pack = from.Backpack;
				if( !(Parent == from || (pack != null && Parent == pack)) )
				{
					from.SendMessage( "The spellbook must be in your backpack [and not in a container within] to open." );
					return;
				}
				else if( UseRestrictions && !SpellRestrictions.CheckRestrictions( from, this ) )
				{
					return;
				}
			}

			from.CloseGump( typeof( RogueSpellbookGump ) );
			from.SendGump( new RogueSpellbookGump( from, this ) );
		}

		public RogueSpellbook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
