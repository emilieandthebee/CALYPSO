/***** ALAMBIK *****/
using System;
using Server.Mobiles;

namespace Server.Items
{
    public class NoneFlyingBlocker : Item
    {
        [Constructable]
        public NoneFlyingBlocker()
            : base( 0x1BC4 )
        {
            Name="None flying blocker";
            Visible = false;
            Movable = false;
        }

        public NoneFlyingBlocker( Serial serial )
            : base( serial )
        {
        }

        public override bool OnMoveOver( Mobile m )
        {
			bool isFlying=((m is PlayerMobile) && ((PlayerMobile)m).Flying);
			if (!(isFlying) && (m is PlayerMobile))
				m.SendMessage("Mmmh... Vu la hauteur, pour passer par ici, il vous faudrait des ailes...");
            return isFlying;
        }

        public override void Serialize( GenericWriter writer )
        {
            base.Serialize( writer );
            writer.Write( (int)0 );
        }

        public override void Deserialize( GenericReader reader )
        {
            base.Deserialize( reader );
            int version = reader.ReadInt();
        }
    }
}