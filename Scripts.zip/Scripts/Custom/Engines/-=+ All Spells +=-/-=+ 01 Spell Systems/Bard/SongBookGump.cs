using System;
using Server;
using Server.Items;
using Server.Gumps;
using Server.Network;

namespace Server.Spells.Song
{
	public class SongBookGump : BaseCGump
	{
		public override int TextHue{   get{ return 2307; } }
		public override int BGImage{   get{ return 2203; } }
		public override int SpellBtn{  get{ return 2362; } }
		public override int SpellBtnP{ get{ return 2361; } }
		public override string MLab{   get{ return "Bard Songs"; } }

		public SongBookGump( Mobile from, SongBook book ) : base( from, book )
		{
		}

		public override void OnResponse( NetState state, RelayInfo info )
		{
			Mobile from = state.Mobile;
			int BID = info.ButtonID;

			if( BID >= 651 && BID <= 666 )
			{
				Spell spell = SpellRegistry.NewSpell( BID, from, null );
				if( spell != null )
					spell.Cast();
			}
		}
	}
}