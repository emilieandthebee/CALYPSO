using System;
using System.Reflection;
using Server.Items;
using Server.Targeting;
using Server.Mobiles;
using Server.Network;


namespace Server.Scripts.Commands
{
	public class Saison
	{ 
		public static void Initialize()
		{
			Server.Commands.Register("Saison", 
				AccessLevel.Administrator, new CommandEventHandler(Saison_OnCommand));
		}

		[Usage("Saison <Numero Saison>")]
		[Description("Change la saison")]
		private static void Saison_OnCommand(CommandEventArgs Event)
		{
			if (Event.Length == 1)
			{
				if (Event.Arguments[0] == null || Event.Arguments[0].Length <= 0)
				{
					Event.Mobile.SendMessage("Entrez une Saison valide");
					return;
				}	
				try
				{
					int NewSaison = System.Convert.ToInt32(Event.Arguments[0]);
					if (Event.Mobile.Map != null && Event.Mobile.Map != Map.Internal)
					{
						Event.Mobile.Map.Season = NewSaison;
						for (int Cmpt = 0; Cmpt < NetState.Instances.Count; Cmpt++)
						{
							Mobile NetStateMobile = ((NetState)NetState.Instances[0]).Mobile;
							if (NetStateMobile != null && 
								NetStateMobile is PlayerMobile && 
								NetStateMobile.Map == Event.Mobile.Map)
							{
								NetStateMobile.Send(SeasonChange.Instantiate(Event.Mobile.Map.Season, true));
							}
						}
					} else {
						Event.Mobile.SendMessage("Vous �tes sur une Map invalide");
					}
				}
				catch (System.Exception)
				{
					Event.Mobile.SendMessage("La Saison doit �tre un nombre d�cimal");
					return;
				}
			} else {
				Event.Mobile.SendMessage("Usage : Saison <Numero Saison>");
				return;
			} 
		} 
	}
}

