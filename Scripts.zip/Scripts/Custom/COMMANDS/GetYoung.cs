using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class GetYoung
	{
		public static void Initialize()
		{
			Server.Commands.Register( "GetYoung", AccessLevel.GameMaster, new CommandEventHandler( GetYoung_OnCommand ) );
		}

		[Usage( "GetYoung" )]
		[Description( "Ramene les joueurs non valider en jeu." )]
		private static void GetYoung_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)e.Mobile;
				pm.SendMessage("Personnages ayant rempli leut fiche:");
				foreach ( Mobile mob in World.Mobiles.Values )
				{
					if (!mob.Deleted)
					if (mob is PlayerMobile)
					{
						PlayerMobile pmob=(PlayerMobile)mob;
						if (pmob.Young)
						if (pmob.Backpack != null)
						if (!pmob.Backpack.Deleted)
						{
							Item note=pmob.Backpack.FindItemByType(typeof(FicheInscription));
							pmob.Map=Map.Trammel;
							pmob.Hidden=true;
							pm.SendMessage(pmob.Name);
						}
					}
				}
			}
		}
	}
}