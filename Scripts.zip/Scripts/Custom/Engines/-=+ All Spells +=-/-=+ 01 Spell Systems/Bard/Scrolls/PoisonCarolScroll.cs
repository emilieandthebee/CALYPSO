using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class PoisonCarolScroll : SpellScroll
	{
		[Constructable]
		public PoisonCarolScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public PoisonCarolScroll( int amount ) : base( 663, 0x14ED, amount )
		{
			Name = "Poison Carol sheet music";
			Hue = 0x96;
		}
		
		public PoisonCarolScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			from.SendMessage( "The sheet music must be in your music book." );
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new PoisonCarolScroll( amount ), amount );
		}
	}
}
