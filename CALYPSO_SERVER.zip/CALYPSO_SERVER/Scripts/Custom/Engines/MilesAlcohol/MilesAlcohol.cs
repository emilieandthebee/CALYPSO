using System; 
using Server; 
using Server.Scripts; 

    namespace Server.Items 
    { 
        public abstract class MilesAlcohol : Item 
        { 
            public Poison m_Poison; 
            public int Highness; 

    [CommandProperty( AccessLevel.GameMaster )] 
        public Poison Poison 
        { 
            get { return m_Poison; } 
            set { m_Poison = value; } 
        } 

        public MilesAlcohol( int itemID ) : base( itemID ) 
        { 
        } 

        public MilesAlcohol( Serial serial ) : base( serial ) 
        { 
        } 

        public override void Serialize( GenericWriter writer ) 
        { 
        base.Serialize( writer ); 
        writer.Write( (int) 0 ); // version 
        Poison.Serialize( m_Poison, writer ); 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
        base.Deserialize( reader ); 

        int version = reader.ReadInt(); 

        switch ( version ) 
        { 
            case 0: 
            { 
            m_Poison = Poison.Deserialize( reader ); 
            break; 
            } 
        } 
    } 
} 

//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class jackdaniels : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public jackdaniels() : base( 0x99F ) 
        { 
        Name = "Bouteille Jacques Dumiel"; 
        this.Weight = 0.1;  
        } 

        public jackdaniels( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( jackdaniels ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You take a swig from the bottle. Public intoxication at its finest." ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" );
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  		} 
    	} 
//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class champagne : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public champagne() : base( 0x99F ) 
        { 
        Name = "Bouteille de Champagnule"; 
        this.Weight = 0.1;  
        } 

        public champagne( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( champagne ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You take a swig from the bottle. The crisp, clear taste is overwhelming." ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" );
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  		} 
    	} 
//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class jimmybean : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public jimmybean() : base( 0x99F ) 
        { 
        Name = "Bouteille de Alcopois"; 
        this.Weight = 0.1;  
        } 

        public jimmybean( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( jimmybean ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You quickly suck down the nasty ass liquor." ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" );
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  		} 
    	} 
//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class rum : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public rum() : base( 0x99F ) 
        { 
        Name = "Bouteille de Rhum"; 
        this.Weight = 0.1;  
        } 

        public rum( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( rum ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You take a swig from the bottle. Yo Ho Yo Ho a pirates life for you?" ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" );
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  		} 
    	} 
//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class Vodka : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public Vodka() : base( 0x99F ) 
        { 
        Name = "Bouteille de Grodegat"; 
        this.Weight = 0.1;  
        } 

        public Vodka( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( Vodka ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You take a swig from the bottle. It burns the hell out of your sinuses!" ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" ); 
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  		} 
    	} 
//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class tequila : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public tequila() : base( 0x99F ) 
        { 
        Name = "Bouteille de Tequitoi"; 
        this.Weight = 0.1;  
        } 

        public tequila( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( tequila ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You take a sip from the bottle. If shit had a taste, this would be it." ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" );
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  		} 
    	} 

//===================================== 

    [FlipableAttribute( 0x99F, 0x99F )] 
    public class moonshine : MilesAlcohol
    { 
        // int hi = 0; // 
    [Constructable] 
        public moonshine() : base( 0x99F ) 
        { 
        Name = "Bouteille de Pleine-Lune"; 
        this.Weight = 0.1;  
        } 

        public moonshine( Serial serial ) : base( serial ) 
        { 
        } 

        public override void OnDoubleClick( Mobile from ) 
        { 
            Container pack = from.Backpack; 
            if (pack != null && pack.ConsumeTotal( typeof( moonshine ), 1 ) ) 
            { 
                if ( from.Body.IsHuman && !from.Mounted ) 
                { 
		from.SendMessage( "You take a swig from the bottle. Your going to regret this tommorrow." ); 
                from.PlaySound( 0x2D6  );
				   
                    if ( Highness >= 6 ) 
                    { 
                        from.Say( "*" + "Hic" );
                        Highness = 0; 
      			} 
                } 
                else 
                { 
                    from.SendMessage( "Your must have the bottle in your pack to drink!" ); 
                    return; 
                } 
            } 
            } 

        public override void Serialize( GenericWriter writer ) 
        { 
            base.Serialize( writer ); 
            writer.Write( (int) 0 ); // version 
        } 

        public override void Deserialize( GenericReader reader ) 
        { 
            base.Deserialize( reader ); 
            int version = reader.ReadInt(); 
  	
        } 
    } 
} 
