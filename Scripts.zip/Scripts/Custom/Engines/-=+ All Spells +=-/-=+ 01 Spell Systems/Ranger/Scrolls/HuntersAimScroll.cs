using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class HuntersAimScroll : SpellScroll
	{
		[Constructable]
		public HuntersAimScroll() : this( 1 )
		{
		}

		[Constructable]
		public HuntersAimScroll( int amount ) : base( 900, 3828, amount )
		{
			Name = "Hunter's Aim";
			Hue = 2001;
		}

		public HuntersAimScroll( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}

		public override Item Dupe( int amount )
		{
			return base.Dupe( new HuntersAimScroll( amount ), amount );
		}
	}
}
