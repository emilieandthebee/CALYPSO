using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class ArmysPaeonScroll : SpellScroll
	{
		[Constructable]
		public ArmysPaeonScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public ArmysPaeonScroll( int amount ) : base( 651, 0x14ED, amount )
		{
			Name = "Armys Paeon sheet music";
			Hue = 0x96;
		}
		
		public ArmysPaeonScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			from.SendMessage( "The sheet music must be in your music book." );
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new ArmysPaeonScroll( amount ), amount );
		}
	}
}
