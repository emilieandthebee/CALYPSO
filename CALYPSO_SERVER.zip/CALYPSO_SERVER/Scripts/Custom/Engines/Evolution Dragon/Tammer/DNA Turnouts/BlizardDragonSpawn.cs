using System; 
using Server.Mobiles;
using Server.Misc; 
using Server.Network; 
using System.Collections; 
using Server.Items; 
using Server.Targeting;

namespace Server.Items 
{ 
   public class BlizardDragonSpawn : Item
   {
      [Constructable]
      public BlizardDragonSpawn() : base( 0xED4 )
      {
			Name = "Blizard Dragon takes 3 Pet Slots";
			ItemID= 8406;
      }

      public override void OnDoubleClick( Mobile from )
      {
         if ( !IsChildOf( from.Backpack ) ) // Make sure its in their pack 
         { 
             from.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it.
		//	 return false; 
         }  
			else if( !from.CheckAlive() )
			{
				from.SendLocalizedMessage( 1060190 );	//You cannot do that while dead!
			}
		 else if ( from.Followers == 3 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
		 else if ( from.Followers == 4 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
		 else if ( from.Followers == 5 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
	//PlayerMobile pm = from as PlayerMobile;
			else if  (from.Skills[SkillName.AnimalTaming].Value > 115.0)
		        {
        		BlizardDragon BlizardDragon = new BlizardDragon();
				from.FixedParticles( 0x373A, 10, 15, 5036, EffectLayer.Head ); 
               from.PlaySound( 710 );
        		BlizardDragon.ControlTarget = from;
        		BlizardDragon.SetControlMaster ( from );
        		BlizardDragon.Location = from.Location;
				BlizardDragon.ControlOrder = OrderType.None;
        		BlizardDragon.Map = from.Map;
        		World.AddMobile( BlizardDragon );
				this.Delete();
				} 
else
{
         from.SendMessage( "You Are Not Certified For use of This pet" );
}
      }

      public BlizardDragonSpawn( Serial serial ) : base( serial )
      {
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );

         writer.Write( (int) 0 ); // version
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );

         int version = reader.ReadInt();
      }
   }
}
