using System;
using Server;
using Server.Engines.Craft;

namespace Server.Items
{
	[FlipableAttribute( 0x13E4, 0x13E3 )]
	public class NecroTool : BaseTool
	{
		public override CraftSystem CraftSystem{ get{ return DefNec.CraftSystem; } }

		[Constructable]
		public NecroTool() : base( 0x13E4 )
		{
			Weight = 8.0;
			ItemID = 3630;
			UsesRemaining = 1;
			Name = "Viagos Necro Tool";
			Hue = 1161;
		}

		[Constructable]
		public NecroTool( int uses ) : base( uses, 0x13E4 )
		{
			Weight = 8.0;
			ItemID = 3630;
			UsesRemaining = 1;
			Name = "Necro Black Magic Tool";
			Hue = 1161;
		}

		public NecroTool( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}