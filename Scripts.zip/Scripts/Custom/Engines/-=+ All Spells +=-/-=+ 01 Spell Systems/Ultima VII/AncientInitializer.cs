using System;
using Server;

namespace Server.Spells
{
	public class AncientInitializer
	{
		public static void Initialize()
		{
			if( Core.AOS )
			{
//--<Ancient Abilities - Start>---------------------------------------------------->
				Register( 340, typeof( Linear.FireworksSpell ) );
				Register( 341, typeof( Linear.GlimmerSpell ) );
				Register( 342, typeof( Linear.AwakenSpell ) );
            	Register( 343, typeof( Linear.ThunderSpell ) );
				Register( 344, typeof( Linear.WeatherSpell ) );
				Register( 345, typeof( Linear.IgniteSpell ) );
				Register( 346, typeof( Linear.DouseSpell ) );
				Register( 348, typeof( First.LocateSpell ) );
				Register( 349, typeof( First.AwakenAllSpell ) );
				Register( 350, typeof( First.DetectTrapSpell ) );
				Register( 351, typeof( First.GreatDouseSpell ) );
				Register( 352, typeof( First.GreatIgniteSpell ) );
				Register( 353, typeof( Second.EnchantSpell ) );
				Register( 354, typeof( Second.FalseCoinSpell ) );
				Register( 355, typeof( Second.GreatLightSpell ) );
				Register( 356, typeof( Second.DestroyTrapSpell ) );
				Register( 357, typeof( Third.SleepSpell ) );
				Register( 358, typeof( Third.SwarmSpell ) );
				Register( 359, typeof( Third.PeerSpell ) );
				Register( 360, typeof( Fourth.SeanceSpell ) );
		    	Register( 361, typeof( Fifth.CharmSpell ) );
				Register( 362, typeof( Fifth.DanceSpell ) );
				Register( 363, typeof( Fifth.MassSleepSpell ) );
				Register( 364, typeof( Sixth.CloneSpell ) );
				Register( 365, typeof( Sixth.CauseFearSpell ) );
				Register( 366, typeof( Sixth.FireRingSpell ) );
				Register( 368, typeof( Sixth.TremorSpell ) );
				Register( 369, typeof( Sixth.SleepFieldSpell ) );
				Register( 370, typeof( Seventh.MassMightSpell ) );
				Register( 372, typeof( Seventh.MassCharmSpell ) );
				Register( 373, typeof( Eighth.InvisibilityAllSpell ) );
				Register( 374, typeof( Eighth.DeathVortexSpell ) );
				Register( 380, typeof( Eighth.MassDeathSpell ) );
				Register( 382, typeof( Eighth.ArmageddonSpell ) );
//--<Ancient Abilities - End>------------------------------------------------------>
			}
		}
		public static void Register( int spellID, Type type )
		{
			SpellRegistry.Register( spellID, type );
		}
	}
}