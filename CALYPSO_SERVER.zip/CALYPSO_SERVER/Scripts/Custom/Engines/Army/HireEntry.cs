using System;
using Server.Mobiles;

namespace Server.ContextMenus
{
	public class HireEntry : ContextMenuEntry
	{
		private Mobile m_From;
		private Mobile m_Hired;

		public HireEntry( Mobile hired, Mobile from ) : base( 6120, 1 )
		{
			m_From = from;
			m_Hired = hired;
		}

		public override void OnClick()
		{
			if ( m_From.Deleted || !m_From.Alive || m_Hired.Deleted || !m_Hired.Alive )
				return;

			if ( (m_From is PlayerMobile) && (m_Hired is BaseCreature) )
			{
				((PlayerMobile)m_From).Hire( (BaseCreature)m_Hired );
			}
		}
	}
}