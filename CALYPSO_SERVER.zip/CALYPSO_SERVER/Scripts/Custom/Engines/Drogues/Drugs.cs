using System; 
using Server; 
using Server.Scripts; 
using Server.Items;

namespace Server.Items 
{ 
   public abstract class Drug : Item 
   { 
      public Poison m_Poison; 
      public int Highness;// 

      [CommandProperty( AccessLevel.GameMaster )] 
      public Poison Poison 
      { 
         get { return m_Poison; } 
         set { m_Poison = value; } 
      } 

      public Drug( int itemID ) : base( itemID ) 
      { 
      } 

      public Drug( Serial serial ) : base( serial ) 
      { 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
         Poison.Serialize( m_Poison, writer ); 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 

         switch ( version ) 
         { 
            case 0: 
            { 
               m_Poison = Poison.Deserialize( reader ); 
               break; 
            } 
         } 
      } 
   } 

   [FlipableAttribute( 0xE28, 0xF00 )] 
   public class WaterBong : Drug 
   { 

      [Constructable] 
      public WaterBong() : base( 0xE28 ) 
      { 
         Name = "a water bong";
         this.Weight = 0.0;
         this.Hue = 1289;
      } 

      public WaterBong( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 

         if (pack != null && pack.ConsumeTotal( typeof( Marijuana ), 1 ) ) 
         { 
            if ( from.Body.IsHuman && !from.Mounted ) 
            { 
               from.Animate( 34, 5, 1, true, false, 0 ); 
            } 
            from.PlaySound( Utility.Random( 0x20, 2 ) ); 
            from.SendMessage( "You pack a bowl and light it." ); 
            ++Highness; 
            if ( Highness >= 6 ) 
            { 
			switch ( Utility.Random( 4 ))
			{
				case 0: from.Say( "*" + from.Name + " begins to cough uncontrollably*" );
					from.PlaySound( 0x420 );
				break;
				case 1: from.Say( "*" + from.Name + " takes a HUGE hit*" );
					from.SendMessage( "You're stoned out of your gorde!" );
				break;
				case 2: if (!from.Female)
					{
						from.Say( "*" + from.Name + " tokes on his bong*" );
					}
					else
					{
						from.Say( "*" + from.Name + " tokes on her bong*" );
					}
						
				break;
				case 3: from.Say( "*" + from.Name + " smokes some herb*" );
					if ( from.Female )
					{
						from.PlaySound( 794 );
						from.Say( "*laughs*" );
					}
					else if ( !from.Female )
					{
						from.PlaySound( 1066 );
						from.Say( "*laughs*" );
					}
				break;
			}
               Highness = Highness - 2; 
            } 
         } 
         else 
         { 
            from.SendMessage( "You do not have enough betteuse" ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //===================================== 

   [FlipableAttribute( 0x1AA2, 0xF00 )] 
   public class Joint : Drug 
   { 
//      int hi = 0;   // 
      [Constructable] 
      public Joint() : base( 0x1420 ) 
      { 
         Name = "a joint"; 
         this.Weight = 0.0;            //this is for future additions... 
         this.Hue = 1153; 
      } 

      public Joint( Serial serial ) : base( serial ) 
      { 
      } 

            public override void OnDoubleClick( Mobile from ) 
            { 
               Container pack = from.Backpack; 
       
               if (pack != null && pack.ConsumeTotal( typeof( Joint ), 1 ) ) 
               { 
                  if ( from.Body.IsHuman && !from.Mounted ) 
                  { 
                     from.Animate( 34, 5, 1, true, false, 0 ); 
                  } 
                  from.SendMessage( "You whip out your lighter and spark up the doobie." ); 
 		  from.FixedParticles( 0x3728, 10, 30, 5052, EffectLayer.Head ); 
                  from.PlaySound( 0x226 ); 
                  ++Highness; 
                  ++Highness; 
                  ++Highness; 
                     if ( Highness >= 6 ) 
                     { 
                        from.Say( "*" + from.Name + " begins to cough uncontrollably*" ); 
                        from.SendMessage( "You are stoned!" ); 
                        Highness = 0; 
                     } 
               } 
               else 
               { 
                  from.SendMessage( "Your must have the doobie in your pack to spark it!" ); 
                  return; 
               } 
            } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   [FlipableAttribute( 0x1AA2, 0xF00 )] 
   public class Cigarette : Drug 
   { 
//      int hi = 0;   // 
      [Constructable] 
      public Cigarette() : base( 0x1420 ) 
      { 
         Name = "a cigarette"; 
         this.Weight = 0.0;            //this is for future additions... 
         this.Hue = 1153; 
      } 

      public Cigarette( Serial serial ) : base( serial ) 
      { 
      } 

	public override void OnDoubleClick( Mobile from ) 
	{ 
		Container pack = from.Backpack; 
       
		if (pack != null && pack.ConsumeTotal( typeof( Cigarette ), 1 ) ) 
		{ 
			if ( from.Body.IsHuman && !from.Mounted ) 
			{ 
				from.Animate( 34, 5, 1, true, false, 0 ); 
			} 
			from.SendMessage( "You smoke the cigarette." ); 
			from.FixedParticles( 0x3728, 10, 30, 5052, EffectLayer.Head ); 
                	from.PlaySound( 0x226 ); 
		} 
		else 
		{ 
			from.SendMessage( "This must be in your pack to use it!" ); 
			return; 
		} 
	} 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //================================= 
   [FlipableAttribute( 0x1AA2, 0xF00 )] 
   public class RollingPaper : Drug 
   { 

      [Constructable] 
      public RollingPaper() : base( 0xFEF ) 
      { 
         Name = "a pack of rastafarian rolling papers"; 
         this.Weight = 0.0; 
         this.Hue = 1153; 
      } 

      public RollingPaper( Serial serial ) : base( serial ) 
      { 
      } 

            public override void OnDoubleClick( Mobile from ) 
            { 
               Container pack = from.Backpack; 
       
               if (pack != null && pack.ConsumeTotal( typeof( Marijuana ), 3 ) ) 
               { 
                  from.SendMessage( "You roll a joint." ); 
                  from.AddToBackpack( new Joint() ); 
               } 
               else 
               { 
                  from.SendMessage( "Your need more betteuse." ); 
                  return; 
               } 
            } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //============ 

   [FlipableAttribute( 0xD16, 0xF00 )] 
   public class Shroom : Drug 
   { 

      [Constructable] 
      public Shroom() : base( 0xD16 ) 
      { 
         Name = "a psychadelic mushroom"; 
         this.Weight = 0.0; 
         this.Hue = 1289; 
      } 

      public Shroom( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( Shroom ), 1 ) ) 
         { 
            if ( from.Body.IsHuman && !from.Mounted ) 
            { 
               from.Animate( 34, 5, 1, true, false, 0 ); 
            } 
            from.PlaySound( Utility.Random( 0x3A, 3 ) );   // random eating noise 
            from.SendMessage( "You break off the stem and eat the funky colored cap." ); 
            from.SendMessage( "You feel yourself beginning to trip mildly!"); 
         } 
         else 
         { 
            from.SendMessage( "Your out of shrooms bro!" ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 
//============== 
   [FlipableAttribute( 0xE7A, 0xF00 )] 
   public class BoxOfPhillies : Drug 
   { 

      [Constructable] 
      public BoxOfPhillies() : base( 0xE7A ) 
      { 
         Name = "A Box of Phillie Blunts"; 
         this.Weight = 0.0; 
         this.Hue = 542; 
      } 

      public BoxOfPhillies( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( BoxOfPhillies ), 1 ) ) 
         { 
            from.SendMessage( "You take the blunts out of the box." ); 
               for ( int i = 0; i < 5; ++i ) 
                  from.AddToBackpack( new PhillieBlunt() ); 
         } 
         else 
         { 
            from.SendMessage( "Your need more blunts!" ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //=========== 

   [FlipableAttribute( 0x1BE0, 0xF00 )] 
   public class Blunt : Drug 
   { 

      [Constructable] 
      public Blunt() : base( 0x1BE0 ) 
      { 
         Name = "a Huge Blunt"; 
         this.Weight = 0.0; 
         this.Hue = 542; 
      } 

      public Blunt( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( Blunt ), 1 ) ) 
         { 
            if ( from.Body.IsHuman && !from.Mounted ) 
            { 
               from.Animate( 34, 5, 1, true, false, 0 ); 
            } 
            from.SendMessage( "You pull out your lighter and spark up the blunt." ); 
            from.PlaySound( 0x226 );   // flame 
            ++Highness; 
            ++Highness; 
            ++Highness; 
            ++Highness; 
            ++Highness; 
            ++Highness; 
            if ( Highness >= 6 ) 
            { 
               from.Say( "*" + from.Name + " begins to cough uncontrollably*" ); 
               from.SendMessage( "You are now stoned!" ); 
               Highness = 0; 
            } 
         } 
         else 
         { 
            from.SendMessage( "This must be in your pack to use it!" ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //============= 

   [FlipableAttribute( 0x1915, 0xF00 )] 
   public class PhillieBluntWrapper : Drug 
   { 

      [Constructable] 
      public PhillieBluntWrapper() : base( 0x1915 ) 
      { 
         Name = "a cut up blunt"; 
         this.Weight = 0.0; 
         this.Hue = 542; 
      } 

      public PhillieBluntWrapper( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( Marijuana ), 6 ) && pack.ConsumeTotal( typeof( PhillieBluntWrapper ), 1 ) ) 
         { 
            from.SendMessage( "You fill the broken blunt with pot, therefore fixing it." ); 
            from.AddToBackpack( new Blunt() ); 
         } 
         else 
         { 
            from.SendMessage( "You need more green bro!" ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //=============== 

   [FlipableAttribute( 0xF8A, 0xF00 )] 
   public class PhillieBlunt : Drug 
   { 

      [Constructable] 
      public PhillieBlunt() : base( 0xF8A ) 
      { 
         Name = "a Phillie Blunt"; 
         this.Weight = 0.0; 
         this.Hue = 542; 
      } 

      public PhillieBlunt( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( PhillieBlunt ), 1 ) ) 
         { 
            from.SendMessage( "You break open the blunt and are left with the exterior." ); 
            from.AddToBackpack( new PhillieBluntWrapper() ); 
         } 
         else 
         { 
            from.SendMessage( "Your out of blunts bro!" ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   //===================================== 

   [FlipableAttribute( 0x099B, 0x099B )] 
   public class EmptyAlcoholBottle : Item 
   { 

      [Constructable] 
      public EmptyAlcoholBottle() : base( 0x099B ) 
      { 
         Name = "empty bottle"; 
         this.Weight = 0.0; 
      } 

      public EmptyAlcoholBottle( Serial serial ) : base( serial ) 
      { 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   [FlipableAttribute( 0x18E5, 0x18E6 )] 
   public class Marijuana : Item 
   { 

      [Constructable] 
      public Marijuana() : base( 0x18E5 ) 
      { 
         Name = "Betteuse"; 
         this.Weight = 0.0; 
      } 

      public Marijuana( Serial serial ) : base( serial ) 
      { 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   [FlipableAttribute( 0x0C60, 0x0C60 )] 
   public class Tobacco : Item 
   { 

      [Constructable] 
      public Tobacco() : base( 0x0C60 ) 
      { 
         Name = "Tabac"; 
         this.Weight = 0.0; 
	 this.Hue = 2601;
      } 

      public Tobacco( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( Tobacco ), 5 ) && pack.ConsumeTotal( typeof( RollingPaper ), 1 ) ) 
         { 
            from.SendMessage( "You roll a cigarette and place it in your pack." ); 
	      from.AddToBackpack( new Cigarette() );
         } 
         else 
         { 
            from.SendMessage( "You do not have the required ingredients." ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 

   [FlipableAttribute( 0x1AA2, 0x1AA2 )] 
   public class Hops : Item 
   { 

      [Constructable] 
      public Hops() : base( 0x1AA2 ) 
      { 
         Name = "Mielesse"; 
         this.Weight = 0.0; 
      } 

      public Hops( Serial serial ) : base( serial ) 
      { 
      } 

      public override void OnDoubleClick( Mobile from ) 
      { 
         Container pack = from.Backpack; 
       
         if (pack != null && pack.ConsumeTotal( typeof( Hops ), 5 ) && pack.ConsumeTotal( typeof( SpringWater ), 1 ) && pack.ConsumeTotal( typeof( EmptyAlcoholBottle ), 1 ) ) 
         { 
            from.SendMessage( "You successfully brew a bottle of ale of mielesse." ); 
	      from.AddToBackpack( new BeverageBottle(BeverageType.Ale) );
         } 
         else 
         { 
            from.SendMessage( "You do not have the required ingredients." ); 
            return; 
         } 
      } 

      public override void Serialize( GenericWriter writer ) 
      { 
         base.Serialize( writer ); 

         writer.Write( (int) 0 ); // version 
      } 

      public override void Deserialize( GenericReader reader ) 
      { 
         base.Deserialize( reader ); 

         int version = reader.ReadInt(); 
      } 
   } 
}