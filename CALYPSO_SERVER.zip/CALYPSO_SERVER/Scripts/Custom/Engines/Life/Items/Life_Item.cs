/*
 * Class that allow to create Items that will
 * not be deleted using the regular way.
 * It is useful when a staff use the wipe command
 * and accidently select an item.
 * You cannot override the Delete() method of a class that inherit from Life_Item
 */

using System;
using System.Collections;
using Server.Items;
using Server.Mobiles;
using Server.ContextMenus; 

namespace Server.Items
{	
	public class Life_Item : Item
	{

		private bool m_CanBeDeleted;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public bool CanBeDeleted { get { return m_CanBeDeleted; } set { m_CanBeDeleted = value; } }
	
		public Life_Item(int id) : base( id )
		{
			CanBeDeleted=true;
		}
		public Life_Item() : base()
		{
			CanBeDeleted=true;
		}

		public Life_Item( Serial serial ) : base( serial )
		{
		}

		public override void Delete()
		{
			if (CanBeDeleted)
				base.Delete();
		}

		public void ReallyDelete()
		{
			base.Delete();
		}

		public override void GetContextMenuEntries( Mobile from, ArrayList list )
		{
			base.GetContextMenuEntries( from, list );
			if (from.AccessLevel >= AccessLevel.GameMaster )
				list.Add( new DeleteThisEntry( from, this ) );
		}
		
		public override void Serialize( GenericWriter writer )
    	{
        	base.Serialize( writer );
        	writer.Write( (int) 1 );
        	writer.Write( CanBeDeleted );
    	}
		
		public override void Deserialize(GenericReader reader)
		{        
			base.Deserialize( reader );
			int version = reader.ReadInt();
			switch ( version )
			{
				case 1:
				{
					CanBeDeleted = reader.ReadBool();
					break;
				}
			}
		}
		
		//////////// CONTEXT /////////////
		public class  DeleteThisEntry : ContextMenuEntry
		{
			private Mobile       m_From;
			private Life_Item    m_Life_Item;
			public DeleteThisEntry(Mobile from,Life_Item lifeitem):base(408,100)
			{
				m_Life_Item=lifeitem;
				m_From=from;
			}
			public override void OnClick()
			{
				m_Life_Item.ReallyDelete();
			}
		}
	}
}
