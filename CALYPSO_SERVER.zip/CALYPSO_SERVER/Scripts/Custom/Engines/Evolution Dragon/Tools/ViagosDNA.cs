using System;
using Server;
using Server.Engines.Craft;

namespace Server.Items
{
	[FlipableAttribute( 0x13E4, 0x13E3 )]
	public class DNAPoolMixer : BaseTool
	{
		public override CraftSystem CraftSystem{ get{ return DefDNA.CraftSystem; } }

		[Constructable]
		public DNAPoolMixer() : base( 0x1812 )
		{
			Weight = 8.0;
			ItemID = 0x1812;
			UsesRemaining = 1;
			Name = "DNA Pool Mixer";
			Hue = 33;
		}

		[Constructable]
		public DNAPoolMixer( int uses ) : base( uses, 0x1812 )
		{
			Weight = 8.0;
			ItemID = 4981;
			UsesRemaining = 1;
			Name = "DNA Pool Mixer";
			Hue = 33;
		}

		public DNAPoolMixer( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}