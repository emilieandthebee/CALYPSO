using System;
using Server;
using Server.Gumps;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Targeting;
using System.Collections;
using Server.Scripts.Commands;
using Server.Prompts;
using Server.Guilds;

namespace Server.Gumps
{
    public class GM : Gump
    {
        Mobile from;
		miniGM stone;
		int context;
		bool help;
		bool debug;
		Guild TG = null;
		Guild NS = null;
		Guild CA = null;
		Guild AA = null;

        public GM(Mobile mfrom, miniGM mstone, int mcontext, bool mdebug) : base( 0, 0 )
        {
            from = mfrom;
			stone = mstone;
			context = mcontext;
			debug = mdebug;

            this.Closable=debug;
			this.Disposable=debug;
			this.Dragable=true;
			this.Resizable=false;

			if (debug) System.Console.WriteLine("GM GUMP: CONTEXT {0}",context);

// 1: TELEPORT
// 2: ADD MOBILE
// 3: ADD ITEM
// 4: MOBILE CONTROL
// 5: ITEM PROPERTIES
// 6: GUILDS MANAGEMENT
// 7: SAY
// 8: BROADCAST			
			
			AddPage(0);
			AddBackground(8, 37, 38, 246, 9200);
			AddButton(16, 72, 2225, 2225, (int)Buttons.B1, GumpButtonType.Reply, 0);
			AddButton(16, 99, 2226, 2226, (int)Buttons.B2, GumpButtonType.Reply, 0);
			AddButton(16, 126, 2227, 2227, (int)Buttons.B3, GumpButtonType.Reply, 0);
			AddButton(16, 153, 2228, 2228, (int)Buttons.B4, GumpButtonType.Reply, 0);
			AddButton(16, 180, 2229, 2229, (int)Buttons.B5, GumpButtonType.Reply, 0);
			AddButton(16, 207, 2230, 2230, (int)Buttons.B6, GumpButtonType.Reply, 0);
			AddButton(16, 234, 2231, 2231, (int)Buttons.B7, GumpButtonType.Reply, 0);
			AddButton(16, 261, 2232, 2232, (int)Buttons.B8, GumpButtonType.Reply, 0);
			if (context>=0)
				AddButton(15, 44, 5540, 5541, (int)Buttons.EXPAND, GumpButtonType.Reply, 0);
			else	
			{
				AddButton(15, 44, 5537, 5538, (int)Buttons.EXPAND, GumpButtonType.Reply, 0);
				AddBackground(48, 37, 163, 246, 9200);
				TimeSpan temps=DateTime.Now-DateTime.Now;
				if (ShardControler.TheShardControlerStone != null)
					temps = ShardControler.TheShardControlerStone.GMNextTime - DateTime.Now;
				AddLabel(56, 45, 0, String.Format("{0:D2}:{1:D2}:{2:D2}", temps.Hours, temps.Minutes, temps.Seconds));
				AddButton(140, 46, 2009, 2010, (int)Buttons.LOGOUT, GumpButtonType.Reply, 0);
				AddLabel(54, 73, 0, @"Se téléporter");
				AddLabel(54, 100, 0, @"Ajouter une creature");
				AddLabel(54, 126, 0, @"Ajouter un objet");
				AddLabel(54, 154, 0, @"Controler une creature");
				AddLabel(55, 180, 0, @"Propriétés d'un objet");
				AddLabel(54, 206, 0, @"Gerer les guildes");
				AddLabel(55, 235, 0, @"Faire parler");
				AddLabel(55, 259, 0, @"Message à tous");
			}
			
			switch (context)
			{
//TELEPORT
				case 1:
				{					
					AddBackground(49, 38, 372, 275, 9200);
					AddButton(54, 47, 9904, 9903, (int)Buttons.GOTO1, GumpButtonType.Reply, 0);
					AddLabel(80, 48, 0, @"Chambre des acteurs");
					AddButton(54, 72, 9904, 9903, (int)Buttons.GOTO2, GumpButtonType.Reply, 0);
					AddLabel(80, 73, 0, @"Halerouine");
					AddButton(54, 96, 9904, 9903, (int)Buttons.GOTO3, GumpButtonType.Reply, 0);
					AddLabel(80, 97, 0, @"Yeletia");
					AddButton(54, 121, 9904, 9903, (int)Buttons.GOTO4, GumpButtonType.Reply, 0);
					AddLabel(80, 122, 0, @"Tregok");
					AddButton(54, 148, 9904, 9903, (int)Buttons.GOTO5, GumpButtonType.Reply, 0);
					AddLabel(80, 149, 0, @"Beyclare");
					AddButton(54, 173, 9904, 9903, (int)Buttons.GOTO6, GumpButtonType.Reply, 0);
					AddLabel(80, 174, 0, @"Periote");
					AddButton(54, 197, 9904, 9903, (int)Buttons.GOTO7, GumpButtonType.Reply, 0);
					AddLabel(80, 198, 0, @"Eli'Tiriel");
					AddButton(54, 222, 9904, 9903, (int)Buttons.GOTO8, GumpButtonType.Reply, 0);
					AddLabel(80, 223, 0, @"Eli'Magdiel");
					AddButton(54, 247, 9904, 9903, (int)Buttons.GOTO9, GumpButtonType.Reply, 0);
					AddLabel(80, 248, 0, @"Iles Morgos");
					AddButton(226-20, 50, 5540, 5541, (int)Buttons.SETGOTO11, GumpButtonType.Reply, 0);
					AddButton(225-20, 75, 5540, 5541, (int)Buttons.SETGOTO12, GumpButtonType.Reply, 0);
					AddButton(225-20, 99, 5540, 5541, (int)Buttons.SETGOTO13, GumpButtonType.Reply, 0);
					AddButton(225-20, 124, 5540, 5541, (int)Buttons.SETGOTO14, GumpButtonType.Reply, 0);
					AddButton(225-20, 151, 5540, 5541, (int)Buttons.SETGOTO15, GumpButtonType.Reply, 0);
					AddButton(225-20, 176, 5540, 5541, (int)Buttons.SETGOTO16, GumpButtonType.Reply, 0);
					AddButton(224-20, 200, 5540, 5541, (int)Buttons.SETGOTO17, GumpButtonType.Reply, 0);
					AddButton(224-20, 225, 5540, 5541, (int)Buttons.SETGOTO18, GumpButtonType.Reply, 0);
					AddButton(224-20, 250, 5540, 5541, (int)Buttons.SETGOTO19, GumpButtonType.Reply, 0);
					AddButton(226, 50, 9904, 9903, (int)Buttons.GOTO11, GumpButtonType.Reply, 0);
					AddButton(225, 75, 9904, 9903, (int)Buttons.GOTO12, GumpButtonType.Reply, 0);
					AddButton(225, 99, 9904, 9903, (int)Buttons.GOTO13, GumpButtonType.Reply, 0);
					AddButton(225, 124, 9904, 9903, (int)Buttons.GOTO14, GumpButtonType.Reply, 0);
					AddButton(225, 151, 9904, 9903, (int)Buttons.GOTO15, GumpButtonType.Reply, 0);
					AddButton(225, 176, 9904, 9903, (int)Buttons.GOTO16, GumpButtonType.Reply, 0);
					AddButton(224, 200, 9904, 9903, (int)Buttons.GOTO17, GumpButtonType.Reply, 0);
					AddButton(224, 225, 9904, 9903, (int)Buttons.GOTO18, GumpButtonType.Reply, 0);
					AddButton(224, 250, 9904, 9903, (int)Buttons.GOTO19, GumpButtonType.Reply, 0);
					AddImage(252, 49, 2440);
					AddTextEntry(260, 51, 147, 20, 0, (int)Buttons.SETGOTO11ENTRY, stone.LocationName11);
					AddImage(252, 75, 2440);
					AddTextEntry(260, 77, 147, 20, 0, (int)Buttons.SETGOTO12ENTRY, stone.LocationName12);
					AddImage(252, 99, 2440);
					AddTextEntry(260, 101, 147, 20, 0, (int)Buttons.SETGOTO13ENTRY, stone.LocationName13);
					AddImage(252, 123, 2440);
					AddTextEntry(260, 125, 147, 20, 0, (int)Buttons.SETGOTO14ENTRY, stone.LocationName14);
					AddImage(252, 148, 2440);
					AddTextEntry(260, 150, 147, 20, 0, (int)Buttons.SETGOTO15ENTRY, stone.LocationName15);
					AddImage(252, 174, 2440);
					AddTextEntry(260, 176, 147, 20, 0, (int)Buttons.SETGOTO16ENTRY, stone.LocationName16);
					AddImage(252, 199, 2440);
					AddTextEntry(261, 200, 147, 20, 0, (int)Buttons.SETGOTO17ENTRY, stone.LocationName17);
					AddImage(252, 223, 2440);
					AddTextEntry(260, 225, 147, 20, 0, (int)Buttons.SETGOTO18ENTRY, stone.LocationName18);
					AddImage(252, 247, 2440);
					AddTextEntry(260, 249, 147, 20, 0, (int)Buttons.SETGOTO19ENTRY, stone.LocationName19);

					AddLabel(80, 275, 0, @"Teleporter au CLIC!");
					AddButton(54, 275, 9904, 9903, (int)Buttons.TELEPORT, GumpButtonType.Reply, 0);
					if ((stone.ToPlayer == null) || (stone.ToPlayer.NetState == null) )
					{
						stone.ToPlayer = null;
						ArrayList states = NetState.Instances;
						int count = states.Count;
						bool found =false;
						for ( int i = 0; ((i < count) && !found); ++i )
						{
							NetState ns = (NetState)states[i];
							Mobile mob = ns.Mobile;
							if (mob.AccessLevel == AccessLevel.Player)
							{
								stone.ToPlayer = mob;
								found = true;
							}
						}
					}
					if (stone.ToPlayer == null)
					{
						AddLabel(260, 275, 0, @"(aucun joueur)");
					} else {
						AddLabel(260, 275, 0, stone.ToPlayer.Name);
						AddButton(224, 275, 9904, 9903, (int)Buttons.TOPLAYER, GumpButtonType.Reply, 0);
					}
					AddButton(224-20, 275, 5540, 5541, (int)Buttons.NEXTPLAYER, GumpButtonType.Reply, 0);
				}
					break;
//ADD MOBILE
				case 2:
				{
					AddBackground(51, 38, 322, 245, 9200);
					AddButton(56, 96, 9904, 9903, (int)Buttons.MOBCAT1, GumpButtonType.Reply, 0);
					AddLabel(82-3, 97, 0, @"Humains");
//					AddButton(56, 121, 9904, 9903, (int)Buttons.MOBCAT2, GumpButtonType.Reply, 0);
//					AddLabel(82-3, 122, 0, @"N/A");
					AddButton(56+100-25, 96, 9904, 9903, (int)Buttons.MOBCAT3, GumpButtonType.Reply, 0);
					AddLabel(82-3+100-25, 97, 0, @"Animaux communs");
					AddButton(56+100-25, 121, 9904, 9903, (int)Buttons.MOBCAT4, GumpButtonType.Reply, 0);
					AddLabel(82-3+100-25, 122, 0, @"Animaux Calypso");
					AddButton(56+200, 96, 9904, 9903, (int)Buttons.MOBCAT5, GumpButtonType.Reply, 0);
					AddLabel(82-3+200, 97, 0, @"Monstres");
					AddButton(56+200, 121, 9904, 9903, (int)Buttons.MOBCAT6, GumpButtonType.Reply, 0);
					AddLabel(82-3+200, 122, 0, @"Infranevralgie");
					AddImage(87, 151+32, 1141, 5);
					int MaxIndex;
					string textM2="";
					string textM1="";
					string textZ="";
					string textP1="";
					string textP2="";
					switch(stone.MOBCAT)
					{
						case (int)Buttons.MOBCAT1: 
							MaxIndex=miniGM.m_MobilesMenu1.Length;
							if (stone.MobileIndex-2>=0) textM2=miniGM.m_MobilesMenu1[stone.MobileIndex-2];
							if (stone.MobileIndex-1>=0) textM1=miniGM.m_MobilesMenu1[stone.MobileIndex-1];
							textZ=miniGM.m_MobilesMenu1[stone.MobileIndex];
							if (stone.MobileIndex+1<MaxIndex) textP1=miniGM.m_MobilesMenu1[stone.MobileIndex+1];
							if (stone.MobileIndex+2<MaxIndex) textP2=miniGM.m_MobilesMenu1[stone.MobileIndex+2];
							break;
						case (int)Buttons.MOBCAT2:
							MaxIndex=miniGM.m_MobilesMenu2.Length;
							if (stone.MobileIndex-2>=0) textM2=miniGM.m_MobilesMenu2[stone.MobileIndex-2];
							if (stone.MobileIndex-1>=0) textM1=miniGM.m_MobilesMenu2[stone.MobileIndex-1];
							textZ=miniGM.m_MobilesMenu2[stone.MobileIndex];
							if (stone.MobileIndex+1<MaxIndex) textP1=miniGM.m_MobilesMenu2[stone.MobileIndex+1];
							if (stone.MobileIndex+2<MaxIndex) textP2=miniGM.m_MobilesMenu2[stone.MobileIndex+2];
							break;
						case (int)Buttons.MOBCAT3:
							MaxIndex=miniGM.m_MobilesMenu3.Length;
							if (stone.MobileIndex-2>=0) textM2=miniGM.m_MobilesMenu3[stone.MobileIndex-2];
							if (stone.MobileIndex-1>=0) textM1=miniGM.m_MobilesMenu3[stone.MobileIndex-1];
							textZ=miniGM.m_MobilesMenu3[stone.MobileIndex];
							if (stone.MobileIndex+1<MaxIndex) textP1=miniGM.m_MobilesMenu3[stone.MobileIndex+1];
							if (stone.MobileIndex+2<MaxIndex) textP2=miniGM.m_MobilesMenu3[stone.MobileIndex+2];
							break;
						case (int)Buttons.MOBCAT4: 
							MaxIndex=miniGM.m_MobilesMenu4.Length;
							if (stone.MobileIndex-2>=0) textM2=miniGM.m_MobilesMenu4[stone.MobileIndex-2];
							if (stone.MobileIndex-1>=0) textM1=miniGM.m_MobilesMenu4[stone.MobileIndex-1];
							textZ=miniGM.m_MobilesMenu4[stone.MobileIndex];
							if (stone.MobileIndex+1<MaxIndex) textP1=miniGM.m_MobilesMenu4[stone.MobileIndex+1];
							if (stone.MobileIndex+2<MaxIndex) textP2=miniGM.m_MobilesMenu4[stone.MobileIndex+2];
							break;
						case (int)Buttons.MOBCAT5: 
							MaxIndex=miniGM.m_MobilesMenu5.Length;
							if (stone.MobileIndex-2>=0) textM2=miniGM.m_MobilesMenu5[stone.MobileIndex-2];
							if (stone.MobileIndex-1>=0) textM1=miniGM.m_MobilesMenu5[stone.MobileIndex-1];
							textZ=miniGM.m_MobilesMenu5[stone.MobileIndex];
							if (stone.MobileIndex+1<MaxIndex) textP1=miniGM.m_MobilesMenu5[stone.MobileIndex+1];
							if (stone.MobileIndex+2<MaxIndex) textP2=miniGM.m_MobilesMenu5[stone.MobileIndex+2];
							break;
						case (int)Buttons.MOBCAT6: 
							MaxIndex=miniGM.m_MobilesMenu6.Length;
							if (stone.MobileIndex-2>=0) textM2=miniGM.m_MobilesMenu6[stone.MobileIndex-2];
							if (stone.MobileIndex-1>=0) textM1=miniGM.m_MobilesMenu6[stone.MobileIndex-1];
							textZ=miniGM.m_MobilesMenu6[stone.MobileIndex];
							if (stone.MobileIndex+1<MaxIndex) textP1=miniGM.m_MobilesMenu6[stone.MobileIndex+1];
							if (stone.MobileIndex+2<MaxIndex) textP2=miniGM.m_MobilesMenu6[stone.MobileIndex+2];
							break;
						default:
							break;
					}
					AddLabel(102, 111+32, 1071, textM2);
					AddLabel(102, 131+32, 1149, textM1);
					AddLabel(102, 154+32, 1149, textZ);
					AddLabel(102, 178+32, 1149, textP1);
					AddLabel(102, 198+32, 1071, textP2);
					AddButton(60, 186+32-10, 9907, 9906, (int)Buttons.MOBDOWN_BTN, GumpButtonType.Reply, 0);
					AddButton(60, 129+32+10, 9901, 9900, (int)Buttons.MOBUP_BTN, GumpButtonType.Reply, 0);
					AddLabel(60, 73, 0, @"Nom (optional):");
					AddImage(193, 71, 2440);
					AddTextEntry(201, 73, 147, 20, 0, (int)Buttons.MOBNAME, stone.MobileName);
					AddButton(290, 245, 247, 248, (int)Buttons.MOBOK, GumpButtonType.Reply, 0);
					AddLabel(59, 45, 1194, @"AJOUTER UN NPC");
					AddCheck(63, 253, 210, 211, stone.InactiveMobile, (int)Buttons.MDISABLED);
					AddLabel(90, 254, 0, @"Inactif");
					AddCheck(163, 253, 210, 211, stone.BadGuys, (int)Buttons.MBADGUYSCHECK);
					AddLabel(190, 254, 0, @"Groupe agressif");
				}
					break;
//ADD ITEM
				case 3:
				{
					AddBackground(51, 38, 322, 245, 9200);
					AddButton(56, 96, ((stone.ItemLevel==1)?211:210), ((stone.ItemLevel==1)?211:210), (int)Buttons.ITCAT1, GumpButtonType.Reply, 0);
					AddLabel(82-3, 97, 0, @"LEVEL 1");
					AddButton(56, 121, ((stone.ItemLevel==2)?211:210), ((stone.ItemLevel==2)?211:210), (int)Buttons.ITCAT2, GumpButtonType.Reply, 0);
					AddLabel(82-3, 122, 0, @"LEVEL 2");
					AddButton(56+100, 96, ((stone.ItemLevel==3)?211:210), ((stone.ItemLevel==3)?211:210), (int)Buttons.ITCAT3, GumpButtonType.Reply, 0);
					AddLabel(82-3+100, 97, 0, @"LEVEL 3");
					AddButton(56+100, 121, ((stone.ItemLevel==4)?211:210), ((stone.ItemLevel==4)?211:210), (int)Buttons.ITCAT4, GumpButtonType.Reply, 0);
					AddLabel(82-3+100, 122, 0, @"LEVEL 4");
					AddButton(56+200, 96, ((stone.ItemLevel==5)?211:210), ((stone.ItemLevel==5)?211:210), (int)Buttons.ITCAT5, GumpButtonType.Reply, 0);
					AddLabel(82-3+200, 97, 0, @"LEVEL 5");
					AddButton(56+200, 121, ((stone.ItemLevel==6)?211:210), ((stone.ItemLevel==6)?211:210), (int)Buttons.ITCAT6, GumpButtonType.Reply, 0);
					AddLabel(82-3+200, 122, 0, @"LEVEL 6");
					AddImage(87, 151+32, 1141, 5);
					int MaxIndex;
					string textM2="";
					string textM1="";
					string textZ="";
					string textP1="";
					string textP2="";
					MaxIndex=miniGM.m_ItemsMenu1.Length;
					if (stone.ItemIndex-2>=0) textM2=miniGM.m_ItemsMenu1[stone.ItemIndex-2];
					if (stone.ItemIndex-1>=0) textM1=miniGM.m_ItemsMenu1[stone.ItemIndex-1];
					textZ=miniGM.m_ItemsMenu1[stone.ItemIndex];
					if (stone.ItemIndex+1<MaxIndex) textP1=miniGM.m_ItemsMenu1[stone.ItemIndex+1];
					if (stone.ItemIndex+2<MaxIndex) textP2=miniGM.m_ItemsMenu1[stone.ItemIndex+2];
					AddLabel(102, 111+32, 1071, textM2);
					AddLabel(102, 131+32, 1149, textM1);
					AddLabel(102, 154+32, 1149, textZ);
					AddLabel(102, 178+32, 1149, textP1);
					AddLabel(102, 198+32, 1071, textP2);
					AddButton(60, 186+32-10, 9907, 9906, (int)Buttons.ITDOWN_BTN, GumpButtonType.Reply, 0);
					AddButton(60, 129+32+10, 9901, 9900, (int)Buttons.ITUP_BTN, GumpButtonType.Reply, 0);
					AddLabel(60, 73, 0, @"Nom (optional):");
					AddImage(193, 71, 2440);
					AddTextEntry(201, 73, 147, 20, 0, (int)Buttons.ITNAME, stone.ItemName);
					AddButton(290, 245, 247, 248, (int)Buttons.ITOK, GumpButtonType.Reply, 0);
					AddLabel(59, 45, 1194, @"AJOUTER UN OBJET");
					}
					break;
//CONTROL MOBILE
				case 4:
				{
					AddBackground(49, 37-3, 347, 246+6+20, 9200);
					AddButton(109, 89, 4500, 4500, (int)Buttons.UP, GumpButtonType.Reply, 0);
					AddButton(158, 87, 4501, 4501, (int)Buttons.NORTH, GumpButtonType.Reply, 0);
					AddButton(155, 140, 4502, 4502, (int)Buttons.RIGHT, GumpButtonType.Reply, 0);
					AddButton(153, 196, 4503, 4503, (int)Buttons.EAST, GumpButtonType.Reply, 0);
					AddButton(107, 194, 4504, 4504, (int)Buttons.DOWN, GumpButtonType.Reply, 0);
					AddButton(56, 198, 4505, 4505, (int)Buttons.SOUTH, GumpButtonType.Reply, 0);
					AddButton(57, 140, 4506, 4506, (int)Buttons.LEFT, GumpButtonType.Reply, 0);
					AddButton(55, 87, 4507, 4507, (int)Buttons.WEST, GumpButtonType.Reply, 0);
					AddButton(117, 151, 10810, 10810, (int)Buttons.GOTO, GumpButtonType.Reply, 0);
					AddButton(261, 251+20, 2026, 2026, (int)Buttons.WAR, GumpButtonType.Reply, 0);
					AddButton(325, 250+20, 2023, 2023, (int)Buttons.PEACE, GumpButtonType.Reply, 0);
					AddButton(225, 252+20, 4030, 4030, (int)Buttons.SAY_MOBILE, GumpButtonType.Reply, 0);

					AddButton(231, 38, 9904, 9903, (int)Buttons.MOBILE_RENAME, GumpButtonType.Reply, 0); 
					AddLabel(256, 39, 0, @"Renommer:");
					AddImage(232+55-58, 60, 2440);
					AddTextEntry(232+63-58, 62, 147, 20, 0, (int)Buttons.SETRENAME_MOBILE, stone.MobileReName);

					AddImage(55, 251+20, 2440);
					AddTextEntry(63, 253+20, 147, 20, 0, (int)Buttons.SETMOBILE_SAY, @"");
					AddCheck(63, 38, 210, 211, stone.MobileSelectionMode, (int)Buttons.MSELECT);
					AddLabel(90, 39, 0, @"Mode selection");
					AddButton(231, 88, 9904, 9903, (int)Buttons.MB1, GumpButtonType.Reply, 0);  // Attack
					AddButton(230, 113, 9904, 9903, (int)Buttons.MB2, GumpButtonType.Reply, 0); // Kill
					AddButton(230, 137, 9904, 9903, (int)Buttons.MB3, GumpButtonType.Reply, 0); // Delete
					AddButton(230, 162, 9904, 9903, (int)Buttons.MB4, GumpButtonType.Reply, 0); // Follow
					AddButton(230, 189, 9904, 9903, (int)Buttons.MB5, GumpButtonType.Reply, 0); // Run/Walk
					AddButton(230, 214, 9904, 9903, (int)Buttons.MB6, GumpButtonType.Reply, 0); // Hide/Show
					AddButton(230, 242, 9904, 9903, (int)Buttons.MB7, GumpButtonType.Reply, 0); // Badguys
					if (!stone.MobileSelectionMode || (stone.PreSelectedMobile == null) ||
						 stone.PreSelectedMobile.Deleted || !stone.PreSelectedMobile.Alive)
						AddLabel(90, 60, 0, @"");
					else if (stone.PreSelectedMobile.Name != null)
						AddLabel(90, 60, 0, stone.PreSelectedMobile.Name);
					AddButton(63, 60, 5540, 5541, (int)Buttons.SELECTMOB, GumpButtonType.Reply, 0);
					AddLabel(256, 88, 0, @"Attaquer");
					AddLabel(255, 112, 0, @"Tuer ce NPC");
					AddLabel(255, 137, 0, @"Supprimer ce NPC");
					AddLabel(255, 163, 0, @"Suivre le GM");
					AddLabel(255, 190, 0, @"Marcher/Courir");
					AddLabel(256, 218, 0, @"Cacher/Montrer");
					AddLabel(256, 246, 0, @"Groupe agressif");
				}
					break;
//ITEM PROPS
				case 5:
				{
					AddBackground(51, 38, 322, 245, 9200);
					AddImage(87, 151, 1141, 5);
					AddLabel(102, 111, 1071, @"Moins 2");
					AddLabel(102, 131, 1149, @"Moins 1");
					AddLabel(102, 154, 1149, @"ZERO");
					AddLabel(102, 178, 1149, @"Plus 1");
					AddLabel(102, 198, 1071, @"Plus 2");
					AddButton(60, 186, 9907, 9906, (int)Buttons.ITDOWN_BTN, GumpButtonType.Reply, 0);
					AddButton(60, 129, 9901, 9900, (int)Buttons.ITUP_BTN, GumpButtonType.Reply, 0);
					AddLabel(60, 73, 0, @"Nom (optional):");
					AddImage(193, 71, 2440);
					AddTextEntry(201, 73, 147, 20, 0, 0, stone.ItemReName);
					AddButton(290, 245, 247, 248, (int)Buttons.PROPOK, GumpButtonType.Reply, 0);
					AddLabel(59, 45, 1194, @"PROPRIETE D'UN OBJET");
				}
					break;
//GUILDS
				case 6:
				{
					TG = (Guild)Server.Guilds.BaseGuild.FindByName( "Techno-Glaive" );
					NS = (Guild)Server.Guilds.BaseGuild.FindByName( "NeuroSapiens" );
					CA = (Guild)Server.Guilds.BaseGuild.FindByName( "Clercs Actifs" );
					AA = (Guild)Server.Guilds.BaseGuild.FindByName( "Ailes D'Argent" );
					if (( TG == null ) || ( NS == null ) || ( CA == null ) || ( AA == null ))
					{
						from.SendMessage("ERREUR DU SERVEUR: UNE GUILDE A ETE SUPPRIMMEE!");
					} else {
						AddBackground(49, 37, 466, 246, 9200);
						AddLabel(80, 112, 0, @"(TG) Techno-Glaive");
						AddLabel(80, 136, 0, @"(NS) NeuroSapiens");
						AddLabel(80, 161, 0, @"(CA) Clercs Actifs");
						AddLabel(80, 188, 0, @"(AA) Ailes D'Argent");
						AddButton(54, 111, 9904, 9903, (int)Buttons.G1RECRUIT, GumpButtonType.Reply, 0);
						AddButton(54, 135, 9904, 9903, (int)Buttons.G2RECRUIT, GumpButtonType.Reply, 0);
						AddButton(54, 160, 9904, 9903, (int)Buttons.G3RECRUIT, GumpButtonType.Reply, 0);
						AddButton(54, 187, 9904, 9903, (int)Buttons.G4RECRUIT, GumpButtonType.Reply, 0);
						int id = 2023;

						AddLabel(242, 85, 0, @"(TG)");
						// AddButton(225, 111, id, id, (int)Buttons.TGTG, GumpButtonType.Reply, 0);
id =2023+(NS.IsEnemy(TG)?3:0); AddButton(225, 137, id, id, (int)Buttons.NSTG, GumpButtonType.Reply, 0);
id =2023+(CA.IsEnemy(TG)?3:0); AddButton(225, 162, id, id, (int)Buttons.CATG, GumpButtonType.Reply, 0);
id =2023+(AA.IsEnemy(TG)?3:0); AddButton(225, 189, id, id, (int)Buttons.AATG, GumpButtonType.Reply, 0);

						AddLabel(314, 85, 0, @"(NS)");
id =2023+(TG.IsEnemy(NS)?3:0); AddButton(297, 111, id, id, (int)Buttons.TGNS, GumpButtonType.Reply, 0);
						// AddButton(297, 137, id, id, (int)Buttons.NSNS, GumpButtonType.Reply, 0);
id =2023+(CA.IsEnemy(NS)?3:0); AddButton(297, 162, id, id, (int)Buttons.CANS, GumpButtonType.Reply, 0);
id =2023+(AA.IsEnemy(NS)?3:0); AddButton(297, 189, id, id, (int)Buttons.AANS, GumpButtonType.Reply, 0);

						AddLabel(384, 85, 0, @"(CA)");
id =2023+(TG.IsEnemy(CA)?3:0); AddButton(367, 111, id, id, (int)Buttons.TGCA, GumpButtonType.Reply, 0);
id =2023+(NS.IsEnemy(CA)?3:0); AddButton(367, 137, id, id, (int)Buttons.NSCA, GumpButtonType.Reply, 0);
						// AddButton(367, 162, id, id, (int)Buttons.CACA, GumpButtonType.Reply, 0);
id =2023+(AA.IsEnemy(CA)?3:0); AddButton(367, 189, id, id, (int)Buttons.AACA, GumpButtonType.Reply, 0);

						AddLabel(457, 85, 0, @"(AA)");
id =2023+(TG.IsEnemy(AA)?3:0); AddButton(440, 111, id, id, (int)Buttons.TGAA, GumpButtonType.Reply, 0);
id =2023+(NS.IsEnemy(AA)?3:0); AddButton(440, 137, id, id, (int)Buttons.NSAA, GumpButtonType.Reply, 0);
id =2023+(CA.IsEnemy(AA)?3:0); AddButton(440, 162, id, id, (int)Buttons.CAAA, GumpButtonType.Reply, 0);
						// AddButton(440, 189, id, id, (int)Buttons.AAAA, GumpButtonType.Reply, 0);

						AddLabel(260, 55, 0, @"Declaration de guerre/paix avec...");
					}
				}
					break;
//SAY
				case 7:
				{
				}
					break;
//BROADCAST
				case 8:
				{
				}
					break;
				default:
				{
				}
					break;
			}
        }

        public enum Buttons
		{
			MDISABLED,
			MSELECT,
			B1,
			B2,
			B3,
			B4,
			B5,
			B6,
			B7,
			B8,
			EXPAND,
			LOGOUT,
			UP,
			NORTH,
			RIGHT,
			WEST,
			DOWN,
			SOUTH,
			LEFT,
			EAST,
			GOTO,
			WAR,
			PEACE,
			SAY_MOBILE,
			ITNAME,
			MOBNAME,
			MOBILE_RENAME,
			MOBCAT1,
			MOBCAT2,
			MOBCAT3,
			MOBCAT4,
			MOBCAT5,
			MOBCAT6,
			ITCAT1,
			ITCAT2,
			ITCAT3,
			ITCAT4,
			ITCAT5,
			ITCAT6,
			MB1,
			MB2,
			MB3,
			MB4,
			MB5,
			MB6,
			MB7,
			SELECTMOB,
			MOBDOWN_BTN,
			MOBUP_BTN,
			ITDOWN_BTN,
			ITUP_BTN,
			PROPDOWN_BTN,
			PROPUP_BTN,
			MOBOK,
			ITOK,
			PROPOK,
			GOTO1,
			GOTO2,
			GOTO3,
			GOTO4,
			GOTO5,
			GOTO6,
			GOTO7,
			GOTO8,
			GOTO9,
			GOTO11,
			GOTO12,
			GOTO13,
			GOTO14,
			GOTO15,
			GOTO16,
			GOTO17,
			GOTO18,
			GOTO19,
			SETGOTO11,
			SETGOTO12,
			SETGOTO13,
			SETGOTO14,
			SETGOTO15,
			SETGOTO16,
			SETGOTO17,
			SETGOTO18,
			SETGOTO19,
			SETGOTO11ENTRY,
			SETGOTO12ENTRY,
			SETGOTO13ENTRY,
			SETGOTO14ENTRY,
			SETGOTO15ENTRY,
			SETGOTO16ENTRY,
			SETGOTO17ENTRY,
			SETGOTO18ENTRY,
			SETGOTO19ENTRY,
			TELEPORT,
			G1RECRUIT,
			G2RECRUIT,
			G3RECRUIT,
			G4RECRUIT,
			TGTG,
			NSTG,
			CATG,
			AATG,
			TGNS,
			NSNS,
			CANS,
			AANS,
			TGCA,
			NSCA,
			CACA,
			AACA,
			TGAA,
			NSAA,
			CAAA,
			AAAA,
			TOPLAYER,
			NEXTPLAYER,
			SETRENAME_MOBILE,
			SETMOBILE_SAY,
			MBADGUYSCHECK,
		}

        public override void OnResponse(NetState sender, RelayInfo info)
        {

			stone.InactiveMobile=false;
			stone.MobileSelectionMode=false;
			stone.BadGuys=false;
			for (int i=0;i<info.Switches.Length;i++)
			{
				if (info.Switches[i] == (int)Buttons.MBADGUYSCHECK)
					stone.BadGuys=true;
				if (info.Switches[i] == (int)Buttons.MDISABLED)
					stone.InactiveMobile=true;
				if (info.Switches[i] == (int)Buttons.MSELECT)
					stone.MobileSelectionMode=true;
			}

			foreach( TextRelay t in info.TextEntries )
			{
				switch ((Buttons)t.EntryID)
				{
					case Buttons.ITNAME:
						stone.ItemName=t.Text;
						break;
					case Buttons.MOBNAME:
						stone.MobileName=t.Text;
						break;
					case Buttons.SETRENAME_MOBILE:
						stone.MobileReName=t.Text;
						break;
					case Buttons.SETMOBILE_SAY:
						stone.MobileSay=t.Text;
						break;
					case Buttons.SETGOTO11ENTRY:
						stone.LocationName11=t.Text;
						break;
					case Buttons.SETGOTO12ENTRY:
						stone.LocationName12=t.Text;
						break;
					case Buttons.SETGOTO13ENTRY:
						stone.LocationName13=t.Text;
						break;
					case Buttons.SETGOTO14ENTRY:
						stone.LocationName14=t.Text;
						break;
					case Buttons.SETGOTO15ENTRY:
						stone.LocationName15=t.Text;
						break;
					case Buttons.SETGOTO16ENTRY:
						stone.LocationName16=t.Text;
						break;
					case Buttons.SETGOTO17ENTRY:
						stone.LocationName17=t.Text;
						break;
					case Buttons.SETGOTO18ENTRY:
						stone.LocationName18=t.Text;
						break;
					case Buttons.SETGOTO19ENTRY:
						stone.LocationName19=t.Text;
						break;
					default:
						break;
				}
			}

			from.CloseGump( typeof( GM ) );
            switch(info.ButtonID)
            {
                case (int)Buttons.ITCAT1: stone.ItemLevel=1; break;
                case (int)Buttons.ITCAT2: stone.ItemLevel=2; break;
                case (int)Buttons.ITCAT3: stone.ItemLevel=3; break;
                case (int)Buttons.ITCAT4: stone.ItemLevel=4; break;
                case (int)Buttons.ITCAT5: stone.ItemLevel=5; break;
                case (int)Buttons.ITCAT6: stone.ItemLevel=6; break;
                case (int)Buttons.MOBCAT1:
                case (int)Buttons.MOBCAT2:
                case (int)Buttons.MOBCAT3:
                case (int)Buttons.MOBCAT4:
                case (int)Buttons.MOBCAT5:
                case (int)Buttons.MOBCAT6:
				{
					stone.MOBCAT = info.ButtonID;
					stone.MobileIndex = 0;
					break;
				}
                case (int)Buttons.B1: //TELEPORT
				{
					context = 1;
					break;
				}
				case (int)Buttons.B2: // ADD MOBILE
				{
					context = 2;
					break;
				}
				case (int)Buttons.B3: // ADD ITEM
				{
					context = 3;
					break;
				}
				case (int)Buttons.B4: // MOBILE CONTROL
				{
					context = 4;
					break;
				}
				case (int)Buttons.B5: // ITEM PROPERTIES
				{
					context = 5;
					break;
				}
				case (int)Buttons.B6: // GUILDS MANAGEMENT
				{
					context = 6;
					break;
				}
				case (int)Buttons.B7: // SAY
				{
					from.SendMessage("Tappez le texte à faire dire:");
					from.Prompt = new Say_Prompt();
					context = 7;
					break;
				}
				case (int)Buttons.B8: // BROADCAST
				{
					from.SendMessage("Tappez votre message à diffuser aux joueurs en ligne:");
					from.Prompt = new Broadcast_Prompt();
					context = 8;
					break;
				}
				case (int)Buttons.EXPAND:
				{
					if (context == 0)
						context=-1;
					else
						context=0;
					break;
				}
				case (int)Buttons.LOGOUT:
				{
					ShardControler.MiniGM_Logout();
					break;
				}
				case (int)Buttons.GOTO:
				case (int)Buttons.UP:
				case (int)Buttons.NORTH:
				case (int)Buttons.RIGHT:
				case (int)Buttons.WEST:
				case (int)Buttons.DOWN:
				case (int)Buttons.SOUTH:
				case (int)Buttons.LEFT:
				case (int)Buttons.EAST:
				case (int)Buttons.PEACE:
				case (int)Buttons.WAR:
				case (int)Buttons.MB1:
				case (int)Buttons.MB2:
				case (int)Buttons.MB3:
				case (int)Buttons.MB4:
				case (int)Buttons.MB5:
				case (int)Buttons.MB6:
				case (int)Buttons.MB7:
				case (int)Buttons.SAY_MOBILE:
				case (int)Buttons.MOBILE_RENAME:
				{
					stone.TargetedMobile=null;
					if (!stone.MobileSelectionMode || (stone.PreSelectedMobile == null) ||
						 stone.PreSelectedMobile.Deleted || !stone.PreSelectedMobile.Alive)
						stone.PreSelectedMobile = null;
					if (stone.PreSelectedMobile != null) stone.DoActionMobile(from,info.ButtonID);
					else from.Target = new ActionMobileTarget(from,stone,info.ButtonID);
					break;
				}
				case (int)Buttons.MSELECT:
				{

					break;
				}
				case (int)Buttons.SELECTMOB:
				{
					from.Target = new ActionMobileTarget(from,stone,-1);
					break;
				}
				case (int)Buttons.MOBDOWN_BTN:
				{
					int MaxIndex=0;
					switch(stone.MOBCAT)
					{
						case (int)Buttons.MOBCAT1: MaxIndex=miniGM.m_MobilesMenu1.Length; break;
						case (int)Buttons.MOBCAT2: MaxIndex=miniGM.m_MobilesMenu2.Length; break;
						case (int)Buttons.MOBCAT3: MaxIndex=miniGM.m_MobilesMenu3.Length; break;
						case (int)Buttons.MOBCAT4: MaxIndex=miniGM.m_MobilesMenu4.Length; break;
						case (int)Buttons.MOBCAT5: MaxIndex=miniGM.m_MobilesMenu5.Length; break;
						case (int)Buttons.MOBCAT6: MaxIndex=miniGM.m_MobilesMenu6.Length; break;
						default: break;
					}
					if (stone.MobileIndex<MaxIndex-1) stone.MobileIndex++;					
					break;
				}
				case (int)Buttons.MOBUP_BTN:
				{
					if (stone.MobileIndex>0) stone.MobileIndex--;					
					break;
				}
				case (int)Buttons.ITDOWN_BTN:
				{
					int MaxIndex=miniGM.m_ItemsMenu1.Length;
					if (stone.ItemIndex<MaxIndex-1) stone.ItemIndex++;					
					break;
				}
				case (int)Buttons.ITUP_BTN:
				{
					if (stone.ItemIndex>0) stone.ItemIndex--;					
					break;
				}
				case (int)Buttons.PROPDOWN_BTN:
				{

					break;
				}
				case (int)Buttons.PROPUP_BTN:
				{

					break;
				}
				case (int)Buttons.MOBOK:
				{
					switch(stone.MOBCAT)
					{
						case (int)Buttons.MOBCAT1:
							from.Target = new CreateTarget(miniGM.m_MobilesMenu1Types[stone.MobileIndex],stone); break;
						case (int)Buttons.MOBCAT2:
							from.Target = new CreateTarget(miniGM.m_MobilesMenu2Types[stone.MobileIndex],stone); break;
						case (int)Buttons.MOBCAT3: 
							from.Target = new CreateTarget(miniGM.m_MobilesMenu3Types[stone.MobileIndex],stone); break;
						case (int)Buttons.MOBCAT4:
							from.Target = new CreateTarget(miniGM.m_MobilesMenu4Types[stone.MobileIndex],stone); break;
						case (int)Buttons.MOBCAT5: 
							from.Target = new CreateTarget(miniGM.m_MobilesMenu5Types[stone.MobileIndex],stone); break;
						case (int)Buttons.MOBCAT6: 
							from.Target = new CreateTarget(miniGM.m_MobilesMenu6Types[stone.MobileIndex],stone); break;
						default: break;
					}
					break;
				}
				case (int)Buttons.ITOK:
				{
					from.Target = new CreateTarget(miniGM.m_ItemsMenu1Types[stone.ItemIndex],stone); break;
					break;
				}
				case (int)Buttons.PROPOK:
				{

					break;
				}
				case (int)Buttons.TELEPORT:
				{
					from.Target = new TeleportToTarget(from,stone,0);
					context=0;
					break;
				}
				case (int)Buttons.TOPLAYER:
				{
					if ((stone.ToPlayer == null) ||
						(stone.ToPlayer.NetState == null))
						{
							from.SendMessage("Ce joueur n'est pas ou plus en ligne...");
						} else {
							from.MoveToWorld( stone.ToPlayer.Location, stone.ToPlayer.Map );
							context=0;
						}
					break;
				}
				case (int)Buttons.NEXTPLAYER:
				{
					if ((stone.ToPlayer == null) || (stone.ToPlayer.NetState == null) )
						stone.ToPlayer = null;
					Mobile FirstOnlinePlayer=null;
					ArrayList states = NetState.Instances;
					int count = states.Count;
					bool found = false;
					bool NextOne = false;
					for ( int i = 0; ((i < count) && !found); ++i )
					{
						NetState ns = (NetState)states[i];
						Mobile mob = ns.Mobile;
						if (mob.AccessLevel == AccessLevel.Player)
						{
							if (stone.ToPlayer == null)
							{
								stone.ToPlayer = mob;
								found = true;
							} else {
								if (FirstOnlinePlayer == null)
									FirstOnlinePlayer = mob;
								if (stone.ToPlayer == mob)
								{
									NextOne=true;
								} else {
									if (NextOne)
									{
										stone.ToPlayer = mob;
										found = true;
									}
								}									
							}
						}
					}
					if (!found && NextOne && (FirstOnlinePlayer != null))
						stone.ToPlayer=FirstOnlinePlayer;
					break;
				}
				case (int)Buttons.GOTO1:
				{
					from.MoveToWorld( new Point3D(5581,1676,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO2:
				{
					from.MoveToWorld( new Point3D(3751,1411,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO3:
				{
					from.MoveToWorld( new Point3D(3719,2218,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO4:
				{
					from.MoveToWorld( new Point3D(3519,3091,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO5:
				{
					from.MoveToWorld( new Point3D(4452,1848,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO6:
				{
					from.MoveToWorld( new Point3D(4763,1652,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO7:
				{
					from.MoveToWorld( new Point3D(4138,3616,46), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO8:
				{
					from.MoveToWorld( new Point3D(4190,3985,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO9:
				{
					from.MoveToWorld( new Point3D(1960,1540,0), Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO11:
				{
					from.MoveToWorld( stone.Location11, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO12:
				{
					from.MoveToWorld( stone.Location12, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO13:
				{
					from.MoveToWorld( stone.Location13, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO14:
				{
					from.MoveToWorld( stone.Location14, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO15:
				{
					from.MoveToWorld( stone.Location15, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO16:
				{
					from.MoveToWorld( stone.Location16, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO17:
				{
					from.MoveToWorld( stone.Location17, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO18:
				{
					from.MoveToWorld( stone.Location18, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.GOTO19:
				{
					from.MoveToWorld( stone.Location19, Map.Trammel );
					context=0;
					break;
				}
				case (int)Buttons.SETGOTO11:
				{
					from.Target = new TeleportToTarget(from,stone,11);
					break;
				}
				case (int)Buttons.SETGOTO12:
				{
					from.Target = new TeleportToTarget(from,stone,12);
					break;
				}
				case (int)Buttons.SETGOTO13:
				{
					from.Target = new TeleportToTarget(from,stone,13);
					break;
				}
				case (int)Buttons.SETGOTO14:
				{
					from.Target = new TeleportToTarget(from,stone,14);
					break;
				}
				case (int)Buttons.SETGOTO15:
				{
					from.Target = new TeleportToTarget(from,stone,15);
					break;
				}
				case (int)Buttons.SETGOTO16:
				{
					from.Target = new TeleportToTarget(from,stone,16);
					break;
				}
				case (int)Buttons.SETGOTO17:
				{
					from.Target = new TeleportToTarget(from,stone,17);
					break;
				}
				case (int)Buttons.SETGOTO18:
				{
					from.Target = new TeleportToTarget(from,stone,18);
					break;
				}
				case (int)Buttons.SETGOTO19:
				{
					from.Target = new TeleportToTarget(from,stone,19);
					break;
				}
				case (int)Buttons.G1RECRUIT:
				{
					
					break;
				}
				case (int)Buttons.G2RECRUIT:
				{

					break;
				}
				case (int)Buttons.G3RECRUIT:
				{

					break;
				}
				case (int)Buttons.G4RECRUIT:
				{

					break;
				}
				case (int)Buttons.TGTG:
				{
					//
					break;
				}
				case (int)Buttons.NSTG:
				{
					if (NS.IsEnemy(TG))	NS.RemoveEnemy(TG);	else NS.AddEnemy(TG);
					break;
				}
				case (int)Buttons.CATG:
				{
					if (CA.IsEnemy(TG))	CA.RemoveEnemy(TG);	else CA.AddEnemy(TG);
					break;
				}
				case (int)Buttons.AATG:
				{
					if (AA.IsEnemy(TG))	AA.RemoveEnemy(TG);	else AA.AddEnemy(TG);
					break;
				}
				case (int)Buttons.TGNS:
				{
					if (TG.IsEnemy(NS))	TG.RemoveEnemy(NS);	else TG.AddEnemy(NS);
					break;
				}
				case (int)Buttons.NSNS:
				{
					//
					break;
				}
				case (int)Buttons.CANS:
				{
					if (CA.IsEnemy(NS))	CA.RemoveEnemy(NS);	else CA.AddEnemy(NS);
					break;
				}
				case (int)Buttons.AANS:
				{
					if (AA.IsEnemy(NS))	AA.RemoveEnemy(NS);	else AA.AddEnemy(NS);
					break;
				}
				case (int)Buttons.TGCA:
				{
					if (TG.IsEnemy(CA))	TG.RemoveEnemy(CA);	else TG.AddEnemy(CA);
					break;
				}
				case (int)Buttons.NSCA:
				{
					if (NS.IsEnemy(CA))	NS.RemoveEnemy(CA);	else NS.AddEnemy(CA);
					break;
				}
				case (int)Buttons.CACA:
				{
					//
					break;
				}
				case (int)Buttons.AACA:
				{
					if (AA.IsEnemy(CA))	AA.RemoveEnemy(CA);	else AA.AddEnemy(CA);
					break;
				}
				case (int)Buttons.TGAA:
				{
					if (TG.IsEnemy(AA))	TG.RemoveEnemy(AA); else TG.AddEnemy(AA);
					break;
				}
				case (int)Buttons.NSAA:
				{
					if (NS.IsEnemy(AA))	NS.RemoveEnemy(AA); else NS.AddEnemy(AA);
					break;
				}
				case (int)Buttons.CAAA:
				{
					if (CA.IsEnemy(AA))	CA.RemoveEnemy(AA); else CA.AddEnemy(AA);
					break;
				}
				case (int)Buttons.AAAA:
				{
					//
					break;
				}
            }
			from.SendGump(new GM(from,stone,context,debug));
        }
    }

	public class CreateTarget : Target
	{
		private Type m_Type;
		private miniGM m_Stone;
		public CreateTarget(Type type, miniGM stone) : base( -1, true, TargetFlags.None )
		{
			m_Type=type;
			m_Stone=stone;
		}
		protected override void OnTarget( Mobile from, object targeted )
		{
			if( targeted is IPoint3D )
			{
				Point3D p=new Point3D((IPoint3D)targeted);
				if ( m_Type != null )
				{
					try
					{
						object o = Activator.CreateInstance( m_Type );
						if ( o is BaseCreature )
						{
							BaseCreature m = (BaseCreature)o;
							if (m.Backpack == null)
								m.AddItem(new Backpack());
							m.PackItem(new miniGM_DeleteMobileStone(m_Stone));
							m.MoveToWorld( p, from.Map );
							if ((m_Stone.MobileName != null) && (m_Stone.MobileName != ""))
								m.Name=m_Stone.MobileName;
							if (m_Stone.InactiveMobile)
							{
								m.Frozen=true;
								m.Hidden=true;
							}
							if (m_Stone.BadGuys)
							{
								m.GuildName="badguys";
								m.Team=101010;
							}
						}
						else if ( o is Item )
						{
							Item item = (Item)o;
							item.MoveToWorld( p, from.Map  );
							if ((m_Stone.ItemName != null) && (m_Stone.ItemName != ""))
								item.Name=m_Stone.ItemName;
						}
					}
					catch
					{
					}
				}
			}
		}
	}
	
	
	public class Broadcast_Prompt : Prompt
	{
		public Broadcast_Prompt()
		{
		}
		public override void OnResponse( Mobile from, string text )
		{
			string ttext="[BROADCAST] "+text;
			if (text != null)
				foreach ( NetState state in NetState.Instances )
					state.Mobile.SendMessage(ttext);
		}
	}		

	public class Say_Prompt : Prompt
	{
		public Say_Prompt()
		{
		}
		public override void OnResponse( Mobile from, string text )
		{
			from.Target= new SayTarget( text );
		}
	}		
	public class SayTarget : Target
	{
		private string m_toSay;
			public SayTarget( string say ) : base( -1, true, TargetFlags.None )
		{
			m_toSay = say;
		}
			protected override void OnTarget( Mobile from, object targeted )
		{
			if ( targeted is Mobile )
			{
				Mobile targ = (Mobile)targeted;
					if ( from != targ && from.AccessLevel > targ.AccessLevel )
				{
					CommandLogging.WriteLine( from, "{0} {1} forcing speech on {2}", from.AccessLevel, CommandLogging.Format( from ), CommandLogging.Format( targ ) );
					targ.Say( m_toSay );
				}
			}
			else if ( targeted is Item )
			{
				Item targ = (Item)targeted;
				targ.PublicOverheadMessage( MessageType.Regular, Utility.RandomDyedHue(), false, m_toSay);
			}
			else if ( targeted is IPoint3D )
			{
				Item targ = new Blood();
				targ.ItemID = 0xEED;
				targ.Hue = 777;
				targ.MoveToWorld (new Point3D((IPoint3D)targeted),from.Map);
				targ.PublicOverheadMessage( MessageType.Regular, Utility.RandomDyedHue(), false, m_toSay);
			}
			else 
				from.SendMessage( "Invaild Target Type" );
		}
	}

	public class ActionMobileTarget : Target
	{
		private int m_action;
		private miniGM m_Stone;
	
		public ActionMobileTarget(Mobile from, miniGM stone, int action ) : base( -1, true, TargetFlags.None )
		{
			m_Stone=stone;
			m_action=action;
			from.SendMessage("Selectionnez une creature.");
		}
		
		protected override void OnTarget( Mobile from, object targeted )
		{
			if( targeted is Mobile )
			{
				m_Stone.PreSelectedMobile = (Mobile)targeted;
				if (m_action>=0) m_Stone.DoActionMobile(from,m_action);
			}
		}
	}
	
	public class TeleportToTarget : Target
	{
		private Mobile m_M;
		private int m_loc;
		private miniGM m_Stone;
	
		public TeleportToTarget(Mobile m, miniGM stone, int loc) : base( -1, true, TargetFlags.None )
		{
			m_M=m;
			m_Stone=stone;
			m_loc=loc;
		}
		
		protected override void OnTarget( Mobile from, object targeted )
		{
			if( targeted is IPoint3D )
			{
				Point3D p=new Point3D((IPoint3D)targeted);
				switch(m_loc)
				{
					case 1: 	m_Stone.Location1=p;	break;
					case 2:		m_Stone.Location2=p;	break;
					case 3:		m_Stone.Location3=p;	break;
					case 4:		m_Stone.Location4=p;	break;
					case 5:		m_Stone.Location5=p;	break;
					case 6:		m_Stone.Location6=p;	break;
					case 7:		m_Stone.Location7=p;	break;
					case 8:		m_Stone.Location8=p;	break;
					case 9:		m_Stone.Location9=p;	break;
					case 11:	m_Stone.Location11=p;	break;
					case 12:	m_Stone.Location12=p;	break;
					case 13:	m_Stone.Location13=p;	break;
					case 14:	m_Stone.Location14=p;	break;
					case 15:	m_Stone.Location15=p;	break;
					case 16:	m_Stone.Location16=p;	break;
					case 17:	m_Stone.Location17=p;	break;
					case 18:	m_Stone.Location18=p;	break;
					case 19:	m_Stone.Location19=p;	break;
					default:
						m_M.MoveToWorld(p,from.Map);
						break;
				}
			}
			if (m_loc == 0) from.Target = new TeleportToTarget(m_M,m_Stone,0);
		}
	}
}