using Server;
using System;
using Server.Items;
using Server.Spells;
using Server.Mobiles;

namespace Server
{
	public enum MusicName
	{
		Invalid = -1,
		M00_THEME = 0,
		M01_T01,
		M02_T02,
		M03_T03,
		M04_T04,
		M05_T05,
		M06_T06,
		M07_T07,
		M08_stones1,
		M09_TE09,
		M10_britain1,
		M11_bucsden,
		M12_jhelom,
		M13_lbc,
		M14_linelle,
		M15_TE10,
		M16_TE11,
		M17_valoriapos,
		M18_ambrosia,
		M19_stones,
		M20_scarabreapos,
		M21_trinsicpos,
		M22_vesper1,
		M23_yew1,
		M24_yewpos,
		M25_dungeon,
		M26_dragonshi,
		M27_citynightedit,
		M28_walking,
		M29_citynightedit,
		M30_walking,
		M31_citynightedit,
		M32_boattravel,
		M33_T12,
		M34_tavern1,
		M35_tavern2,
		M36_tavern3,
		M37_pubtune,
		M38_goodevil,
		M39_humanoids,
		M40_gargoyles,
		M41_turfin,
		M42_deathtune,
		M43_victory,
		M44_overlordv2,
		M45_nujelm,
		M46_dragonslo,
		M47_cove,
		M48_TE08,
		M49_zento,
		M50_tokunodungeon,
		M51_taiko,
		M52_dread_horn_area,
		M53_elf_city_1,
		M54_grizzle_dungeon,
		M55_melisandes_lair,
		M56_paroxysmus_lair,
		M57_T00,
		M58_T01,
		M59_T02,
		M60_T03,
		M61_T04,
		M62_T05,
		M63_T06,
		M64_T07,
		M65_T08,
		M66_T09,
		M67_T10,
		M68_T11,
		M69_T12,
		M70_T13,
		M71_T14,
		M72_T15		
	}
}

namespace Server.Regions
{
	public class CustomRegion : GuardedRegion
	{
		RegionControl m_Controller;

		public CustomRegion( RegionControl m, Map map ) : base( "", "Custom Region", map, typeof( WarriorGuard ) )
		{
			LoadFromXml = false;
			Map=Map;
            m_Controller = m;
		}

		public bool CanSleep()
		{
			return m_Controller.CanSleep;
		}

		public override bool IsDisabled()
		{
			if( base.Disabled != !m_Controller.GetFlag( RegionFlag.IsGuarded ) )
			{
				m_Controller.IsGuarded = !Disabled;
			}

			return Disabled;
		}

		public override bool AllowBenificial( Mobile from, Mobile target )
		{
			if( ( !m_Controller.AllowBenifitPlayer && target is PlayerMobile ) || ( !m_Controller.AllowBenifitNPC && target is BaseCreature ))
			{
				from.SendMessage( "Vous ne pouvez faire d'acte b�n�fique ici." );
				return false;
			}

			return base.AllowBenificial( from, target );
		}

		public override bool AllowHarmful( Mobile from, Mobile target )
		{
			if( ( !m_Controller.AllowHarmPlayer && target is PlayerMobile ) || ( !m_Controller.AllowHarmNPC && target is BaseCreature ))
			{
				from.SendMessage( "Vous ne pouvez faire d'acte malfaisant ici." );
				return false;
			}

			return base.AllowHarmful( from, target );
		}

		public override bool AllowHousing( Mobile from, Point3D p )
		{
			return m_Controller.AllowHousing;
		}

		public override bool AllowSpawn()
		{
			return m_Controller.AllowSpawn;
		}

		public override bool CanUseStuckMenu( Mobile m )
		{
			if ( ! m_Controller.CanUseStuckMenu )
				m.SendMessage( "Vous ne pouvez utiliser cette comp�tence ici." );
			return m_Controller.CanUseStuckMenu;
		}

		public override bool OnDamage( Mobile m, ref int Damage )
		{
			if ( !m_Controller.CanBeDamaged )
			{
				m.SendMessage( "Vous ne pouvez recevoir de dommage ici." );
			}

			return m_Controller.CanBeDamaged;
		}
		public override bool OnResurrect( Mobile m )
		{
			if ( ! m_Controller.CanRessurect && m.AccessLevel == AccessLevel.Player)
				m.SendMessage( "Vous ne pouvez rescussiter ici." );
			return m_Controller.CanRessurect;
		}

		public override bool OnBeginSpellCast( Mobile from, ISpell s )
		{
			if ( from.AccessLevel == AccessLevel.Player )
			{
				bool restricted = m_Controller.IsRestrictedSpell( s );
				if ( restricted )
				{
					from.SendMessage( "Vous ne pouvez utiliser un pouvoir de mutant ici." ); 
					return false;
				}

				//if ( s is EtherealSpell && !CanMountEthereal ) Grr, EthereealSpell is private :<
				if ( ! m_Controller.CanMountEthereal && ((Spell)s).Info.Name == "Ethereal Mount" ) //Hafta check with a name compare of the string to see if ethy
				{
					from.SendMessage( "Vous ne pouvez monter un ethereal ici." );
					return false; 
				}
			}

			//Console.WriteLine( m_Controller.GetRegistryNumber( s ) );

			//return base.OnBeginSpellCast( from, s );
			return true;	//Let users customize spells, not rely on weather it's guarded or not.
		}

		public override bool OnDecay( Item item )
		{
			return m_Controller.ItemDecay;
		}

		public override bool OnHeal( Mobile m, ref int Heal )
		{
			if ( !m_Controller.CanHeal )
			{
				m.SendMessage( "Vous ne pouvez �tre soign� ici." );
			}

			return m_Controller.CanHeal;
		}

		public override bool OnSkillUse( Mobile m, int skill )
		{
			bool restricted = m_Controller.IsRestrictedSkill( skill );
			if ( restricted && m.AccessLevel == AccessLevel.Player )
			{
				m.SendMessage( "Vous ne pouvez utiliser cette comp�tence ici." ); 
				return false;
			}

			return base.OnSkillUse( m, skill );
		}

		public override void OnExit( Mobile m )
		{
			if ( m_Controller.ShowExitMessage )
				m.SendMessage("Vous quittez {0}", this.Name );

			base.OnExit( m );

		}

		public override void OnEnter( Mobile m )
		{
			if ( m_Controller.ShowEnterMessage )
				m.SendMessage("Vous entrez dans {0}", this.Name );

			base.OnEnter( m );
		}


		
		public override bool OnMoveInto( Mobile m, Direction d, Point3D newLocation, Point3D oldLocation )
		{
			if( m_Controller.CannotEnter && ! this.Contains( oldLocation ) )
			{
				m.SendMessage( "Vous ne pouvez entrer dans cette r�gion." );
				return false; 
			}

			return true;
		}

		public override TimeSpan GetLogoutDelay( Mobile m )
		{
			if( m.AccessLevel == AccessLevel.Player )
				return m_Controller.PlayerLogoutDelay;

			return base.GetLogoutDelay( m );
		}


		
		public override bool OnDoubleClick( Mobile m, object o )
		{
			if( o is BasePotion && !m_Controller.CanUsePotions )
			{
				m.SendMessage( "Vous ne pouvez boire de potion ici." );
				return false;
			}
			
			if( o is Corpse )
			{
				Corpse c = (Corpse)o;

				bool canLoot;

				if( c.Owner == m )
					canLoot = !m_Controller.CannotLootOwnCorpse;
				else if ( c.Owner is PlayerMobile )
					canLoot =  m_Controller.CanLootPlayerCorpse;
				else
					canLoot =  m_Controller.CanLootNPCCorpse;

				if( !canLoot )
					m.SendMessage( "Vous ne pouvez voler un corps inanim� ici." );

				if ( m.AccessLevel >= AccessLevel.GameMaster && !canLoot )
				{
					m.SendMessage( "This is unlootable but you are able to open that with your Godly powers." );
					return true;
				}
				
				return canLoot;
			}


			return base.OnDoubleClick( m, o );
		}


		
		public override void AlterLightLevel( Mobile m, ref int global, ref int personal ) 
		{
			if( m_Controller.LightLevel >= 0 )
				global = m_Controller.LightLevel;
			else
				base.AlterLightLevel( m, ref global, ref personal );
		}
	}
}
