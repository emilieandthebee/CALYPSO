using System;
using Server.Network;
using Server.Mobiles;
using Server.SkillHandlers;
namespace Server.Items
{ 
	public class TobaccoSeed : Item 
	{
		[Constructable] 
		public TobaccoSeed() : base( 0x0F7F ) 
		{ 
			Movable = true; 
			Weight = 0.1; 
			Stackable = true; 
			Name = "Une graine de tabac"; 
		} 

		public TobaccoSeed( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 0 ); 
		} 

		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 
			int version = reader.ReadInt(); 
		} 

		public override void OnDoubleClick( Mobile from ) 
		{ 
			Map pmap = from.Map; 
			int playerX = from.X; 
			int playerY = from.Y; 
	
			Tile FarmTile = pmap.Tiles.GetLandTile( playerX, playerY ); 

			if ( !IsChildOf( from.Backpack ) ) 
			{ 
				from.SendMessage("That must be in your BackPack."); 
			} 
			else 
			{ 
				if ( FarmTile.ID == 9 ) 
				{ 
					from.SendMessage("You plant a seed!"); 
					this.Consume(); 
					Item item = new PlantedSeedTobacco(); 
					item.Location = from.Location; 
					item.Map = from.Map; 
				} 
				else
				{
					from.SendMessage("You may only plant seeds on farmland."); 
				}
			} 
		} 
	}


	public class PlantedSeedTobacco : Item, IChopable
	{
		private bool m_Harvestable;

		[CommandProperty( AccessLevel.GameMaster )]
		public bool Harvestable
		{
			get{ return m_Harvestable; }
			set{ m_Harvestable = value; }
		}

		[Constructable] 
		public PlantedSeedTobacco() : base( 0x187E ) 
		{ 
			Movable = false; 
			Name = "a planted Seed"; 
			ItemGrowTimer growTimer = new ItemGrowTimer( this ); 
			growTimer.Start();
		} 
		public PlantedSeedTobacco( Serial serial ) : base( serial ) 
		{ 
		}

	public void OnChop( Mobile from )
	{
		if ( this != null && from.InRange( GetWorldLocation(), 3 ) )
		{
			this.Consume();
			from.SendMessage("You destroy the plant.");

			switch ( Utility.Random( 9 ) )
			{
				case 0: break;
				case 1: break;
				case 2: break;
				case 3: TobaccoSeed TobaccoSeed = new TobaccoSeed();
					if (!from.AddToBackpack(TobaccoSeed)) 
						TobaccoSeed.Consume();
					from.SendMessage("You harvest a seed from the plant."); break;
				case 4: break;
				case 5: break;
				case 6: break;
				case 7: break;
				case 8: break;
			}
		}
		else
		{
			from.SendLocalizedMessage( 500446 ); // That is too far away.
		}
	}

		public class ItemGrowTimer : Timer 
		{ 
			private Item i_item; 
			//The time of the growth cycle; 
			public ItemGrowTimer( Item item ) : base( TimeSpan.FromSeconds( 540 ) ) 
			{ 
				Priority = TimerPriority.OneSecond; 
				i_item = item; 
			} 

			protected override void OnTick() 
			{
				ItemFruitionTimer fruitionTimer = new ItemFruitionTimer( i_item ); 
				if (( i_item != null ) && ( !i_item.Deleted )) 
				{ 
					i_item.ItemID = 0xC3D;
					i_item.Name = "Une plante a tabac";
					fruitionTimer.Start();
				} 
			} 
		}
	
		public class ItemFruitionTimer : Timer 
		{
			public bool Harvestable;
			private Item i_item; 
	
			//The time of the fruition cycle
			public ItemFruitionTimer( Item item ) : base( TimeSpan.FromSeconds( 540 ) ) 
			{ 
				Priority = TimerPriority.OneSecond; 
				i_item = item; 
			}
	
			protected override void OnTick()
			{ 
				if (( i_item != null ) && ( !i_item.Deleted )) 
				{
					((PlantedSeedTobacco)i_item).Harvestable = true;
				} 
			} 
		} 
	
		public override void OnDoubleClick( Mobile from ) 
		{
			ItemFruitionTimer fruitionTimer = new ItemFruitionTimer( this ); 
	
				if (!this.Harvestable)
				{
					from.SendMessage("This plant has not yet reached fruition."); 
				}
				else if (from.InRange(this.GetWorldLocation(),1))
				{
					if ( from.CheckSkill( SkillName.Lumberjacking, 0.0, 120.0 ) )
					{
			            		if ( !from.Mounted ) 
        	      					from.Animate( 32, 5, 1, true, true, 0 ); 
						//Set number of Tobacco that one plant generates; 
						Tobacco Tobacco = new Tobacco();
						if (!from.AddToBackpack(Tobacco)) 
							Tobacco.Consume();
						from.SendMessage("You pick the crops and place them in your pack."); 
						this.Harvestable = false;
						fruitionTimer.Start();
					}
					else
					{
						from.SendMessage("You fail to harvest anything from the plant."); 
					} 
				} 
				else 
				{ 
					from.SendMessage("You cannot reach the plant."); 
				} 
		}
	
		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 
			writer.Write( (int) 1 ); // version

			writer.Write( (bool)m_Harvestable ); 
		} 
		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 
			int version = reader.ReadInt();

			switch ( version )
			{
				case 1:
				{
					m_Harvestable = reader.ReadBool();
					goto case 0;
				}

				case 0:
				{
					break;
				}
			}
		} 
	}
}