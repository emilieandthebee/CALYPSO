using System;
using Server;

namespace Server.Spells.Rogue
{
   public abstract class RogueSpell : Spell
   {
      public abstract double CastDelay{ get; }
      public abstract double RequiredSkill{ get; }
      public abstract int RequiredMana{ get; }

      public override SkillName CastSkill{ get{ return SkillName.Stealing; } }
      public override SkillName DamageSkill{ get{ return SkillName.Hiding; } }

      public override bool ClearHandsOnCast{ get{ return false; } }

      public RogueSpell( Mobile caster, Item scroll, SpellInfo info ) : base( caster, scroll, info )
      {
      }

      public override void GetCastSkills( out double min, out double max )
      {
         min = RequiredSkill;
         max = RequiredSkill;
      }

      public override int GetMana()
      {
         return RequiredMana;
      }
	public override bool ConsumeReagents()
		{
			return true;
		}
      public override TimeSpan GetCastDelay()
      {
         return TimeSpan.FromSeconds( CastDelay );
      }
   }
}
