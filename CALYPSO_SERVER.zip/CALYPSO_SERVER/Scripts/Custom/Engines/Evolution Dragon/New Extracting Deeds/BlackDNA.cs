using System; 
using Server.Items; 

namespace Server.Items 
{ 
   	public class BlackDNA: Item 
   	{ 
		[Constructable]
		public BlackDNA() : this( 1 )
		{
		}

		[Constructable]
		public BlackDNA( int amount ) : base( 0x0F91 )
		{
			Stackable = true;
			Weight = 0.0;
			Amount = amount;
			Name = "Black DNA";
			Hue = 1175;
		}

            	public BlackDNA( Serial serial ) : base ( serial ) 
            	{             
           	} 

		public override Item Dupe( int amount )
		{
			return base.Dupe( new BlackDNA( amount ), amount );
		}

           	public override void Serialize( GenericWriter writer ) 
           	{ 
              		base.Serialize( writer ); 
              		writer.Write( (int) 0 ); 
           	} 
            
           	public override void Deserialize( GenericReader reader ) 
           	{ 
              		base.Deserialize( reader ); 
              		int version = reader.ReadInt(); 
           	} 
        } 
} 