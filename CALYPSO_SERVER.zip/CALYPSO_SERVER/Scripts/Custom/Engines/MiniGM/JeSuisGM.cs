using System;
using System.Text.RegularExpressions; 
using Server; 
using Server.Gumps; 
using Server.Network; 
using Server.Prompts; 
using Server.Targeting;
using Server.Mobiles; 
using Server.Items; 

namespace Server.Scripts.Commands
{
   public class JeSuisGM_Command 
   {  
      public static void Initialize() 
      { 
         Server.Commands.Register( "JeSuisGM", AccessLevel.Player, new CommandEventHandler( JeSuisGM_OnCommand ) ); 
      } 

      [Usage( "JeSuisGM" )] 
      [Description( "Permets de vous proposez en tant que Maitre de Jeu (GameMaster) temporairement" )] 
      private static void JeSuisGM_OnCommand(CommandEventArgs e) 
      {
		if (!(e.Mobile is PlayerMobile))
			return;
		if (ShardControler.TheShardControlerStone == null)
			return;
		ShardControler STONE = ShardControler.TheShardControlerStone;
		PlayerMobile pm = (PlayerMobile)e.Mobile;
		Accounting.Account acct = pm.Account as Accounting.Account;		
		switch(STONE.GMStatus)
		{
			case ShardControler.GMStatusEnum.Nobody:
				if (!pm.IsMiniGM) // If set, workaround the check.
				{
					if (acct.Created + TimeSpan.FromDays(7.0) > DateTime.Now)
					{
						e.Mobile.SendMessage("Votre compte doit avoir au moins 1 semaine d'ancienneté pour pouvoir faire Maitre de Jeu");
						return;
					}
					// Requester shall have enough old activity
					if (acct.TotalGameTime<TimeSpan.FromHours(5.0))
					{
						e.Mobile.SendMessage("Il vous faut avoir accumulé au moins 5 heures de jeu pour pouvoir commencer à faire Maitre de Jeu");
						return;
					}
					// Requester shall not have made a rejected request during the last hour
					if (STONE.GMPlayerRejectedTime + TimeSpan.FromMinutes(ShardControler.GMVoteRejectionMinutes)> DateTime.Now)
					if (STONE.GMPlayerRejectedReference != null)
					if (STONE.GMPlayerReference is PlayerMobile)
					if (acct == (STONE.GMPlayerRejectedReference.Account as Accounting.Account))
					{
						e.Mobile.SendMessage("Il va falloir attendre... Votre demande en tant que MJ a été rejeté il y a moins de "+
							ShardControler.GMVoteRejectionMinutes+" minutes.");
						return;
					}
					// Check  the cooldown
					if (STONE.GMNextTime + TimeSpan.FromMinutes(ShardControler.GMVoteCoolDownMinutes)> DateTime.Now)
					{
						e.Mobile.SendMessage("Il faut attendre "+ShardControler.GMVoteCoolDownMinutes+
							" minutes entre chaque vote, histoire de ne pas pourrir le jeu.");
						return;
					}
					//At least 1 player of antother account should be online
					bool found = false;
					foreach ( NetState state in NetState.Instances )
					{
						if (state.Mobile is PlayerMobile)
							if (state.Mobile.AccessLevel == AccessLevel.Player)
								if ( acct != (((PlayerMobile)state.Mobile).Account as Accounting.Account))
									found = true;
					}
					if (!found)
					{
						e.Mobile.SendMessage("Il faut au moins un joueur pour faire le Maitre de Jeu.");
						return;
					}
				}
				//Go for voting
				STONE.GMPollVoters=0;
				STONE.GMPollYes=0;
				STONE.GMPollNo=0;
				foreach ( NetState state in NetState.Instances )
					if ((state.Mobile is PlayerMobile) && (e.Mobile is PlayerMobile) && (state.Mobile.AccessLevel == AccessLevel.Player) )
					if ( ((PlayerMobile)(state.Mobile)).Account != ((PlayerMobile)(e.Mobile)).Account)
					{
						state.Mobile.SendGump(new VoteMiniGM(e.Mobile));
						STONE.GMPollVoters++;
					}
				STONE.GMPlayerReference = e.Mobile;
				STONE.GMStatus=ShardControler.GMStatusEnum.OnVoteIn;
				STONE.GMNextTime=DateTime.Now+TimeSpan.FromMinutes(ShardControler.GMVoteDelay);
				e.Mobile.SendMessage("Le vote a été envoyé aux joueurs connectés.");
				break;
			case ShardControler.GMStatusEnum.OnVoteIn:
				e.Mobile.SendMessage("Un vote a deja été lancé par "+ShardControler.GET_GMPlayerReferenceName()+"...");
				break;
			case ShardControler.GMStatusEnum.Online:
				e.Mobile.SendMessage("Un Maitre de Jeu est deja actif ("+ShardControler.GET_GMPlayerReferenceName()+")");
				break;
			case ShardControler.GMStatusEnum.OnVoteOut:
				e.Mobile.SendMessage("Attendez, un vote pour la prestation de "+ShardControler.GET_GMPlayerReferenceName()+" en tant que Maitre de Jeu est en cours...");
				break;
			default:
				break;
		}
      } 
   } 
}