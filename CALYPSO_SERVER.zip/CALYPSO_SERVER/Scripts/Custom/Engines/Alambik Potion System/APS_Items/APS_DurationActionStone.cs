using System;
using Server;
using Server.Mobiles;
using Server.Gumps;
using Server.Network;
using Server.SkillHandlers;

namespace Server.Items
{
	public class APS_DurationActionStone : Item
	{
		public static int TicksPerSeconds = 3;
		public string m_Message;
		public Item m_Item;
		public Point3D m_Point;

		public override bool HandlesOnSpeech
		{
			get{ return ((m_Action == APS_Potion.APS_PotionEffect.StrangeEffect) && (m_ArgValue == 10)); }
		}

		public override void OnSpeech( SpeechEventArgs e )
		{
			if ( e.Type == MessageType.Emote )
				return;
			Mobile from = e.Mobile;
			string speech = e.Speech;
			if (from != m_Owner)
				m_Message = speech;
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public virtual Mobile Owner
		{
			get { return m_Owner; }
			set { m_Owner = value; }
		}
		public Mobile m_Owner;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual APS_Potion.APS_PotionEffect Action
		{
			get { return m_Action; }
			set { m_Action = value; }
		}
		public APS_Potion.APS_PotionEffect m_Action;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int Counter
		{
			get { return m_Counter; }
			set { m_Counter = value; }
		}
		public int m_Counter;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int InitialCounter
		{
			get { return m_InitialCounter; }
			set { m_InitialCounter = value; }
		}
		public int m_InitialCounter;

		[CommandProperty( AccessLevel.GameMaster )]
		public virtual int ArgValue
		{
			get { return m_ArgValue; }
			set { m_ArgValue = value; }
		}
		public int m_ArgValue;

		private InternalTimer m_Timer;
		
		[Constructable]
		public APS_DurationActionStone(Mobile from, APS_Potion.APS_PotionEffect action, int counterInSeconds, int argvalue) : base( 574 )
		{
			Name				= "Pierre du systeme APS (do not delete)";
			Weight				= 0.0;
			Visible 			= false;
			m_ArgValue 			= argvalue;
			m_Message			= "";
			m_Owner 			= from;
			m_Point				= from.Location;
			m_Counter 			= counterInSeconds*TicksPerSeconds;
			m_InitialCounter 	= counterInSeconds*TicksPerSeconds;
			m_Action 			= action;
			m_Timer = new InternalTimer(this);
			m_Timer.Start();
			if (!m_Owner.AddToBackpack(this))
				MoveToWorld(m_Owner.Location, m_Owner.Map);
		}

		public void Tick()
		{
			// ON-GOING ACTION
			if ((m_Counter > 0) && (m_Owner.Map != Map.Internal))
			{
				switch (m_Action)
				{
					case APS_Potion.APS_PotionEffect.StrangeEffect:
						switch (m_ArgValue)
						{
							case 1:
								m_Owner.HueMod = 3+(m_Counter%150)*5;
								break;
							case 2:
								if ( m_Counter % (TicksPerSeconds*7) == 0 )
									if (Utility.RandomDouble()<0.3)
									{
										Effects.PlaySound( m_Owner.Location, m_Owner.Map, m_Owner.Female ? 792 : 1064 );
										m_Owner.Emote("*pete*");
									}
								break;
							case 3:
								if ( m_Counter % (TicksPerSeconds*7) == 0 )
									if (Utility.RandomDouble()<0.3)
									{	
										Effects.PlaySound( m_Owner.Location, m_Owner.Map, m_Owner.Female ? 782 : 1053 );
										m_Owner.Emote("*vomit*");
										Item v=new Vomi();
										m_Owner.Animate( 32, 5, 1, true, false, 0 );
										v.MoveToWorld(m_Owner.Location,m_Owner.Map);
									}
								break;
							case 4:
								if (Utility.RandomDouble()<0.3)
									m_Owner.Direction = (Direction)((int)(Direction.North)+Utility.Random(0,7));
								break;
							case 5:
								if (Utility.RandomDouble()<0.1)
									m_Owner.SendMessage("vous avez des cheveux qui tombent...");
								break;
							case 6:
								if ( m_Counter % (TicksPerSeconds*2) == 0 )
									if (Utility.RandomDouble()<0.3)
										switch(Utility.Random(1,10))
										{
											case 1: m_Owner.Say("uuhu..."); break;
											case 2: m_Owner.Say("miap!"); break;
											case 3: m_Owner.Say("prrrt..."); break;
											case 4: m_Owner.Say("hehe!"); break;
											case 5: m_Owner.Say("pouet pouet!"); break;
											case 6: m_Owner.Say("chooOOOoo..."); break;
											case 7: m_Owner.Say("bipu bipu!"); break;
											case 8: m_Owner.Say("gné!"); break;
											case 9: m_Owner.Say("bouze..."); break;
											case 10: m_Owner.Say("chhhh..."); break;
											default: break;
										}
								break;
							case 7:
								if ( m_Counter % (TicksPerSeconds*3) == 0 )
									if (Utility.RandomDouble()<0.1)
										switch(Utility.Random(1,10))
										{
											case 1: m_Owner.Say("face de rat."); break;
											case 2: m_Owner.Say("vieille carpe..."); break;
											case 3: m_Owner.Say("cul terreux!"); break;
											case 4: m_Owner.Say("merde"); break;
											case 5: m_Owner.Say("pauvre nouille..."); break;
											case 6: m_Owner.Say("sale chien"); break;
											case 7: m_Owner.Say("grognasse..."); break;
											case 8: m_Owner.Say("j't'emmerde..."); break;
											case 9: m_Owner.Say("va chier..."); break;
											case 10: m_Owner.Say("tete de piaf"); break;
											default: break;
										}
								break;
							case 8:
								if ((m_Owner.X == m_Point.X) && (m_Owner.Y == m_Point.Y)) {
									int relativeZ = m_Counter % 2;
									Point3D relativePoint = new Point3D(m_Point.X,m_Point.Y,m_Point.Z+relativeZ);
									m_Owner.MoveToWorld(relativePoint,m_Owner.Map);
								} else {
									m_Point=m_Owner.Location;
								}
								break;
							case 9:
								if ( m_Counter % (TicksPerSeconds*2) == 0 )
									m_Owner.Animate( Utility.Random(9,20), 5, 1, true, false, 0 );
								break;
							case 10:
								if ( m_Counter % (TicksPerSeconds*1) == 0 )
									if (m_Message != "")
									{
										m_Owner.Say(m_Message);
										m_Message ="";
									}
								break;
							default:
								break;
						}
						break;
					case APS_Potion.APS_PotionEffect.Invisibility:
						if (m_Owner.Hidden == false)
							m_Counter=0;
						break;
					case APS_Potion.APS_PotionEffect.NightSight:
						m_Owner.LightLevel = LightCycle.DungeonLevel*m_Counter/m_InitialCounter;
						break;
					case APS_Potion.APS_PotionEffect.Mute:
						if ( m_Counter % (TicksPerSeconds*5) == 0 )
							m_Owner.SendMessage ("Vous ne pouvez plus parler...");
						break;
					case APS_Potion.APS_PotionEffect.Paralyze:
						if ( m_Counter % (TicksPerSeconds*5) == 0 )
							m_Owner.SendMessage ("Vous etes paralyse(e)...");
						break;
					case APS_Potion.APS_PotionEffect.Truth:
						if ( m_Counter % (TicksPerSeconds*5) == 0 )
						{
							m_Owner.SendMessage("Vous etes sous l'effet d'une potion de verite:");
							m_Owner.SendMessage("Vous ne pouvez mentir!... ('roleplay')");
						}
						break;
					case APS_Potion.APS_PotionEffect.Levitate:
						if ((m_Owner.X == m_Point.X) && (m_Owner.Y == m_Point.Y)) {
							int high=3;
							int relativeZ = m_Counter % (high*2);
							if (relativeZ >= high)
								relativeZ = (high*2) - relativeZ;
							Point3D relativePoint = new Point3D(m_Point.X,m_Point.Y,m_Point.Z+relativeZ);
							m_Owner.MoveToWorld(relativePoint,m_Owner.Map);
						} else {
							m_Point=m_Owner.Location;
						}
						break;
					case APS_Potion.APS_PotionEffect.Unfreeze:
						if (m_Owner.Frozen)
						if ( m_Counter % (TicksPerSeconds*5) == 0 )
							m_Owner.SendMessage ("Vous commencez a pouvoir doucement bouger vos membres.");
						break;
					case APS_Potion.APS_PotionEffect.Love:
						if ( m_Message == "")
						{
							bool found = false;
							Mobile cible = null;
							foreach ( Mobile mobile in m_Owner.Map.GetMobilesInRange( m_Owner.Location, 7 ) )
							{
								if ( !mobile.Deleted )
								if ( mobile != m_Owner )
								if ( mobile.Body.IsHuman )
								if ( mobile.Alive )
								if ( !mobile.Hidden )
								{
									if (cible == null) {
										cible=mobile;
										found=true;
									} else if (Utility.RandomDouble()<0.5) {
										cible = mobile;
										found=true;
									}
								}
							}
							if (found)
							{
								m_Owner.SendMessage ("Vous tombez irresistiblement amoureux de "+cible.Name+"!");
								m_Owner.QuestArrow = new TrackArrow( m_Owner, cible, 100 );
								m_Message = cible.Name;
							}
						} else {
							if ( m_Counter % (TicksPerSeconds*5) == 0 )
								m_Owner.SendMessage ("Vous etes tombe amoureux de "+m_Message+", faites en le roleplay...");
						}
						break;
					case APS_Potion.APS_PotionEffect.MAX_Unused: // SPECIFIC CUSTOM POTION EFFECT
							if (m_InitialCounter == m_Counter)
							{
								m_Item=new Item();
								m_Item.ItemID=8148;
								m_Item.Light=LightType.Moongate;
								m_Item.Name="Une porte sur les tenebres";
								m_Item.MoveToWorld(m_Owner.Location,m_Owner.Map);
							}
							if ( m_Counter % (TicksPerSeconds*20) == 0 )
							if (m_Item != null)
							if (!m_Item.Deleted)
							{	
								Mobile badguy=null;
								switch(Utility.Random(1,7))
								{
									case 1: badguy=new LichLord(); break; 		
									case 2: badguy=new Balron();  break; 		
									case 3: badguy=new AncientLich(); break; 	
									case 4: badguy=new Spectre();  break; 		
									case 5: badguy=new BoneKnight(); break;						
									case 6: badguy=new ChaosDaemon();  break;	
									case 7: badguy=new SkeletalKnight(); break;	
									default: break;
								}
								if (badguy != null)
								{
									if (badguy.Backpack != null)
										badguy.Backpack.Delete(); // Remove any loot pack
									badguy.MoveToWorld(m_Item.Location,m_Item.Map);
								}
							}
							Effects.PlaySound(m_Item.Location,m_Item.Map,897);
						break;
					default:
						m_Counter = 0;
						break;
				}
			}

			// STOPING ACTION
			if (m_Counter <= 0) 
			{
				switch ( m_Action )
				{
					case APS_Potion.APS_PotionEffect.StrangeEffect:
						switch (m_ArgValue)
						{
							case 1:
								m_Owner.HueMod = -1;
								break;
							case 2:
							case 3:
							case 4:
							case 6:
							case 7:
							case 9:
								m_Owner.SendMessage("Vous vous sentez mieux");
								break;
							case 5:
								m_Owner.SendMessage("Tout vos cheveux sont tombes...");
/*2.0*
								m_Owner.HairItemID=0;
*1.0*/
								if (m_Owner.Hair != null) m_Owner.Hair.Delete();
/****/
								break;
							case 8:
								m_Owner.SendMessage("Vous arretez de trembler...");
								if ((m_Owner.X == m_Point.X) && (m_Owner.X == m_Point.Y))
									m_Owner.MoveToWorld(m_Point,m_Owner.Map);
								break;
							default:
								break;
						}
						break;
					case APS_Potion.APS_PotionEffect.Invisibility:
						m_Owner.Hidden = false;
						break;
					case APS_Potion.APS_PotionEffect.NightSight:
						m_Owner.LightLevel = 0;
						break;
					case APS_Potion.APS_PotionEffect.Mute:
						m_Owner.Squelched=false;
						m_Owner.SendMessage ("Vous retrouvez l'usage de la parole.");
						break;
					case APS_Potion.APS_PotionEffect.Paralyze:
						m_Owner.Frozen=false;
						m_Owner.SendMessage ("Vous n'etes plus paralyse(e).");
						break;
					case APS_Potion.APS_PotionEffect.Truth:
						m_Owner.SendMessage("*********************");
						m_Owner.SendMessage("L'effet de la potion de verite a pris fin.");
						m_Owner.SendMessage("Vous pouvez mentir a votre guise.");
						break;
					case APS_Potion.APS_PotionEffect.Levitate:
						m_Owner.SendMessage("L'effet de la potion de levitation.");
						if (m_Owner is PlayerMobile)
							((PlayerMobile)m_Owner).Flying=false;
						if ((m_Owner.X == m_Point.X) && (m_Owner.X == m_Point.Y))
							m_Owner.MoveToWorld(m_Point,m_Owner.Map);
						break;
					case APS_Potion.APS_PotionEffect.Unfreeze:
						if (m_Owner.Frozen)
						{
							m_Owner.Frozen = false;
							m_Owner.SendMessage("Vous n'etes plus paralyse.");
						}
						break;
					case APS_Potion.APS_PotionEffect.Love:
						if (m_Message != "") 
						{
							m_Owner.SendMessage("*********************");
							m_Owner.SendMessage ("Vous n'etes plus sous l'effet du filtre d'amour envers "+m_Message+".");
							if (m_Owner.QuestArrow != null)
								m_Owner.QuestArrow.Stop();
						}
						break;
					case APS_Potion.APS_PotionEffect.MAX_Unused:
						Effects.PlaySound(m_Item.Location,m_Item.Map,897);
						if (!m_Item.Deleted)
							m_Item.Delete();
						m_Owner.SendMessage("Le passage s'est fermé...");
						break;
					default:
						break;
				}
				m_Timer.Stop();
				Delete();
			}
			
			m_Counter--;
		}
		
		public APS_DurationActionStone( Serial serial ) : base( serial )
		{}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
			
			writer.Write( (int)m_Action );
			writer.Write( m_Counter );
			writer.Write( m_Owner );
			writer.Write( m_ArgValue );
			writer.Write( m_Item );
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			
			m_Action	= (APS_Potion.APS_PotionEffect)(reader.ReadInt());
			m_Counter 	= reader.ReadInt();
			m_Owner 	= reader.ReadMobile();
			m_ArgValue	= reader.ReadInt();
			m_Item	= reader.ReadItem();

			m_Point	= m_Owner.Location;
			m_Timer = new InternalTimer(this);
			m_Timer.Start();			
		}

		public class InternalTimer : Timer
		{
			APS_DurationActionStone m_Stone;
			public InternalTimer ( APS_DurationActionStone thestone ) : base( TimeSpan.FromSeconds( 1.0/(double)TicksPerSeconds ), TimeSpan.FromSeconds( 1.0/(double)TicksPerSeconds ) )
			{
				m_Stone   = thestone;
			}
			protected override void OnTick()
			{
				if ((m_Stone == null) || (m_Stone.Deleted))
					Stop();
				else
					m_Stone.Tick();
			}
		}
	}
}