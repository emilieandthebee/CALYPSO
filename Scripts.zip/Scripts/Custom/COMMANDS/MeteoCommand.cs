using System;
using System.Collections;
using Server;
using Server.Misc;
using Server.Mobiles;
using Server.Items;

namespace Server.Scripts.Commands
{
	public class WeatherCommand
	{
		public WeatherCommand()
		{
		}

		public static void Initialize()
		{
			Server.Commands.Register( "Meteo", AccessLevel.Player,
							new CommandEventHandler( Weather_OnCommand ) );
		}

		[Usage( "Meteo" )]
		[Description( "Donne la m�t�o actuelle (Gets the actual weather)." )]
		public static void Weather_OnCommand( CommandEventArgs e )
		{
			Mobile from=e.Mobile;
			if (from.Map == Map.Malas)
			{
				from.SendMessage("Il fait un temps digitallement vert aujourd'hui...");
				return;
			}
			
			ArrayList weathers = Weather.GetWeatherList(from.Map);
			int intersections=0;
			
			int avg_type=0;
			int avg_density=0;
			int avg_temperature=0;

			for ( int i = 0; i < weathers.Count; i++ )
			{
				Weather weather=((Weather)(weathers[i]));
				if ( weather.Active )
				{
					bool contains = ( weather.Area.Length == 0 );
					for ( int j = 0; !contains && j < weather.Area.Length; ++j )
						contains = weather.Area[j].Contains( from.Location );
					if (contains)
					{
						int temperature = weather.m_Temperature;
						int density;
						if ( weather.Stage < 15 )
							density = weather.Stage * 5;
						else
						{
							density = 150 - (weather.Stage * 5);
							if ( density < 10 )
								density = 10;
							else if ( density > 70 )
								density = 70;
						}
						intersections++;
						avg_density+=density;
						avg_temperature+=temperature;
					}
				}
			}
			if (intersections == 0)
			{
				avg_type=0xFE;
				avg_density=0;
				avg_temperature=Weather.GetTemperature(from);
			} else {
				avg_density=avg_density/intersections;
				avg_temperature=avg_temperature/intersections;
				if ( avg_density == 0 )
					avg_type = 20;  // RESET
				else if ( avg_temperature > 0 )
				{
					if ( avg_density == 70)
						avg_type = 3; // "A storm is brewing."
					else if ((avg_density < 15) && (avg_density > 40))
						avg_type = 1; // "A fierce storm approaches."
					else
						avg_type = 0; // "It starts to rain"
				}
				else
					avg_type = 2; // "It begins to snow"

			}
			if (from.AccessLevel >= AccessLevel.Administrator)
			{
				from.SendMessage( "[ADMIN only] Temperature: {0}",avg_temperature );
				from.SendMessage( "[ADMIN only] Pression:{0}",avg_density );
				from.SendMessage( "[ADMIN only] Type:{0}",avg_type );
			}

			if (avg_density == 0)
			{
				from.SendMessage("Pas un nuage dans le ciel...");
			} else if (avg_density < 5) {
				from.SendMessage("Un ou deux nuages de ci de l�...");
			} else if (avg_density < 20) {
				from.SendMessage("Le ciel est couvert...");
			} else if (avg_density < 50) {
				from.SendMessage("Le ciel est couvert de nuages gris...");
			} else  if (avg_density < 50) {
				from.SendMessage("Le ciel est couvert de nuages orageux...");
			} else {
				from.SendMessage("Le ciel est couvert de nuages noirs...");
			}

			switch (avg_type)
			{
				case 0:  from.SendMessage( "Le temps est pluvieux" );
					 break;
				case 1:  from.SendMessage( "Le temps est orageux" );
					 break;
				case 2:  from.SendMessage( "Le temps est neigeux" );
					 break;
				case 3:  from.SendMessage( "C'est la temp�te..." );
					 break;
				case 20:  from.SendMessage( "Le temps est sec" );
					 break;
				default: from.SendMessage( "Le temps est humide" );
					 break;
			}
			if (avg_temperature < -30)
				from.SendMessage( "C'est un froid extr�me!" );
			else if (avg_temperature < -10)
				from.SendMessage( "Il fait tr�s froid!" );
			else if (avg_temperature < 0)
				from.SendMessage( "Il fait froid." );
			else if (avg_temperature < 10)
				from.SendMessage( "C'est un temps tr�s frais." );
			else if (avg_temperature < 20)
				from.SendMessage( "Il fait doux." );
			else if (avg_temperature < 30)
				from.SendMessage( "Il fait chaud." );
			else if (avg_temperature < 40)
				from.SendMessage( "Il fait tr�s chaud!" );
			else
				from.SendMessage( "C'est une chaleur extr�me!" );

			int hours, minutes;
			Server.Items.Clock.GetTime( from.Map, from.X, from.Y, out hours, out minutes );
			if (avg_density < 5)
			if (( hours > 22 ) || ( hours < 6 ))
			{
				MoonPhase mp=Clock.GetMoonPhase( from.Map, from.X, from.Y );
				switch(mp)
				{
				case MoonPhase.NewMoon: from.SendMessage("C'est une nuit sans Lune Bleue...");
					break;
				case MoonPhase.WaxingCrescentMoon: from.SendMessage("La Lune Bleue est entrain de cro�tre et est bient�t au quart.");
					break;
				case MoonPhase.FirstQuarter: from.SendMessage("C'est le quart ascendant de la Lune Bleue");
					break;
				case MoonPhase.WaxingGibbous: from.SendMessage("C'est presque la Pleine Lune Bleue.");
					break;
				case MoonPhase.FullMoon: from.SendMessage("C'est la Pleine Lune Bleue!");
					break;
				case MoonPhase.WaningGibbous: from.SendMessage("C'est la fin de la pleine Lune Bleue... Elle commence � d�cro�tre.");
					break;
				case MoonPhase.LastQuarter: from.SendMessage("C'est le quart descendant de la Lune Bleue.");
					break;
				case MoonPhase.WaningCrescent: from.SendMessage("La Lune Bleue est entrain de dispara�tre...");
					break;
				}
				mp=(MoonPhase)(( ((int)mp) + hours ) % 8 );
				switch(mp)
				{
				case MoonPhase.NewMoon: from.SendMessage("C'est une nuit sans Lune Rousse...");
					break;
				case MoonPhase.WaxingCrescentMoon: from.SendMessage("La Lune Rousse est entrain de cro�tre et est bient�t au quart.");
					break;
				case MoonPhase.FirstQuarter: from.SendMessage("C'est le quart ascendant de la Lune Rousse");
					break;
				case MoonPhase.WaxingGibbous: from.SendMessage("C'est presque la Pleine Lune Rousse.");
					break;
				case MoonPhase.FullMoon: from.SendMessage("C'est la Pleine Lune Rousse!");
					break;
				case MoonPhase.WaningGibbous: from.SendMessage("C'est la fin de la pleine Lune Rousse... Elle commence � d�cro�tre.");
					break;
				case MoonPhase.LastQuarter: from.SendMessage("C'est le quart descendant de la Lune Rousse.");
					break;
				case MoonPhase.WaningCrescent: from.SendMessage("La Lune Rousse est entrain de dispara�tre...");
					break;
				}
			}
		}
	}
}

