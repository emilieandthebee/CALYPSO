/*** ALAMBIK ***/
// That AI will make thecreature attack anything in range! (even familiars!)
using System;
using System.Collections;
using Server.Targeting;
using Server.Network;

namespace Server.Mobiles
{

	public class FoolishAI : BaseAI
	{
		public FoolishAI(BaseCreature m) : base (m)
		{
		}
	
		public override bool DoActionWander()
		{
			m_Mobile.DebugSay( "I have No Combatant" );
			if( Acquire() )
			{
				if ( m_Mobile.Debug )
					m_Mobile.DebugSay( "I have detected " + m_Mobile.FocusMob.Name + " and I will attack" );
				m_Mobile.Combatant = m_Mobile.FocusMob;
				Action = ActionType.Combat;
			}			
			else
			{
				base.DoActionWander();
			}

			return true;			
		}
			
		public override bool DoActionCombat()
		{
			if( m_Mobile.Combatant == null || m_Mobile.Combatant.Deleted )
			{
				m_Mobile.DebugSay("My combatant is deleted");
				Action = ActionType.Guard;
				return true;
			}

			if( WalkMobileRange( m_Mobile.Combatant, 1, true, m_Mobile.RangeFight, m_Mobile.RangeFight ) )
			{
				// Be sure to face the combatant
				m_Mobile.Direction = m_Mobile.GetDirectionTo( m_Mobile.Combatant.Location );
			}
			else
			{
				if( m_Mobile.Combatant != null )
				{
					if ( m_Mobile.Debug )
						m_Mobile.DebugSay("I am still not in range of " + m_Mobile.Combatant.Name);
					if( (int) m_Mobile.GetDistanceToSqrt( m_Mobile.Combatant ) > m_Mobile.RangePerception + 1 )
					{
						if ( m_Mobile.Debug )
							m_Mobile.DebugSay( "I have lost " + m_Mobile.Combatant.Name );
						Action = ActionType.Guard;
						return true;
					}
				}
			}
			
			return true;
		}
		
		public override bool DoActionGuard()
		{
			if ( Acquire() )
			{
				if ( m_Mobile.Debug )
					m_Mobile.DebugSay( "I have detected {0}, attacking", m_Mobile.FocusMob.Name );
				m_Mobile.Combatant = m_Mobile.FocusMob;
				Action = ActionType.Combat;
			}
			else
			{
				base.DoActionGuard();
			}

			return true;
		}
		
		public bool Acquire()
		{
			Map map = m_Mobile.Map;
			if( map != null )
			{
				Mobile newFocusMob = null;
				double val = double.MinValue;
				double theirVal;
				IPooledEnumerable eable = map.GetMobilesInRange( m_Mobile.Location, m_Mobile.RangePerception );
				foreach( Mobile m in eable )
				{
					if ( m.Deleted || m.Blessed )
						continue;
					// Let's not target ourselves...
					if ( m == m_Mobile || m is BaseFamiliar )
						continue;
					// Dead targets are invalid.
					if ( !m.Alive || m.IsDeadBondedPet )
						continue;
					// Staff members cannot be targeted.
					if ( m.AccessLevel > AccessLevel.Player )
						continue;
					// Can't acquire a target we can't see.
					if ( !m_Mobile.CanSee( m ) )
						continue;
/*2.0*
					theirVal = m_Mobile.GetFightModeRanking( m, FightMode.Closest, false );
*1.0*/
					theirVal = m_Mobile.GetValueFrom( m, FightMode.Closest, false );
/****/
					if( theirVal > val && m_Mobile.InLOS( m ) )
					{
						newFocusMob = m;
						val = theirVal;
					}
				}
				eable.Free();
				m_Mobile.FocusMob = newFocusMob;
			}
			return (m_Mobile.FocusMob != null);
		}			
	}
}
