using System;
using Server;
using Server.Gumps;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Targeting;
using System.Collections;
using Server.Scripts.Commands;
using Server.Prompts;
using Server.Guilds;

namespace Server.Items
{
	public class miniGM : Item
	{

		public static String[] m_ItemsProps = new String[]
		{
			"Renommer",
			"Mot de passe",
			"Deverouiller",
			"Verouiller/Encrypte",
			"Encrypte+Securise",
			"Quantité",
			"Difficulte",
		};

		public static String[] m_ItemsPropsRange = new String[]
		{
			"Très Faible",
			"Faible",
			"Moyenne",
			"Dure",
			"Très dure",
		};
	
		public static String[] m_MobilesMenu1 = new String[]
		{
			"Habitant non technophobe",
			"Habitant technophobe",
			"Inquisiteur",
			"Membre Techno-Glaive",
			"Garde Techno-Glaive",
			"Membre Neurosapiens",
			"Garde Neurosapiens",
			"Membre Clercs Actifs",
			"Garde Clercs Actifs",
			"Membre Ailes D'Argents",
			"Garde Ailes D'Argents",
		};	
		public static Type[] m_MobilesMenu1Types = new Type[]
		{
			typeof( Habitant ),
			typeof( TechnophobeHabitant ),
			typeof( TechnoInquisiteur ),
			typeof( TechnoGlaiveMember ),
			typeof( TechnoGlaiveGuard ),
			typeof( NeuroSapiensMember ),
			typeof( NeuroSapiensGuard ),
			typeof( ClercActifMember ),
			typeof( ClercActifGuard ),
			typeof( AilesDArgentMember ),
			typeof( AilesDArgentGuard ),
		};
		
		public static String[] m_MobilesMenu2 = new String[]
		{
			"N/A",
		};	
		public static Type[] m_MobilesMenu2Types = new Type[]
		{
			typeof( Bird ),
		};
		
		public static String[] m_MobilesMenu3 = new String[]
		{
			"Chien",
			"Chat",
			"Aigle",
			"Poulet",
			"Perroquet",
			"Taureau",
			"Vache",
			"Snake",
			"BlackBear",
			"Ours brun",
			"Ours noir",
			"Grizzly",
			"Ours polaire",
			"Loup gris",
			"Loup des bois",
			"Loup blanc",
			"Cerf",
			"Daim",
			"Panthere",
			"Cougar",
			"Leopard des neiges",
			"Craoaud",
			"Crapaud geant",
			"Crocodile",
			"Lama",
			"Lama a monter",
			"Lama de transport",
			"Cheval",
			"Cheval de transport",
			"Autruche des forets",
			"Autruche du desert",
			"Porc",
			"Cochon",
			"Rat",
			"Rat d'egout",
			"Rat geant",
			"Lapin",
			"Chevre",
			"Chevre des montagnes",
			"Mouton",
			"Gorille",
			"Phoque",
			"Dauphin",
		};	
		public static Type[] m_MobilesMenu3Types = new Type[]
		{
			typeof( Dog ),
			typeof( Cat ),
			typeof( Eagle ),
			typeof( Chicken ),
			typeof( AParrot ),
			typeof( Bull ),
			typeof( Cow ),
			typeof( Snake ),
			typeof( BrownBear ),
			typeof( BlackBear ),
			typeof( GrizzlyBear ),
			typeof( PolarBear ),
			typeof( GreyWolf ),
			typeof( TimberWolf ),
			typeof( WhiteWolf ),
			typeof( GreatHart ),
			typeof( Hind ),
			typeof( Panther ),
			typeof( Cougar ),
			typeof( SnowLeopard ),
			typeof( BullFrog ),
			typeof( GiantToad ),
			typeof( Alligator ),
			typeof( Llama ),
			typeof( RidableLlama ),
			typeof( PackLlama ),
			typeof( Horse ),
			typeof( PackHorse ),
			typeof( ForestOstard ),
			typeof( DesertOstard ),
			typeof( Boar ),
			typeof( Pig ),
			typeof( Rat ),
			typeof( Sewerrat ),
			typeof( GiantRat ),
			typeof( Rabbit ),
			typeof( Goat ),
			typeof( MountainGoat ),
			typeof( Sheep ),
			typeof( Gorilla ),
			typeof( Walrus ),
			typeof( Dolphin ),
		};

		public static String[] m_MobilesMenu4 = new String[]
		{
			"Mogouaille",
			"Chauve-Pire",
			"Escorlien",
			"Guenilleux ",
			"Jabilien Piqueur",
			"Punaise",
			"Gobelamort ",
			"Gerpent",
			"Egorgeur",
			"DoparaigneeVelue",
			"Doparaignee Nacree",
			"Doparaignee Glacee",
			"Doparaignee Bariolee",
			"Doparaignee Nacree Vedeuse",
			"Scorpius ",
			"GriffeMord",
			"Locnaisse",
			"Poulpauvent",
			"Grole",
		};	
		public static Type[] m_MobilesMenu4Types = new Type[]
		{
			typeof (Mogouaille),
			typeof (ChauvePire),
			typeof (Escorlien ),
			typeof (Guenilleux),
			typeof (JabilienPiqueur),
			typeof (Punaise),
			typeof (Gobelamort ),
			typeof (Gerpent),
			typeof (Egorgeur),
			typeof (DoparaigneeVelue),
			typeof (DoparaigneeNacree),
			typeof (DoparaigneeGlacee),
			typeof (DoparaigneeBariolee),
			typeof (DoparaigneeNacreeVedeuse),
			typeof (Scorpius),
			typeof (GriffeMord),
			typeof (Locnaisse),
			typeof (Poulpauvent),
			typeof (Grole ),
		};
		
		public static String[] m_MobilesMenu5 = new String[]
		{
			"Ratapieds",
			"Ratapieds Archer",
			"Vindouze",
			"Vindouze (bombes)",
			"Vindouze (chef)",
			"Vindouze (gros chef)",
			"Ventrafaim",
			"Ventrafaim (Gros)",
			"Homolezardus",
			"Trolay",
			"Bibrute",
			"Monoculaire",
			"Raporteuse",
			"Cyberateur",
			"Cyclope",
			"Vibifort",
			"Neila",
		};	
		public static Type[] m_MobilesMenu5Types = new Type[]
		{
			typeof (Ratman),
			typeof (RatmanArcher),
			typeof (Orc),
			typeof (OrcBomber),
			typeof (OrcCaptain),
			typeof (OrcishLord),
			typeof (Ogre),
			typeof (OgreLord),
			typeof (Lizardman),
			typeof (Troll),
			typeof (Ettin),
			typeof (Cyclops),
			typeof (Cyberateur),
			typeof (Raporteuse),
			typeof (Cyclope),
			typeof (Vibifort),
			typeof (Neila),
		};

		public static String[] m_MobilesMenu6 = new String[]
		{
			"Cyber Bot 547GG",
			"Cyber Virus GG45",
			"Cyber Glaire Digital",
			"Cyber Entite Folle",
			"Cyber Frappeur",
			"Cyber Epouvante",
			"Cyber Virus Non Repertorie",
			"Cyber Monstruositee Digitale",
			"Cyber Avaleur",
			"Cyber Voyageur Agressif",
			"Cyber Glouton Vengeur",
		};	
		public static Type[] m_MobilesMenu6Types = new Type[]
		{
			typeof (CyberBot547GG),
			typeof (CyberVirusGG45),
			typeof (CyberGlaireDigital),
			typeof (CyberEntiteFolle),
			typeof (CyberFrappeur),
			typeof (CyberEpouvante),
			typeof (CyberVirusNonRepertorie),
			typeof (CyberMonstruositeeDigitale),
			typeof (CyberAvaleur),
			typeof (CyberVoyageurAgressif),
			typeof (CyberGloutonVengeur),
		};
//////////////////////////////////////////////////////////////////////////
		public static String[] m_ItemsMenu1 = new String[]
		{
			"Coffre en bois",
			"Coffre en metal",
			"Coffret en bois",
			"Coffret dore",
			"Sac a dos",
			"Petit sac",
			"Coffre a recompenses",
			"Coffre HyperSecure",
			"Livre HyperSecure",
			"Oeuf de Neila",
			"Carte au tresor",
			"Fuel de vehicule",
			"Clef de WaveSpeeder",
			"Clef de OctoNuker",
			"Clef de EagleGear",
			"Gateau anniversaire joueur",
		};	
		public static Type[] m_ItemsMenu1Types = new Type[]
		{
			typeof( WoodenChest ),
			typeof( MetalChest ),
			typeof( WoodenBox ),
			typeof( MetalBox ),
			typeof( Backpack ),
			typeof( Bag ),
			typeof( Bag /*RewardBox*/ ),
			typeof( SecuredContainer ),
			typeof( EncryptedBook ),
			typeof( NeilaEgg ),
			typeof( TreasureMap ),
			typeof( VehicleFuel ),
			typeof( VehicleKey ),
			typeof( VehicleKey ),
			typeof( VehicleKey ),
			typeof( RewardCake ),
		};
		
		public static String[] m_ItemsMenu2 = new String[]
		{
			"Bag",
		};	
		public static Type[] m_ItemsMenu2Types = new Type[]
		{
			typeof( Bag ),
		};
		
		public static String[] m_ItemsMenu3 = new String[]
		{
			"Bag",
		};	
		public static Type[] m_ItemsMenu3Types = new Type[]
		{
			typeof( Bag ),
		};

		public static String[] m_ItemsMenu4 = new String[]
		{
			"Bag",
		};	
		public static Type[] m_ItemsMenu4Types = new Type[]
		{
			typeof( Bag ),
		};
		
		public static String[] m_ItemsMenu5 = new String[]
		{
			"Bag",
		};	
		public static Type[] m_ItemsMenu5Types = new Type[]
		{
			typeof( Bag ),
		};

		public static String[] m_ItemsMenu6 = new String[]
		{
			"Bag",
		};	
		public static Type[] m_ItemsMenu6Types = new Type[]
		{
			typeof( Bag ),
		};
//////////////////////////////////////////////////////////////////////////
		public Point3D Location1 = new Point3D(5661,1678,0);
		public Point3D Location2 = new Point3D(5661,1678,0);
		public Point3D Location3 = new Point3D(5661,1678,0);
		public Point3D Location4 = new Point3D(5661,1678,0);
		public Point3D Location5 = new Point3D(5661,1678,0);
		public Point3D Location6 = new Point3D(5661,1678,0);
		public Point3D Location7 = new Point3D(5661,1678,0);
		public Point3D Location8 = new Point3D(5661,1678,0);
		public Point3D Location9 = new Point3D(5661,1678,0);
		public Point3D Location11 = new Point3D(5661,1678,0);
		public Point3D Location12 = new Point3D(5661,1678,0);
		public Point3D Location13 = new Point3D(5661,1678,0);
		public Point3D Location14 = new Point3D(5661,1678,0);
		public Point3D Location15 = new Point3D(5661,1678,0);
		public Point3D Location16 = new Point3D(5661,1678,0);
		public Point3D Location17 = new Point3D(5661,1678,0);
		public Point3D Location18 = new Point3D(5661,1678,0);
		public Point3D Location19 = new Point3D(5661,1678,0);
		public string LocationName11="a definir";
		public string LocationName12="a definir";
		public string LocationName13="a definir";
		public string LocationName14="a definir";
		public string LocationName15="a definir";
		public string LocationName16="a definir";
		public string LocationName17="a definir";
		public string LocationName18="a definir";
		public string LocationName19="a definir";
		public int MobileIndex=0;
		public int ItemIndex=0;
		public int ItemLevel=1;
		public bool InactiveMobile=true;
		public bool BadGuys=false;
		public bool MobileSelectionMode=true;
		public string MobileName="";
		public string ItemName="";
		public string MobileReName="";
		public string MobileSay="";
		public string ItemReName="";
		public Mobile ToPlayer=null;
		public Mobile PreSelectedMobile = null;
		public Mobile TargetedMobile = null;
		public int MOBCAT = (int)GM.Buttons.MOBCAT1;
		public int ITCAT = (int)GM.Buttons.ITCAT1;
		public Item m_ShardControlerStone = null;
		
		[CommandProperty( AccessLevel.Administrator )]
		public Item ShardControlerStone
		{
			get{ return m_ShardControlerStone; }
			set{ m_ShardControlerStone = value; }
		}

		bool m_Debug=false;
		[CommandProperty( AccessLevel.Administrator )]
		public bool Debug
		{
			get{ return m_Debug; }
			set{ m_Debug = value; }
		}
	
		[Constructable]
		public miniGM() : base( 572 )
		{
			Visible=false;
		}

		public miniGM( Serial serial ) : base( serial )
		{}

		public override void OnDoubleClick( Mobile from )
		{
			from.SendGump(new GM(from,this,-1,m_Debug));
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 3 ); // version
			writer.Write( m_ShardControlerStone );
			writer.Write( BadGuys );
			writer.Write( Location1 );
			writer.Write( Location2 );
			writer.Write( Location3 );
			writer.Write( Location4 );
			writer.Write( Location5 );
			writer.Write( Location6 );
			writer.Write( Location7 );
			writer.Write( Location8 );
			writer.Write( Location9 );
			writer.Write( Location11 );
			writer.Write( Location12 );
			writer.Write( Location13 );
			writer.Write( Location14 );
			writer.Write( Location15 );
			writer.Write( Location16 );
			writer.Write( Location17 );
			writer.Write( Location18 );
			writer.Write( Location19 );
			writer.Write( LocationName11 );
			writer.Write( LocationName12 );
			writer.Write( LocationName13 );
			writer.Write( LocationName14 );
			writer.Write( LocationName15 );
			writer.Write( LocationName16 );
			writer.Write( LocationName17 );
			writer.Write( LocationName18 );
			writer.Write( LocationName19 );
			writer.Write( MobileIndex );
			writer.Write( ItemIndex );
			writer.Write( InactiveMobile );
			writer.Write( MobileSelectionMode );
			writer.Write( MobileName );
			writer.Write( ItemName );
			writer.Write( MobileReName );
			writer.Write( ItemReName );

		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			switch (version)
			{
				case 3:
					m_ShardControlerStone=reader.ReadItem(  );
					goto case 2;
				case 2:
					BadGuys=reader.ReadBool(  );
					goto case 1;
				case 1:
					Location1=reader.ReadPoint3D(  );
					Location2=reader.ReadPoint3D(  );
					Location3=reader.ReadPoint3D(  );
					Location4=reader.ReadPoint3D(  );
					Location5=reader.ReadPoint3D(  );
					Location6=reader.ReadPoint3D(  );
					Location7=reader.ReadPoint3D(  );
					Location8=reader.ReadPoint3D(  );
					Location9=reader.ReadPoint3D(  );
					Location11=reader.ReadPoint3D(  );
					Location12=reader.ReadPoint3D(  );
					Location13=reader.ReadPoint3D(  );
					Location14=reader.ReadPoint3D(  );
					Location15=reader.ReadPoint3D(  );
					Location16=reader.ReadPoint3D(  );
					Location17=reader.ReadPoint3D(  );
					Location18=reader.ReadPoint3D(  );
					Location19=reader.ReadPoint3D(  );
					LocationName11=reader.ReadString(  );
					LocationName12=reader.ReadString(  );
					LocationName13=reader.ReadString(  );
					LocationName14=reader.ReadString(  );
					LocationName15=reader.ReadString(  );
					LocationName16=reader.ReadString(  );
					LocationName17=reader.ReadString(  );
					LocationName18=reader.ReadString(  );
					LocationName19=reader.ReadString(  );
					MobileIndex=reader.ReadInt(  ); MobileIndex=0;
					ItemIndex=reader.ReadInt(  ); ItemIndex=0;
					InactiveMobile=reader.ReadBool(  );
					MobileSelectionMode=reader.ReadBool(  );
					MobileName=reader.ReadString(  );
					ItemName=reader.ReadString(  );
					MobileReName=reader.ReadString(  );
					ItemReName=reader.ReadString(  );
					break;
				default:
					break;
			}
		}
		public void DoActionMobile (Mobile from, int action)
		{
			if (   (PreSelectedMobile != null) 
				&& (PreSelectedMobile.AccessLevel == AccessLevel.Player) 
				&& !PreSelectedMobile.Deleted 
				&& PreSelectedMobile.Alive 
				&& ((!PreSelectedMobile.Blessed  && PreSelectedMobile.CanBeDamaged()) || (action == (int)GM.Buttons.SAY_MOBILE)) )
			switch (action)
			{
				case (int)GM.Buttons.GOTO: 	if (PreSelectedMobile is BaseCreature)
												from.Target = new GotoTarget(((BaseCreature)PreSelectedMobile)); 
											break;
				case (int)GM.Buttons.UP: 	PreSelectedMobile.Direction=Direction.Up; break;
				case (int)GM.Buttons.DOWN: 	PreSelectedMobile.Direction=Direction.Down; break;
				case (int)GM.Buttons.LEFT: 	PreSelectedMobile.Direction=Direction.Left; break;
				case (int)GM.Buttons.RIGHT: PreSelectedMobile.Direction=Direction.Right; break;
				case (int)GM.Buttons.NORTH:	PreSelectedMobile.Direction=Direction.North; break;
				case (int)GM.Buttons.EAST: 	PreSelectedMobile.Direction=Direction.East; break;
				case (int)GM.Buttons.WEST: 	PreSelectedMobile.Direction=Direction.West; break;
				case (int)GM.Buttons.SOUTH: PreSelectedMobile.Direction=Direction.South; break;
				case (int)GM.Buttons.SAY_MOBILE:		PreSelectedMobile.Say(MobileSay); break;
				case (int)GM.Buttons.MOBILE_RENAME:	if (MobileReName!="") PreSelectedMobile.Name=MobileReName; break;
				case (int)GM.Buttons.MB1: 	if ((TargetedMobile == null) || TargetedMobile.Deleted || !TargetedMobile.Alive)
												from.Target = new MobileTarget(from,this,action);
											else
											{
												if (PreSelectedMobile is BaseCreature)
												{
													((BaseCreature)PreSelectedMobile).AIObject.Action = ActionType.Combat;
													PreSelectedMobile.Combatant=TargetedMobile;
													((BaseCreature)PreSelectedMobile).Warmode=true;
												}
											}
											break;
				case (int)GM.Buttons.MB2: 	PreSelectedMobile.Kill(); break;
				case (int)GM.Buttons.MB3: 	PreSelectedMobile.Delete(); break;
				case (int)GM.Buttons.MB4: 	if (PreSelectedMobile is BaseCreature)
											{
												if ( ((BaseCreature)PreSelectedMobile).AIObject.Action == ActionType.FollowThisLocation)
												{
													((BaseCreature)PreSelectedMobile).CurrentSpeed=((BaseCreature)PreSelectedMobile).PassiveSpeed;
													((BaseCreature)PreSelectedMobile).AIObject.Action = ActionType.Wander;
													from.SendMessage("La creature ne vous suis plus.");
												} else {
													from.SendMessage("La creature vous suis.");													
													((BaseCreature)PreSelectedMobile).FollowThisLocation=from;
													((BaseCreature)PreSelectedMobile).AIObject.Action = ActionType.FollowThisLocation;
													((BaseCreature)PreSelectedMobile).CurrentSpeed=0.1;
												}
											}
											break;
				case (int)GM.Buttons.MB5: 	if (PreSelectedMobile is BaseCreature)
											if (((BaseCreature)PreSelectedMobile).CurrentSpeed == ((BaseCreature)PreSelectedMobile).ActiveSpeed)
												((BaseCreature)PreSelectedMobile).CurrentSpeed = ((BaseCreature)PreSelectedMobile).PassiveSpeed;
											else
												((BaseCreature)PreSelectedMobile).CurrentSpeed = ((BaseCreature)PreSelectedMobile).ActiveSpeed;
												break;
				case (int)GM.Buttons.MB6: 	PreSelectedMobile.Hidden=!PreSelectedMobile.Hidden; 
											PreSelectedMobile.Frozen=PreSelectedMobile.Hidden;
											break;
				case (int)GM.Buttons.MB7:   if (PreSelectedMobile is BaseCreature)
												if (((BaseCreature)PreSelectedMobile).Team == 101010)
												{
													((BaseCreature)PreSelectedMobile).GuildName="NO GUILD";												
													((BaseCreature)PreSelectedMobile).Team=0;
												} else {
													((BaseCreature)PreSelectedMobile).GuildName="badguys";												
													((BaseCreature)PreSelectedMobile).Team=101010;
												}; 
											break;
				case (int)GM.Buttons.PEACE: if (PreSelectedMobile is BaseCreature)
											{
												((BaseCreature)PreSelectedMobile).Warmode=false;
												((BaseCreature)PreSelectedMobile).FightMode=FightMode.None;
												((BaseCreature)PreSelectedMobile).AI=AIType.AI_Animal;
												((BaseCreature)PreSelectedMobile).Combatant = null;
											}
											break;
				case (int)GM.Buttons.WAR: 	if (PreSelectedMobile is BaseCreature)
											{
												((BaseCreature)PreSelectedMobile).FightMode=FightMode.Closest;
												((BaseCreature)PreSelectedMobile).Warmode=true;
												switch ( ((BaseCreature)PreSelectedMobile).DefaultAI )
												{
													case AIType.AI_Berserk:
													case AIType.AI_Archer:
													case AIType.AI_Predator:
													case AIType.AI_Melee:
														((BaseCreature)PreSelectedMobile).ChangeAIToDefault();
														break;
													default:
														((BaseCreature)PreSelectedMobile).AI=AIType.AI_Melee;
														break;
												}
											}
											break;
				default: break;
			}
		}
	}
	
	public class MobileTarget : Target
	{
		private int m_action;
		private miniGM m_Stone;
		private Mobile m_from;
		
		public MobileTarget(Mobile from, miniGM stone, int action ) : base( -1, true, TargetFlags.None )
		{
			m_Stone=stone;
			m_action=action;
			m_from = from;
			m_from.SendMessage("Selectionnez une creature.");
		}
		
		protected override void OnTarget( Mobile from, object targeted )
		{
			if( targeted is Mobile )
			{
				m_Stone.TargetedMobile = (Mobile)targeted;
				if (m_action>=0) m_Stone.DoActionMobile(m_from,m_action);
			}
		}
	}
	
	public class GotoTarget : Target
	{
		private BaseCreature m_bc;
		public GotoTarget( BaseCreature bc ) : base( -1, true, TargetFlags.None )
		{
			m_bc = bc;
		}
		protected override void OnTarget( Mobile from, object targeted )
		{
			if ((m_bc == null) || m_bc.Deleted || !m_bc.Alive )
				return;
			if ( targeted is Mobile )
			{
				m_bc.Home=((Mobile)targeted).Location;
				m_bc.DoNotIdle=true;
				m_bc.RangeHome=0;
			}
			else if ( targeted is Item )
			{
				m_bc.Home=((Item)targeted).Location;
				m_bc.DoNotIdle=true;
				m_bc.RangeHome=0;
			}
			else if ( targeted is IPoint3D )
			{
				m_bc.Home=new Point3D((IPoint3D)targeted);
				m_bc.DoNotIdle=true;
				m_bc.RangeHome=0;
			}
			else 
				from.SendMessage( "Cible non valide" );
		}
	}
}
