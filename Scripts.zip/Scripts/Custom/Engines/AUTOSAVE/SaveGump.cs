using System;
using Server;
using Server.Gumps;

namespace Server.Gumps
{
	public class SaveGump : Gump
	{
		public SaveGump()
			: base( 200, 200 )
		{
			this.Closable=true;
			this.Disposable=true;
			this.Dragable=true;
			this.Resizable=false;
			this.AddPage(0);
			this.AddBackground(0, 0, 353, 118, 9270);
			this.AddItem(297, 38, 4168);
			this.AddLabel(118, 15, 1149, @"Sauvegarde du Monde");
			this.AddLabel(48, 71, 255, @"cela peut prendre jusqu'� une minute");
			this.AddLabel(48, 39, 255, @"Attendez le temps que le monde soit sauv�!");
			this.AddItem(12, 38, 4171);

		}
	}
}