using System;
using Server;

namespace Server.Items
{
	public class RangerBag : Bag
	{
		[Constructable]
		public RangerBag()
		{
			PlaceItemIn( 30, 35, new FireBowScroll() );
			PlaceItemIn( 50, 35, new FlightOfThePheonixScroll() );
			PlaceItemIn( 70, 35, new HuntersAimScroll() );
			PlaceItemIn( 90, 35, new IceBowScroll() );
			PlaceItemIn( 30, 55, new LightningBowScroll() );
			PlaceItemIn( 50, 55, new RangerFamiliarScroll() );
			PlaceItemIn( 70, 55, new RangerNoxBowScroll() );
		}

		private void PlaceItemIn( int x, int y, Item item )
		{
			AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public RangerBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}