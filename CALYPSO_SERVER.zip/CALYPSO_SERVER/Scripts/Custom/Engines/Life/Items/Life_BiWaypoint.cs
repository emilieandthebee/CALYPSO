/*
 * A Bi-Waypoint is a 1 to 2 waypoints: the choice between 2 waypoints is
 * done randomly. This allow to choose different paths (example: crossroad)
 * You can create branches as much as you want by creating new instances.
 */

 using System;
using Server;
using Server.Targeting;
using Server.Items;

namespace Server.Items
{
	[FlipableAttribute( 0x1f14, 0x1f15, 0x1f16, 0x1f17 )]
	public class BiWayPoint : WayPoint
	{
		
		[CommandProperty( AccessLevel.GameMaster )]
		public WayPoint Next { get{ return m_Next; } set{ m_Next = value; } }

		private WayPoint m_AlternativeNext;
		[CommandProperty( AccessLevel.GameMaster )]
		public WayPoint AlternativeNext { get{ return m_AlternativeNext; } set{ m_AlternativeNext = value; } }
		
		private int m_AltProbaPurcent;
		[CommandProperty( AccessLevel.GameMaster )]
		public int AltProbaPurcent { get{ return m_AltProbaPurcent; } set{ m_AltProbaPurcent = value; } }

		[Constructable]
		public BiWayPoint() : base( 0x1f14 )
		{
			this.Hue = 0x498;
			this.Visible = false;
			this.Name = "AI Bi-Way Point";
			this.Movable = false;
		}

		public BiWayPoint( WayPoint prev ) : this()
		{
			if ( prev != null )
				prev.NextPoint = this;
		}

		[CommandProperty( AccessLevel.GameMaster )]
		public override WayPoint NextPoint
		{
			get
			{
				if (Utility.Random(100)<m_AltProbaPurcent)
					return m_AlternativeNext;
				else
					return m_Next;
			}
			set
			{
				m_Next = value;
			}
		}

		public BiWayPoint( Serial serial ) : base( serial )
		{
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();

			switch( version )
			{
				case 0:
				{
					m_AlternativeNext = reader.ReadItem() as WayPoint;
					m_AltProbaPurcent = reader.ReadInt();
					break;
				}
			}
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 );

			writer.Write( m_AlternativeNext );
			writer.Write( m_AltProbaPurcent );
		}
	}
}
