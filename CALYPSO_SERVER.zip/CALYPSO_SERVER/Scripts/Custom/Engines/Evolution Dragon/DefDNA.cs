using System;
using Server.Items;

namespace Server.Engines.Craft
{
	public class DefDNA : CraftSystem
	{
		public override SkillName MainSkill
		{
			get	{ return SkillName.AnimalTaming;	}
		}


		private static CraftSystem m_CraftSystem;

		public static CraftSystem CraftSystem
		{
			get
			{
				if ( m_CraftSystem == null )
					m_CraftSystem = new DefDNA();

				return m_CraftSystem;
			}
		}

		public override double GetChanceAtMin( CraftItem item )
		{
			return 0.0; // 0%
		}

		private DefDNA() : base( 1, 1, 1.25 )// base( 1, 1, 3.1 )
		{
		}

		public override int CanCraft( Mobile from, BaseTool tool, Type itemType )
		{
			if ( tool.Deleted || tool.UsesRemaining < 0 )
				return 1044038; // You have worn out your tool!
			//else if ( !BaseTool.CheckAccessible( tool, from ) )
				//return 1044263; // The tool must be on your person to use.

			return 0;
		}

		public override void PlayCraftEffect( Mobile from )
		{
			from.PlaySound( 0x242 );
		}

		public override int PlayEndingEffect( Mobile from, bool failed, bool lostMaterial, bool toolBroken, int quality, bool makersMark, CraftItem item )
		{
			if ( toolBroken )
				from.SendLocalizedMessage( 1044038 ); // You have worn out your tool

			if ( failed )
			{
				from.AddToBackpack( new Bottle() );

				return 500287; // You fail to create a useful potion.
			}
			else
			{
				from.PlaySound( 0x240 ); // Sound of a filling bottle

				if ( quality == -1 )
					return 1048136; // You create the potion and pour it into a keg.
				else
					return 500279; // You pour the potion into a bottle...
			}
		}

		public override void InitCraftList()
		{
			int index = -1;

			index = AddCraft( typeof( AshDragonSpawn ), "Dragons", "Ash Dragon", 120.0, 120.0, typeof( BlazeDNA ), @"Blaze DNA", 4, 0 );
			AddSkill( index, SkillName.AnimalLore, 110.0, 110.0 );

			index = AddCraft( typeof( BlizardDragonSpawn ), "Dragons", "Blizard Dragon", 120.0, 120.0, typeof( SnowDNA ), @"Snow DNA", 4, 0 );
			AddSkill( index, SkillName.AnimalLore, 110.0, 110.0 );

			index = AddCraft( typeof( LustriousDragonSpawn ), "Dragons", "Lustrious Dragon", 120.0, 120.0, typeof( GoldenDNA ), @"Golden DNA", 4, 0 );
			AddSkill( index, SkillName.AnimalLore, 110.0, 110.0 );

			index = AddCraft( typeof( StarLightDragonSpawn ), "Dragons", "Star Light Dragon", 120.0, 120.0, typeof( LightningDNA ), @"Lightning DNA", 4, 0 );
			AddSkill( index, SkillName.AnimalLore, 110.0, 110.0 );

			index = AddCraft( typeof( ToxicDragonSpawn ), "Dragons", "Toxic Dragon", 120.0, 120.0, typeof( PoisonDNA ), @"Poison DNA", 4, 0 );
			AddSkill( index, SkillName.AnimalLore, 110.0, 110.0 );
			
			index = AddCraft( typeof( DeathDragonSpawn ), "Dragons", "Death Dragon", 120.0, 120.0, typeof( BlackDNA ), @"Black DNA", 4, 0 );
			AddSkill( index, SkillName.AnimalLore, 110.0, 110.0 );
		}
	}
}