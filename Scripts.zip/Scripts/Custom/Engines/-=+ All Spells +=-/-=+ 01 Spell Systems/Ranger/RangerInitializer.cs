using System;
using Server;
using Server.Spells;


namespace Server.Spells.Ranger
{
	public class RangerInitializer
	{
		public static void Initialize()
		{
			if( Core.AOS )
			{
				Register( 900, typeof( RangerHuntersAimSpell ) );
				Register( 901, typeof( RangerFlightOfThePheonixSpell ) );
				Register( 902, typeof( RangerFamiliarSpell ) );
				Register( 903, typeof( RangerFireBowSpell ) );
				Register( 904, typeof( RangerIceBowSpell ) );
				Register( 905, typeof( RangerLightningBowSpell ) );
				Register( 906, typeof( RangerNoxBowSpell ) );

				//RegDef( spellID, "Name", "Description", "Reagent1; Reagent2; Reagentn", "Skill; Mana; Tithe; Etc" );
				RegDef( 900, "Hunter's Aim", "Increases the Rangers archery, and tactics for a short period of time.", "Nightshade; Spring Water; Bloodmoss; Fertile Dirt", "Skill: 50; Mana: 25" );
				RegDef( 901, "Flight of the Pheonix", "Calls Forth a Phoenix who will carry you to the location of your choice.", "Sulfuous Ash; Petrafied Wood; Fertile Dirt", "Skill: 30; Mana: 30" );
				RegDef( 902, "Animal Companion", "The Ranger summons an animal companion (baised on skill level) to aid him in his quests.", "Destroying Angel; Spring Water; Petrafied Wood", "Skill: 30; Mana: 17" );
				RegDef( 903, "Fire Bow", "The Ranger uses his knowlage of archery and hunting, to craft a temparary fire elemental bow, that last for a short duration.", "Kindling; Sulfurous Ash", "Skill: 85; Mana: 30" );
				RegDef( 904, "Ice Bow", "The Ranger uses his knowlage of archery and hunting, to craft a temparary ice elemental bow, that last for a short duration.", "Kindling; Spring Water", "Skill: 85; Mana 30" );
				RegDef( 905, "Lightning Bow", "The Ranger uses his knowlage of archery and hunting, to craft a temparary lightning elemental bow, that last for a short duration.", "Kindling; Black Pearl", "Skill: 75; Mana: 60" );
				RegDef( 906, "Nox Bow", "The Ranger uses his knowlage of archery and hunting, to craft a temparary poison elemental bow, that last for a short duration.", "Kindling; Nightshade", "Skill: 85; Mana: 70" );
			}
		}
		public static void Register( int spellID, Type type )
		{
			SpellRegistry.Register( spellID, type );
		}
		public static void RegDef( int spellID, string name, string des, string regs, string inf )
		{
			SpellDefRegistry.Register( spellID, name, des, regs, inf );
		}
	}
}
