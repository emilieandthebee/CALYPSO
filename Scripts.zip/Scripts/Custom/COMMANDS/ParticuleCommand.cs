using System;
using Server;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class Particule
	{
		public static void Initialize()
		{
			Register( "Particule", AccessLevel.GameMaster, new CommandEventHandler( Particule_OnCommand ) );
		}

		public static void Register( string command, AccessLevel access, CommandEventHandler handler )
		{
			Server.Commands.Register( command, access, handler );
		}
		
		[Usage( "Particule <id>" )]
		[Description( "Send a fixed particule effect." )]
		public static void Particule_OnCommand( CommandEventArgs e )
		{
			string toSay = e.ArgString.Trim();
			
			int i = (int)e.GetInt32( 0 );
			e.Mobile.SendMessage("Sending fixed particule {0}",i);
			e.Mobile.FixedParticles( 0, 1, 0, i, EffectLayer.Head );
			Effects.SendMovingParticles( 
				new Entity( 
					Serial.Zero, 
					new Point3D( e.Mobile.X, e.Mobile.Y, e.Mobile.Z + 50 ),
					e.Mobile.Map ),
				new Entity( 
					Serial.Zero,
					new Point3D( e.Mobile.X, e.Mobile.Y, e.Mobile.Z + 20 ),
					e.Mobile.Map ),
				i, 1, 0, false, false, 0, 3, 9501, 1, 0, EffectLayer.Head, 0x100 );
		}

	}
}