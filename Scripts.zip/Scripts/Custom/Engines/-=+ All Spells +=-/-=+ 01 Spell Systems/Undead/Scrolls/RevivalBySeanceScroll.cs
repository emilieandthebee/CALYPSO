using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class RevivalBySeanceScroll : SpellScroll
	{
		[Constructable]
		public RevivalBySeanceScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public RevivalBySeanceScroll( int amount ) : base( 121, 0x226F, amount )
		{
			Name = "Revival By Seance";
			Hue = 0x44;
		}
		
		public RevivalBySeanceScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new RevivalBySeanceScroll( amount ), amount );
		}
	}
}


