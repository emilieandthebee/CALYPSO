using System; 
using Server;
using Server.Gumps;
using Server.Mobiles;

namespace Server.Items
{
	[Flipable( 0xFBD, 0xFBE )]
	public class AddressBook : Item
	{
		private string f_1 = "Empty";
		private string f_2 = "Empty";
		private string f_3 = "Empty";
		private string f_4 = "Empty";
		private string f_5 = "Empty";
		private string f_6 = "Empty";
		private string f_7 = "Empty";
		private string f_8 = "Empty";
		private string a_1 = "Empty";
		private string a_2 = "Empty";
		private string a_3 = "Empty";
		private string a_4 = "Empty";
		private string a_5 = "Empty";
		private string a_6 = "Empty";
		private string a_7 = "Empty";
		private string a_8 = "Empty";
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend1
		{
			get{ return f_1; }
			set{ f_1 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend2
		{
			get{ return f_2; }
			set{ f_2 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend3
		{
			get{ return f_3; }
			set{ f_3 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend4
		{
			get{ return f_4; }
			set{ f_4 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend5
		{
			get{ return f_5; }
			set{ f_5 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend6
		{
			get{ return f_6; }
			set{ f_6 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend7
		{
			get{ return f_7; }
			set{ f_7 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Friend8
		{
			get{ return f_8; }
			set{ f_8 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct1
		{
			get{ return a_1; }
			set{ a_1 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct2
		{
			get{ return a_2; }
			set{ a_2 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct3
		{
			get{ return a_3; }
			set{ a_3 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct4
		{
			get{ return a_4; }
			set{ a_4 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct5
		{
			get{ return a_5; }
			set{ a_5 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct6
		{
			get{ return a_6; }
			set{ a_6 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct7
		{
			get{ return a_7; }
			set{ a_7 = value; }
		}
		
		[CommandProperty( AccessLevel.GameMaster )]
		public string Acct8
		{
			get{ return a_8; }
			set{ a_8 = value; }
		}
		
		[Constructable]
		public AddressBook() : base( 0xFBE )
		{
			Movable = true;
			Name = "Address Book";
			LootType = LootType.Blessed;
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if( from.InRange( this.GetWorldLocation(), 1 ) ) 
			{
				from.SendGump( new AddressBookGump( from, this ) );
			} 
			else 
		    {
		    	from.SendLocalizedMessage( 500446 ); // That is too far away.
		    }
		}
		
		public AddressBook( Serial serial ) : base( serial ) 
		{ 
		} 

		public override void Serialize( GenericWriter writer ) 
		{ 
			base.Serialize( writer ); 

			writer.Write( (int) 0 ); // version 
			
			writer.Write( f_1 );
			writer.Write( f_2 );
			writer.Write( f_3 );
			writer.Write( f_4 );
			writer.Write( f_5 );
			writer.Write( f_6 );
			writer.Write( f_7 );
			writer.Write( f_8 );
			writer.Write( a_1 );
			writer.Write( a_2 );
			writer.Write( a_3 );
			writer.Write( a_4 );
			writer.Write( a_5 );
			writer.Write( a_6 );
			writer.Write( a_7 );
			writer.Write( a_8 );
		}

		public override void Deserialize( GenericReader reader ) 
		{ 
			base.Deserialize( reader ); 

			int version = reader.ReadInt(); 
			
			f_1 = reader.ReadString();
			f_2 = reader.ReadString();
			f_3 = reader.ReadString();
			f_4 = reader.ReadString();
			f_5 = reader.ReadString();
			f_6 = reader.ReadString();
			f_7 = reader.ReadString();
			f_8 = reader.ReadString();
			a_1 = reader.ReadString();
			a_2 = reader.ReadString();
			a_3 = reader.ReadString();
			a_4 = reader.ReadString();
			a_5 = reader.ReadString();
			a_6 = reader.ReadString();
			a_7 = reader.ReadString();
			a_8 = reader.ReadString();
			LootType = LootType.Blessed;
		} 
	}
}
