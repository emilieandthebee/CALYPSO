using System;
using Server;
using Server.Misc;

namespace Server.Items
{
	public class Vomi : Item
	{
		[Constructable]
		public Vomi() : this( 4650+Utility.Random(5) )
		{
		}

		[Constructable]
		public Vomi( int itemID ) : base( itemID )
		{
			Movable = false;
			Name="beurk...";
			Hue=1437+Utility.Random(9);;
			new InternalTimer( this ).Start();
		}

		public Vomi( Serial serial ) : base( serial )
		{
			new InternalTimer( this ).Start();
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}

		private class InternalTimer : Timer
		{
			private Item m_Vomi;

			public InternalTimer( Item Vomi ) : base( TimeSpan.FromMinutes( 1.0 ) )
			{
				Priority = TimerPriority.FiveSeconds;

				m_Vomi = Vomi;
			}

			protected override void OnTick()
			{
				if ((m_Vomi != null) && (!m_Vomi.Deleted))
					m_Vomi.Delete();
			}
		}
	}
}