using System; 
using Server.Mobiles;
using Server.Misc; 
using Server.Network; 
using System.Collections; 
using Server.Items; 
using Server.Targeting;

namespace Server.Items 
{ 
   public class AshDragonSpawn : Item
   {
      [Constructable]
      public AshDragonSpawn() : base( 0xED4 )
      {
			Name = "Ash Dragon takes 3 Pet Slots";
			ItemID= 8406;
      }

      public override void OnDoubleClick( Mobile from )
      {
         if ( !IsChildOf( from.Backpack ) ) // Make sure its in their pack 
         { 
             from.SendLocalizedMessage( 1042001 ); // That must be in your pack for you to use it.
		//	 return false; 
         }  
			else if( !from.CheckAlive() )
			{
				from.SendLocalizedMessage( 1060190 );	//You cannot do that while dead!
			}
		 else if ( from.Followers == 3 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
		 else if ( from.Followers == 4 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
		 else if ( from.Followers == 5 ) // Make sure its in their pack 
         { 
             from.SendMessage( "You Have Too Many Pets To Summon This" ); // That must be in your pack for you to use it. 
		//	 return false; 
		 } 
	//PlayerMobile pm = from as PlayerMobile;
			else if  (from.Skills[SkillName.AnimalTaming].Value > 115.0)
		        {
           		from.FixedParticles( 0x373A, 10, 15, 5036, EffectLayer.Head ); 
               		from.PlaySound( 710 );
        		AshDragon AshDragon = new AshDragon();
        		AshDragon.ControlTarget = from;
        		AshDragon.SetControlMaster ( from );
        		AshDragon.Location = from.Location;
				AshDragon.ControlOrder = OrderType.None;
        		AshDragon.Map = from.Map;
        		World.AddMobile( AshDragon );
				this.Delete();
				} 
				else
{
         from.SendMessage( "You Are Not Certified For use of This pet" );
		 return;
}
      }

      public AshDragonSpawn( Serial serial ) : base( serial )
      {
      }

      public override void Serialize( GenericWriter writer )
      {
         base.Serialize( writer );

         writer.Write( (int) 0 ); // version
      }

      public override void Deserialize( GenericReader reader )
      {
         base.Deserialize( reader );

         int version = reader.ReadInt();
      }
   }
}
