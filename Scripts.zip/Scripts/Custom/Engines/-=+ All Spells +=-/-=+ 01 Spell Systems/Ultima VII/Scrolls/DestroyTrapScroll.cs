using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class DestroyTrapScroll : SpellScroll
	{
		[Constructable]
		public DestroyTrapScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public DestroyTrapScroll( int amount ) : base( 356, 0x1F35, amount )
		{
			Name = "Destroy Trap";
		}
		
		public DestroyTrapScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel <= AccessLevel.Counselor )
			{
				//--<Optional Restrictions>----------<Start>
				from.SendMessage( "Low level staff and players are not allowed to have this scroll." );
				Delete();
			}
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new DestroyTrapScroll( amount ), amount );
		}
		
		
	}
}
