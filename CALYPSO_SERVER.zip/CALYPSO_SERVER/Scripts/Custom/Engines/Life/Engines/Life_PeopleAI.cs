/********************************************
 *
 * Alambik Life System
 *
 ********************************************/
using System;
using System.Collections;
using Server.Targeting;
using Server.Network;
using Server.Items;

namespace Server.Mobiles
{
	public class Life_PeopleAI : TechnoBaseAI 
	{
		public Life_PeopleAI(BaseCreature m) : base (m)
		{
		}

		public override void OnActionChanged()
        {
			if ( m_Mobile is Life_People )
			{
				Life_People people=((Life_People)m_Mobile);
				people.InteractingTimer=DateTime.Now;
				people.Interacting=( Action == ActionType.Interact );
				people.InteractingWith=null;
				people.InteractionStage=0;
			}
			base.OnActionChanged();
		}
		
		double GetCourage()
		{
			if (m_Mobile is Life_People)
				return ((Life_People)m_Mobile).Courage;
			else
				return 0.2; // Default value
		}
				
		public override bool DoActionInteract()
		{
			
			if ( !(m_Mobile is Life_People) )
			{
				base.DoActionInteract();
				return true;
			}
			Life_People people=(Life_People)m_Mobile;
			double hitPercent = (double)people.Hits / people.HitsMax;

			try {
				if ( !people.Summoned && !people.Controled && hitPercent < GetCourage() ) // Less than 20% health
				{
					Life_Speak.I_Am_Hurt(people,0.05);
					people.DebugSay( "I am low on health!");
					Action = ActionType.Flee;
					return true;
				}
				else if ( AquireFocusMob( people.RangePerception, people.FightMode, false, false, true ) )
				{
					Life_Speak.You_Attack_Me(people,0.05);
					if ( people.Debug )
						people.DebugSay( "I have detected {0}, attacking", people.FocusMob.Name );

					people.Combatant = people.FocusMob;
					Action = ActionType.Combat;
					return true;
				}
				if ((DateTime.Now - people.InteractingTimer) > TimeSpan.FromSeconds( 10.0+people.InteractionDelay ) )
				{
					Action = ActionType.Wander;
					return true;
				}
			} catch ( Exception e ) {
				System.Console.WriteLine("Error in Life IA Interaction (Part 1) "+m_Mobile.Name);
				Console.WriteLine( e );
				return false;
			}
			
			switch(people.Job)
			{
				case Life_Job.Unemployed:
					if (people.InteractingWith != null)
					{ // ALREADY INTERACTING
						try {
							if (( people.InteractingWith.Deleted)  ||
								( !people.InteractingWith.Alive ) ||
								( !(people.InteractingWith is Life_People))  ||
								( people.InteractingWith == m_Mobile ) ||
								( people.m_AI.Action != ActionType.Interact ) ||
								( people.GetDistanceToSqrt(people.InteractingWith) > 2.1 ) )
							{
								Action = ActionType.Wander;
							} else {
								if (people.Interacting is Life_People)
								{
									Life_People with=(Life_People)people.InteractingWith;
									people.DebugSay( "Discussing with "+with.Name+"("+people.InteractionStage+")" );
									if (with.InteractingWith != people)
										Action = ActionType.Wander;
									if (people.InteractionStage<-1)
									{
										if (with.InteractionStage<0)
											people.InteractionStage=0;
										else
											people.InteractionStage++;
									} else if (with.InteractionStage == -1) {
										const int MAXI=10;
										switch (people.InteractionStage)
										{
											case 0: // Wander mode
													Action=ActionType.Wander;
													with.InteractionStage=0;
													break;
											case 1: // HELLO
													Life_Speak.Hello(people,with,1.0);
													with.InteractionStage=1001;
													break;
											case 1001: // - HELLO
													Life_Speak.Hello(people,with,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 2: // HELLO, MY NAME IS...
													Life_Speak.Hello_I_Am(people,1.0);
													with.InteractionStage=1002;
													break;
											case 1002: // GLAD TO MEET YOU, MY NAME IS...
													Life_Speak.Glad_To_Meet_You(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 10: // AU REVOIR...
													Life_Speak.Bye(people,with,1.0);
													with.InteractionStage=1010;
													break;
											case 1010: // - AU REVOIR...
													Life_Speak.Bye(people,with,1.0);
													with.InteractionStage=0;
													Action=ActionType.Wander;
													break;
											case 11: // ABOUT WEATHER...
													Life_Speak.About_Weather(people,1.0);
													with.InteractionStage=1015+Utility.Random(2);
													break;
											case 1011: // ACKNOWLEDGE...
													Life_Speak.Sure(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 12: // ABOUT WEATHER...
													Life_Speak.How_Are_You(people,1.0);
													with.InteractionStage=1012;
													break;
											case 1012: // I AM WELL...
													Life_Speak.I_Am_Well(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 13: // WHERE DO YOU GO?.
													Life_Speak.Where_Are_You_Going(people,1.0);
													with.InteractionStage=1013;
													break;
											case 1013: // I GO THERE...
													Life_Speak.I_Am_Going_There(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 14: // WHAT ARE YOU DOING?.
													Life_Speak.Where_Are_You_Going(people,1.0);
													with.InteractionStage=1013+Utility.Random(2);
													break;
											case 1014: // I DO THIS...
													Life_Speak.I_Am_Going_There(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 15: // WANNA EAT OR DRINK?...
													Life_Speak.Do_You_Want_To_Have_A_Drink_Or_Meal(people,1.0);
													with.InteractionStage=1015+Utility.Random(3);
													break;
											case 1015: // YES...
													Life_Speak.Sure(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 1016: // NO...
													Life_Speak.Negative_Answer(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 1017: // PERHAPS...
													Life_Speak.Maybe(people,1.0);
													with.InteractionStage=10+Utility.Random(MAXI);
													break;
											case 16: // THE GUARDS ARE SEARCHING FOR HIM...
													Life_Speak.Do_You_Know_This_Criminal(people,1.0);
													with.InteractionStage=1015+Utility.Random(3);
													break;
											case 17: // BYE
													goto case 10;
											case 18: // BYE
													goto case 10;
											case 19: // BYE
													goto case 10;
											default: break;
										}
										people.InteractionStage=-(Utility.Random(10)+20);
									}
								}
							}
						} catch ( Exception e ) {
							System.Console.WriteLine("Error in Life IA Interaction (Part 2) "+m_Mobile.Name);
							Console.WriteLine( e );
							return false;
						}
					} else {
						// FIND SOMEBODY AROUND
						if ( Utility.Random(100) == 1 ) {
							try {
								if ( people.Map != null )
								{
									people.DebugSay( "Checking people to talk with" );
									Life_People target=null;
									IPooledEnumerable eable = people.GetMobilesInRange( 2 );
									foreach ( Mobile m in eable )
									{
										if ( m != m_Mobile )
										if ( m is Life_People )
										if ( m.Alive )
										if ( m_Mobile.InLOS(m) && m_Mobile.CanSee(m) )
										{
											Life_People mp=(Life_People)m;
											if ( mp.InteractingWith == null )
											if ( mp.Job == Life_Job.Unemployed )
											if (( mp.m_AI.Action == ActionType.Wander ) 
											 || ( mp.m_AI.Action == ActionType.Interact))
												target=mp;
										}
									}
									eable.Free();
									if ( target != null )
									{
										people.InteractionStage=Utility.Random(2)+1;
										people.InteractingWith=target;
										people.Direction=people.GetDirectionTo(target);

										target.m_AI.Action=ActionType.Interact;
										target.InteractionStage=-3;
										target.InteractingWith=people;
										target.Direction=target.GetDirectionTo(people);
									}
								}
							} catch ( Exception e ) {
								System.Console.WriteLine("Error in Life IA Interaction (Part 3) "+m_Mobile.Name);
								Console.WriteLine( e );
								return false;
							}
							
						} else {
							try {
								Life_Speak.I_Am_A_Looser(m_Mobile,0.0005);
								if ( Utility.Random(10) == 1 )
									people.Turn( Utility.Random(0, 2) - 1 );
								if ( Utility.Random(100) == 1 )
								{
										//ENOUGH!
										Action = ActionType.Wander;
								}
							} catch ( Exception e ) {
								System.Console.WriteLine("Error in Life IA Interaction (Part 4) "+m_Mobile.Name);
								Console.WriteLine( e );
								return false;
							}
						}
					}
					break;
				case Life_Job.Merchant:
					Life_Speak.I_Sell(m_Mobile,0.005);
					break;
				case Life_Job.Thief:
					if (people.InteractingWith != null)
					{ // ALREADY INTERACTING
						try {
							if (( people.InteractingWith.Deleted)  ||
								( !people.InteractingWith.Alive ) ||
								( people.m_AI.Action != ActionType.Interact ) ||
								( people.GetDistanceToSqrt(people.InteractingWith) > 1.1 ) )
							{
								Action = ActionType.Wander;
							} else {
								Mobile with=people.InteractingWith;
								people.DebugSay( "Stealing "+with.Name+"("+people.InteractionStage+")" );
								if ((with.Backpack == null) ||
									(with.Backpack.Items.Count == 0))
								{
									Action = ActionType.Wander;
								} else {
									if (people.InteractionStage<0)
									{
										people.InteractionStage++;
									} else {
										Item stolen = TryStealItem( (Item)((with.Backpack.Items)[Utility.Random( with.Backpack.Items.Count )]), people );
										if ( stolen != null )
										{
											people.AddToBackpack( stolen );
											people.DebugSay( "Stealing "+((stolen.Name==null)?"item":stolen.Name)+" from "+with.Name+"("+people.InteractionStage+")" );
											Action = ActionType.Wander;
											Life_Speak.I_Steal(people,with,0.1);
										} else {
											people.DebugSay( "Unable to steal" );
										}
									}
								}
							}
						} catch ( Exception e ) {
							System.Console.WriteLine("Error in Life IA Interaction (Part 5) "+m_Mobile.Name);
							System.Console.WriteLine("More information: "+e.StackTrace);
							System.Console.WriteLine( "Message: {0}", e.Message );
							System.Console.WriteLine( "HelpLink: {0}", e.HelpLink );
							System.Console.WriteLine( "Source: {0}", e.Source );
							System.Console.WriteLine( "StackTrace: {0}", e.StackTrace );
							System.Console.WriteLine( "TargetSite: {0}", e.TargetSite );
								return false;
						}
					} else {
						// FIND SOMEBODY TO ROB
						if ( Utility.Random(5) == 1 ) {
							if ( people.Map != null )
							{
								try {
									people.DebugSay( "Checking people to rob" );
									Mobile target=null;
									IPooledEnumerable eable = people.GetMobilesInRange( 1 );
									foreach ( Mobile m in eable )
									{
										if ( m != m_Mobile )
										if ( m.Alive )
										if ( m_Mobile.InLOS(m) && m_Mobile.CanSee(m) )
											target=m;
									}
									eable.Free();
									if ( target != null )
									{
										people.InteractingWith=target;
										people.InteractionStage=-(Utility.Random(30)+3);
										people.Direction=people.GetDirectionTo(target);
										Life_Speak.I_Steal(people,target,0.1);
									}
								} catch ( Exception e ) {
									System.Console.WriteLine("Error in Life IA Interaction (Part 6) "+m_Mobile.Name);
									Console.WriteLine( e );
									return false;
								}
							}
						}	
						Life_Speak.I_Want_To_Rob(m_Mobile,0.005);
					}
					break;
				case Life_Job.Singer:
					break;
				case Life_Job.Guard:
					Life_Speak.I_Am_Guarding(m_Mobile,0.01);
					break;
				default:
					break;
			}
			return true;
		}
		
		public override bool DoActionWander()
		{
			if ( !(m_Mobile is Life_People) )
			{
				base.DoActionWander();
				return true;
			}
			Life_People people=(Life_People)m_Mobile;
			double hitPercent = (double)people.Hits / people.HitsMax;
			if ( !people.Summoned && !people.Controled && hitPercent < GetCourage() ) // Less than 20% health
			{
				Life_Speak.I_Am_Hurt(people,0.05);
				people.DebugSay( "I am low on health!");
				Action = ActionType.Flee;
			}
			else if ( AquireFocusMob( people.RangePerception, people.FightMode, false, false, true ) )
			{
				Life_Speak.You_Attack_Me(people,0.05);
				if ( people.Debug )
					people.DebugSay( "I have detected {0}, attacking", people.FocusMob.Name );

				people.Combatant = people.FocusMob;
				Action = ActionType.Combat;
			}
			else
			{
				if ( CheckHerding() )
				{
					people.DebugSay( "Praise the shepherd!" );
					return true;
				}
				
				// CHECK IF THERE IS AN ATTRACTIVE PLACE AROUND
				if ( people.ToAttractivePlace == 0 )
				if ( CheckMove() )
				{
					Life_Speak.I_Am_A_Looser(people,0.0005);
					if ( Utility.Random(30) == 1 )
					if ( people.Map != null )
					{
						people.DebugSay( "Checking attractive places around" );
						Life_AttractivePlace target=null;
						IPooledEnumerable eable = people.GetItemsInRange( 40 );
						foreach ( Item item in eable )
						{
							if ( item is Life_AttractivePlace )
							target=(Life_AttractivePlace)item;
						}
						eable.Free();
						if ( target != null )
						{
							people.DebugSay( "Found One..." );
							if ( Utility.Random(5) == 1 )
							{
								people.DebugSay( "and do want to go there..." );
								if ( people.CurrentWayPoint != null )
								{
									people.CurrentWayPoint=null;
									Life_People.OnTheWayCounter--;
								}
								people.ToAttractivePlace = Utility.Random(50);
								people.Place=target.Location;
								people.PlaceRange=target.Range;
							}
						}
					}
				}
				
				// ALREADY ON A WAYPOINTS PATH ?
				if ( people.CurrentWayPoint != null )
				{
					// PERHAPS WE MAY CHANGE OUR IDEAS AND GO IN ELSEWHERE...
					if (Utility.Random(5000) == 1)
					{
						people.CurrentWayPoint=null;
						Life_People.OnTheWayCounter--;
					}
					else
					{
						WayPoint point = people.CurrentWayPoint;
						if ( ( point.X != people.Location.X || point.Y != people.Location.Y ) && point.Map == people.Map && point.Parent == null && !point.Deleted )
						{
							people.DebugSay( "I will move towards my waypoint." );
							DoMove( people.GetDirectionTo( people.CurrentWayPoint ) );
						}
						else if ( OnAtWayPoint() )
						{
							people.DebugSay( "I will go to the next waypoint" );
							people.CurrentWayPoint = point.NextPoint;
							if ( point.NextPoint != null && point.NextPoint.Deleted )
								people.CurrentWayPoint = point.NextPoint = point.NextPoint.NextPoint;
						}
					}
				}
				else if ( CheckMove() )
				{
					if (people.ToAttractivePlace>0) 
					{
						if ( !people.CheckIdle() )
						{
							// ATTRACTIVE PLACE IN EFFECT
							people.ToAttractivePlace--;
							if ( (people.InRange(people.Place,people.PlaceRange)) )
							{
								// I'M THERE ALREADY
								if (Utility.Random(30) == 1)
									Action=ActionType.Interact;
								if (Utility.Random(10) == 1)
								{
									if ( MoveTo( people.Place,true,0 ) )
										people.Direction = people.GetDirectionTo( people.Place );
								} else {
									WalkRandomInHome(2, 2, 1);
								}
							} else {
								// MOVE THERE
								if ( MoveTo( people.Place,true,0 ) )
									people.Direction = people.GetDirectionTo( people.Place );
							}
						}
					} else {
						if ( Utility.Random(1000) == 1 ) 
						{
							// CHECK IF THERE IS A WAYPOINT AROUND
							if ( 100*Life_People.OnTheWayCounter/Life_People.PeopleCounter < 3 )
							if ( people.Map != null )
							{
								people.DebugSay( "Checking waypoints around" );
								WayPoint target=null;
								IPooledEnumerable eable = people.GetItemsInRange( 10 );
								foreach ( Item item in eable )
								{
									if ( item is WayPoint )
									target=(WayPoint)item;
								}
								eable.Free();
								if ( target != null )
								{
									people.DebugSay( "Found One..." );
									people.CurrentWayPoint=target;
									Life_People.OnTheWayCounter++;
								}
							}
						} else {
							// LET'S IDLE...
							if ( !people.CheckIdle() )
							{
								WalkRandomInHome(2, 2, 1);
								if (Utility.Random(200) == 1)
									Action=ActionType.Interact;
							}
						}
					}
				}

				if ( people.Combatant != null && !people.Combatant.Deleted && people.Combatant.Alive && !people.Combatant.IsDeadBondedPet )
				{
					people.Direction = people.GetDirectionTo( people.Combatant );                
				}
			}
			return true;
		}

		/// COMBAT
		public override bool DoActionCombat()
		{
			Mobile combatant = m_Mobile.Combatant;
			if (    combatant == null ||
				combatant.Deleted ||
				combatant.Map != m_Mobile.Map ||
				!combatant.Alive ||
				combatant.IsDeadBondedPet )
			{
				Life_Speak.Where_Is_My_Combatant(m_Mobile,0.5);
				m_Mobile.DebugSay( "My combatant is gone, so let's guard" );
				Action = ActionType.Guard;
				return true;
			}

			if ( !m_Mobile.InRange( combatant, m_Mobile.RangePerception ) )
			{
				// They are somewhat far away, can we find something else?
				if ( AquireFocusMob( m_Mobile.RangePerception,
						     m_Mobile.FightMode,
						     false, false, true ) )
				{
					Life_Speak.I_Look_Next_Combatant(m_Mobile,0.5);
					m_Mobile.Combatant = m_Mobile.FocusMob;
					m_Mobile.FocusMob = null;
				}
				else
				{
					m_Mobile.Combatant = null;
				}

				combatant = m_Mobile.Combatant;
				if ( combatant == null )
				{
					Life_Speak.Where_Is_My_Combatant(m_Mobile,0.5);
					m_Mobile.DebugSay( "My combatant is gone, so let's guard" );
					Action = ActionType.Guard;
					return true;
				}
			}

			// Have a gun or not ?
			bool I_Have_A_Gun=false;
			//int range=0;
			Item item=m_Mobile.FindItemOnLayer(Layer.OneHanded);
			if (item != null)
				if (item is BaseRanged)
				{
					I_Have_A_Gun=true;
				}
			if (!I_Have_A_Gun)
			{
				item=m_Mobile.FindItemOnLayer(Layer.TwoHanded);
				if (item != null)
					if (item is BaseRanged)
					{
						I_Have_A_Gun=true;
					}
			}

			// Enough Ammo ?
			Item ammo=null;
			if( I_Have_A_Gun )
			{
				Container pack = m_Mobile.Backpack;
				if (pack == null)
				{
					I_Have_A_Gun=false;
				} else {
					ammo=pack.FindItemByType( ((BaseRanged)item).AmmoType );
					if (ammo == null)
					{
						Life_Speak.I_Put_My_Ranged_Weapon_In_My_Pack(m_Mobile,0.8,item);
						m_Mobile.PlaceInBackpack(item);
						I_Have_A_Gun=false;
					}
				}
			}
		
			if( I_Have_A_Gun )
			{ 
				// Ranged fight!
				if (WalkMobileRange(m_Mobile.Combatant, 1, true,
									m_Mobile.RangeFight, m_Mobile.Weapon.MaxRange))
				{
					// Be sure to face the combatant
					m_Mobile.Direction = m_Mobile.GetDirectionTo(m_Mobile.Combatant.Location);
					if (Utility.Random(20) == 1)
					{
						if (ammo.Amount == 1)
							ammo.Delete();
						else
							ammo.Amount--;
					}
					Life_Speak.I_Ranged_Fight(m_Mobile,0.05,item);
				}
				else
				{
					if ( m_Mobile.Combatant != null )
					{
						if ( m_Mobile.Debug )
							m_Mobile.DebugSay( "I am still not in range of {0}", m_Mobile.Combatant.Name);

						if ( (int) m_Mobile.GetDistanceToSqrt( m_Mobile.Combatant ) > m_Mobile.RangePerception + 1 )
						{
							if ( m_Mobile.Debug )
								m_Mobile.DebugSay( "I cannot find {0}, guard.", combatant.Name );
							Action = ActionType.Guard;
							m_Mobile.Combatant = null;
							return true;
						}
					}
				}
			} else {
				// Meele fight!
				if ( MoveTo( combatant, true, m_Mobile.RangeFight ) )
				{
					m_Mobile.Direction = m_Mobile.GetDirectionTo( combatant );
				}
				else if ( AquireFocusMob( m_Mobile.RangePerception,
							  m_Mobile.FightMode,
							  false, false, true ) )
				{
					m_Mobile.DebugSay( "My move is blocked, so I am going to attack {0}", m_Mobile.FocusMob.Name );
					m_Mobile.Combatant = m_Mobile.FocusMob;
					Action = ActionType.Combat;
					Life_Speak.I_Melee_Fight(m_Mobile,0.05);
					return true;
				}
				else if ( m_Mobile.GetDistanceToSqrt( combatant ) >
					  m_Mobile.RangePerception + 1 )
				{
					m_Mobile.DebugSay( "I cannot find {0}, so I will search him.", combatant.Name );
					Action = ActionType.Guard;
					return true;
				}
				else
				{
					m_Mobile.DebugSay( "I should be closer to {0}", combatant.Name );
				}	
			}
			
			// At "Courage" we should check if we must leave
			if ( m_Mobile.Hits < m_Mobile.HitsMax*GetCourage() )
			{
				bool bFlee = false;
				// if my current hits are more than my opponent, i don't care
				if ( m_Mobile.Combatant != null && m_Mobile.Hits < m_Mobile.Combatant.Hits)
				{
					int iDiff = m_Mobile.Combatant.Hits - m_Mobile.Hits;

					if ( Utility.Random(0, 100) > 10 + iDiff) // 10% to flee + the diff of hits
					{
						bFlee = true;
					}
				}
				else if ( m_Mobile.Combatant != null && m_Mobile.Hits >= m_Mobile.Combatant.Hits)
				{
					if ( Utility.Random(0, 100) > 40 ) // 40% to flee
					{
						bFlee = true;
					}
				}
						
				if (bFlee)
				{
					Life_Speak.I_Flee(m_Mobile,0.05);
					Action = ActionType.Flee; 
				}
			}

			return true;
		}
		
		public override bool DoActionBackoff()
		{
			double hitPercent = (double)m_Mobile.Hits / m_Mobile.HitsMax;

			if ( !m_Mobile.Summoned && !m_Mobile.Controled && hitPercent < 0.05 ) // Less than 10% health
			{
				Action = ActionType.Flee;
			}
			else
			{
				if (AquireFocusMob(m_Mobile.RangePerception * 2, FightMode.Closest, true, false , true))
				{
					if ( WalkMobileRange(m_Mobile.FocusMob, 1, false, m_Mobile.RangePerception, m_Mobile.RangePerception * 2) )
					{
						Life_Speak.After_Flee_I_Can_Relax(m_Mobile,0.5);
						m_Mobile.DebugSay( "Well, here I am safe" );
						Action = ActionType.Wander;
					}					
				}
				else
				{
					Life_Speak.After_Flee_I_Can_Relax(m_Mobile,0.5);
					m_Mobile.DebugSay( "I have lost my focus, lets relax" );
					Action = ActionType.Wander;
				}
			}

			return true;
		}

		public override bool DoActionFlee()
		{
			AquireFocusMob(m_Mobile.RangePerception * 2, m_Mobile.FightMode, true, false, true);

			if ( m_Mobile.FocusMob == null )
				m_Mobile.FocusMob = m_Mobile.Combatant;

			Life_Speak.I_Run_To_Flee(m_Mobile,0.001);

			return base.DoActionFlee();
		}
		
		private Item TryStealItem( Item toSteal, Life_People m_Thief )
		{
				Item stolen = null;
				object root = toSteal.RootParent;
				if ( root is BaseCreature && (((BaseCreature)root).Blessed || !((BaseCreature)root).CanBeDamaged()) )
				{}
				else if ( root is BaseVendor && ((BaseVendor)root).IsInvulnerable )
				{}
				else if ( root is PlayerVendor )
				{}
				else if ( m_Thief.Backpack == null || !m_Thief.Backpack.CheckHold( m_Thief, toSteal, false, true ) )
				{}
				else if ( (toSteal.Parent == null || !toSteal.Movable || toSteal.LootType == LootType.Newbied || toSteal.CheckBlessed( root )) && !ItemFlags.GetStealable(toSteal))
                {}
				else if ( Core.AOS && toSteal is Container && !ItemFlags.GetStealable(toSteal))
				{}
				else if ( !m_Thief.InRange( toSteal.GetWorldLocation(), 1 ) )
				{}
				else if ( toSteal.Parent is Mobile )
				{}
				else if ( root == m_Thief )
				{}
				else if ( root is Mobile && ((Mobile)root).AccessLevel > AccessLevel.Player )
				{}
				else if ( root is Mobile && !m_Thief.CanBeHarmful( (Mobile)root ) )
				{}
				else if ( root is Corpse )
				{}
				else
				{
					double w = toSteal.Weight + toSteal.TotalWeight;
					if ( w <= 10 )
					{
						if ( toSteal.Stackable && toSteal.Amount > 1 )
						{
                            int maxAmount = toSteal.Amount;
                            if(toSteal.Weight > 0)
                                maxAmount = (int)((m_Thief.Skills[SkillName.Stealing].Value / 10.0) / toSteal.Weight);
							if ( maxAmount < 1 )
								maxAmount = 1;
							else if ( maxAmount > toSteal.Amount )
								maxAmount = toSteal.Amount;
							int amount = Utility.RandomMinMax( 1, maxAmount );
							if ( amount >= toSteal.Amount )
							{
								int pileWeight = (int)Math.Ceiling( toSteal.Weight * toSteal.Amount );
								pileWeight *= 10;
								stolen = toSteal;
							}
							else
							{
								int pileWeight = (int)Math.Ceiling( toSteal.Weight * amount );
								pileWeight *= 10;
								stolen = toSteal.Dupe( amount );
							}
						}
						else
						{
							int iw = (int)Math.Ceiling( w );
							iw *= 10;
							Type ptype;
							string value = BaseXmlSpawner.GetBasicPropertyValue(toSteal,"ArtifactRarity", out ptype);
							if(ptype == typeof(int) && value != null)
							{
                                int rarity = 0;
                                try{
                                    rarity = int.Parse(value);
                                } catch{}
                                if(rarity > 0)
                                {
                                    iw = (int)Math.Ceiling(120 + rarity*1.5);
                                }
							}
								stolen = toSteal;
						}
						if ( stolen != null )
						{
                            ItemFlags.SetTaken(stolen, true);
                            ItemFlags.SetStealable(stolen, false);
                            stolen.Movable = true;
						}
					}
				}
				return stolen;
		}
		
	}
}