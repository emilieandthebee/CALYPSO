/********************************************
 *
 * Alambik Life System
 *
 ********************************************/
using System;
using System.Collections;
using Server.Items;
using Server.ContextMenus;
using Server.Misc;
using Server.Network;

namespace Server.Mobiles
{

	public enum Life_Job
	{
		Unemployed=0,
		Merchant,
		Thief,
		Singer,
		Guard,
		MAX
	}

	public class Life_People : Technophobe /* Mobile */
	{
		public static int OnTheWayCounter=0;
		public static int PeopleCounter=0;
	
		private double m_Courage;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public double Courage { get { return m_Courage; } set { m_Courage = value; } }

		private Life_Job m_Job;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public Life_Job Job { get { return m_Job; } set { m_Job = value; } }
		
		private bool m_Interacting;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public bool Interacting { get { return m_Interacting; } set { m_Interacting = value; } }

		private Mobile m_InteractingWith;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public Mobile InteractingWith { get { return m_InteractingWith; } set { m_InteractingWith = value; } }

		private DateTime m_InteractingTimer;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public DateTime InteractingTimer { get{ return m_InteractingTimer; } set{ m_InteractingTimer=value;  } }

		private double m_InteractionDelay;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public double InteractionDelay { get { return m_InteractionDelay; } set { m_InteractionDelay = value; } }
		
		private int m_InteractionStage;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public int InteractionStage { get { return m_InteractionStage; } set { m_InteractionStage = value; } }
		
		private int m_ToAttractivePlace;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public int ToAttractivePlace { get { return m_ToAttractivePlace; } set { m_ToAttractivePlace = value; } }

		private Point3D m_Place;
		[CommandProperty( AccessLevel.GameMaster )]
		public Point3D Place { get{ return m_Place; } set{ m_Place=value;  } }
		
		private int m_PlaceRange;
		[CommandProperty( AccessLevel.GameMaster, AccessLevel.GameMaster )]
		public int PlaceRange { get { return m_PlaceRange; } set { m_PlaceRange = value; } }

		public override bool ClickTitle{ get{ return true; } }

		private int AnyColor()
		{
			switch (Utility.Random(0,3))
			{
				case 0:  return Utility.RandomNondyedHue();
				case 1:  return Utility.RandomDyedHue();
				default: return Utility.RandomNeutralHue();
			}
		}
		
		public override bool CanRummageCorpses{ get{ return (	(Job == Life_Job.Thief) ||
																((Job == Life_Job.Unemployed) && (Utility.Random(2)==1)) ); } }

		
		[Constructable]
		public Life_People () : base( 	AIType.AI_LifePeople,
										FightMode.Agressor, 10, 1, 
										0.1+(Utility.Random(4)/10), 
										0.3+(Utility.Random(4)/10) )
		{
			VirtualArmor = Utility.Random(10);
			if (Utility.Random(10) == 1)
				WantsToReport=false;
			else
				WantsToReport=true;
			PeopleCounter++;
			m_ToAttractivePlace=0;
			m_Place=new Point3D(0,0,0);
			m_Interacting=false;
			m_InteractingTimer=DateTime.Now;
			m_InteractionDelay=10.0+Utility.RandomDouble()*60.0*10;
			// Courage  is % of damage to flee.
			// Population may be more courageous in proportion.
			if (Utility.Random(10) == 1)
				Job=(Life_Job)(Utility.Random((int)(Life_Job.MAX)));
			else
				Job=Life_Job.Unemployed;
			if (Job == Life_Job.Guard)
			{
				WantsToReport=true;
				Courage=0.7+Utility.RandomDouble()*0.3;
			} else {
				Courage=Utility.RandomDouble();
			}
			Courage = 0.01+Courage*0.94;
			SpeechHue = Utility.RandomDyedHue();
			Hue = Utility.RandomSkinHue();
			NameHue=26;
			bool needUp=true;

			SetStr( 5, 80 );
			SetDex( 5, 80 );
			SetInt( 5, 80 );

			SetHits( Str/3, Str*2/3 );
			SetDamage( 3, 15 );

			SetDamageType( ResistanceType.Physical, 100 );

			SetSkill( SkillName.Tactics, 0.0, 80.0 );
			SetSkill( SkillName.Wrestling, 0.0, 80.0 );
			
			VirtualArmor = Utility.Random(10);

			
			// CLOTHINGS DEPENDING OF SEXE
			if ( this.Female = Utility.RandomBool() )
			{
				Body = 0x191;
				Name = NameList.RandomName( "female" );
				if (Job != Life_Job.Guard )
					switch (Utility.Random(6))
					{
						case 0:  AddItem( new FancyDress(AnyColor()));
								 needUp=false;
								 break;
						case 1:  AddItem( new Robe(AnyColor()));	  break;
						case 2:  AddItem( new Skirt(AnyColor()));  break;
						case 3:  AddItem( new Kilt(AnyColor()));   break;		
						case 4:  if ( Utility.Random(2)==1 )
									AddItem( new LongPants(AnyColor()));
								 else
									AddItem( new ShortPants(AnyColor()));
								 break;
						default: AddItem( new PlainDress(AnyColor()));
								 needUp=false;
								 break;
					}
			}
			else
			{
				Body = 0x190;
				Name = NameList.RandomName( "male" );
				if (Job != Life_Job.Guard )
				{
					if ( Utility.Random(2)==1 )
						AddItem( new LongPants(AnyColor()));
					else
						AddItem( new ShortPants(AnyColor()));
				}
			}

			if (Job == Life_Job.Guard )
			{
				Item item = new LeatherNinjaJacket();
				item.Hue = 1155;
				item.Name = "Blouson militaire";
				item.Movable = false;
				AddItem( item );
				item = new Shoes(1175);
				item.Name = "Rangers cirees au vrai molard";
				item.Movable = false;
				AddItem( item );
				item = new BodySash(32);
				item.Movable = false;
				item.Name = "Garde de la brigade anti-criminelle";
				AddItem( item );
				AddItem( new Lantern() );
				item = new LeatherLegs();
				item.Hue = 1193;
				item.Name = "Pantalon militaire";
				item.Movable = false;
				AddItem( item );
				item = new Bonnet(1157);
				item.Movable = false;
				item.Name = "Beret militaire de la brigade anti-criminelle";
				AddItem( item );
				AddItem( new Dagger() ); 
				SetStr( 50, 90 );
				SetDex( 50, 90 );
				SetInt( 50, 90 );
				SetHits( Str*2/3, Str );
				SetDamage( 14, 50 );
				SetDamageType( ResistanceType.Physical, 100 );
				SetSkill( SkillName.Tactics, 50.0, 90.0 );
				SetSkill( SkillName.Wrestling, 50.0, 90.0 );
				SetSkill( SkillName.Fencing, 50.0, 90.0 );
				VirtualArmor = 10+Utility.Random(10);
			} else {
				// EVENTUALLY
				if (needUp)
				{
					switch (Utility.Random(7))
					{
					case 0:   AddItem( new Doublet(AnyColor())); break;
					case 1:   AddItem( new FancyShirt(AnyColor())); break;
					case 2:   AddItem( new Tunic(AnyColor())); break;
					case 3:   AddItem( new Surcoat(AnyColor())); break;
					default:  AddItem( new Shirt(AnyColor())); break;
					}
				}
				
				// CLOAK
				if (Utility.Random(7) == 1)
					AddItem( new Cloak( AnyColor() ) );
				
				// STAFF
				if (Utility.Random(20) == 1)
					AddItem( new GnarledStaff() );
					
				// HAT
				switch (Utility.Random(30))
				{
				case 0:  AddItem( new Bandana(AnyColor())); break;
				case 1:  AddItem( new Bonnet(AnyColor())); break;
				case 2:  AddItem( new Cap(AnyColor())); break;
				case 3:  AddItem( new FeatheredHat(AnyColor())); break;
				case 4:  AddItem( new FloppyHat(AnyColor())); break;
				case 5:  AddItem( new WizardsHat(AnyColor())); break;
				case 6:  AddItem( new SkullCap(AnyColor())); break;
				case 7:  AddItem( new StrawHat(AnyColor())); break;
				case 8:  AddItem( new TallStrawHat(AnyColor())); break;
				case 9:  AddItem( new TricorneHat(AnyColor())); break;
				case 10: AddItem( new Bandana(AnyColor())); break;
				case 11: AddItem( new WideBrimHat(AnyColor())); break;
				default: break;
				}
				
				switch (Utility.Random(3))
				{
				case 0:  AddItem( new Boots( Utility.RandomNeutralHue() ) ); break;
				case 1:  AddItem( new ThighBoots( Utility.RandomNeutralHue() ) ); break;
				case 2:  AddItem( new Sandals( Utility.RandomNeutralHue() ) ); break;
				default: AddItem( new Shoes( Utility.RandomNeutralHue() ) ); break;
				}

			}
			
			// BACKPACK
				AddItem( new Backpack( Utility.RandomNeutralHue() ) );

			// GOLD
			if (Utility.Random(5) == 1)
				AddToBackpack( new Gold( Utility.Random(100) ) );
			else if (Utility.Random(30) == 1)
				AddToBackpack( new Gold( 100+Utility.Random(1000) ) );
				
			// MELEE WEAPON
			switch (Utility.Random(50))
			{
				case 0: AddToBackpack( new Longsword() ); break;
				case 1: AddToBackpack( new Kryss() ); break;
				case 2: AddToBackpack( new Cutlass() ); break;
				case 3: AddToBackpack( new ThinLongsword() ); break;
				case 4: AddToBackpack( new Dagger() ); break;
				case 5: AddToBackpack( new Axe() ); break;
				case 6: AddToBackpack( new Hatchet() ); break;
				case 7: AddToBackpack( new ThrowingDagger() ); break;
				case 8: AddToBackpack( new Dagger() ); break;
				case 9: AddToBackpack( new Dagger() ); break;
				case 10: AddToBackpack( new Dagger() ); break;
				case 11: AddToBackpack( new Bow() ); AddToBackpack( new Arrow(Utility.Random(40)) ); break;
				case 12: AddToBackpack( new Crossbow() ); AddToBackpack( new Bolt(Utility.Random(40)) ); break;
				default: break;
			}

			// MUSICAL INSTRUMENT
			switch (Utility.Random(200))
			{
				case 0: AddToBackpack( new BambooFlute() ); break;
				case 1: AddToBackpack( new Drums() ); break;
				case 2: AddToBackpack( new Harp() ); break;
				case 3: AddToBackpack( new LapHarp() ); break;
				case 4: AddToBackpack( new Lute() ); break;
				case 5: AddToBackpack( new Tambourine() ); break;
				case 6: AddToBackpack( new Beltherlute() ); break;
				case 7: AddToBackpack( new Digeridoo() ); break;
				case 8: AddToBackpack( new fiddle() ); break;
				case 9: AddToBackpack( new Panpipes() ); break;
				case 10: AddToBackpack( new Savagedrum() ); break;
				case 11: AddToBackpack( new Savagetambourine() ); break;
				case 12: AddToBackpack( new Trumpet() ); break;
				case 13: AddToBackpack( new Woodharp() ); break;
				case 14: AddToBackpack( new Vahallansaxe() ); break;
				case 15: AddToBackpack( new SoloLute() ); break;
				default: break;
			}

			// VARIOUS OBJECTS
			switch (Utility.Random(200))
			{
				case 0: AddToBackpack( new Sextant() ); break;
				case 1: AddToBackpack( new Scales() ); break;
				case 2: AddToBackpack( new Scissors() ); break;
				//case 3: AddToBackpack( new () ); break;
				//case 4: AddToBackpack( new () ); break;
				//case 5: AddToBackpack( new () ); break;
				//case 6: AddToBackpack( new () ); break;
				default: break;
			}

			// NUKACOLA!!!
			if (Utility.Random(5) == 1)
			{
				AddToBackpack( new Nukacola() );
			}
			
			// KEY
			if (Utility.Random(200) == 1)
			{
				//AddToBackpack( new Key() );
			}
			
			// FOOD
			for (int i=0; i<3;i++)
			{
				switch (Utility.Random(100))
				{
					case 0: AddToBackpack( new FrenchBread(Utility.Random(3)) ); break;
					case 1: AddToBackpack( new Apple(Utility.Random(3)) ); break;
					case 2: AddToBackpack( new ApplePie(Utility.Random(3)) ); break;
					case 3: AddToBackpack( new Banana(Utility.Random(3)) ); break;
					case 4: AddToBackpack( new BreadLoaf(Utility.Random(3)) ); break;
					case 5: AddToBackpack( new Cabbage(Utility.Random(3)) ); break;
					case 6: AddToBackpack( new Carrot(Utility.Random(3)) ); break;
					case 7: AddToBackpack( new Cantaloupe(Utility.Random(3)) ); break;
					case 8: AddToBackpack( new CheesePizza(Utility.Random(3)) ); break;
					case 9: AddToBackpack( new CheeseWedge(Utility.Random(3)) ); break;
					case 10: AddToBackpack( new CheeseWheel(Utility.Random(3)) ); break;
					case 11: AddToBackpack( new ChickenLeg(Utility.Random(3)) ); break;
					case 12: AddToBackpack( new Coconut(Utility.Random(3)) ); break;
					case 13: AddToBackpack( new CookedBird(Utility.Random(3)) ); break;
					case 14: AddToBackpack( new Dates(Utility.Random(3)) ); break;
					case 15: AddToBackpack( new FishSteak(Utility.Random(3)) ); break;
					case 16: AddToBackpack( new FruitBasket(Utility.Random(3)) ); break;
					case 17: AddToBackpack( new FruitPie(Utility.Random(3)) ); break;
					case 18: AddToBackpack( new Dates(Utility.Random(3)) ); break;
					case 19: AddToBackpack( new Grapes(Utility.Random(3)) ); break;
					case 20: AddToBackpack( new GreenGourd(Utility.Random(3)) ); break;
					case 21: AddToBackpack( new Ham(Utility.Random(3)) ); break;
					case 22: AddToBackpack( new LambLeg(Utility.Random(3)) ); break;
					case 23: AddToBackpack( new Lemon(Utility.Random(3)) ); break;
					case 24: AddToBackpack( new Lettuce(Utility.Random(3)) ); break;
					case 25: AddToBackpack( new Lime(Utility.Random(3)) ); break;
					case 26: AddToBackpack( new MeatPie(Utility.Random(3)) ); break;
					case 27: AddToBackpack( new Muffins(Utility.Random(3)) ); break;
					case 28: AddToBackpack( new Peach(Utility.Random(3)) ); break;
					case 29: AddToBackpack( new PeachCobbler(Utility.Random(3)) ); break;
					case 30: AddToBackpack( new Pear(Utility.Random(3)) ); break;
					case 31: AddToBackpack( new Pumpkin(Utility.Random(3)) ); break;
					case 32: AddToBackpack( new Quiche(Utility.Random(3)) ); break;
					case 33: AddToBackpack( new Ribs(Utility.Random(3)) ); break;
					case 34: AddToBackpack( new Sausage(Utility.Random(3)) ); break;
					case 35: AddToBackpack( new SausagePizza(Utility.Random(3)) ); break;
					case 36: AddToBackpack( new SplitCoconut(Utility.Random(3)) ); break;
					case 37: AddToBackpack( new Squash(Utility.Random(3)) ); break;
					case 38: AddToBackpack( new Watermelon(Utility.Random(3)) ); break;
					case 39: AddToBackpack( new YellowGourd(Utility.Random(3)) ); break;
					case 40: AddToBackpack( new Cantaloupe(Utility.Random(3)) ); break;
					default: break;
				}
			}
				
			Fame = 0;
			Karma = 0;
			
			Item hair;
			if (Job != Life_Job.Guard)
				hair = Server.Items.Hair.GetRandomHair( Female );
			else
				hair = new ShortHair( Utility.RandomHairHue() );
			
			AddItem( hair );
			if( Utility.RandomBool() && !this.Female && Job != Life_Job.Guard )
			{
				Item beard = new Item( Utility.RandomList( 	0x203E, 0x203F, 0x2040, 0x2041,
															0x204B, 0x204C, 0x204D ) );
				beard.Hue = hair.Hue;
				beard.Layer = Layer.FacialHair;
				beard.Movable = false;
				AddItem( beard );
			}
		}

		public Life_People( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
			
			writer.Write( m_Courage );
			writer.Write( (int)m_Job );
			writer.Write( m_Interacting );
			writer.Write( m_InteractingTimer );
			writer.Write( m_InteractionDelay );
			writer.Write( m_InteractionStage );
			writer.Write( m_InteractingWith );
			writer.Write( m_ToAttractivePlace );
			writer.Write( m_Place );
			writer.Write( m_PlaceRange );
		}

		public override void Deserialize( GenericReader reader )
		{
			PeopleCounter++;
			base.Deserialize( reader );

			int version	= reader.ReadInt();
			switch (version)
			{
				case 0:
					m_Courage 			= reader.ReadDouble();
					m_Job 				= (Life_Job)(reader.ReadInt());
					m_Interacting		= reader.ReadBool();
					m_InteractingTimer	= reader.ReadDateTime();
					m_InteractionDelay	= reader.ReadDouble();
					m_InteractionStage	= reader.ReadInt();
					m_InteractingWith	= reader.ReadMobile();
					m_ToAttractivePlace = reader.ReadInt();
					m_Place 			= reader.ReadPoint3D();
					m_PlaceRange		= reader.ReadInt();
					break;
				default:
					break;
			}
		}
	}
}