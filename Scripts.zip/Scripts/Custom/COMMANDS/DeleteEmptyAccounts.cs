using System;
using Server;
using Server.Network;
using Server.Targeting;
using Server.Mobiles;
using Server.Accounting;

namespace Server.Scripts.Commands
{
	public class DeleteEmptyAccounts
	{
		public static void Initialize()
		{
			Register( "DeleteEmptyAccounts", AccessLevel.Administrator, new CommandEventHandler( DeleteEmptyAccounts_OnCommand ) );
		}

		public static void Register( string command, AccessLevel access, CommandEventHandler handler )
		{
			Server.Commands.Register( command, access, handler );
		}		

		[Usage( "DeleteEmptyAccounts" )]
		[Description( "Delete empty accounts." )]
		public static void DeleteEmptyAccounts_OnCommand( CommandEventArgs e )
		{
			e.Mobile.SendMessage( "Deleting accounts..." );
			int i=0;
			bool found = true;
			Account acc=null;
			while (found)
			{
				found = false;
				foreach ( Account a in Accounts.Table.Values )
				{
					bool empty=true;
					for ( int j = 0; j < a.Length; ++j )
					{
						Mobile m = a[j];
						if (m != null)
							empty=false;
					}
					if (empty)
					{
						acc=a;
						i++;
						found=true;
					}
				}
				if (found)
					acc.Delete();
			}
			e.Mobile.SendMessage( "{0} accounts deleted!",i);			
		}
	}
}