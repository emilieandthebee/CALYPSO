/********************************************
 *
 * Alambik Life System
 *
 ********************************************/
using System;
using System.Collections;
using Server.Items;
using Server.ContextMenus;
using Server.Misc;
using Server.Network;

namespace Server.Mobiles
{
	public class Life_Speak
	{
		public static void I_Am_Hurt( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			if ( Utility.Random(10) == 1 ) m.Emote("*crie*");
			switch(Utility.Random(6))
			{
				case 0: m.Say("Aaaah!..."); break;
				case 1: m.Say("Aaaah!..."); break;
				case 2: m.Say("Au secours!... Aidez-moi!"); break;
				case 3: if (m.Female) m.Say("Aaaah!... je suis blessee"); else m.Say("Aaaah!... je suis blesse"); break;
				case 4: m.Say("Au secours!..."); break;				
				case 5: m.Say("Argh..."); break;				
			}
		}
		public static void You_Attack_Me( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			if ( Utility.Random(10) == 1 ) m.Emote("*crie*");
			switch(Utility.Random(6))
			{
				case 0: m.Say("Aaaahh..."); break;
				case 1: m.Say("Ah!? Vous voulez me tuer ou quoi?..."); break;
				case 2: m.Say("Rustre!"); break;
				case 3: m.Say("A l'agresseur! A l'agresseur!"); break;
				case 4: m.Say("Espece de criminel!..."); break;				
				case 5: m.Say("Aaaaaah!!!..."); break;				
			}
		}
		public static void Where_Is_My_Combatant( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Say("Un de moins!..."); break;
				case 1: m.Emote("*crie*"); m.Say("Couard!..."); break;
				case 2: m.Emote("*crache parterre*");m.Say("Ou est ce mecreant?..."); break;
				case 3: m.Say("Mmhh... ce bandit doit etre parti"); break;
				case 4: m.Say("Bon debarras!..."); break;				
				case 5: m.Say("Ouf, c'est mieux comme ca..."); break;				
			}
		}
		public static void I_Look_Next_Combatant( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Emote("*Cherche un autre adevresaire*"); break;				
				case 1: m.Emote("*crie*"); m.Say("Haha! Mais il y en a plusieur!..."); break;
				case 2: m.Emote("*crache parterre*");m.Say("Suivant!..."); break;
				case 3: m.Say("Voyons cet autre..."); break;
				case 4: m.Say("Eh, toi!..."); break;
				case 5: m.Say("Ah nous deux..."); break;				
			}
		}
		public static void I_Put_My_Ranged_Weapon_In_My_Pack( Mobile m, double probability, Item item )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(3))
			{
				case 0: m.Emote("*range son "+item.Name+" dans son sac*"); break;
				case 1: m.Emote("*bascule son "+item.Name+" dans son dos*"); break;
				case 2: m.Emote("*met son "+item.Name+" a son ceinturon*"); break;
			}
		}
		public static void I_Melee_Fight( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(10))
			{
				case 0: m.Emote("*fait de grand moulinets avec son bras*"); break;				
				case 1: m.Emote("*a un rictus agressif aux levres*"); break;
				case 2: m.Emote("*se deplace afin de porter un meilleur coup*"); break;
				case 3: m.Say("Allez, viens-la, poltron..."); break;
				case 4: m.Say("Par ici, morveux!..."); break;				
				case 5: m.Say("Ah nous deux..."); break;				
				case 6: m.Say("Haaaa!!!..."); break;				
				case 7: m.Say("Umpf!..."); break;				
				case 8: m.Say("Je t'aurai!..."); break;				
				case 9: m.Say("Han!..."); break;				
			}
		}
		public static void I_Ranged_Fight( Mobile m, double probability, Item item)
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(8))
			{
				case 0: m.Emote("*vise "+m.Name+" de son arme*"); break;				
				case 1: m.Emote("*ajuste le tire de son "+item.Name+"*"); break;
				case 2: m.Emote("*essaie de toucher sa cible*"); break;
				case 3: m.Emote("*vise avec son "+item.Name+"*"); break;
				case 4: m.Say("Tu vas voir..."); break;
				case 5: m.Say("Ah, ca va faire mal..."); break;				
				case 6: m.Say("Ah nous deux..."); break;				
				case 7: m.Say("Mmhh..."); break;				
			}
		}
		public static void I_Flee( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			if ( Utility.RandomDouble()<0.01) m.Say("(Cours Forest! Cours!!!...)");
			switch(Utility.Random(7))
			{
				case 0: m.Emote("*fuit*"); break;				
				case 1: m.Emote("*abandonne le combat*"); break;
				case 2: m.Emote("*s'enfuit en courant*"); break;
				case 3: m.Say("Aaahh!! Au secours..."); break;
				case 4: m.Say("A l'aide!..."); break;				
				case 5: m.Say("Aie Aie Aie..."); break;				
				case 6: m.Say("Oulalah!!!..."); break;				
			}
		}
		public static void After_Flee_I_Can_Relax( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(7))
			{
				case 0: if (m.Female) m.Emote("*s'arrette de courir, essoufle*"); else m.Emote("*s'arrette de courir, essouflee*"); break;				
				case 1: m.Emote("*s'arrette et regarde derriere son epaule*"); break;
				case 2: if (m.Female) m.Emote("*essoufle*"); else m.Emote("*essouflee*"); break;
				case 3: m.Say("Ouch... Ici ca va mieux..."); break;
				case 4: m.Say("Je crois que je l'ai seme..."); break;				
				case 5: m.Say("Ouf... Ca va mieux..."); break;				
				case 6: m.Say("Et bien... Quel combat..."); break;				
			}
		}
		public static void I_Run_To_Flee( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(3))
			{
				case 0: m.Emote("*court*"); break;
				case 1: m.Emote("*court*"); break;
				case 2: m.Emote("*prend ses jambes a son cou*"); break;		
			}
		}
		public static void I_Sell( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(15))
			{
				case 0: m.Emote("*parle fort*"); m.Say("Allez, allez! Par ici! A vendre ici!"); break;
				case 2: m.Say("Allez, approchez mesdames messieurs! Pas cher!"); break;
				case 3: m.Say("Des bons prix ici!"); break;
				case 4: m.Say("Ils sont beaux ils sont beaux mes articles!"); break;
				case 5: m.Say("Venez messieurs dames, par ici!"); break;
				case 6: m.Say("Le meilleur au meilleur prix!"); break;
				case 7: m.Say("Ce qui se fait de mieux pour un tout petit peu plus cher! Allons allons!"); break;
				case 8: m.Say("Par ici, que puis-je vous offrir?... Venez, venez..."); break;
				case 9: m.Say("Vous en reviez, "+m.Name+" l'a fait! Venez voir ca!..."); break;
				case 10: m.Say("S'il vous plait, une minute pour admirer ma marchandise!..."); break;
				case 11: m.Say("Les meilleurs articles sont chez "+m.Name+"!... Par ici!"); break;
				case 12: m.Say("Nouvel arrivage! Allez, venez voir ca!"); break;
				case 13: m.Say("Tout a petits prix! C'est ici que ca se passe!"); break;
				case 14: m.Say("Appelez-moi "+m.Name+", je vous fait les meilleurs ristournes!..."); break;
			}
		}
		public static void I_Want_To_Rob( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Emote("*regarde a droite a gauche*"); break;
				case 1: m.Emote("*regarde de biais*"); break;
				case 2: m.Emote("*plisse les yeux*"); break;
				case 3: m.Emote("*regarde les sacs des gens*"); break;
				case 4: m.Emote("*regarde les sacs des gens*"); break;
				case 5: m.Emote("*fait pendre ses mains*"); break;
			}
		}
		public static void I_Am_Guarding( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Emote("*surveille*"); break;
				case 1: m.Emote("*regarde chaque personne avec attention*"); break;
				case 2: m.Emote("*tourne la tete a droite a gauche hostensiblement*"); break;
				case 3: m.Emote("*suit les gens du regard*"); break;
				case 4: m.Emote("*tatonne du pieds parterre*"); break;
				case 5: m.Emote("*salue les gens au passage*"); break;
			}
		}
		public static void I_Am_A_Looser( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Emote("*regarde ses propres pieds*"); break;
				case 1: m.Emote("*se gratte l'oreille*"); break;
				case 2: m.Emote("*se gratte le derriere*"); break;
				case 3: m.Emote("*regarde en l'air*"); break;
				case 4: m.Emote("*a l'air fatigue*"); break;
				case 5: m.Emote("*a l'air pensif*"); break;
				case 6: m.Emote("*cherche quelquechose dans son sac*"); break;
				case 7: m.Emote("*met la main dans la poche*"); break;
				case 8: m.Emote("*refait son soulier*"); break;
				case 9: m.Emote("*rote*"); m.PlaySound( (m.Female)?782:1053 ); 
					if ( !m.Mounted ) m.Animate( 34, 5, 1, true, false, 0 );
					break;
				case 10: m.Emote("*se mouche*"); m.PlaySound( 781 ); 
					if ( !m.Mounted ) m.Animate( 34, 5, 1, true, false, 0 );
					break;
				case 11: m.Emote("*toussote*"); m.PlaySound( (m.Female)?786:1057 );
					if ( !m.Mounted ) m.Animate( 34, 5, 1, true, false, 0 );
					break;
				case 12: m.Emote("*tousse*"); m.PlaySound( (m.Female)?7005:1056 );
					if ( !m.Mounted ) m.Animate( 34, 5, 1, true, false, 0 );
					break;
				case 13: m.Emote("*se racle la gorge*"); m.PlaySound( (m.Female)?784:1055 );
					if ( !m.Mounted ) m.Animate( 34, 5, 1, true, false, 0 );
					break;
				case 14: m.Emote("*soupire*"); m.PlaySound( (m.Female)?816:1090 );
					if ( !m.Mounted ) m.Animate( 6, 5, 1, true, false, 0 );
					break;
				case 15: m.Emote("*eternue*"); m.PlaySound( (m.Female)?817:1091 );
					if ( !m.Mounted ) m.Animate( 32, 5, 1, true, false, 0 );
					break;
				case 16: m.Emote("*baille*"); m.PlaySound( (m.Female)?822:1096 );
					break;
				case 17: m.Emote("*renifle*"); m.PlaySound( (m.Female)?818:1092 );
					break;
			}
		}
		public static void Hello( Mobile m, Mobile mm, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(10))
			{
				case 0: m.Emote("*salue*"); m.Say("Bonjour!"); break;
				case 1: m.Say("Bonjour "+mm.Name+"..."); break;
				case 2: m.Say("Salut "+mm.Name+"!"); break;
				case 3: m.Say("Bonjour "+mm.Name+"!..."); break;
				case 4: m.Say("Ah, "+mm.Name+", je voulais te voir..."); break;
				case 5: m.Say("Oh, mais c'est "+mm.Name+"!, quelle bonne surprise!..."); break;
				case 6: m.Say("Bonjour!"); break;
				case 7: m.Say("Salut!"); break;
				case 8: m.Say("Bien le bonjour."); break;
				case 10: m.Say("Mes salutations."); break;
			}
		}
		public static void Hello_I_Am( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(5))
			{
				case 0: m.Emote("*salue*"); m.Say("Bonjour! Je me nomme "+m.Name); break;
				case 1: m.Say("Bonjour, je me presente: "+m.Name); break;
				case 2: m.Say("Salutations. Moi c'est "+m.Name+"."); break;
				case 3: m.Say("Bonjour, je m'appelle "+m.Name+"."); break;
				case 4: m.Say("Bonjour, puis-je me presenter: "+m.Name+"."); break;
			}
		}
		public static void Glad_To_Meet_You( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(5))
			{
				case 0: m.Emote("*salue*"); m.Say("Echante! Je me nomme "+m.Name); break;
				case 1: m.Say("Bonjour, moi c'est "+m.Name); break;
				case 2: m.Say("Et moi, "+m.Name+"."); break;
				case 3: m.Say("Heureux de faire votre connaissance, moi c'est "+m.Name+"."); break;
				case 4: m.Say("Bonjour a vous. Mon nom est "+m.Name+"."); break;
			}
		}
		public static void About_Weather( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(5))
			{
				case 0: m.Emote("*regarde vers le ciel*"); m.Say("Drole de temps en ce moment. Non?"); break;
				case 1: m.Say("Le temps change vite en ce moment..."); break;
				case 2: m.Say("Comme j'aimerai qu'il fasse ce temps plus souvent... Moi j'aime!"); break;
				case 3: m.Say("Drole de temps n'est-ce pas?"); break;
				case 4: m.Say("Ca fait un moment que le soleil ne fait pas de longues apparitions, n'est-ce pas?"); break;
			}
		}
		public static void Sure( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(15))
			{
				case 0: m.Emote("*aquiesse d'un hochement de tete*"); break;
				case 1: m.Say("Assurement..."); break;
				case 2: m.Say("Tout a fair!"); break;
				case 3: m.Say("Je ne dirais pas mieux."); break;
				case 4: m.Say("A qui le dites-vous!"); break;
				case 5: m.Say("Oui"); break;
				case 6: m.Say("C'est certain."); break;
				case 7: m.Say("Sans doute..."); break;
				case 8: m.Say("Evidement!"); break;
				case 9: m.Say("C'est certain."); break;
				case 10: m.Say("En effet"); break;
				case 11: m.Say("Je ne vous le fais pas dire!"); break;
				case 12: m.Say("Ca c'est sure..."); break;
				case 13: m.Say("Oh que oui!"); break;
				case 14: m.Say("oui oui..."); break;
			}
		}
		public static void Bye( Mobile m, Mobile mm, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(10))
			{
				case 0: m.Emote("*salue*"); m.Say("Au revoir!"); break;
				case 1: m.Say("Au revoir "+mm.Name+"..."); break;
				case 2: m.Say("A bientot "+mm.Name+"!"); break;
				case 3: m.Say("Aller, je dois y aller "+mm.Name+"... A bientot!"); break;
				case 4: m.Say("Au revoir et a bientot "+mm.Name+"..."); break;
				case 5: m.Say("Au revoir..."); break;
				case 6: m.Say("au revoir!"); break;
				case 7: m.Say("Salut!"); break;
				case 8: m.Say("Ah la prochaine..."); break;
				case 10: m.Say("J'y vais, allez, a bientot..."); break;
			}
		}
		public static void How_Are_You( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(7))
			{
				case 0: m.Say("Comment ca va?"); break;
				case 1: m.Say("Ca va bien?"); break;
				case 2: m.Say("Tout va bien?"); break;
				case 3: m.Say("Ca se passe bien?"); break;
				case 4: m.Say("Ca va la sante?"); break;
				case 5: m.Say("Est-ce que ca va?"); break;
				case 6: m.Say("Ca roule?"); break;
			}
		}
		public static void I_Am_Well( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(12))
			{
				case 0: m.Say("Ca va."); break;
				case 1: m.Say("Ca va, ca va..."); break;
				case 2: m.Say("Comme-ci comme-ca..."); break;
				case 3: m.Say("On fait aller..."); break;
				case 4: m.Say("Oui, bien, merci..."); break;
				case 5: m.Say("Tres bien!"); break;
				case 6: m.Say("La pleine forme!"); break;
				case 7: m.Say("Super bien."); break;
				case 8: m.Say("Oh, je me sens un peu fatigue en ce moment..."); break;
				case 9: m.Say("Pas trop la forme..."); break;
				case 11: m.Say("Oui, ca va."); break;
			}
		}
		public static void You_Will_Die( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(12))
			{
				case 0: m.Say("Meurt, criminel!"); break;
				case 1: m.Say("Tu vas tater de mon poing, mecreant!..."); break;
				case 2: m.Say("Tu vas voir, malfrat!..."); break;
				case 3: m.Say("Espece de vaut-rien! Tu vas voir..."); break;
				case 4: m.Say("Ah nous deux, espece de pourriture!..."); break;
				case 5: m.Say("Tu vas le payer!"); break;
				case 6: m.Say("Viens la, pleutre!"); break;
				case 7: m.Say("Tu vas voir ce que tu vas voir!"); break;
				case 8: m.Say("Alors la, n'espere pas t'en tirer comme ca!..."); break;
				case 9: m.Say("Meurt, espece de maraud..."); break;
				case 11: m.Say("Viens la, chien!"); break;
			}
		}
		public static void Thief( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Say("Au voleur! Au voleur!"); break;
				case 1: m.Say("Au voleur! A L'aide!"); break;
				case 2: m.Say("Au voleur!..."); break;
				case 3: m.Say("Espece de voleur... Au secour!!!"); break;
				case 4: m.Say("Aidez-moiiiii! Au Voleuuuur!!!..."); break;
				case 5: m.Say("Voleur!"); break;
			}
		}
		public static void I_Steal( Mobile m, Mobile mm, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(6))
			{
				case 0: m.Emote("plonge la main dans le sac de "+mm.Name); break;
				case 1: m.Emote("attrappe quelquechose a la ceinture de "+mm.Name); break;
				case 2: m.Emote("escamote quelquechose du sac de "+mm.Name); break;
				case 3: m.Emote("faufile une main dans le sac dans le dos de "+mm.Name); break;
				case 4: m.Emote("prend quelquechose du sac de "+mm.Name+" en regardant ailleurs"); break;
				case 5: m.Emote("detache quelquechose du ceinturon de "+mm.Name); break;
			}
		}
		public static void Where_Are_You_Going( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(7))
			{
				case 0: m.Say("Ou allez-vous comme ca?..."); break;
				case 1: m.Say("Vers ou vous dirigez-vous?"); break;
				case 2: m.Say("Vous allez ou au fait?"); break;
				case 3: m.Say("Vous allez loin?"); break;
				case 4: m.Say("Vers quel endroit allez-vous?"); break;
				case 5: m.Say("Vous allez ou?"); break;
				case 6: m.Say("Ou donc allez-vous?"); break;
			}
		}
		public static void I_Am_Going_There( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(26))
			{
				case 0: m.Say("Je vais par la..."); m.Emote("*pointe une direction de son doigt*"); break;
				case 1: m.Say("Oh, je pensais allez vers une batisse par la-bas..."); break;
				case 2: m.Say("Et bien je vais chercher un fleuriste..."); break;
				case 3: m.Say("Je comptais allez dans le Sud..."); break;
				case 4: m.Say("Je comptais allez dans le Nord..."); break;
				case 5: m.Say("Je comptais allez dans vers l'Est..."); break;
				case 6: m.Say("Je comptais allez dans vers l'Ouest..."); break;
				case 7: m.Say("Je vais chercher a manger."); break;
				case 8: m.Say("Moi? Oh, je vais me saouler dans une taverne."); break;
				case 9: m.Say("Oh, j'esperais trouver un coin tranquile ou pecher."); break;
				case 10: m.Say("Je vais essayer de voir si mon couturier est ouvert."); break;
				case 11: m.Say("Au marche..."); break;
				case 12: m.Say("Je vais voire une amie..."); break;
				case 13: m.Say("Je vais voire un ami..."); break;
				case 14: m.Say("Je vais une masseuse... Si vous voyez ce que je veux dire..."); break;
				case 15: m.Say("Je vais me trouver une taverne."); break;
				case 16: m.Say("Je cherche un coin tranquile ou aller lire."); break;
				case 17: m.Say("Et bien j'etais sur le chemin de mon domicile..."); break;
				case 18: m.Say("Ca vous regarde ou je vais?..."); break;
				case 19: m.Say("Je vais ou ca me chante..."); break;
				case 20: m.Say("J'irais bien chez toi boire un coup en fait si tu as le temps."); break;
				case 21: m.Say("J'vais chez ta mere..."); break;
				case 22: m.Say("Oh, et bien je n'en sais rien."); break;
				case 23: m.Say("Je voulais aller en mer."); break;
				case 24: m.Say("Ben a la taverne, comme tout le monde..."); break;
				case 25: m.Say("Je vais a un endroit ou vous ne pourrez me suivre."); break;
			}
		}
		public static void What_Are_You_Doing( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(7))
			{
				case 0: m.Say("Que faites vous?"); break;
				case 1: m.Say("Vous faites quoi en ce moment?"); break;
				case 2: m.Say("Qu'est-ce que vous faites pour le moment?"); break;
				case 3: m.Say("Vous faites quoi?"); break;
				case 4: m.Say("Que faisez-vous donc en ce moment?"); break;
				case 5: m.Say("Et vous faites quoi, la?"); break;
				case 6: m.Say("Vous faites quelquechose en ce moment?"); break;
			}
		}
		public static void I_Do_This( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(24))
			{
				case 0: m.Say("Bah je glande, comme vous..."); break;
				case 1: m.Say("Oh, je regarde l'environnement..."); break;
				case 2: m.Say("Ben ca se voit pas?"); break;
				case 3: m.Say("Je fais ce que ca me chante!..."); break;
				case 4: m.Say("Je cherche quelqu'un..."); break;
				case 5: m.Say("Je lisais un livre en marchant..."); break;
				case 6: m.Say("Je me promene..."); break;
				case 7: m.Say("Et bien je cherche des clients..."); break;
				case 8: m.Say("Oh, je travaille, comme tout le monde!..."); break;
				case 9: m.Say("Je fait semblant de travailler..."); break;
				case 10: m.Say("Et bien je cherche a gagner ma vie."); break;
				case 11: m.Say("Oh, j'ecoute ce que disent les gens..."); break;
				case 12: m.Say("Oh, rien, mais on paux faire des trucs ensemble chez moi, enfin si tu vois ce que je veux dire..."); break;
				case 13: m.Say("Ah! be... je me saoule la gueule... hehhe... Un pt'it coup?"); break;
				case 14: m.Say("Je fais les cents pas... J'attends mon frere..."); break;
				case 15: m.Say("Je fais les cents pas... J'attends ma soeur..."); break;
				case 16: m.Say("Oh, je fais des exercices!..."); break;
				case 17: m.Say("La? Et bien rien..."); break;
				case 18: m.Say("Qu'est ce que ca peux te foutre..."); break;
				case 19: m.Say("Je me demandais la meme question sur toi, branleur!"); break;
				case 20: m.Say("Pas grand chose en ce moment."); break;
				case 21: m.Say("Je suis a l'affut d'informations a glaner ici et la..."); break;
				case 22: m.Say("Je recherche ce foutu voleur qui m'a pique ma bourse..."); break;
				case 23: m.Say("Mais je vous dit merde!... Espece de curieux!"); break;
			}
		}
		public static void Do_You_Want_To_Have_A_Drink_Or_Meal( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(14))
			{
				case 0: m.Say("Vous voulez boire un coup tout a l'heure?"); break;
				case 1: m.Say("Ca vous dit un verre de Nukacola demain soir?"); break;
				case 2: m.Say("J'ai soif, je boirais bien un verre, pas vous?"); break;
				case 3: m.Say("Pourquoi n'irions nous pas boire une biere?"); break;
				case 4: m.Say("Vous boirez bien un coup dans une taverne?"); break;
				case 5: m.Say("Apres-demain je vais boire un coup dans une taverne, ca vous dit?"); break;
				case 6: m.Say("Vous etes libre demain midi? Je vous invite a boire un coup..."); break;
				case 7: m.Say("Vous avez le temps pour aller manger un morceau?"); break;
				case 8: m.Say("On va manger demain soir a la taverne?"); break;
				case 9: m.Say("J'ai faim... On va mange un bout?"); break;
				case 10: m.Say("Voulez-vous aller manger chez moi apres-demain?"); break;
				case 11: m.Say("Que diriez-vous d'un bon restaurant?"); break;
				case 12: m.Say("Et si nous allions manger?..."); break;
				case 13: m.Say("Vous prendrez bien un verre avec moi?"); break;
			}
		}
		public static void Negative_Answer( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(8))
			{
				case 0: m.Say("Non..."); break;
				case 1: m.Say("Surement pas..."); break;
				case 2: m.Say("Ah non..."); break;
				case 3: m.Say("Impossible."); break;
				case 4: m.Say("Non, certainement pas."); break;
				case 5: m.Say("Ah non..."); break;
				case 6: m.Emote("*fait un non de la tete*"); break;
				case 7: m.Say("Mmmhh... je dois repondre que non."); break;
			}
		}
		public static void Maybe( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			switch(Utility.Random(11))
			{
				case 0: m.Say("Peut-etre..."); break;
				case 1: m.Say("Qui sait..."); break;
				case 2: m.Say("C'est possible..."); break;
				case 3: m.Say("Pas Impossible..."); break;
				case 4: m.Say("Je ne saurais dire."); break;
				case 5: m.Say("Difficile de savoir."); break;
				case 6: m.Emote("*hausse les epaules*"); break;
				case 7: m.Say("Eventuellement..."); break;
				case 8: m.Say("Ce n'est pas impossible..."); break;
				case 9: m.Say("C'est probable..."); break;
				case 10: m.Say("Je ne m'avancerai pas sur une reponse..."); break;
			}
		}
		public static void Do_You_Know_This_Criminal( Mobile m, double probability )
		{
			if ( Utility.RandomDouble()>probability) return;
			
			ArrayList list = new ArrayList();
			foreach ( Mobile mob in World.Mobiles.Values )
			{
				if ( !mob.Deleted )
				if ( mob is PlayerMobile)
				if ( mob.AccessLevel <= AccessLevel.GameMaster)
				if ( ((PlayerMobile)mob).TechnoCrimes > 0 )
					list.Add( mob );
			}	double val=0.0;
			string name="";
			for (int j=0;j<list.Count;j++)
			{
				PlayerMobile pm = (PlayerMobile)(list[j]);
				if (val < TechnoInquisiteur.ComputeGravity(pm))
				{
					name=pm.Name;
					val=TechnoInquisiteur.ComputeGravity(pm);
				}
			}
			val=val*1000;
			if (name == "") 
				 m.Say("Il semblarait qu'il y ai peu de criminels ces temps-ci...");
			else switch(Utility.Random(6))
			{
				case 0: m.Say("Il parait que qu'un criminel du nom de "+name+" est tres recherche en ce moment..."); break;
				case 1: m.Say("Vous saviez qu'un(e) certain(e) "+name+" est recherche(e) pour "+(int)val+" caps?..."); break;
				case 2: m.Say("Au fait, ils offrent une prime de "+(int)val+" caps pour la tete de "+name+", vous le saviez?..."); break;
				case 3: m.Say("Ah! si ca vous interesse, ils ont mis la tete d'un certain "+name+" a "+(int)val+" caps..."); break;
				case 4: m.Say("Si vous voulez vous faire "+(int)val+" caps, ils recherchent un certain "+name+". Ca vous interesse?..."); break;
				case 5: m.Say("Vous ne connaitriez pas un certain "+name+"? Il parait que sa tete est mise a prix pour "+(int)val+" caps..."); break;
			}
		}
	}
}