using System;
using Server;
using Server.Items;
using Server.SpellCrafting;

namespace Server.SpellCrafting.Crafts
{
	public class HitColdArea
	{
		private static readonly int Minimum = 2;
		private static readonly int Maximum = 50;

		public static void Callback( Mobile from, object target )
		{
			if ( !(target is BaseWeapon) )
			{
				from.SendMessage( "This craft cannot be placed on that item" );
			}
			else if ( !SpellCraft.CheckSpellCrafted( from, target ) )
			{
				return;
			}
			else
			{
				int scalar = (int)( (from.Skills[SkillName.Inscribe].Value + from.Skills[SkillName.Alchemy].Value) / 200.0 );

				SpellCraft.ApplyAttribute( ((BaseWeapon)target).WeaponAttributes, 20 * scalar, 100 * scalar, AosWeaponAttribute.HitColdArea, Minimum, Maximum, 2 );
			}
		}
	}
}