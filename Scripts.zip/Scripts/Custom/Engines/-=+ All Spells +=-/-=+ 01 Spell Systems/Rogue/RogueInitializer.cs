using System;
using Server;
using Server.Spells;

namespace Server.Spells.Rogue
{
	public class RogueInitializer
	{
		public static void Initialize()
		{
			if( Core.AOS )
			{
				Register( 150, typeof( RogueFalseCoinSpell ) );
				Register( 151, typeof( RogueCharmSpell ) );
				Register( 152, typeof( SlyFoxSpell ) );
				Register( 153, typeof( ShadowSpell ) );
				Register( 154, typeof( IntimidationSpell ) );

				//RegDef( spellID, "Name", "Description", "Reagent1; Reagent2; Reagentn", "Skill; Mana; Tithe; Etc" );
				RegDef( 150, "False Coin",   "The Rogue produces false gold with the trick of the hand.",          "Nightshade; Sulfurous Ash",               null );
				RegDef( 151, "Charm",        "The Rogue mesmerizes a target with evil eyes.",                      "Blackpearl; Nightshade; Spiders Silk",    null );
				RegDef( 152, "Sly Fox",      "The Rogue changes shape into a stealthy Sly Fox.",                   "Petrafied Wood; Nox Crystal; Nightshade", null );
				RegDef( 153, "Shadow",       "The Rogue slips into the shadows.",                                  "Spiders Silk; Daemon Blood; Black Pearl", null );
				RegDef( 154, "Intimidation", "The Rogue begins to look angry and mean at the loss of his skills.", null,                                      null );
			}
		}
		public static void Register( int spellID, Type type )
		{
			SpellRegistry.Register( spellID, type );
		}
		public static void RegDef( int spellID, string name, string des, string regs, string inf )
		{
			SpellDefRegistry.Register( spellID, name, des, regs, inf );
		}
	}
}