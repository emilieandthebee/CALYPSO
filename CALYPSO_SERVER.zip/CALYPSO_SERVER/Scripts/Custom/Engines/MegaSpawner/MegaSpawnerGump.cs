using System;
using Server;
using System.IO;
using System.Collections;
using Server.Mobiles;
using Server.Gumps;
using Server.Items;
using Server.Targeting;

namespace Server.Scripts.Commands
{
	public class MegaSpawnerCommand
	{
		public static void Initialize()
		{
			Register( "MegaSpawner", AccessLevel.Administrator, new CommandEventHandler( MegaSpawner_OnCommand ) );
		}

		public static void Register( string command, AccessLevel access, CommandEventHandler handler )
		{
			Server.Commands.Register( command, access, handler );
		}

		[Usage( "MegaSpawner" )]
		[Description( "Opens Mega Spawner gump." )]
		public static void MegaSpawner_OnCommand( CommandEventArgs e )
		{
			Mobile mobile = e.Mobile;

			mobile.CloseGump( typeof( MegaSpawnerGump ) );
			mobile.SendGump( new MegaSpawnerGump( mobile ) );
		}
	}

	public class MegaSpawnerGump : Gump
	{
		public static ArrayList SpawnerList = new ArrayList();

		public MegaSpawnerGump( Mobile mobile ) : base( 0,0 )
		{
			CheckSpawners();

			AddPage(0); // Page 0

			AddBackground( 80, 80, 600, 450, 0 );
			AddImageTiled( 80, 80, 600, 450, 2624 );
			AddAlphaRegion( 100, 100, 560, 330 );
			AddAlphaRegion( 100, 450, 560, 60 );
			AddImage( 30, 50, 10440);
			AddImage( 648, 50, 10441);
			AddLabel( 140, 80, 60, "Mega Spawners In The Entire World" );
			AddButton( 630, 490, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			if ( SpawnerList.Count != 0 )
			{
				AddLabel( 140, 100, 10, "Name" );
				AddLabel( 300, 100, 10, "Facet" );
				AddLabel( 380, 100, 10, "Location" );
				AddLabel( 520, 100, 10, "Active" );
				AddLabel( 580, 100, 10, "Total Entries" );
			}

			AddPage(1); // Page 1

			AddLabel( 540, 80, 60, "Page: 1" );

			AddButtons();

			int listX = 140;
			int listY = 120;
			int page = 1;
			int newPage = 15;

			if ( SpawnerList.Count == 0 )
			{
				AddLabel( 140, 100, 10, "There are no Mega Spawners in the entire world." );
			}
			else
			{
				for ( int i = 0; i < SpawnerList.Count; i++ )
				{
					MegaSpawner megaSpawner = (MegaSpawner) SpawnerList[i];

					if ( i == newPage )
					{
						listY = 120;
						newPage += 15;
						page += 1;

						AddLabel( 430, 430, 10, "Page " + page.ToString() );
						AddButton( 380, 430, 4005, 4007, 0, GumpButtonType.Page, page );

						AddPage(page); // New Page

						AddLabel( 540, 80, 60, "Page: " + page.ToString() );

						AddLabel( 280, 430, 10, "Page " + ( page - 1 ).ToString() );
						AddButton( 340, 430, 4014, 4016, 0, GumpButtonType.Page, page - 1 );

						AddButtons();
					}

					AddButton( listX - 40, listY, 9904, 9905, i + 10, GumpButtonType.Reply, 0 );
					AddLabel( listX, listY, 10, megaSpawner.Name );
					AddLabel( listX + 160, listY, 10, megaSpawner.Map.ToString() );
					AddLabel( listX + 240, listY, 10, megaSpawner.Location.ToString() );
					AddLabel( listX + 380, listY, 10, megaSpawner.Active.ToString() );
					AddLabel( listX + 440, listY, 10, megaSpawner.CreatureList.Count.ToString() );

					listY += 20;
				}
			}
		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;
			int index = (int) info.ButtonID - 10;
			MegaSpawner megaSpawner = null;

			if ( index >= 0 )
				megaSpawner = (MegaSpawner) SpawnerList[index];

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( MegaSpawnerGump ) );

					break;
				}
				case 1: // Delete All Imported Spawners
				{
					mobile.CloseGump( typeof ( MegaSpawnerGump ) );
					mobile.SendGump( new ConfirmDeleteAllImportedSpawnersGump( mobile ) );

					break;
				}
				case 2: // Delete All Spawners
				{
					mobile.CloseGump( typeof ( MegaSpawnerGump ) );
					mobile.SendGump( new ConfirmDeleteAllSpawnersGump( mobile ) );

					break;
				}
				case 3: // Add Spawner
				{
					mobile.SendMessage( "Target a location for the new Mega Spawner." );
					mobile.Target = new AddSpawnerTarget( mobile );

					break;
				}
				case 4: // Export Spawners
				{
					if ( MegaSpawnerGump.SpawnerList.Count == 0 )
					{
						mobile.SendMessage( "There are no spawners to export." );

						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}

					mobile.CloseGump( typeof ( MegaSpawnerGump ) );
					mobile.SendGump( new ExportSpawnersGump( mobile ) );

					break;
				}
				case 5: // Turn On All Spawners
				{
					if ( MegaSpawnerGump.SpawnerList.Count == 0 )
					{
						mobile.SendMessage( "There are no spawners to turn on." );

						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}

					CheckSpawners();

					foreach( MegaSpawner megaspawner in SpawnerList )
						megaspawner.Active = true;

					mobile.SendMessage( "All spawners have been turned on." );

					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
				case 6: // Turn Off All Spawners
				{
					if ( MegaSpawnerGump.SpawnerList.Count == 0 )
					{
						mobile.SendMessage( "There are no spawners to turn off." );

						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}

					CheckSpawners();

					foreach( MegaSpawner megaspawner in SpawnerList )
						megaspawner.Active = false;

					mobile.SendMessage( "All spawners have been turned off." );

					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
				case 7: // Import Spawners
				{
					mobile.CloseGump( typeof ( MegaSpawnerGump ) );
					mobile.SendGump( new ImportSpawnersGump( mobile ) );

					break;
				}
				case 8: // Respawn All
				{
					if ( MegaSpawnerGump.SpawnerList.Count == 0 )
					{
						mobile.SendMessage( "There are no spawners to respawn." );

						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}

					CheckSpawners();

					foreach( MegaSpawner megaspawner in SpawnerList )
						megaspawner.Respawn();

					mobile.SendMessage( "All spawners have been respawned." );

					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
				case 9: // All To Home
				{
					if ( MegaSpawnerGump.SpawnerList.Count == 0 )
					{
						mobile.SendMessage( "There are no spawners to bring to home." );

						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}

					CheckSpawners();

					foreach( MegaSpawner megaspawner in SpawnerList )
						megaspawner.BringToHome();

					mobile.SendMessage( "All creatures on each spawner have been brought to their spawner's location." );

					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
				default:
				{
					mobile.CloseGump( typeof ( MegaSpawnerGump ) );
					mobile.SendGump( new MegaSpawnerEditGump( mobile, megaSpawner, true ) );

					break;
				}
			}
		}

		public void AddButtons()
		{
			AddLabel( 140, 450, 10, "Delete All Imported" );
			AddButton( 100, 450, 9904, 9905, 1, GumpButtonType.Reply, 0 );

			AddLabel( 140, 470, 10, "Delete All Spawners" );
			AddButton( 100, 470, 9904, 9905, 2, GumpButtonType.Reply, 0 );

			AddLabel( 140, 490, 10, "Add Spawner" );
			AddButton( 100, 490, 9904, 9905, 3, GumpButtonType.Reply, 0 );

			AddLabel( 340, 450, 10, "Export Spawners" );
			AddButton( 300, 450, 9904, 9905, 4, GumpButtonType.Reply, 0 );

			AddLabel( 340, 470, 10, "Turn On All Spawners" );
			AddButton( 300, 470, 9904, 9905, 5, GumpButtonType.Reply, 0 );

			AddLabel( 340, 490, 10, "Turn Off All Spawners" );
			AddButton( 300, 490, 9904, 9905, 6, GumpButtonType.Reply, 0 );

			AddLabel( 540, 450, 10, "Import Spawners" );
			AddButton( 500, 450, 9904, 9905, 7, GumpButtonType.Reply, 0 );

			AddLabel( 540, 470, 10, "Respawn All" );
			AddButton( 500, 470, 9904, 9905, 8, GumpButtonType.Reply, 0 );

			AddLabel( 540, 490, 10, "All To Home" );
			AddButton( 500, 490, 9904, 9905, 9, GumpButtonType.Reply, 0 );
		}

		public class AddSpawnerTarget : Target
		{
			private MegaSpawner megaSpawner = null;
			private Mobile mobile;

			public AddSpawnerTarget( Mobile owner ) : base( -1, true, TargetFlags.None )
			{
				mobile = owner;
			}

			protected override void OnTarget( Mobile mobile, object o )
			{
				IPoint3D target = (IPoint3D) o;
				Point3D point3D;

				if ( target != null )
				{
					megaSpawner = new MegaSpawner();

					if ( target is Item )
						target = ( (Item) target ).GetWorldTop();
					else if ( target is Mobile )
						target = ( (Mobile) target ).Location;

					point3D = new Point3D( target.X, target.Y, target.Z );

					megaSpawner.MoveToWorld( point3D, mobile.Map );
				}
			}

			protected override void OnTargetFinish( Mobile mobile )
			{
				if ( megaSpawner != null )
					mobile.SendMessage( "Mega Spawner placed at location: {0}.", megaSpawner.Location.ToString() );
				else
					mobile.SendMessage( "You have cancelled placement of a new Mega Spawner." );

				mobile.SendGump( new MegaSpawnerGump( mobile ) );
			}
		}

		public static void CheckSpawners()
		{
			for( int i = 0; i < SpawnerList.Count; i++ )
			{
				MegaSpawner megaSpawner = (MegaSpawner) SpawnerList[i];

				if ( megaSpawner.Deleted )
				{
					SpawnerList.RemoveAt(i);
					i--;
				}
			}
		}
	}

	public class ConfirmDeleteAllSpawnersGump : Gump
	{
		public ConfirmDeleteAllSpawnersGump( Mobile mobile ) : base( 0,0 )
		{
			AddPage(0); // Page 0

			AddBackground( 180, 180, 330, 90, 0 );
			AddImageTiled( 180, 180, 330, 90, 2624 );
			AddAlphaRegion( 200, 200, 290, 20 );
			AddAlphaRegion( 200, 230, 290, 20 );
			AddLabel( 240, 180, 60, "Confirmation Of Deleting All Spawners" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Are you sure you want to delete all spawners?" );

			AddLabel( 440, 230, 10, "Cancel" );
			AddButton( 400, 230, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 230, 10, "Ok" );
			AddButton( 200, 230, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ConfirmDeleteAllSpawnersGump ) );
					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					mobile.SendMessage( "You have chosen not to delete all spawners." );

					break;
				}
				case 1: // Delete All Spawners
				{
					MegaSpawnerGump.CheckSpawners();

					foreach( MegaSpawner megaSpawner in MegaSpawnerGump.SpawnerList )
						megaSpawner.Delete();

					mobile.SendMessage( "All spawners have now been deleted." );

					mobile.CloseGump( typeof ( ConfirmDeleteAllSpawnersGump ) );
					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
			}
		}
	}

	public class ConfirmDeleteAllImportedSpawnersGump : Gump
	{
		public ConfirmDeleteAllImportedSpawnersGump( Mobile mobile ) : base( 0,0 )
		{
			AddPage(0); // Page 0

			AddBackground( 180, 180, 380, 90, 0 );
			AddImageTiled( 180, 180, 380, 90, 2624 );
			AddAlphaRegion( 200, 200, 340, 20 );
			AddAlphaRegion( 200, 230, 340, 20 );
			AddLabel( 240, 180, 60, "Confirmation Of Deleting All Imported Spawners" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Are you sure you want to delete all imported spawners?" );

			AddLabel( 490, 230, 10, "Cancel" );
			AddButton( 450, 230, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 230, 10, "Ok" );
			AddButton( 200, 230, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ConfirmDeleteAllImportedSpawnersGump ) );
					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					mobile.SendMessage( "You have chosen not to delete all imported spawners." );

					break;
				}
				case 1: // Delete All Imported Spawners
				{
					MegaSpawnerGump.CheckSpawners();

					foreach( MegaSpawner megaSpawner in MegaSpawnerGump.SpawnerList )
					{
						if ( megaSpawner.Imported )
							megaSpawner.Delete();
					}

					mobile.SendMessage( "All imported spawners have now been deleted." );

					mobile.CloseGump( typeof ( ConfirmDeleteAllImportedSpawnersGump ) );
					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					break;
				}
			}
		}
	}

	public class ImportSpawnersGump : Gump
	{
		public ImportSpawnersGump( Mobile mobile ) : base( 0,0 )
		{
			AddPage(0); // Page 0

			AddBackground( 180, 180, 340, 120, 0 );
			AddImageTiled( 180, 180, 340, 120, 2624 );
			AddAlphaRegion( 200, 200, 300, 40 );
			AddAlphaRegion( 200, 260, 300, 20 );
			AddLabel( 240, 180, 60, "Import Spawners" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Type in the filename to import:" );
			AddImageTiled( 200, 220, 300, 18, 2604 );
			AddTextEntry( 200, 220, 300, 15, 1153, 0, "" );

			AddLabel( 440, 260, 10, "Cancel" );
			AddButton( 400, 260, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 260, 10, "Ok" );
			AddButton( 200, 260, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ImportSpawnersGump ) );
					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					mobile.SendMessage( "You have chosen not to import spawners." );

					break;
				}
				case 1: // Import Spawners
				{
					string fileName;

					TextRelay textInput = info.GetTextEntry( 0 );
					fileName = Convert.ToString( textInput.Text ) + ".msf";

					if ( fileName == ".msf" )
					{
						mobile.SendMessage( "That filename is invalid. Please type in another filename." );

						mobile.SendGump( new ImportSpawnersGump( mobile ) );

						break;
					}

					try
					{
						StreamReader r = File.OpenText( fileName );
						string read = r.ReadLine();
						int amountOfSpawners, amountOfEntries, locX, locY, locZ;
						string map;
						Map spawnerMap = null;

						if ( read != "Mega Spawners" )
						{
							mobile.SendMessage( "That file is not a Mega Spawner File (*.msf). Please type in another filename." );

							mobile.SendGump( new ImportSpawnersGump( mobile ) );

							break;
						}

						amountOfSpawners = Convert.ToInt32( r.ReadLine() );

						for( int i = 0; i < amountOfSpawners; i++ )
						{
							MegaSpawner megaSpawner = new MegaSpawner();

							megaSpawner.Imported = true;

							map = r.ReadLine().ToLower();

							if ( map == "felucca" )
								spawnerMap = Map.Felucca;

							if ( map == "trammel" )
								spawnerMap = Map.Trammel;

							if ( map == "ilshenar" )
								spawnerMap = Map.Ilshenar;

							if ( map == "malas" )
								spawnerMap = Map.Malas;

							locX = Convert.ToInt32( r.ReadLine() );
							locY = Convert.ToInt32( r.ReadLine() );
							locZ = Convert.ToInt32( r.ReadLine() );

							megaSpawner.MoveToWorld( new Point3D( locX, locY, locZ ), spawnerMap );

							amountOfEntries = Convert.ToInt32( r.ReadLine() );

							for( int cnt = 0; cnt < amountOfEntries; cnt++ )
							{
								megaSpawner.CreatureList.Add( r.ReadLine() );
								megaSpawner.SpawnRangeList.Add( Convert.ToInt32( r.ReadLine() ) );
								megaSpawner.WalkRangeList.Add( Convert.ToInt32( r.ReadLine() ) );
								megaSpawner.AmountList.Add( Convert.ToInt32( r.ReadLine() ) );
								megaSpawner.MinDelayList.Add( Convert.ToInt32( r.ReadLine() ) );
								megaSpawner.MaxDelayList.Add( Convert.ToInt32( r.ReadLine() ) );
								megaSpawner.SpawnCounterList.Add( 0 );
							}
						}

						r.Close();

						mobile.SendMessage( "All spawners have now been imported." );

						mobile.CloseGump( typeof ( ImportSpawnersGump ) );
						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}
					catch
					{
						mobile.SendMessage( "That filename is invalid. Please type in another filename." );

						mobile.SendGump( new ImportSpawnersGump( mobile ) );
					}

					break;
				}
			}
		}
	}

	public class ExportSpawnersGump : Gump
	{
		public ExportSpawnersGump( Mobile mobile ) : base( 0,0 )
		{
			AddPage(0); // Page 0

			AddBackground( 180, 180, 340, 120, 0 );
			AddImageTiled( 180, 180, 340, 120, 2624 );
			AddAlphaRegion( 200, 200, 300, 40 );
			AddAlphaRegion( 200, 260, 300, 20 );
			AddLabel( 240, 180, 60, "Export Spawners" );

			AddPage(1); // Page 1

			AddLabel( 200, 200, 10, "Type in a filename without an extension:" );
			AddImageTiled( 200, 220, 300, 18, 2604 );
			AddTextEntry( 200, 220, 300, 15, 1153, 0, "" );

			AddLabel( 440, 260, 10, "Cancel" );
			AddButton( 400, 260, 4017, 4019, 0, GumpButtonType.Reply, 0 );

			AddLabel( 240, 260, 10, "Ok" );
			AddButton( 200, 260, 4023, 4025, 1, GumpButtonType.Reply, 0 );

		}

		public override void OnResponse( Server.Network.NetState sender, RelayInfo info )
		{
			Mobile mobile = sender.Mobile;

			switch ( info.ButtonID )
			{
				case 0: // Close Gump
				{
					mobile.CloseGump( typeof ( ExportSpawnersGump ) );
					mobile.SendGump( new MegaSpawnerGump( mobile ) );

					mobile.SendMessage( "You have chosen not to export spawners." );

					break;
				}
				case 1: // Export Spawners
				{
					string fileName;

					TextRelay textInput = info.GetTextEntry( 0 );
					fileName = Convert.ToString( textInput.Text ) + ".msf";

					if ( fileName == ".msf" )
					{
						mobile.SendMessage( "That filename is invalid. Please type in another filename." );

						mobile.SendGump( new ExportSpawnersGump( mobile ) );

						break;
					}

					try
					{
						FileInfo f = new FileInfo( fileName );
						f.Delete();
						StreamWriter w = f.CreateText();

						MegaSpawnerGump.CheckSpawners();

						w.WriteLine( "Mega Spawners" );
						w.WriteLine( MegaSpawnerGump.SpawnerList.Count );

						for( int i = 0; i < MegaSpawnerGump.SpawnerList.Count; i++ )
						{
							MegaSpawner megaSpawner = (MegaSpawner) MegaSpawnerGump.SpawnerList[i];

							w.WriteLine( megaSpawner.Map );
							w.WriteLine( megaSpawner.X );
							w.WriteLine( megaSpawner.Y );
							w.WriteLine( megaSpawner.Z );
							w.WriteLine( megaSpawner.CreatureList.Count );

							for( int cnt = 0; cnt < megaSpawner.CreatureList.Count; cnt++ )
							{
								w.WriteLine( megaSpawner.CreatureList[cnt] );
								w.WriteLine( megaSpawner.SpawnRangeList[cnt] );
								w.WriteLine( megaSpawner.WalkRangeList[cnt] );
								w.WriteLine( megaSpawner.AmountList[cnt] );
								w.WriteLine( megaSpawner.MinDelayList[cnt] );
								w.WriteLine( megaSpawner.MaxDelayList[cnt] );
							}
						}

						w.Close();

						mobile.SendMessage( "All spawners have now been exported." );

						mobile.CloseGump( typeof ( ExportSpawnersGump ) );
						mobile.SendGump( new MegaSpawnerGump( mobile ) );

						break;
					}
					catch
					{
						mobile.SendMessage( "That filename is invalid. Please type in another filename." );

						mobile.SendGump( new ExportSpawnersGump( mobile ) );
					}

					break;
				}
			}
		}
	}
}