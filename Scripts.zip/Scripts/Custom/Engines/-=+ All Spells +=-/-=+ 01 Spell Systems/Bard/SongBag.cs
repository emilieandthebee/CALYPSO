using System;
using Server;

namespace Server.Items
{
	public class SongBag : Bag
	{
		[Constructable]
		public SongBag()
		{
			PlaceItemIn( 30, 35, new ArmysPaeonScroll() );
			PlaceItemIn( 50, 35, new EnchantingEtudeScroll() );
			PlaceItemIn( 70, 35, new EnergyCarolScroll() );
			PlaceItemIn( 90, 35, new EnergyThrenodyScroll() );
			PlaceItemIn( 30, 55, new FireCarolScroll() );
			PlaceItemIn( 50, 55, new FireThrenodyScroll() );
			PlaceItemIn( 70, 55, new FoeRequiemScroll() );
			PlaceItemIn( 90, 55, new IceCarolScroll() );
			PlaceItemIn( 30, 75, new IceThrenodyScroll() );
			PlaceItemIn( 50, 75, new KnightsMinneScroll() );
			PlaceItemIn( 70, 75, new MagesBalladScroll() );
			PlaceItemIn( 90, 75, new MagicFinaleScroll() );
			PlaceItemIn( 30, 95, new PoisonCarolScroll() );
			PlaceItemIn( 50, 95, new PoisonThrenodyScroll() );
			PlaceItemIn( 70, 95, new SheepfoeMamboScroll() );
			PlaceItemIn( 90, 95, new SinewyEtudeScroll() );
		}

		private void PlaceItemIn( int x, int y, Item item )
		{
			AddItem( item );
			item.Location = new Point3D( x, y, 0 );
		}

		public SongBag( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}