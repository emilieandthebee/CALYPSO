using System;
using Server.Spells;
using Server.Spells.Song;

namespace Server.Items
{
	public class SongBook : Spellbook
	{
		public override SpellbookType SpellbookType{ get{ return SpellbookType.Song; } }
		public override int BookOffset{ get{ return 651; } }
		public override int BookCount{ get{ return 16; } }

		public override Item Dupe( int amount )
		{
			Spellbook book = new SongBook();
			book.Content = this.Content;
			return base.Dupe( book, amount );
		}

		[Constructable]
		public SongBook() : this( (ulong)0 )
		{
		}

		[Constructable]
		public SongBook( ulong content ) : base( content, 0xEFA )
		{
			Name = "Song Book";
			Hue = 0x96;
		}

		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel == AccessLevel.Player )
			{
				Container pack = from.Backpack;
				if( !(Parent == from || (pack != null && Parent == pack)) )
				{
					from.SendMessage( "The spellbook must be in your backpack [and not in a container within] to open." );
					return;
				}
				else if( UseRestrictions && !SpellRestrictions.CheckRestrictions( from, this ) )
				{
					return;
				}
			}

			from.CloseGump( typeof( SongBookGump ) );
			from.SendGump( new SongBookGump( from, this ) );
		}

		public SongBook( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}



