using System;
using System.Collections;
using Server.Items;
using Server.Targeting;

namespace Server.Mobiles
{
	[CorpseName( "un corps de matiere globuleuse" )]
	public class APS_StrangeEssence : APS_Creature
	{
		[Constructable]
		public APS_StrangeEssence() : base()
		{
			Name = "une matiere globuleuse";
/*** CHANGE FOR UO TEMRAEL ***
			Body = 273; 
******************************/
			Body = 273;
			Hue = 38;
/*****************************/
			SetStr( 22, 34 );
			SetDex( 5, 21 );
			SetInt( 2, 5 );
			SetHits( 17, 19 );
			SetDamage( 1, 5 );
			SetDamageType( ResistanceType.Physical, 100 );
			SetResistance( ResistanceType.Physical, 5, 10 );
			SetResistance( ResistanceType.Poison, 10, 20 );
			SetSkill( SkillName.MagicResist, 15.1, 20.0 );
			SetSkill( SkillName.Tactics, 12.3, 20.0 );
			SetSkill( SkillName.Wrestling, 12.3, 20.0 );
			VirtualArmor = 8;
		}

		public override Poison PoisonImmune{ get{ return Poison.Lethal; } }

		public override int GetAngerSound()
		{
			return 0x56d;
		}

		public override int GetIdleSound()
		{
			return 0x56b;
		}

		public override int GetAttackSound()
		{
			return 0x56c;
		}

		public override int GetHurtSound()
		{
			return 0x56c;
		}

		public override int GetDeathSound()
		{
			return 0x56e;
		}

		public APS_StrangeEssence( Serial serial ) : base( serial )
		{}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}
