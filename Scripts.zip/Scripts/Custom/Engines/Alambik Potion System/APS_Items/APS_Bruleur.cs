/***************************
 * Alambik Potions Systems *
 ***************************/
using System;
using Server;
using Server.Mobiles;
using Server.Targeting;

namespace Server.Items
{
	[Flipable( 6217 , 6221 )]
	public class APS_Bruleur : Item
	{
		
/********************
Bruleur
6217 flip 6221 éteint
6218 flip 6222 Allumé
*********************/
	
		public int LitSound{ get { return 0x47; } }
		public int UnlitSound{ get { return 0x3be; } }

		public override void OnDoubleClick( Mobile from )
		{ if ( Utility.RandomDouble() < APS_Mortier.APS_ChanceToBreak )
			{
				from.SendMessage("Oups... ça s'est cassé...");
				Delete();
				return;
			}
		  from.SendMessage("Selectionnez quelquechose que vous voulez utiliser avec ce bruleur.");
		  from.Target = new InternalTarget( this ); }
		private class InternalTarget : Target
		{
			private APS_Bruleur m_thing;
			public InternalTarget( APS_Bruleur thing ) : base( -1, false, TargetFlags.None )
			{ m_thing = thing; }
			protected override void OnTarget( Mobile from, object targeted )
			{
				if ( m_thing.Deleted )
				{
					from.SendMessage( "L'objet en question a ete supprime..." );
					return;
				} else if ( !( targeted is Item ) ) {
					from.SendMessage( "Il faut que ce soit un objet..." );
					return;					
				}
				if ( m_thing == targeted )
				{
					m_thing.SelfClick( from );
				} else {
					m_thing.LikeDragDrop( from, (Item)targeted );
				}
			}
		}

		public void SelfClick( Mobile from )
		{			
			Point3D loc = GetWorldLocation();
			if ((ItemID == 6217) || (ItemID == 6217)) //Eteint
			{
				Effects.PlaySound( loc, Map, LitSound );
				ItemID = ItemID + 1;
			} else { // Allumé
				Effects.PlaySound( loc, Map, UnlitSound );
				ItemID = ItemID - 1;				
			}
		}

		public override  bool OnDragDrop( Mobile from, Item dropped )
		{
			LikeDragDrop( from, dropped );
			return false;
		}
		
		public bool LikeDragDrop( Mobile from, Item dropped )
		{
			if ((ItemID == 6217) || (ItemID == 6217)) //Eteint
			{
				from.SendMessage("Le bruleur est eteint. Vous devriez peut-etre l'allumer?...");
			} else {	
				if (dropped is APS_Melangeur)
				{
					if ( ((APS_Melangeur)dropped).Bruleur )
						from.SendMessage("Le melange semble avoir deja ete chauffe...");	
					else 
					{
						Effects.PlaySound(from.Location, from.Map, 0x20 );
						((APS_Melangeur)dropped).Bruleur = true;
						if (((APS_Melangeur)dropped).ItemID == 6209) // That's something!
						{
							double skillValue = from.Skills[SkillName.Alchemy].Value;
							double chance = skillValue;
							if ( chance > Utility.RandomDouble() * 150.0 )
							{	
								from.SendMessage("Le resultat semble etre bien plus interessant...");	
								((APS_Melangeur)dropped).Enhanced = true;
							} else {
								from.SendMessage("Ca a l'air d'avoir rate...");	
								((APS_Melangeur)dropped).Enhanced = false;
								((APS_Melangeur)dropped).ItemID = 6203; // Jaune
							}
						} else {
							from.SendMessage("Bah, ca chauffe, et apres...");	
							((APS_Melangeur)dropped).Enhanced = false;
						}
					}
				} else {
					from.SendMessage("Vous devriez essayer de faire chauffer un melangeur...");	
				}
				if ( Utility.RandomDouble() < 0.20 )
				{
					from.SendMessage("Le bruleur s'est éteint à la fin de l'opération.");	
					OnDoubleClick(from); // Unlit it
				}
			}
			return true;
		}
		
		[Constructable]
		public APS_Bruleur() : base( 6217 )
		{
			InitializeItemVaraiables();
		}

		public void InitializeItemVaraiables()
		{
			Name = "Un bruleur";
			Weight = 1.0;
			Light=LightType.Circle150;
		}
		
		public APS_Bruleur( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
	}
}