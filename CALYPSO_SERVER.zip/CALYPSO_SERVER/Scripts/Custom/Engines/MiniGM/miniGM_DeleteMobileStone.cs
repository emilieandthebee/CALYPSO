using System;
using Server;
using Server.Gumps;
using Server.Network;
using Server.Mobiles;
using Server.Items;
using Server.Targeting;
using System.Collections;
using Server.Scripts.Commands;
using Server.Prompts;
using Server.Guilds;

namespace Server.Items
{
	public class miniGM_DeleteMobileStone : Item
	{
		[Constructable]
		public miniGM_DeleteMobileStone( miniGM mstone) : base( 573 )
		{
			Visible=false;
			Name = "Pierre de suppression de NPC MiniGM";
			ShardControler.All_miniGM_DeleteMobileStone.Add(this);
		}
		public miniGM_DeleteMobileStone( Serial serial ) : base( serial )
		{}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 1 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			
			switch (version)
			{
				case 2:
					goto case 1;
				case 1:
					break;
				default:
					break;
			}
			
			ShardControler.All_miniGM_DeleteMobileStone.Add(this);
		}
	}
}
