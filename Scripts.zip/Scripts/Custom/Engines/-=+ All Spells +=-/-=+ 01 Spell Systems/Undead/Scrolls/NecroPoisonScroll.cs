using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class NecroPoisonScroll : SpellScroll
	{
		[Constructable]
		public NecroPoisonScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public NecroPoisonScroll( int amount ) : base( 126, 0x226F, amount )
		{
			Name = "Poison";
			Hue = 0x44;
		}
		
		public NecroPoisonScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new NecroPoisonScroll( amount ), amount );
		}
	}
}
