using System;
using Server;
using Server.Items;

namespace Server.Items
{
	public class CauseFearScroll : SpellScroll
	{
		[Constructable]
		public CauseFearScroll() : this( 1 )
		{
		}
		
		[Constructable]
		public CauseFearScroll( int amount ) : base( 365, 0x1F56, amount )
		{
			Name = "Cause Fear";
		}
		
		public CauseFearScroll( Serial serial ) : base( serial )
		{
		}
		
		public override void OnDoubleClick( Mobile from )
		{
			if ( from.AccessLevel <= AccessLevel.Counselor )
			{
				//--<Optional Restrictions>----------<Start>
				from.SendMessage( "Low level staff and players are not allowed to have this scroll." );
				Delete();
			}
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 0 ); // version
		}
		
		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
		}
		
		public override Item Dupe( int amount )
		{
			return base.Dupe( new CauseFearScroll( amount ), amount );
		}
	}
}
