using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;
using Server.Targeting;
using Server.Accounting;

namespace Server.Gumps
{
	public class SendToGump : Gump
	{
		private AddressBook i_from;
				
		public SendToGump( Mobile from ) : base( 25, 25)
		{
			from.CloseGump( typeof( AddressBookGump ) );
			from.CloseGump( typeof( SendToGump ) );
			
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;

			if ( from.Backpack.FindItemByType( typeof( AddressBook ) ) == null )
			{
				from.SendMessage("You need an address book to use this.");
				return;
			}
			else
				i_from = from.Backpack.FindItemByType( typeof( AddressBook ) ) as AddressBook;

			AddPage(0);
			AddBackground(0, 0, 0, 0, 0);
			AddImage(39, 90, 2201, 0);
			AddLabel(93, 109, 0, "Address Book");
			AddLabel(67, 150, 0, "Here you can store");
			AddLabel(67, 165, 0, "The names of your");
			AddLabel(67, 180, 0, "Friends so that there");
			AddLabel(67, 195, 0, "Is no mix-up on people");
			AddLabel(67, 210, 0, "With the same name");
			AddLabel(67, 225, 0, "as Your Friends...");
			AddButton(230, 110, 2117, 2118, 1, GumpButtonType.Reply, 0);
			AddButton(230, 130, 2117, 2118, 2, GumpButtonType.Reply, 0);
			AddButton(230, 150, 2117, 2118, 3, GumpButtonType.Reply, 0);
			AddButton(230, 170, 2117, 2118, 4, GumpButtonType.Reply, 0);
			AddButton(230, 190, 2117, 2118, 5, GumpButtonType.Reply, 0);
			AddButton(230, 210, 2117, 2118, 6, GumpButtonType.Reply, 0);
			AddButton(230, 230, 2117, 2118, 7, GumpButtonType.Reply, 0);
			AddButton(230, 250, 2117, 2118, 8, GumpButtonType.Reply, 0);
			AddLabel( 250, 110, 0, i_from.Friend1);
			AddLabel( 250, 130, 0, i_from.Friend2);
			AddLabel( 250, 150, 0, i_from.Friend3);
			AddLabel( 250, 170, 0, i_from.Friend4);
			AddLabel( 250, 190, 0, i_from.Friend5);
			AddLabel( 250, 210, 0, i_from.Friend6);
			AddLabel( 250, 230, 0, i_from.Friend7);
			AddLabel( 250, 250, 0, i_from.Friend8);
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			Mobile m = state.Mobile;
			string toName, toAcct;
			
			if ( info.ButtonID >= 1 )
			{
				switch ( info.ButtonID )
				{
					case 1:
						{
							toName = i_from.Friend1;
							toAcct = i_from.Acct1;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 2:
						{
							toName = i_from.Friend2;
							toAcct = i_from.Acct2;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 3:
						{
							toName = i_from.Friend3;
							toAcct = i_from.Acct3;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 4:
						{
							toName = i_from.Friend4;
							toAcct = i_from.Acct4;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 5:
						{
							toName = i_from.Friend5;
							toAcct = i_from.Acct5;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 6:
						{
							toName = i_from.Friend6;
							toAcct = i_from.Acct6;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 7:
						{
							toName = i_from.Friend7;
							toAcct = i_from.Acct7;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					case 8:
						{
							toName = i_from.Friend8;
							toAcct = i_from.Acct8;
							m.SendGump( new PostOfficeGump( m, toName, toAcct ) );
							break;
						}
					default:
						{
							m.SendMessage("Please try again.");
							m.SendGump( new PostOfficeGump( m, "", "" ) );
							break;
						}
				}
			}
			else
			{
				m.SendMessage("You must choose a person to send to.");
				m.SendGump( new PostOfficeGump( m, "", "" ) );
			}
		}
	}
}
