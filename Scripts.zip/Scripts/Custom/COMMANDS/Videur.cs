using System;
using System.Collections;
using Server;
using Server.Targeting;
using Server.Items;
using Server.Multis;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class Videur
	{
		public static void Initialize()
		{
			Server.Commands.Register( "Videur", AccessLevel.GameMaster, new CommandEventHandler( Videur_OnCommand ) );
		}

		[Usage( "Videur" )]
		[Description( "Liste et ramene les joueurs non-inscrits." )]
		private static void Videur_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)e.Mobile;
				pm.SendMessage("PERSONNAGES:");
				foreach ( Mobile mob in World.Mobiles.Values )
				{
					if (!mob.Deleted)
					if (mob is PlayerMobile)
					{
						PlayerMobile pmob=(PlayerMobile)mob;
						if (pmob.Young)
						if (pmob.Backpack != null)
						if (!pmob.Backpack.Deleted)
						{
							Item note=pmob.Backpack.FindItemByType(typeof(FicheInscription));
							if (note is FicheInscription)
							{
								FicheInscription fiche=(FicheInscription)note;
								pmob.Map=Map.Trammel;
								pmob.Hidden=true;
								pm.SendMessage("{0} {1} [{2}] {3}",pmob.Serial,pmob.Name,fiche.STATUS,pmob.CreationTime);
							}
						}
					}
				}
			}
		}
	}
}