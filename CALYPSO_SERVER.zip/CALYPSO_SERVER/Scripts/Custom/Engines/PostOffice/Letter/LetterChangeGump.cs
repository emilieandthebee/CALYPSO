using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;

namespace Server.Gumps
{	
	public class ChangeLetterGump : Gump
	{
		public ChangeLetterGump( Mobile m, string i_to, string i_message, string i_from ) : base( 25, 25)
		{
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;
			AddPage(0);
			AddBackground(29, 49, 384, 350, 3000);
			AddImage(40, 64, 95);
			AddImage(47, 73, 96);
			AddImage(214, 73, 96);
			AddImage(392, 64, 97);
			AddLabel(84, 110, 0, "To ");
			AddTextEntry(104, 110, 99, 20, 0, 0, i_to);
			AddTextEntry(58, 138, 190, 137, 0, 1, i_message);
			AddLabel(75, 290, 0, "Best Wishes,");
			AddLabel(78, 312, 0, i_from);
			AddImage(340, 111, 1261);
			AddLabel(281, 138, 0, "Raisor's");
			AddImage(32, 101, 52);
			AddImage(40, 364, 95);
			AddImage(47, 373, 96);
			AddImage(214, 373, 96);
			AddImage(392, 364, 97);
			AddLabel(135, 356, 0, "Single-Click Button to close this Window");
			AddImage(269, 163, 9000);
			AddButton(115, 356, 5601, 5605, 1, GumpButtonType.Reply, 0);
			AddLabel(264, 266, 0, "Post System");
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			if( info.ButtonID == 1 )
			{
				Mobile m_from = state.Mobile;
		
				TextRelay relayTo = info.GetTextEntry( 0 );
				string to = ( relayTo == null ? null : relayTo.Text.Trim() );
				
				TextRelay relayMessage = info.GetTextEntry( 1 );
				string message = ( relayMessage == null ? null : relayMessage.Text.Trim() );
	
				TextRelay relayFrom = info.GetTextEntry( 3 );
				string from = ( relayFrom == null ? null : relayFrom.Text.Trim() );
				
				if ( to == "" )
				{
					m_from.SendMessage("You did not specify a recipient.");
					m_from.SendGump( new ChangeLetterGump( m_from, to, message, from ) );
					return;
				}
			
				if ( message == "" )
				{
					m_from.SendMessage("You did not write a message.");
					m_from.SendGump( new ChangeLetterGump( m_from, to, message, from ) );
					return;
				}
			
				Letter newLetter = new Letter();
				newLetter.i_to = to;
				newLetter.i_from = m_from.Name;
				newLetter.i_message = message;
				newLetter.Name = "a letter from " + m_from.Name;
				m_from.AddToBackpack( newLetter);
			}
			else
			{
				Mobile m_from = state.Mobile;
				
				TextRelay relayTo = info.GetTextEntry( 0 );
				string to = ( relayTo == null ? null : relayTo.Text.Trim() );
				
				TextRelay relayMessage = info.GetTextEntry( 1 );
				string message = ( relayMessage == null ? null : relayMessage.Text.Trim() );
	
				TextRelay relayFrom = info.GetTextEntry( 3 );
				string from = ( relayFrom == null ? null : relayFrom.Text.Trim() );
				
				Letter newLetter = new Letter();
				newLetter.i_to = to;
				newLetter.i_from = m_from.Name;
				newLetter.i_message = message;
				newLetter.Name = "a letter from " + m_from.Name;
				m_from.AddToBackpack( newLetter);
			}
		}
	}
}
