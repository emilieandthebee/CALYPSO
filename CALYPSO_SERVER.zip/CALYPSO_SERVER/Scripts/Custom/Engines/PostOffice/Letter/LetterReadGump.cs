using System;
using System.Reflection;
using System.Collections;
using Server;
using Server.Items;
using Server.Network;
using Server.Mobiles;

namespace Server.Gumps
{
	public class LetterReadGump : Gump
	{
		public LetterReadGump( Mobile m, string i_from, string i_message, string i_to ) : base( 25, 25)
		{
			Closable=true;
			Disposable=true;
			Dragable=true;
			Resizable=false;
			AddPage(0);
			AddBackground(29, 49, 384, 350, 3000);
			AddHtml( 58, 138, 200, 147, i_message, (bool)true, (bool)true);
			AddImage(40, 64, 95);
			AddImage(47, 73, 96);
			AddImage(214, 73, 96);
			AddImage(392, 64, 97);
			AddLabel(84, 110, 0, "To ");
			AddLabel(104, 110, 0, i_to);
			AddLabel(75, 290, 0, "Best Wishes,");
			AddLabel(78, 312, 0, i_from);
			AddImage(340, 111, 1261);
			AddLabel(281, 138, 0, "Raisor's");
			AddImage(32, 101, 52);
			AddImage(40, 364, 95);
			AddImage(47, 373, 96);
			AddImage(214, 373, 96);
			AddImage(392, 364, 97);
			AddLabel(135, 356, 0, "Single-Click Button to close this Window");
			AddImage(269, 163, 9000);
			AddButton(115, 356, 5601, 5605, 0, GumpButtonType.Reply, 0);
			AddLabel(264, 266, 0, "Post System");
		}
		
		public override void OnResponse( NetState state, RelayInfo info )
		{
			return;
		}
	}
}
