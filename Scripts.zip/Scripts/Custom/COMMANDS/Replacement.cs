/* --------------------------->
 * Replacing script by Kaon 
 * Version 1.1
 * Creation : 06.03.2007
 * Revision : 07.03.2007
 * --------------------------->
 */
// D�commentez la ligne suivante si vous utilisez RunUO1.0
// Uncomment this line if you're using RunUO 1.0
#define USE_RUNUO_1

using System;
using System.Reflection;
using Server.Items;
using System.Collections;
using Server.Scripts.Commands;
#if !USE_RUNUO_1
using Server.Commands;
using System.Collections.Generic;
#endif

namespace Server.Engines.Remplacement
{
    /// <summary>
    /// Attribut pour assigner les types � remplacer par la classe
    /// Attribute to design types to replace by the class
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class ReplaceEntities : Attribute
    {
        private Type[] tToReplace;

        public Type[] ToReplace { get { return tToReplace; } }

        public ReplaceEntities(params Type[] t)
        {
            tToReplace = t;
        }
    }

#if USE_RUNUO_1
    public class Replacement
#else
    public static class Replacement
#endif
    {
        private const string stCommandName = "replace";
        private const string stCommandKeyword = "by";
        private const bool bStrictNamespace = true;

        [CallPriority(10)]
        public static void Initialize()
        {
            // On enregistre la commande manuelle
            // Registering the command
#if USE_RUNUO_1
            Commands.Register(stCommandName, AccessLevel.Administrator, new CommandEventHandler(Replacement_OnCommand));
#else
            CommandSystem.Register(stCommandName, AccessLevel.Administrator, new CommandEventHandler(Replacement_OnCommand));
#endif
       
            // R�cup�ration de toutes les classes
            // We get all the classes
#if USE_RUNUO_1
            ArrayList alAssemblies = new ArrayList();
#else
            List<Assembly> alAssemblies = new List<Assembly>();
#endif
            Assembly assembly = null;
            try
            {
                assembly = Assembly.LoadFrom("Scripts/Output/Scripts.CS.dll");
                if (assembly != null) alAssemblies.Add(assembly);

                assembly = Assembly.LoadFrom("Scripts/Output/Scripts.VB.dll");
                if (assembly != null) alAssemblies.Add(assembly);
            }
            catch { }
            
            
            for (int a = 0; a < alAssemblies.Count; ++a)
            {
#if USE_RUNUO_1
                Type[] types = ((Assembly)alAssemblies[a]).GetTypes();
#else
                Type[] types = alAssemblies[a].GetTypes();
#endif

                // Parcours des classes
                // Getting through classes
                for (int i = 0; i < types.Length; ++i)
                {
                    object[] atts = types[i].GetCustomAttributes(typeof(ReplaceEntities), false);

                    // S'il s'agit d'un objet rempla�ant un autre
                    // If it is a replacing Item...
                    if ( atts.Length > 0)
                    {
                        // R�cup�ration du type d'objet � remplacer
                        // We get the type of the items to replace
                        ReplaceEntities att = atts[0] as ReplaceEntities;
                        if (att.ToReplace != null && att.ToReplace.Length > 0)
                            ReplaceInstances(att.ToReplace, types[i]);
                    }
                }
            }
        }

        /// <summary>
        /// Remplace les instances de type multiples par des instances d'un type unique
        /// Replace instances of multiples types by instances of an other type
        /// </summary>
        /// <param name="_olds">Array of Type to replace | Tableau de Type � remplacer</param>
        /// <param name="_new">Type to instanciate in replacement | Type � mettre � la place</param>
        private static void ReplaceInstances(Type[] _olds, Type _new)
        {
            if (_new.IsSubclassOf(typeof(Item)) || _new.Equals(typeof(Item)))
            {
                // Recherche de tous les objets de ce type
                // Searching all items to replace
#if USE_RUNUO_1
                IEnumerator its = World.Items.GetEnumerator();
                ArrayList alItems = new ArrayList();
                while (its.MoveNext()) alItems.Add(its.Current);
#else
                Dictionary<Serial, Item>.Enumerator its = World.Items.GetEnumerator();
                List<Item> alItems = new List<Item>();
                while (its.MoveNext()) alItems.Add(its.Current.Value);
                its.Dispose();
#endif

                for (int k = 0; k < alItems.Count; ++k)
                {
                    Item it = alItems[k] as Item;
                    for (int j = 0; j < _olds.Length; ++j)
                    {
                        if (it.GetType().Equals(_olds[j]))
                        {
                            // Une fois trouv�, on cr�� une instance du rempla�ant...
                            // If we get one, we create an instance of the replacing object...
                            MethodInfo m = _new.GetMethod("GetNewItemFrom", BindingFlags.Static | BindingFlags.Public);
                            Item replacent = null;

                            if (m != null) replacent = m.Invoke(null, new object[] { it }) as Item;
                            else replacent = Activator.CreateInstance(_new) as Item;

                            // Test de s�curit�
                            // Security check
                            if (replacent == null) continue;

                            // ... et on remplace l'ancien par le nouveau (dans un contenant, �quip� par un mobile ou dans le monde)
                            // ... and replace the old by the new (in a container, equiped on a mobile or in the world)
                            if (it.Parent is Container)
                                ((Container)it.Parent).AddItem(replacent);
                            else if (it.Parent is Mobile)
                            {
                                Mobile parent = it.Parent as Mobile;
                                parent.RemoveItem(it);
                                if (!parent.EquipItem(replacent))
                                    parent.AddToBackpack(replacent);
                            }
                            else replacent.MoveToWorld(it.GetWorldLocation(), it.Map);

                            // Suppression de l'ancien objet
                            // Deleting the old item
                            it.Delete();
                        }
                    }
                }
            }
            else if (_new.IsSubclassOf(typeof(Mobile)) || _new.Equals(typeof(Mobile)))
            {
                // Recherche de tous les mobiles de ce type
                // Searching all mobiles to replace
#if USE_RUNUO_1
                IEnumerator mobs = World.Mobiles.GetEnumerator();
                ArrayList alMobiles = new ArrayList();
                while (mobs.MoveNext()) alMobiles.Add(mobs.Current);
#else
                Dictionary<Serial, Mobile>.Enumerator mobs = World.Mobiles.GetEnumerator();
                List<Mobile> alMobiles = new List<Mobile>();
                while (mobs.MoveNext()) alMobiles.Add(mobs.Current.Value);
                mobs.Dispose();
#endif

                for (int k = 0; k < alMobiles.Count; ++k)
                {
                    Mobile mob = alMobiles[k] as Mobile;
                    for (int j = 0; j < _olds.Length; ++j)
                    {
                        if (mob.GetType().Equals(_olds[j]))
                        {
                            // Une fois trouv�, on cr�� une instance du rempla�ant...
                            // If we get one, we create an instance of the replacing mobile...
                            MethodInfo m = _new.GetMethod("GetNewMobileFrom", BindingFlags.Static | BindingFlags.Public);
                            Mobile replacent = null;
                            if (m != null) replacent = m.Invoke(null, new object[] { mob }) as Mobile;
                            else replacent = Activator.CreateInstance(_new) as Mobile;

                            // Test de s�curit�
                            // Security check
                            if (replacent == null) continue;

                            // ... et on remplace l'ancien par le nouveau
                            // ... and replace the old by the new 
                            replacent.MoveToWorld(mob.Location, mob.Map);

                            // Suppression de l'ancien mobile
                            // Deleting the old mobile
                            mob.Delete();
                        }
                    }
                }
            }
        }

        [Description("Allow to replace all instances of multiples Item or Mobile types by a other Mobile or Item type")]
        [Usage(stCommandName + " <type1> <type2> <type3> ... " + stCommandKeyword + " <type4>")]
        private static void Replacement_OnCommand(CommandEventArgs e)
        {
            Mobile from = e.Mobile;

            // Pas assez d'arguments
            // Not enough arguments
            if (e.Arguments.Length < 3)
            {
                from.SendMessage(stCommandName + " <type1> <type2> <type3> ... "+stCommandKeyword+" <type4>");
                return;
            }

#if USE_RUNUO_1
            ArrayList alToReplace = new ArrayList();
#else
            List<Type> alToReplace = new List<Type>();
#endif
            Type tReplacing = null;
            bool bByFound = false;
            for (int i = 0; i < e.Arguments.Length; ++i)
            {
                // On cherche le mot cl� by
                // Searching for BY keyword
                if (!bByFound && (bByFound = e.Arguments[i].ToLower().Trim().Equals(stCommandKeyword.ToLower().Trim())))
                    continue;

                // S'il on a pas encore trouv� le mot cl� s�parateur, c'est un type � remplacer
                // If we havn't found the separator keyword, it's a type to replace
                if (!bByFound)
                {
                    Type t = Type.GetType(e.Arguments[i], false);
                    if (!bStrictNamespace)
                    {
                        if (t == null) t = Type.GetType("Server." + e.Arguments[i], false);
                        if (t == null) t = Type.GetType("Server.Items." + e.Arguments[i], false);
                        if (t == null) t = Type.GetType("Server.Mobiles." + e.Arguments[i], false);
                    }
                    if (t == null) from.SendMessage(55, @"/!\ Warning : type " + e.Arguments[i] + " not found.");
                    else alToReplace.Add(t);
                }
                // Sinon c'est le type rempla�ant
                // Else it is the replacement Type
                else
                {
                    tReplacing = Type.GetType(e.Arguments[i], false);
                    if (!bStrictNamespace)
                    {
                        if (tReplacing == null) tReplacing = Type.GetType("Server." + e.Arguments[i], false);
                        if (tReplacing == null) tReplacing = Type.GetType("Server.Items." + e.Arguments[i], false);
                        if (tReplacing == null) tReplacing = Type.GetType("Server.Mobiles." + e.Arguments[i], false);
                    }
                    if (tReplacing == null) from.SendMessage(55, @"/!\ Warning : type " + e.Arguments[i] + " not found.");
                    break;
                }
            }
            if (alToReplace.Count > 0 && tReplacing != null)
            {
#if USE_RUNUO_1
                ReplaceInstances((Type[])alToReplace.ToArray(typeof(Type)), tReplacing);
#else
                ReplaceInstances(alToReplace.ToArray(), tReplacing);
#endif
            }
            else
            {
                from.SendMessage(42, @"Can't replace, wrong parameters.");
            }
        }

    }
}
