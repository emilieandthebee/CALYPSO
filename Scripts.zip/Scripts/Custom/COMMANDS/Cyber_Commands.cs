using System;
using System.Collections;
using Server;
using Server.Accounting;
using Server.Items;
using Server.Network;
using Server.Mobiles;

namespace Server.Scripts.Commands
{
	public class CyberCommands
	{
		public static void Initialize()
		{
			Server.Commands.Register(
				"cyberjambes",
				AccessLevel.Player,
				new CommandEventHandler( cyberjambes_OnCommand ) );
			Server.Commands.Register(
				"cyberyeux",
				AccessLevel.Player,
				new CommandEventHandler( cyberyeux_OnCommand ) );
			Server.Commands.Register(
				"cybervoix",
				AccessLevel.Player,
				new CommandEventHandler( cybervoix_OnCommand ) );
			Server.Commands.Register(
				"cyberoreilles",
				AccessLevel.Player,
				new CommandEventHandler( cyberoreilles_OnCommand ) );
		}

		[Usage( "cyberjambes" )]
		[Description( "Cybernetique: active les cyber jambes, si implantees." )]
		private static void cyberjambes_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)(e.Mobile);
				pm.StartSuperRun();
			}
		}

		[Usage( "cyberoreilles" )]
		[Description( "Cybernetique: active les cyber oreilles, si implantee." )]
		private static void cyberoreilles_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)(e.Mobile);
				if (pm.SuperEaring == false)
				{
					Item item=pm.FindItemOnLayer(Layer.Unused_xF);
					if (item != null)
					{
						if (item is TechnoCyberPowersData)
						{
							int ears =((TechnoCyberPowersData)item).Ears;
							if (ears>0)
							{
								pm.SuperEaring=true;
								pm.StopSuperEaring=DateTime.Now+TimeSpan.FromSeconds(10.0+2*(double)ears);
								Effects.PlaySound( pm.Location, pm.Map, 0x1F9); // ON	
								Server.Misc.HearAll.m_HearAll.Add( e.Mobile );
								return;
							}
						}
					}
				}
			}
			e.Mobile.SendMessage("Vous n'avez pas de cyber oreilles...");
		}

		[Usage( "cybervoix" )]
		[Description( "Cybernetique: active la cyber voix, si implantee." )]
		private static void cybervoix_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)(e.Mobile);
				if (!pm.Squelched)
				{
					Item item = pm.FindItemOnLayer(Layer.Unused_xF);
					if (( item!= null ) && (item is TechnoCyberPowersData))
						if (((TechnoCyberPowersData)item).Voice <= 0)
							return;
					Effects.PlaySound( pm.Location, pm.Map, 0x1F9); // ON	
					pm.Emote("*crie comme dans un porte-voix*");
					pm.Yell(e.ArgString);
					IPooledEnumerable eable = pm.Map.GetMobilesInRange( pm.Location, 20+((TechnoCyberPowersData)item).Voice*2 );
					ArrayList list = new ArrayList();
					foreach( Mobile mob in eable )
					{
						if (mob != pm)
						{
							mob.SendMessage("Vous entendez crier: \"{0}\"",e.ArgString);
							if (pm.X>mob.X)
							{
								if (pm.Y>mob.Y)
									mob.SendMessage("Cela semble venir du Sud ou de l'Est");
								else
									mob.SendMessage("Cela semble venir du Nord ou de l'Est");
							} else {
								if (pm.Y>mob.Y)
									mob.SendMessage("Cela semble venir du Sud ou de l'Ouest");
								else
									mob.SendMessage("Cela semble venir du Nord ou de l'Ouest");
							}
						}
					}
					eable.Free();
				}
			}
		}

		[Usage( "cyberyeux" )]
		[Description( "Cybernetique: active les cyber yeux, si implantees." )]
		private static void cyberyeux_OnCommand( CommandEventArgs e )
		{
			if (e.Mobile is PlayerMobile)
			{
				PlayerMobile pm = (PlayerMobile)(e.Mobile);
				Item item = pm.FindItemOnLayer(Layer.Unused_xF);
				if (( item!= null ) && (item is TechnoCyberPowersData))
					if (((TechnoCyberPowersData)item).Eyes <= 0)
						return;
				if ( !Multis.DesignContext.Check( e.Mobile ) )
					return; // They are customizing
				Server.Spells.Spell spell = Server.Spells.SpellRegistry.NewSpell(
								"CyberEyes",
								e.Mobile,
								null );
				if ( spell != null )
				{
					spell.Cast();
				}
				else
				{
					System.Console.WriteLine("Command of cyber eyes: no spell found.");
				}
			}
		}
	}
}